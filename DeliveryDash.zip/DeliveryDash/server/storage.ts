import { 
  users, type User, type InsertUser,
  vehicleTypes, type VehicleType, type InsertVehicleType,
  orders, type Order, type InsertOrder,
  orderStatusUpdates, type OrderStatusUpdate, type InsertOrderStatusUpdate,
  feeConfigurations, type FeeConfiguration, type InsertFeeConfiguration,
  partnerPayments, type PartnerPayment, type InsertPartnerPayment,
  systemSettings, type SystemSetting, type InsertSystemSetting,
  partnerDocuments, type PartnerDocument, type InsertPartnerDocument,
  payments, type Payment, type InsertPayment,
  paymentGateways, type PaymentGateway, type InsertPaymentGateway,
  commissionConfigurations, type CommissionConfiguration, type InsertCommissionConfiguration,
  mapApiConfigs, type MapApiConfig, type InsertMapApiConfig
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, gte, lte, lt, sql, not } from "drizzle-orm";

// Interface with CRUD methods
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  getUsersByType(userType: string): Promise<User[]>;
  getAvailableDeliveryPartners(vehicleTypeId?: number, maxDistance?: number, pickupLat?: number, pickupLng?: number): Promise<User[]>;
  createUser(user: InsertUser & { profilePicture?: string, driversLicense?: string }): Promise<User>;
  updateUserAvailability(userId: number, update: { isAvailable: boolean, currentLat: number | null, currentLng: number | null }): Promise<User>;
  updateUserProfile(userId: number, update: Partial<User>): Promise<User>;
  deleteUser(id: number): Promise<boolean>;
  
  // Vehicle type operations
  getVehicleTypes(): Promise<VehicleType[]>;
  getVehicleType(id: number): Promise<VehicleType | undefined>;
  createVehicleType(vehicleType: InsertVehicleType): Promise<VehicleType>;
  updateVehicleType(id: number, vehicleType: Partial<VehicleType>): Promise<VehicleType>;
  deleteVehicleType(id: number): Promise<boolean>;
  
  // Order operations
  getOrders(userId: number): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  getPendingOrders(): Promise<Order[]>;
  getAllOrders(): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(orderId: number, status: string): Promise<Order>;
  
  // Order status update operations
  getOrderStatusUpdates(orderId: number): Promise<OrderStatusUpdate[]>;
  createOrderStatusUpdate(update: InsertOrderStatusUpdate): Promise<OrderStatusUpdate>;
  
  // Partner payment operations
  getPartnerPayments(partnerId?: number): Promise<PartnerPayment[]>;
  getPartnerPayment(id: number): Promise<PartnerPayment | undefined>;
  createPartnerPayment(payment: InsertPartnerPayment): Promise<PartnerPayment>;
  updatePartnerPayment(id: number, update: Partial<PartnerPayment>): Promise<PartnerPayment>;
  processPartnerPayment(id: number, adminId: number): Promise<PartnerPayment>;
  
  // Fee configuration operations
  getFeeConfigurations(): Promise<FeeConfiguration[]>;
  getActiveFeeConfiguration(vehicleTypeId: number): Promise<FeeConfiguration | undefined>;
  createFeeConfiguration(config: InsertFeeConfiguration): Promise<FeeConfiguration>;
  
  // System settings operations
  getSystemSettings(key?: string): Promise<SystemSetting[]>;
  updateSystemSetting(key: string, value: string, adminId: number): Promise<SystemSetting>;
  
  // Customer payment transactions by time range
  getCustomerPayments(startDate?: Date, endDate?: Date): Promise<Order[]>;
  
  // Archive older payment records (for 3-month retention policy)
  archiveOldPaymentRecords(olderThanDate: Date): Promise<{ archived: number }>;
  
  // Payment management operations
  getPayments(userId?: number, orderId?: number, paymentMethod?: string): Promise<Payment[]>;
  getPayment(id: number): Promise<Payment | undefined>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: number, update: Partial<Payment>): Promise<Payment>;
  
  // Map API configuration operations
  getMapApiConfigurations(): Promise<MapApiConfig[]>;
  getMapApiConfiguration(id: number): Promise<MapApiConfig | undefined>;
  createMapApiConfiguration(config: InsertMapApiConfig): Promise<MapApiConfig>;
  updateMapApiConfiguration(id: number, update: Partial<MapApiConfig>): Promise<MapApiConfig>;
  deleteMapApiConfiguration(id: number): Promise<boolean>;
  getPaymentMethods(userId: number): Promise<Payment[]>;
  
  // Partner document operations
  getPartnerDocuments(partnerId?: number, documentType?: string, verificationStatus?: string): Promise<PartnerDocument[]>;
  getPartnerDocument(id: number): Promise<PartnerDocument | undefined>;
  createPartnerDocument(document: InsertPartnerDocument): Promise<PartnerDocument>;
  updatePartnerDocumentStatus(id: number, status: string, adminId: number, rejectionReason?: string): Promise<PartnerDocument>;
  
  // Payment gateway operations
  getPaymentGateways(isActive?: boolean): Promise<PaymentGateway[]>;
  getPaymentGateway(id: number): Promise<PaymentGateway | undefined>;
  createPaymentGateway(gateway: InsertPaymentGateway): Promise<PaymentGateway>;
  updatePaymentGateway(id: number, update: Partial<PaymentGateway>): Promise<PaymentGateway>;
  togglePaymentGatewayStatus(id: number, isActive: boolean): Promise<PaymentGateway>;
  setDefaultPaymentGateway(id: number): Promise<PaymentGateway>;
  
  // Commission configuration operations
  getCommissionConfigurations(isActive?: boolean): Promise<CommissionConfiguration[]>;
  getCommissionConfiguration(id: number): Promise<CommissionConfiguration | undefined>;
  createCommissionConfiguration(config: InsertCommissionConfiguration): Promise<CommissionConfiguration>;
  updateCommissionConfiguration(id: number, update: Partial<CommissionConfiguration>): Promise<CommissionConfiguration>;
  toggleCommissionConfigurationStatus(id: number, isActive: boolean): Promise<CommissionConfiguration>;
  setDefaultCommissionConfiguration(id: number): Promise<CommissionConfiguration>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private vehicleTypes: Map<number, VehicleType>;
  private orders: Map<number, Order>;
  private orderStatusUpdates: Map<number, OrderStatusUpdate>;
  private partnerPayments: Map<number, PartnerPayment>;
  private feeConfigurations: Map<number, FeeConfiguration>;
  private systemSettings: Map<string, SystemSetting>;
  private payments: Map<number, Payment>;
  private partnerDocuments: Map<number, PartnerDocument>;
  private paymentGateways: Map<number, PaymentGateway>;
  private commissionConfigurations: Map<number, CommissionConfiguration>;
  private mapApiConfigs: Map<number, MapApiConfig>;
  
  private userCurrentId: number;
  private vehicleTypeCurrentId: number;
  private orderCurrentId: number;
  private orderStatusUpdateCurrentId: number;
  private partnerPaymentCurrentId: number;
  private feeConfigurationCurrentId: number;
  private systemSettingCurrentId: number;
  private paymentCurrentId: number;
  private partnerDocumentCurrentId: number;
  private paymentGatewayCurrentId: number;
  private commissionConfigurationCurrentId: number;
  private mapApiConfigCurrentId: number;
    
  constructor() {
    this.users = new Map();
    this.vehicleTypes = new Map();
    this.orders = new Map();
    this.orderStatusUpdates = new Map();
    this.partnerPayments = new Map();
    this.feeConfigurations = new Map();
    this.systemSettings = new Map();
    this.payments = new Map();
    this.partnerDocuments = new Map();
    this.paymentGateways = new Map();
    this.commissionConfigurations = new Map();
    this.mapApiConfigs = new Map();
    
    this.userCurrentId = 1;
    this.vehicleTypeCurrentId = 1;
    this.orderCurrentId = 1;
    this.orderStatusUpdateCurrentId = 1;
    this.partnerPaymentCurrentId = 1;
    this.feeConfigurationCurrentId = 1;
    this.systemSettingCurrentId = 1;
    this.paymentCurrentId = 1;
    this.partnerDocumentCurrentId = 1;
    this.paymentGatewayCurrentId = 1;
    this.commissionConfigurationCurrentId = 1;
    this.mapApiConfigCurrentId = 1;
    
    // Pre-populate vehicle types
    this.initVehicleTypes();
    
    // Initialize default payment gateways
    this.initPaymentGateways();
  }
  
  private initPaymentGateways() {
    // Default payment gateways with Paypal and Google Pay as default options
    const gateways: InsertPaymentGateway[] = [
      {
        gatewayType: 'paypal',
        displayName: 'PayPal',
        isActive: true,
        isDefault: true,
        configuration: {},
        supportedCountries: ['US', 'UK', 'KE', 'CA', 'AU'],
        supportedCurrencies: ['USD', 'GBP', 'KES', 'EUR'],
        minimumAmount: 1,
        processingFee: 2.9,
        processingFeeType: 'percentage',
        createdBy: 1 // Admin user ID
      },
      {
        gatewayType: 'google_pay',
        displayName: 'Google Pay',
        isActive: true,
        isDefault: true,
        configuration: {},
        supportedCountries: ['US', 'UK', 'KE', 'CA', 'AU', 'IN'],
        supportedCurrencies: ['USD', 'GBP', 'KES', 'EUR', 'INR'],
        minimumAmount: 1,
        processingFee: 2.5,
        processingFeeType: 'percentage',
        createdBy: 1
      },
      {
        gatewayType: 'mpesa',
        displayName: 'M-Pesa',
        isActive: true,
        isDefault: false,
        configuration: {},
        supportedCountries: ['KE', 'TZ'],
        supportedCurrencies: ['KES', 'TZS'],
        minimumAmount: 10,
        processingFee: 1.5,
        processingFeeType: 'percentage',
        createdBy: 1
      },
      {
        gatewayType: 'airtel_money',
        displayName: 'Airtel Money',
        isActive: true,
        isDefault: false,
        configuration: {},
        supportedCountries: ['KE', 'UG', 'TZ', 'RW'],
        supportedCurrencies: ['KES', 'UGX', 'TZS', 'RWF'],
        minimumAmount: 10,
        processingFee: 1,
        processingFeeType: 'percentage',
        createdBy: 1
      }
    ];
    
    gateways.forEach(gateway => this.createPaymentGateway(gateway));
  }
  
  private initVehicleTypes() {
    const types: InsertVehicleType[] = [
      { name: "Bike", icon: "bicycle", maxWeight: 5, baseFare: 5.99 },
      { name: "Motorbike", icon: "motorcycle", maxWeight: 20, baseFare: 8.99 },
      { name: "Pickup", icon: "truck-pickup", maxWeight: 100, baseFare: 14.99 },
      { name: "Van", icon: "shuttle-van", maxWeight: 500, baseFare: 24.99 },
      { name: "Lorry", icon: "truck", maxWeight: 2000, baseFare: 44.99 },
      { name: "Motor Breakdown", icon: "wrench", maxWeight: 0, baseFare: 29.99 }
    ];
    
    types.forEach(type => this.createVehicleType(type));
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async createUser(insertUser: InsertUser & { profilePicture?: string, driversLicense?: string }): Promise<User> {
    const id = this.userCurrentId++;
    // Ensure userType is set and has a default
    const userType = insertUser.userType || "customer";
    // Create user with proper defaults
    const user: User = { 
      ...insertUser, 
      id, 
      userType,
      // Only include vehicleTypeId for delivery users
      vehicleTypeId: userType === "delivery" ? insertUser.vehicleTypeId || null : null,
      // Handle file uploads
      profilePicture: insertUser.profilePicture || null,
      driversLicense: insertUser.driversLicense || null,
      // Add location and availability defaults
      currentLat: null,
      currentLng: null,
      isAvailable: true
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserAvailability(userId: number, update: { isAvailable: boolean, currentLat: number | null, currentLng: number | null }): Promise<User> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const updatedUser = { 
      ...user, 
      isAvailable: update.isAvailable,
      currentLat: update.currentLat,
      currentLng: update.currentLng
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateUserProfile(userId: number, update: any): Promise<User> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    // Update the user with new data, preserving the original password
    const updatedUser = { 
      ...user,
      ...update,
      // Make sure we don't overwrite the password if not provided
      password: update.password || user.password
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => a.id - b.id);
  }
  
  async getUsersByType(userType: string): Promise<User[]> {
    return Array.from(this.users.values())
      .filter(user => user.userType === userType)
      .sort((a, b) => a.id - b.id);
  }
  
  async getAvailableDeliveryPartners(vehicleTypeId?: number, maxDistance?: number, pickupLat?: number, pickupLng?: number): Promise<User[]> {
    // Filter for delivery partners who are available
    let partners = Array.from(this.users.values())
      .filter(user => user.userType === 'delivery' && user.isAvailable === true);
    
    // If vehicleTypeId is provided, filter by it
    if (vehicleTypeId) {
      partners = partners.filter(user => user.vehicleTypeId === vehicleTypeId);
    }
    
    // If pickup coordinates and max distance are provided, filter by distance
    if (pickupLat !== undefined && pickupLng !== undefined && maxDistance !== undefined) {
      partners = partners.filter(partner => {
        // Skip partners without location data
        if (partner.currentLat === null || partner.currentLng === null) return false;
        
        // Calculate distance using Haversine formula (in kilometers)
        const distance = this.calculateDistance(
          pickupLat, 
          pickupLng, 
          partner.currentLat, 
          partner.currentLng
        );
        
        return distance <= maxDistance;
      });
      
      // Sort by distance from pickup (closest first)
      partners.sort((a, b) => {
        const distanceA = this.calculateDistance(
          pickupLat,
          pickupLng,
          a.currentLat!,
          a.currentLng!
        );
        
        const distanceB = this.calculateDistance(
          pickupLat,
          pickupLng,
          b.currentLat!,
          b.currentLng!
        );
        
        return distanceA - distanceB;
      });
    }
    
    return partners;
  }
  
  // Helper function to calculate distance between coordinates using Haversine formula
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Radius of the Earth in km
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }
  
  private deg2rad(deg: number): number {
    return deg * (Math.PI/180);
  }
  
  async deleteUser(id: number): Promise<boolean> {
    // Check if user exists
    const user = this.users.get(id);
    if (!user) {
      return false;
    }
    
    // Check if user is referenced in any orders (as customer)
    const userOrders = Array.from(this.orders.values())
      .filter(order => order.userId === id);
    
    if (userOrders.length > 0) {
      // User has orders, can't delete
      return false;
    }
    
    // Check if user is referenced in any orders (as delivery partner)
    const partnerOrders = Array.from(this.orders.values())
      .filter(order => order.partnerId === id);
    
    if (partnerOrders.length > 0) {
      // User is assigned to orders as delivery partner, can't delete
      return false;
    }
    
    // Check if user has any documents
    const userDocuments = Array.from(this.partnerDocuments.values())
      .filter(doc => doc.userId === id);
      
    if (userDocuments.length > 0) {
      // User has documents, can't delete
      return false;
    }
    
    // Safe to delete
    return this.users.delete(id);
  }
  
  // Vehicle type operations
  async getVehicleTypes(): Promise<VehicleType[]> {
    return Array.from(this.vehicleTypes.values());
  }
  
  async getVehicleType(id: number): Promise<VehicleType | undefined> {
    return this.vehicleTypes.get(id);
  }
  
  async createVehicleType(insertVehicleType: InsertVehicleType): Promise<VehicleType> {
    const id = this.vehicleTypeCurrentId++;
    const vehicleType: VehicleType = { ...insertVehicleType, id };
    this.vehicleTypes.set(id, vehicleType);
    return vehicleType;
  }
  
  async updateVehicleType(id: number, update: Partial<VehicleType>): Promise<VehicleType> {
    const vehicleType = this.vehicleTypes.get(id);
    if (!vehicleType) {
      throw new Error(`Vehicle type with ID ${id} not found`);
    }
    
    const updatedVehicleType = { ...vehicleType, ...update };
    this.vehicleTypes.set(id, updatedVehicleType);
    return updatedVehicleType;
  }
  
  async deleteVehicleType(id: number): Promise<boolean> {
    // Check if this vehicle type is used by any users
    const userWithType = Array.from(this.users.values()).find(
      user => user.vehicleTypeId === id
    );
    
    if (userWithType) {
      // Vehicle type is in use by at least one user
      return false;
    }
    
    // Check if it's used in any orders
    const orderWithType = Array.from(this.orders.values()).find(
      order => order.vehicleTypeId === id
    );
    
    if (orderWithType) {
      // Vehicle type is in use by at least one order
      return false;
    }
    
    // Safe to delete
    return this.vehicleTypes.delete(id);
  }
  
  // Order operations
  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }
  
  async getPendingOrders(): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.status === 'pending')
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderCurrentId++;
    const now = new Date();
    // Use "pending" as the initial status
    const initialStatus = "pending";
    
    // Process optional fields with proper null handling
    const { 
      packageDescription = null, 
      packageWeight = null, 
      packageDimensions = null, 
      specialInstructions = null,
      paymentMethod = null,
      paymentStatus = 'pending',
      paymentId = null,
      ...requiredFields 
    } = insertOrder;
    
    // Create the order with proper typing
    const order = { 
      ...requiredFields,
      packageDescription,
      packageWeight,
      packageDimensions,
      specialInstructions,
      paymentMethod,
      paymentStatus,
      paymentId, 
      id, 
      createdAt: now, 
      status: initialStatus 
    } as Order;
    
    this.orders.set(id, order);
    
    // Create initial status update
    await this.createOrderStatusUpdate({
      orderId: id,
      status: initialStatus
    });
    
    return order;
  }
  
  async updateOrderStatus(orderId: number, status: string): Promise<Order> {
    const order = this.orders.get(orderId);
    if (!order) {
      throw new Error(`Order with ID ${orderId} not found`);
    }
    
    const updatedOrder = { ...order, status };
    this.orders.set(orderId, updatedOrder);
    
    // Create status update record
    await this.createOrderStatusUpdate({
      orderId,
      status
    });
    
    return updatedOrder;
  }
  
  // Order status update operations
  async getOrderStatusUpdates(orderId: number): Promise<OrderStatusUpdate[]> {
    return Array.from(this.orderStatusUpdates.values())
      .filter(update => update.orderId === orderId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }
  
  async createOrderStatusUpdate(insertUpdate: InsertOrderStatusUpdate): Promise<OrderStatusUpdate> {
    const id = this.orderStatusUpdateCurrentId++;
    const now = new Date();
    const update: OrderStatusUpdate = { ...insertUpdate, id, timestamp: now };
    this.orderStatusUpdates.set(id, update);
    return update;
  }
  
  // Partner payment operations
  async getPartnerPayments(partnerId?: number): Promise<PartnerPayment[]> {
    let payments = Array.from(this.partnerPayments.values());
    
    if (partnerId) {
      payments = payments.filter(payment => payment.partnerId === partnerId);
    }
    
    return payments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getPartnerPayment(id: number): Promise<PartnerPayment | undefined> {
    return this.partnerPayments.get(id);
  }
  
  async createPartnerPayment(payment: InsertPartnerPayment): Promise<PartnerPayment> {
    const id = this.partnerPaymentCurrentId++;
    const now = new Date();
    
    const newPayment: PartnerPayment = {
      ...payment,
      id,
      status: payment.status || "pending",
      createdAt: now,
      paymentDate: null,
      processedBy: payment.processedBy || null
    };
    
    this.partnerPayments.set(id, newPayment);
    return newPayment;
  }
  
  async updatePartnerPayment(id: number, update: Partial<PartnerPayment>): Promise<PartnerPayment> {
    const payment = this.partnerPayments.get(id);
    if (!payment) {
      throw new Error(`Partner payment with ID ${id} not found`);
    }
    
    const updatedPayment = { ...payment, ...update };
    this.partnerPayments.set(id, updatedPayment);
    return updatedPayment;
  }
  
  async processPartnerPayment(id: number, adminId: number): Promise<PartnerPayment> {
    const payment = this.partnerPayments.get(id);
    if (!payment) {
      throw new Error(`Partner payment with ID ${id} not found`);
    }
    
    const now = new Date();
    
    const updatedPayment = {
      ...payment,
      status: "paid",
      paymentDate: now,
      processedBy: adminId
    };
    
    this.partnerPayments.set(id, updatedPayment);
    return updatedPayment;
  }
  
  // Fee configuration operations
  async getFeeConfigurations(): Promise<FeeConfiguration[]> {
    return Array.from(this.feeConfigurations.values())
      .sort((a, b) => new Date(b.effectiveDate).getTime() - new Date(a.effectiveDate).getTime());
  }
  
  async getActiveFeeConfiguration(vehicleTypeId: number): Promise<FeeConfiguration | undefined> {
    return Array.from(this.feeConfigurations.values())
      .filter(config => config.vehicleTypeId === vehicleTypeId && config.isActive)
      .sort((a, b) => new Date(b.effectiveDate).getTime() - new Date(a.effectiveDate).getTime())[0];
  }
  
  async createFeeConfiguration(config: InsertFeeConfiguration): Promise<FeeConfiguration> {
    const id = this.feeConfigurationCurrentId++;
    const now = new Date();
    
    // Set defaults for optional fields
    const newConfig: FeeConfiguration = {
      ...config,
      id,
      minDistance: config.minDistance ?? 0,
      effectiveDate: config.effectiveDate ?? now,
      isActive: config.isActive ?? true,
      updatedAt: now
    };
    
    this.feeConfigurations.set(id, newConfig);
    return newConfig;
  }
  
  // System settings operations
  async getSystemSettings(key?: string): Promise<SystemSetting[]> {
    let settings = Array.from(this.systemSettings.values());
    
    if (key) {
      settings = settings.filter(setting => setting.settingKey === key);
    }
    
    return settings;
  }
  
  async updateSystemSetting(key: string, value: string, adminId: number): Promise<SystemSetting> {
    const now = new Date();
    let setting = this.systemSettings.get(key);
    
    if (setting) {
      // Update existing
      setting = {
        ...setting,
        settingValue: value,
        updatedBy: adminId,
        updatedAt: now
      };
    } else {
      // Create new
      setting = {
        id: this.systemSettingCurrentId++,
        settingKey: key,
        settingValue: value,
        dataType: 'string',
        description: null,
        updatedBy: adminId,
        updatedAt: now
      };
    }
    
    this.systemSettings.set(key, setting);
    return setting;
  }
  
  // Customer payment transactions
  async getCustomerPayments(startDate?: Date, endDate?: Date): Promise<Order[]> {
    let orders = Array.from(this.orders.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    if (startDate) {
      orders = orders.filter(order => new Date(order.createdAt) >= startDate);
    }
    
    if (endDate) {
      orders = orders.filter(order => new Date(order.createdAt) <= endDate);
    }
    
    return orders;
  }
  
  // Archive older payment records
  async archiveOldPaymentRecords(olderThanDate: Date): Promise<{ archived: number }> {
    // In memory version just counts them, doesn't actually remove them
    const oldOrders = Array.from(this.orders.values())
      .filter(order => new Date(order.createdAt) < olderThanDate);
    
    return { archived: oldOrders.length };
  }
  
  // Payment management operations
  async getPayments(userId?: number, orderId?: number, paymentMethod?: string): Promise<Payment[]> {
    let paymentList = Array.from(this.payments.values());
    
    if (userId !== undefined) {
      paymentList = paymentList.filter(payment => payment.userId === userId);
    }
    
    if (orderId !== undefined) {
      paymentList = paymentList.filter(payment => payment.orderId === orderId);
    }
    
    if (paymentMethod) {
      paymentList = paymentList.filter(payment => payment.paymentMethod === paymentMethod);
    }
    
    return paymentList.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
  
  async getPayment(id: number): Promise<Payment | undefined> {
    return this.payments.get(id);
  }
  
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = this.paymentCurrentId++;
    const now = new Date();
    
    // Ensure all required fields are set with defaults
    const paymentData = {
      ...insertPayment,
      paymentStatus: insertPayment.paymentStatus || 'pending',
      paymentProvider: insertPayment.paymentProvider || null,
      currency: insertPayment.currency || 'USD',
      transactionId: insertPayment.transactionId || null,
      phoneNumber: insertPayment.phoneNumber || null,
      receiptUrl: insertPayment.receiptUrl || null,
      metadata: insertPayment.metadata || null,
      errorMessage: insertPayment.errorMessage || null
    };
    
    const payment = {
      ...paymentData,
      id,
      createdAt: now,
      updatedAt: now
    } as Payment;
    
    this.payments.set(id, payment);
    
    // Update the related order with payment information if needed
    if (payment.orderId) {
      const order = this.orders.get(payment.orderId);
      if (order) {
        const updatedOrder = {
          ...order,
          paymentStatus: payment.paymentStatus,
          paymentMethod: payment.paymentMethod,
          paymentId: payment.transactionId
        };
        this.orders.set(payment.orderId, updatedOrder);
      }
    }
    
    return payment;
  }
  
  async updatePayment(id: number, update: Partial<Payment>): Promise<Payment> {
    const payment = this.payments.get(id);
    if (!payment) {
      throw new Error(`Payment with ID ${id} not found`);
    }
    
    const now = new Date();
    const updatedPayment = {
      ...payment,
      ...update,
      updatedAt: now
    };
    
    this.payments.set(id, updatedPayment);
    
    // Update the related order with payment status if needed
    if (updatedPayment.orderId && updatedPayment.paymentStatus) {
      const order = this.orders.get(updatedPayment.orderId);
      if (order) {
        const updatedOrder = {
          ...order,
          paymentStatus: updatedPayment.paymentStatus
        };
        this.orders.set(updatedPayment.orderId, updatedOrder);
      }
    }
    
    return updatedPayment;
  }
  
  async getPaymentMethods(userId: number): Promise<Payment[]> {
    // Returns saved payment methods for a specific user
    // Filter by userId and only return payments with status 'saved' for reuse
    return Array.from(this.payments.values())
      .filter(payment => 
        payment.userId === userId && 
        payment.paymentStatus === 'saved' // Only get saved payment methods
      )
      .sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  // Partner document operations
  async getPartnerDocuments(partnerId?: number, documentType?: string, verificationStatus?: string): Promise<PartnerDocument[]> {
    let documents = Array.from(this.partnerDocuments.values());
    
    if (partnerId !== undefined) {
      documents = documents.filter(doc => doc.partnerId === partnerId);
    }
    
    if (documentType) {
      documents = documents.filter(doc => doc.documentType === documentType);
    }
    
    if (verificationStatus) {
      documents = documents.filter(doc => doc.verificationStatus === verificationStatus);
    }
    
    return documents.sort((a, b) => 
      new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
    );
  }
  
  async getPartnerDocument(id: number): Promise<PartnerDocument | undefined> {
    return this.partnerDocuments.get(id);
  }
  
  async createPartnerDocument(insertDocument: InsertPartnerDocument): Promise<PartnerDocument> {
    const id = this.partnerDocumentCurrentId++;
    const now = new Date();
    
    // Create a properly typed document object
    const document: PartnerDocument = {
      id,
      partnerId: insertDocument.partnerId,
      documentType: insertDocument.documentType,
      documentUrl: insertDocument.documentUrl,
      verificationStatus: insertDocument.verificationStatus || 'pending',
      verifiedBy: insertDocument.verifiedBy || null,
      verificationDate: insertDocument.verificationDate || null,
      rejectionReason: insertDocument.rejectionReason || null,
      expiryDate: insertDocument.expiryDate || null,
      uploadedAt: now
    };
    
    this.partnerDocuments.set(id, document);
    return document;
  }
  
  async updatePartnerDocumentStatus(id: number, status: string, adminId: number, rejectionReason?: string): Promise<PartnerDocument> {
    const document = this.partnerDocuments.get(id);
    if (!document) {
      throw new Error(`Document with ID ${id} not found`);
    }
    
    const now = new Date();
    
    // Handle rejection reason based on status
    let rejectionReasonValue = null;
    if (status === 'rejected') {
      rejectionReasonValue = rejectionReason || 'No reason provided';
    }
    
    const updatedDocument = {
      ...document,
      verificationStatus: status,
      verifiedBy: adminId,
      verificationDate: now,
      rejectionReason: rejectionReasonValue
    };
    
    this.partnerDocuments.set(id, updatedDocument);
    return updatedDocument;
  }
  
  // Payment gateway operations
  async getPaymentGateways(isActive?: boolean): Promise<PaymentGateway[]> {
    let gateways = Array.from(this.paymentGateways.values());
    
    if (isActive !== undefined) {
      gateways = gateways.filter(gateway => gateway.isActive === isActive);
    }
    
    return gateways.sort((a, b) => {
      // Sort by default first, then by name
      if (a.isDefault && !b.isDefault) return -1;
      if (!a.isDefault && b.isDefault) return 1;
      return a.displayName.localeCompare(b.displayName);
    });
  }
  
  async getPaymentGateway(id: number): Promise<PaymentGateway | undefined> {
    return this.paymentGateways.get(id);
  }
  
  async createPaymentGateway(gateway: InsertPaymentGateway): Promise<PaymentGateway> {
    const id = this.paymentGatewayCurrentId++;
    const now = new Date();
    
    // If this is marked as default and isDefault is true, clear other defaults
    if (gateway.isDefault) {
      this.clearDefaultGateways();
    }
    
    const newGateway: PaymentGateway = {
      ...gateway,
      id,
      isActive: gateway.isActive ?? true,
      isDefault: gateway.isDefault ?? false,
      configuration: gateway.configuration ?? {},
      supportedCountries: gateway.supportedCountries ?? [],
      supportedCurrencies: gateway.supportedCurrencies ?? [],
      minimumAmount: gateway.minimumAmount ?? 0,
      createdAt: now,
      updatedAt: now
    };
    
    this.paymentGateways.set(id, newGateway);
    return newGateway;
  }
  
  private clearDefaultGateways() {
    // Clear default flag from all gateways
    for (const [id, gateway] of this.paymentGateways.entries()) {
      if (gateway.isDefault) {
        this.paymentGateways.set(id, { ...gateway, isDefault: false });
      }
    }
  }
  
  async updatePaymentGateway(id: number, update: Partial<PaymentGateway>): Promise<PaymentGateway> {
    const gateway = this.paymentGateways.get(id);
    if (!gateway) {
      throw new Error(`Payment gateway with ID ${id} not found`);
    }
    
    // If we're setting this as default, clear other defaults
    if (update.isDefault) {
      this.clearDefaultGateways();
    }
    
    const updatedGateway = { 
      ...gateway, 
      ...update,
      updatedAt: new Date()
    };
    
    this.paymentGateways.set(id, updatedGateway);
    return updatedGateway;
  }
  
  async togglePaymentGatewayStatus(id: number, isActive: boolean): Promise<PaymentGateway> {
    const gateway = this.paymentGateways.get(id);
    if (!gateway) {
      throw new Error(`Payment gateway with ID ${id} not found`);
    }
    
    const updatedGateway = { 
      ...gateway, 
      isActive,
      updatedAt: new Date()
    };
    
    this.paymentGateways.set(id, updatedGateway);
    return updatedGateway;
  }
  
  async setDefaultPaymentGateway(id: number): Promise<PaymentGateway> {
    const gateway = this.paymentGateways.get(id);
    if (!gateway) {
      throw new Error(`Payment gateway with ID ${id} not found`);
    }
    
    // Clear other defaults
    this.clearDefaultGateways();
    
    // Set this one as default
    const updatedGateway = { 
      ...gateway, 
      isDefault: true,
      updatedAt: new Date()
    };
    
    this.paymentGateways.set(id, updatedGateway);
    return updatedGateway;
  }
  
  // Commission configuration operations
  async getCommissionConfigurations(isActive?: boolean): Promise<CommissionConfiguration[]> {
    let configs = Array.from(this.commissionConfigurations.values());
    
    if (isActive !== undefined) {
      configs = configs.filter(config => config.isActive === isActive);
    }
    
    return configs.sort((a, b) => {
      // Sort by default first, then by vehicle type
      if (a.isDefault && !b.isDefault) return -1;
      if (!a.isDefault && b.isDefault) return 1;
      return a.vehicleTypeId - b.vehicleTypeId;
    });
  }
  
  async getCommissionConfiguration(id: number): Promise<CommissionConfiguration | undefined> {
    return this.commissionConfigurations.get(id);
  }
  
  async createCommissionConfiguration(config: InsertCommissionConfiguration): Promise<CommissionConfiguration> {
    const id = this.commissionConfigurationCurrentId++;
    const now = new Date();
    
    // If this is marked as default, clear other defaults
    if (config.isDefault) {
      this.clearDefaultCommissionConfigurations();
    }
    
    const newConfig: CommissionConfiguration = {
      ...config,
      id,
      isActive: config.isActive ?? true,
      isDefault: config.isDefault ?? false,
      createdAt: now,
      updatedAt: now
    };
    
    this.commissionConfigurations.set(id, newConfig);
    return newConfig;
  }
  
  private clearDefaultCommissionConfigurations() {
    // Clear default flag from all commission configurations
    for (const [id, config] of this.commissionConfigurations.entries()) {
      if (config.isDefault) {
        this.commissionConfigurations.set(id, { ...config, isDefault: false });
      }
    }
  }
  
  async updateCommissionConfiguration(id: number, update: Partial<CommissionConfiguration>): Promise<CommissionConfiguration> {
    const config = this.commissionConfigurations.get(id);
    if (!config) {
      throw new Error(`Commission configuration with ID ${id} not found`);
    }
    
    // If we're setting this as default, clear other defaults
    if (update.isDefault) {
      this.clearDefaultCommissionConfigurations();
    }
    
    const updatedConfig = { 
      ...config, 
      ...update,
      updatedAt: new Date()
    };
    
    this.commissionConfigurations.set(id, updatedConfig);
    return updatedConfig;
  }
  
  async toggleCommissionConfigurationStatus(id: number, isActive: boolean): Promise<CommissionConfiguration> {
    const config = this.commissionConfigurations.get(id);
    if (!config) {
      throw new Error(`Commission configuration with ID ${id} not found`);
    }
    
    const updatedConfig = { 
      ...config, 
      isActive,
      updatedAt: new Date()
    };
    
    this.commissionConfigurations.set(id, updatedConfig);
    return updatedConfig;
  }
  
  async setDefaultCommissionConfiguration(id: number): Promise<CommissionConfiguration> {
    const config = this.commissionConfigurations.get(id);
    if (!config) {
      throw new Error(`Commission configuration with ID ${id} not found`);
    }
    
    // Clear other defaults
    this.clearDefaultCommissionConfigurations();
    
    // Set this one as default
    const updatedConfig = { 
      ...config, 
      isDefault: true,
      updatedAt: new Date()
    };
    
    this.commissionConfigurations.set(id, updatedConfig);
    return updatedConfig;
  }
  
  // Map API configuration operations
  async getMapApiConfigurations(): Promise<MapApiConfig[]> {
    return Array.from(this.mapApiConfigs.values())
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }
  
  async getMapApiConfiguration(id: number): Promise<MapApiConfig | undefined> {
    return this.mapApiConfigs.get(id);
  }
  
  // Helper method to clear default map API configurations
  private clearDefaultMapApiConfigurations() {
    for (const [id, config] of this.mapApiConfigs.entries()) {
      if (config.isDefault) {
        this.mapApiConfigs.set(id, { ...config, isDefault: false });
      }
    }
  }
  
  async createMapApiConfiguration(config: InsertMapApiConfig): Promise<MapApiConfig> {
    // If this is to be the default, clear other defaults
    if (config.isDefault) {
      this.clearDefaultMapApiConfigurations();
    }
    
    const id = this.mapApiConfigCurrentId++;
    const now = new Date();
    
    const newConfig: MapApiConfig = {
      ...config,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.mapApiConfigs.set(id, newConfig);
    return newConfig;
  }
  
  async updateMapApiConfiguration(id: number, update: Partial<MapApiConfig>): Promise<MapApiConfig> {
    const config = this.mapApiConfigs.get(id);
    if (!config) {
      throw new Error(`Map API configuration with ID ${id} not found`);
    }
    
    // If we're setting this as default, clear other defaults
    if (update.isDefault) {
      this.clearDefaultMapApiConfigurations();
    }
    
    const updatedConfig = {
      ...config,
      ...update,
      updatedAt: new Date()
    };
    
    this.mapApiConfigs.set(id, updatedConfig);
    return updatedConfig;
  }
  
  async deleteMapApiConfiguration(id: number): Promise<boolean> {
    const config = this.mapApiConfigs.get(id);
    if (!config) {
      return false;
    }
    
    // Don't allow deleting the default config
    if (config.isDefault) {
      throw new Error("Cannot delete the default map API configuration");
    }
    
    return this.mapApiConfigs.delete(id);
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUsersByType(userType: string): Promise<User[]> {
    return db.select().from(users).where(eq(users.userType, userType));
  }
  
  // Helper function to calculate distance between coordinates using Haversine formula
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Radius of the Earth in km
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }
  
  private deg2rad(deg: number): number {
    return deg * (Math.PI/180);
  }
  
  async getAvailableDeliveryPartners(vehicleTypeId?: number, maxDistance?: number, pickupLat?: number, pickupLng?: number): Promise<User[]> {
    // Base query for available delivery partners
    let query = db.select()
      .from(users)
      .where(
        and(
          eq(users.userType, 'delivery'),
          eq(users.isAvailable, true)
        )
      );
    
    // Add vehicle type filter if specified
    if (vehicleTypeId) {
      query = query.where(eq(users.vehicleTypeId, vehicleTypeId));
    }
    
    // Execute the query
    const partners = await query;
    
    // If distance filtering is requested
    if (pickupLat !== undefined && pickupLng !== undefined && maxDistance !== undefined) {
      // Filter and sort partners by distance (in memory since this requires calculation)
      const filteredPartners = partners.filter(partner => {
        // Skip partners without location data
        if (partner.currentLat === null || partner.currentLng === null) return false;
        
        // Calculate distance using Haversine formula
        const distance = this.calculateDistance(
          pickupLat, 
          pickupLng, 
          partner.currentLat, 
          partner.currentLng
        );
        
        return distance <= maxDistance;
      });
      
      // Sort by distance from pickup location (closest first)
      return filteredPartners.sort((a, b) => {
        const distanceA = this.calculateDistance(
          pickupLat,
          pickupLng,
          a.currentLat!,
          a.currentLng!
        );
        
        const distanceB = this.calculateDistance(
          pickupLat,
          pickupLng,
          b.currentLat!,
          b.currentLng!
        );
        
        return distanceA - distanceB;
      });
    }
    
    return partners;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(users.id);
  }
  
  async deleteUser(id: number): Promise<boolean> {
    try {
      // Check if user exists
      const user = await this.getUser(id);
      if (!user) {
        return false;
      }
      
      // Check if user is referenced in any orders (as customer)
      const userOrders = await db.select().from(orders).where(eq(orders.userId, id));
      if (userOrders.length > 0) {
        // User has orders, can't delete
        return false;
      }
      
      // Check if user has any documents
      const userDocuments = await db.select().from(partnerDocuments).where(eq(partnerDocuments.partnerId, id));
      if (userDocuments.length > 0) {
        // User has documents, can't delete
        return false;
      }
      
      const result = await db.delete(users).where(eq(users.id, id));
      return result.rowCount ? result.rowCount > 0 : false;
    } catch (error) {
      console.error("Error deleting user:", error);
      return false;
    }
  }

  async createUser(insertUser: InsertUser & { profilePicture?: string, driversLicense?: string }): Promise<User> {
    // Make userType have a default
    const userType = insertUser.userType || "customer";
    
    // Create a data object that matches our schema
    const userData = {
      ...insertUser,
      userType,
      vehicleTypeId: userType === "delivery" ? insertUser.vehicleTypeId : null,
      profilePicture: insertUser.profilePicture || null,
      driversLicense: insertUser.driversLicense || null,
      currentLat: null,
      currentLng: null,
      isAvailable: true,
    };
    
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUserAvailability(userId: number, update: { isAvailable: boolean, currentLat: number | null, currentLng: number | null }): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        isAvailable: update.isAvailable,
        currentLat: update.currentLat,
        currentLng: update.currentLng,
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return user;
  }

  async updateUserProfile(userId: number, update: Partial<User>): Promise<User> {
    // First get the current user to preserve password
    const currentUser = await this.getUser(userId);
    if (!currentUser) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    // Create update object without password
    const { password, ...updateData } = update;
    
    const [updatedUser] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  // Vehicle type operations
  async getVehicleTypes(): Promise<VehicleType[]> {
    return db.select().from(vehicleTypes);
  }

  async getVehicleType(id: number): Promise<VehicleType | undefined> {
    const [vehicleType] = await db.select().from(vehicleTypes).where(eq(vehicleTypes.id, id));
    return vehicleType;
  }

  async createVehicleType(insertVehicleType: InsertVehicleType): Promise<VehicleType> {
    const [vehicleType] = await db.insert(vehicleTypes).values(insertVehicleType).returning();
    return vehicleType;
  }

  async updateVehicleType(id: number, update: Partial<VehicleType>): Promise<VehicleType> {
    const [vehicleType] = await db
      .update(vehicleTypes)
      .set(update)
      .where(eq(vehicleTypes.id, id))
      .returning();
    
    if (!vehicleType) {
      throw new Error(`Vehicle type with ID ${id} not found`);
    }
    
    return vehicleType;
  }

  async deleteVehicleType(id: number): Promise<boolean> {
    try {
      // First check if this vehicle type is used by any users
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.vehicleTypeId, id))
        .limit(1);
      
      if (user) {
        // Vehicle type is in use by at least one user
        return false;
      }
      
      // Check if it's used in any orders
      const [order] = await db
        .select()
        .from(orders)
        .where(eq(orders.vehicleTypeId, id))
        .limit(1);
      
      if (order) {
        // Vehicle type is in use by at least one order
        return false;
      }
      
      // Safe to delete
      await db
        .delete(vehicleTypes)
        .where(eq(vehicleTypes.id, id));
      
      return true;
    } catch (error) {
      console.error('Error deleting vehicle type:', error);
      return false;
    }
  }

  // Order operations
  async getOrders(userId: number): Promise<Order[]> {
    return db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }

  async getPendingOrders(): Promise<Order[]> {
    return db
      .select()
      .from(orders)
      .where(eq(orders.status, "pending"))
      .orderBy(desc(orders.createdAt));
  }
  
  async getAllOrders(): Promise<Order[]> {
    return db
      .select()
      .from(orders)
      .orderBy(desc(orders.createdAt));
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    // Set initial status
    const initialStatus = "pending";
    const orderData = {
      ...insertOrder,
      status: initialStatus,
    };
    
    // Create order in transaction to also add status update
    const [order] = await db.insert(orders).values(orderData).returning();
    
    // Create initial status update
    await this.createOrderStatusUpdate({
      orderId: order.id,
      status: initialStatus,
    });
    
    return order;
  }

  async updateOrderStatus(orderId: number, status: string): Promise<Order> {
    const [order] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, orderId))
      .returning();
    
    if (!order) {
      throw new Error(`Order with ID ${orderId} not found`);
    }
    
    // Create status update record
    await this.createOrderStatusUpdate({
      orderId,
      status,
    });
    
    return order;
  }

  // Order status update operations
  async getOrderStatusUpdates(orderId: number): Promise<OrderStatusUpdate[]> {
    return db
      .select()
      .from(orderStatusUpdates)
      .where(eq(orderStatusUpdates.orderId, orderId))
      .orderBy(orderStatusUpdates.timestamp);
  }

  async createOrderStatusUpdate(insertUpdate: InsertOrderStatusUpdate): Promise<OrderStatusUpdate> {
    const [statusUpdate] = await db
      .insert(orderStatusUpdates)
      .values(insertUpdate)
      .returning();
    
    return statusUpdate;
  }
  
  // Partner payment operations
  async getPartnerPayments(partnerId?: number): Promise<PartnerPayment[]> {
    if (partnerId) {
      return db
        .select()
        .from(partnerPayments)
        .where(eq(partnerPayments.partnerId, partnerId))
        .orderBy(desc(partnerPayments.createdAt));
    }
    
    return db
      .select()
      .from(partnerPayments)
      .orderBy(desc(partnerPayments.createdAt));
  }
  
  async getPartnerPayment(id: number): Promise<PartnerPayment | undefined> {
    const [payment] = await db.select().from(partnerPayments).where(eq(partnerPayments.id, id));
    return payment;
  }
  
  async createPartnerPayment(payment: InsertPartnerPayment): Promise<PartnerPayment> {
    const [newPayment] = await db
      .insert(partnerPayments)
      .values({
        ...payment,
        status: payment.status || "pending", // Set default status if not provided
      })
      .returning();
      
    return newPayment;
  }
  
  async updatePartnerPayment(id: number, update: Partial<PartnerPayment>): Promise<PartnerPayment> {
    const [payment] = await db
      .update(partnerPayments)
      .set(update)
      .where(eq(partnerPayments.id, id))
      .returning();
      
    if (!payment) {
      throw new Error(`Partner payment with ID ${id} not found`);
    }
    
    return payment;
  }
  
  async processPartnerPayment(id: number, adminId: number): Promise<PartnerPayment> {
    const now = new Date();
    
    const [payment] = await db
      .update(partnerPayments)
      .set({
        status: "paid",
        paymentDate: now,
        processedBy: adminId,
      })
      .where(eq(partnerPayments.id, id))
      .returning();
      
    if (!payment) {
      throw new Error(`Partner payment with ID ${id} not found`);
    }
    
    return payment;
  }
  
  // Fee configuration operations
  async getFeeConfigurations(): Promise<FeeConfiguration[]> {
    return db
      .select()
      .from(feeConfigurations)
      .orderBy(desc(feeConfigurations.effectiveDate));
  }
  
  async getActiveFeeConfiguration(vehicleTypeId: number): Promise<FeeConfiguration | undefined> {
    const [config] = await db
      .select()
      .from(feeConfigurations)
      .where(
        and(
          eq(feeConfigurations.vehicleTypeId, vehicleTypeId),
          eq(feeConfigurations.isActive, true)
        )
      )
      .orderBy(desc(feeConfigurations.effectiveDate))
      .limit(1);
      
    return config;
  }
  
  async createFeeConfiguration(config: InsertFeeConfiguration): Promise<FeeConfiguration> {
    const [newConfig] = await db
      .insert(feeConfigurations)
      .values(config)
      .returning();
      
    return newConfig;
  }
  
  // System settings operations
  async getSystemSettings(key?: string): Promise<SystemSetting[]> {
    if (key) {
      return db
        .select()
        .from(systemSettings)
        .where(eq(systemSettings.settingKey, key));
    }
    
    return db.select().from(systemSettings);
  }
  
  async updateSystemSetting(key: string, value: string, adminId: number): Promise<SystemSetting> {
    // Check if the setting exists
    const [existing] = await db
      .select()
      .from(systemSettings)
      .where(eq(systemSettings.settingKey, key));
      
    if (existing) {
      // Update existing setting
      const [updated] = await db
        .update(systemSettings)
        .set({
          settingValue: value,
          updatedBy: adminId,
          updatedAt: new Date(),
        })
        .where(eq(systemSettings.settingKey, key))
        .returning();
        
      return updated;
    } else {
      // Create new setting
      const [newSetting] = await db
        .insert(systemSettings)
        .values({
          settingKey: key,
          settingValue: value,
          dataType: 'string', // Default type
          updatedBy: adminId,
        })
        .returning();
        
      return newSetting;
    }
  }
  
  // Customer payment transactions by time range
  async getCustomerPayments(startDate?: Date, endDate?: Date): Promise<Order[]> {
    // No filters - return all orders
    if (!startDate && !endDate) {
      return db
        .select()
        .from(orders)
        .orderBy(desc(orders.createdAt));
    }
    
    // For dates, use manual filtering with JS
    const allOrders = await db
      .select()
      .from(orders)
      .orderBy(desc(orders.createdAt));
      
    return allOrders.filter(order => {
      const orderDate = new Date(order.createdAt);
      
      if (startDate && orderDate < startDate) {
        return false;
      }
      
      if (endDate && orderDate > endDate) {
        return false;
      }
      
      return true;
    });
  }
  
  // Archive older payment records (for 3-month retention policy)
  async archiveOldPaymentRecords(olderThanDate: Date): Promise<{ archived: number }> {
    // In a real implementation, this would:
    // 1. Extract the data older than the date
    // 2. Send it via email to admin
    // 3. Delete or anonymize the records
    
    // Get orders older than the specified date
    const allOrders = await db.select().from(orders);
    
    // Filter orders that are older than the cutoff date
    const oldOrders = allOrders.filter(order => {
      const orderDate = new Date(order.createdAt);
      return orderDate < olderThanDate;
    });
      
    // For this implementation we'll just count them
    // In a real system, we would store them elsewhere or email them
    
    // Records would be deleted after archiving
    // This is left commented out since we're not actually emailing the data yet
    /*
    const oldOrderIds = oldOrders.map(order => order.id);
    
    if (oldOrderIds.length > 0) {
      await db
        .delete(orders)
        .where(inArray(orders.id, oldOrderIds));
    }
    */
    
    return { archived: oldOrders.length };
  }
  
  // Payment management operations
  async getPayments(userId?: number, orderId?: number, paymentMethod?: string): Promise<Payment[]> {
    let conditions = [];
    
    if (userId !== undefined) {
      conditions.push(eq(payments.userId, userId));
    }
    
    if (orderId !== undefined) {
      conditions.push(eq(payments.orderId, orderId));
    }
    
    if (paymentMethod) {
      conditions.push(eq(payments.paymentMethod, paymentMethod));
    }
    
    // If we have conditions, use them all with AND operator
    if (conditions.length > 0) {
      return db
        .select()
        .from(payments)
        .where(and(...conditions))
        .orderBy(desc(payments.createdAt));
    }
    
    // Otherwise return all payments
    return db
      .select()
      .from(payments)
      .orderBy(desc(payments.createdAt));
  }
  
  async getPayment(id: number): Promise<Payment | undefined> {
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    return payment;
  }
  
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    // Ensure all required fields are set with defaults
    const paymentData = {
      ...insertPayment,
      paymentStatus: insertPayment.paymentStatus || 'pending',
      paymentProvider: insertPayment.paymentProvider || null,
      currency: insertPayment.currency || 'USD',
      transactionId: insertPayment.transactionId || null,
      phoneNumber: insertPayment.phoneNumber || null,
      receiptUrl: insertPayment.receiptUrl || null,
      metadata: insertPayment.metadata || null,
      errorMessage: insertPayment.errorMessage || null
    } as InsertPayment;
    
    const [payment] = await db.insert(payments).values(paymentData).returning();
    
    // Update the related order with payment information if needed
    if (payment.orderId) {
      await db
        .update(orders)
        .set({
          paymentStatus: payment.paymentStatus,
          paymentMethod: payment.paymentMethod,
          paymentId: payment.transactionId
        })
        .where(eq(orders.id, payment.orderId));
    }
    
    return payment;
  }
  
  async updatePayment(id: number, update: Partial<Payment>): Promise<Payment> {
    const now = new Date();
    const updateData = {
      ...update,
      updatedAt: now
    };
    
    const [payment] = await db
      .update(payments)
      .set(updateData)
      .where(eq(payments.id, id))
      .returning();
    
    if (!payment) {
      throw new Error(`Payment with ID ${id} not found`);
    }
    
    // Update the related order with payment status if needed
    if (payment.orderId && update.paymentStatus) {
      await db
        .update(orders)
        .set({
          paymentStatus: update.paymentStatus
        })
        .where(eq(orders.id, payment.orderId));
    }
    
    return payment;
  }
  
  async getPaymentMethods(userId: number): Promise<Payment[]> {
    // Returns saved payment methods for a specific user
    // Filter by userId and only return payments with status 'saved' for reuse
    return await db
      .select()
      .from(payments)
      .where(
        and(
          eq(payments.userId, userId),
          eq(payments.paymentStatus, 'saved')
        )
      )
      .orderBy(desc(payments.createdAt));
  }
  
  // Partner document operations
  async getPartnerDocuments(partnerId?: number, documentType?: string, verificationStatus?: string): Promise<PartnerDocument[]> {
    let conditions = [];
    
    if (partnerId !== undefined) {
      conditions.push(eq(partnerDocuments.partnerId, partnerId));
    }
    
    if (documentType) {
      conditions.push(eq(partnerDocuments.documentType, documentType));
    }
    
    if (verificationStatus) {
      conditions.push(eq(partnerDocuments.verificationStatus, verificationStatus));
    }
    
    // If we have conditions, use them all with AND operator
    if (conditions.length > 0) {
      return db
        .select()
        .from(partnerDocuments)
        .where(and(...conditions))
        .orderBy(desc(partnerDocuments.uploadedAt));
    }
    
    // Otherwise return all documents
    return db
      .select()
      .from(partnerDocuments)
      .orderBy(desc(partnerDocuments.uploadedAt));
  }
  
  async getPartnerDocument(id: number): Promise<PartnerDocument | undefined> {
    const [document] = await db.select().from(partnerDocuments).where(eq(partnerDocuments.id, id));
    return document;
  }
  
  async createPartnerDocument(insertDocument: InsertPartnerDocument): Promise<PartnerDocument> {
    // Ensure all required fields are set with defaults
    const documentData = {
      partnerId: insertDocument.partnerId,
      documentType: insertDocument.documentType,
      documentUrl: insertDocument.documentUrl,
      verificationStatus: insertDocument.verificationStatus || 'pending',
      verifiedBy: insertDocument.verifiedBy || null,
      verificationDate: insertDocument.verificationDate || null,
      rejectionReason: insertDocument.rejectionReason || null,
      expiryDate: insertDocument.expiryDate || null,
    };
    
    const [document] = await db
      .insert(partnerDocuments)
      .values(documentData)
      .returning();
      
    return document;
  }
  
  async updatePartnerDocumentStatus(id: number, status: string, adminId: number, rejectionReason?: string): Promise<PartnerDocument> {
    const now = new Date();
    
    const updateData: Partial<PartnerDocument> = {
      verificationStatus: status,
      verifiedBy: adminId,
      verificationDate: now,
    };
    
    // Handle rejection reason based on status
    if (status === 'rejected') {
      updateData.rejectionReason = rejectionReason || 'No reason provided';
    } else {
      // Explicitly clear the rejection reason when verifying a document
      updateData.rejectionReason = null;
    }
    
    const [document] = await db
      .update(partnerDocuments)
      .set(updateData)
      .where(eq(partnerDocuments.id, id))
      .returning();
      
    if (!document) {
      throw new Error(`Document with ID ${id} not found`);
    }
    
    return document;
  }
  
  // Payment gateway operations
  async getPaymentGateways(isActive?: boolean): Promise<PaymentGateway[]> {
    if (isActive !== undefined) {
      return db
        .select()
        .from(paymentGateways)
        .where(eq(paymentGateways.isActive, isActive))
        .orderBy(
          desc(paymentGateways.isDefault),
          asc(paymentGateways.displayName)
        );
    }
    
    return db
      .select()
      .from(paymentGateways)
      .orderBy(
        desc(paymentGateways.isDefault),
        asc(paymentGateways.displayName)
      );
  }
  
  async getPaymentGateway(id: number): Promise<PaymentGateway | undefined> {
    const [gateway] = await db
      .select()
      .from(paymentGateways)
      .where(eq(paymentGateways.id, id));
      
    return gateway;
  }
  
  async createPaymentGateway(gateway: InsertPaymentGateway): Promise<PaymentGateway> {
    // If this gateway should be the default one, clear other defaults first
    if (gateway.isDefault) {
      await db
        .update(paymentGateways)
        .set({ isDefault: false })
        .where(eq(paymentGateways.isDefault, true));
    }
    
    const [newGateway] = await db
      .insert(paymentGateways)
      .values(gateway)
      .returning();
      
    return newGateway;
  }
  
  async updatePaymentGateway(id: number, update: Partial<PaymentGateway>): Promise<PaymentGateway> {
    // If setting as default, clear other defaults
    if (update.isDefault) {
      await db
        .update(paymentGateways)
        .set({ isDefault: false })
        .where(eq(paymentGateways.isDefault, true));
    }
    
    const [gateway] = await db
      .update(paymentGateways)
      .set({
        ...update,
        updatedAt: new Date()
      })
      .where(eq(paymentGateways.id, id))
      .returning();
      
    if (!gateway) {
      throw new Error(`Payment gateway with ID ${id} not found`);
    }
    
    return gateway;
  }
  
  async togglePaymentGatewayStatus(id: number, isActive: boolean): Promise<PaymentGateway> {
    const [gateway] = await db
      .update(paymentGateways)
      .set({
        isActive,
        updatedAt: new Date()
      })
      .where(eq(paymentGateways.id, id))
      .returning();
      
    if (!gateway) {
      throw new Error(`Payment gateway with ID ${id} not found`);
    }
    
    return gateway;
  }
  
  async setDefaultPaymentGateway(id: number): Promise<PaymentGateway> {
    // First, clear all default gateways
    await db
      .update(paymentGateways)
      .set({ isDefault: false })
      .where(eq(paymentGateways.isDefault, true));
    
    // Then set the specified one as default
    const [gateway] = await db
      .update(paymentGateways)
      .set({
        isDefault: true,
        updatedAt: new Date()
      })
      .where(eq(paymentGateways.id, id))
      .returning();
      
    if (!gateway) {
      throw new Error(`Payment gateway with ID ${id} not found`);
    }
    
    return gateway;
  }
  
  // Commission configuration operations
  async getCommissionConfigurations(isActive?: boolean): Promise<CommissionConfiguration[]> {
    if (isActive !== undefined) {
      return db
        .select()
        .from(commissionConfigurations)
        .where(eq(commissionConfigurations.isActive, isActive))
        .orderBy(
          desc(commissionConfigurations.isDefault),
          asc(commissionConfigurations.commissionName)
        );
    }
    
    return db
      .select()
      .from(commissionConfigurations)
      .orderBy(
        desc(commissionConfigurations.isDefault),
        asc(commissionConfigurations.commissionName)
      );
  }
  
  async getCommissionConfiguration(id: number): Promise<CommissionConfiguration | undefined> {
    const [config] = await db
      .select()
      .from(commissionConfigurations)
      .where(eq(commissionConfigurations.id, id));
      
    return config;
  }
  
  async createCommissionConfiguration(config: InsertCommissionConfiguration): Promise<CommissionConfiguration> {
    // If this config should be the default one, clear other defaults first
    if (config.isDefault) {
      await db
        .update(commissionConfigurations)
        .set({ isDefault: false })
        .where(eq(commissionConfigurations.isDefault, true));
    }
    
    const [newConfig] = await db
      .insert(commissionConfigurations)
      .values(config)
      .returning();
      
    return newConfig;
  }
  
  async updateCommissionConfiguration(id: number, update: Partial<CommissionConfiguration>): Promise<CommissionConfiguration> {
    // If setting as default, clear other defaults
    if (update.isDefault) {
      await db
        .update(commissionConfigurations)
        .set({ isDefault: false })
        .where(eq(commissionConfigurations.isDefault, true));
    }
    
    const [config] = await db
      .update(commissionConfigurations)
      .set({
        ...update,
        updatedAt: new Date()
      })
      .where(eq(commissionConfigurations.id, id))
      .returning();
      
    if (!config) {
      throw new Error(`Commission configuration with ID ${id} not found`);
    }
    
    return config;
  }
  
  async toggleCommissionConfigurationStatus(id: number, isActive: boolean): Promise<CommissionConfiguration> {
    const [config] = await db
      .update(commissionConfigurations)
      .set({
        isActive,
        updatedAt: new Date()
      })
      .where(eq(commissionConfigurations.id, id))
      .returning();
      
    if (!config) {
      throw new Error(`Commission configuration with ID ${id} not found`);
    }
    
    return config;
  }
  
  async setDefaultCommissionConfiguration(id: number): Promise<CommissionConfiguration> {
    // First, clear all default configurations
    await db
      .update(commissionConfigurations)
      .set({ isDefault: false })
      .where(eq(commissionConfigurations.isDefault, true));
    
    // Then set the specified one as default
    const [config] = await db
      .update(commissionConfigurations)
      .set({
        isDefault: true,
        updatedAt: new Date()
      })
      .where(eq(commissionConfigurations.id, id))
      .returning();
      
    if (!config) {
      throw new Error(`Commission configuration with ID ${id} not found`);
    }
    
    return config;
  }

  // Map API configuration operations
  async getMapApiConfigurations(): Promise<MapApiConfig[]> {
    return await db.select().from(mapApiConfigs).orderBy(desc(mapApiConfigs.updatedAt));
  }
  
  async getMapApiConfiguration(id: number): Promise<MapApiConfig | undefined> {
    const [config] = await db.select().from(mapApiConfigs).where(eq(mapApiConfigs.id, id));
    return config;
  }
  
  async createMapApiConfiguration(config: InsertMapApiConfig): Promise<MapApiConfig> {
    // If this config should be the default one, clear other defaults first
    if (config.isDefault) {
      await db
        .update(mapApiConfigs)
        .set({ isDefault: false, updatedAt: new Date() })
        .where(eq(mapApiConfigs.isDefault, true));
    }
    
    const [newConfig] = await db.insert(mapApiConfigs).values(config).returning();
    return newConfig;
  }
  
  async updateMapApiConfiguration(id: number, update: Partial<MapApiConfig>): Promise<MapApiConfig> {
    // If setting as default, clear other defaults
    if (update.isDefault) {
      await db
        .update(mapApiConfigs)
        .set({ isDefault: false, updatedAt: new Date() })
        .where(and(
          not(eq(mapApiConfigs.id, id)),
          eq(mapApiConfigs.isDefault, true)
        ));
    }
    
    // Apply the update
    const [updatedConfig] = await db
      .update(mapApiConfigs)
      .set({ ...update, updatedAt: new Date() })
      .where(eq(mapApiConfigs.id, id))
      .returning();
      
    if (!updatedConfig) {
      throw new Error(`Map API configuration with ID ${id} not found`);
    }
    
    return updatedConfig;
  }
  
  async deleteMapApiConfiguration(id: number): Promise<boolean> {
    // Don't allow deleting default configs
    const [config] = await db
      .select()
      .from(mapApiConfigs)
      .where(eq(mapApiConfigs.id, id));
      
    if (!config) {
      return false;
    }
    
    if (config.isDefault) {
      throw new Error("Cannot delete the default map API configuration");
    }
    
    const result = await db
      .delete(mapApiConfigs)
      .where(eq(mapApiConfigs.id, id));
      
    return result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();

// Keep MemStorage available for testing/development if needed
// export const storage = new MemStorage();
