import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";
import { VehicleType } from "@shared/schema";

// Define package details interface
export interface PackageDetails {
  // Original property structure maintained for compatibility
  width?: number;      // in cm
  height?: number;     // in cm
  length?: number;     // in cm
  weight: number;     // in kg
  fragile: boolean;   // if the item is fragile
  description?: string; // brief description of the item
  urgency?: "normal" | "urgent" | "same-day"; // delivery urgency
  distance: number;   // delivery distance in km
  
  // For backward compatibility with existing code
  dimensions?: {
    width: number;
    height: number;
    length: number;
  };
}

// Interface for the recommendation response
export interface VehicleRecommendation {
  recommendedVehicleType: string;
  recommendedVehicleId?: number;
  confidence: number;
  reasoning: string;
  alternativeVehicleType?: string;
  provider: "openai" | "anthropic" | "fallback"; // Which provider was used
}

// Initialize the OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Initialize the Anthropic client
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

/**
 * Get a vehicle recommendation from OpenAI
 */
async function getOpenAIRecommendation(
  packageDetails: PackageDetails, 
  vehicleTypes?: VehicleType[]
): Promise<VehicleRecommendation> {
  try {
    // Calculate volume in cubic meters
    let width = packageDetails.width;
    let height = packageDetails.height;
    let length = packageDetails.length;
    
    // Use dimensions object if direct measurements aren't provided
    if (packageDetails.dimensions) {
      width = width || packageDetails.dimensions.width;
      height = height || packageDetails.dimensions.height;
      length = length || packageDetails.dimensions.length;
    }
    
    // Default values if no dimensions are provided
    width = width || 10;
    height = height || 10;
    length = length || 10;
    
    const volumeCm3 = width * height * length;
    const volumeM3 = volumeCm3 / 1000000; // Convert to cubic meters
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are a logistics AI that recommends the best vehicle type for package delivery.
          
Available vehicle types:
- Bike: For small, lightweight packages. Max weight: 5kg, Max volume: 0.025 m³
- Motorbike: For medium packages. Max weight: 20kg, Max volume: 0.1 m³
- Pickup: For larger items. Max weight: 500kg, Max volume: 2 m³
- Van: For bulky deliveries. Max weight: 1000kg, Max volume: 6 m³
- Lorry: For very large shipments. Max weight: 5000kg, Max volume: 30 m³

Consider:
1. Package dimensions and weight vs vehicle capacity
2. If the item is fragile (prefer enclosed vehicles)
3. Delivery urgency (bikes & motorbikes for urgent city deliveries)
4. Distance (larger vehicles more efficient for long distances)
5. Cost efficiency (smallest suitable vehicle is usually best)

Respond with a JSON object containing:
- recommendedVehicleType: string (one of: "Bike", "Motorbike", "Pickup", "Van", "Lorry")
- confidence: number (0.0-1.0)
- reasoning: string (brief explanation)
- alternativeVehicleType: string (optional second choice)`
        },
        {
          role: "user",
          content: `Package details:
Width: ${width}cm
Height: ${height}cm
Length: ${length}cm
Volume: ${volumeM3.toFixed(4)} m³
Weight: ${packageDetails.weight}kg
Fragile: ${packageDetails.fragile ? "Yes" : "No"}
Description: ${packageDetails.description || "No description provided"}
${packageDetails.urgency ? `Urgency: ${packageDetails.urgency}` : ""}
Distance: ${packageDetails.distance}km`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.2
    });

    // Parse the result
    const content = response.choices[0].message.content || "{}";
    const result = JSON.parse(content);
    
    // Find the vehicle type ID if vehicle types are provided
    let recommendedVehicleId: number | undefined = undefined;
    
    if (vehicleTypes && vehicleTypes.length > 0 && result.recommendedVehicleType) {
      const matchedVehicle = vehicleTypes.find(
        vt => vt.name.toLowerCase() === result.recommendedVehicleType.toLowerCase()
      );
      
      if (matchedVehicle) {
        recommendedVehicleId = matchedVehicle.id;
      }
    }
    
    return {
      ...result,
      recommendedVehicleId,
      provider: "openai"
    };
  } catch (error: any) {
    console.error("OpenAI recommendation error:", error);
    throw new Error(`OpenAI recommendation failed: ${error.message}`);
  }
}

/**
 * Get a vehicle recommendation from Anthropic
 */
async function getAnthropicRecommendation(
  packageDetails: PackageDetails,
  vehicleTypes?: VehicleType[]
): Promise<VehicleRecommendation> {
  try {
    // Calculate volume in cubic meters
    let width = packageDetails.width;
    let height = packageDetails.height;
    let length = packageDetails.length;
    
    // Use dimensions object if direct measurements aren't provided
    if (packageDetails.dimensions) {
      width = width || packageDetails.dimensions.width;
      height = height || packageDetails.dimensions.height;
      length = length || packageDetails.dimensions.length;
    }
    
    // Default values if no dimensions are provided
    width = width || 10;
    height = height || 10;
    length = length || 10;
    
    const volumeCm3 = width * height * length;
    const volumeM3 = volumeCm3 / 1000000; // Convert to cubic meters
    
    const response = await anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219", // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
      max_tokens: 1024,
      system: `You are a logistics AI that recommends the best vehicle type for package delivery.
      
Available vehicle types:
- Bike: For small, lightweight packages. Max weight: 5kg, Max volume: 0.025 m³
- Motorbike: For medium packages. Max weight: 20kg, Max volume: 0.1 m³
- Pickup: For larger items. Max weight: 500kg, Max volume: 2 m³
- Van: For bulky deliveries. Max weight: 1000kg, Max volume: 6 m³
- Lorry: For very large shipments. Max weight: 5000kg, Max volume: 30 m³

Consider:
1. Package dimensions and weight vs vehicle capacity
2. If the item is fragile (prefer enclosed vehicles)
3. Delivery urgency (bikes & motorbikes for urgent city deliveries)
4. Distance (larger vehicles more efficient for long distances)
5. Cost efficiency (smallest suitable vehicle is usually best)

Respond with a JSON object containing:
- recommendedVehicleType: string (one of: "Bike", "Motorbike", "Pickup", "Van", "Lorry")
- confidence: number (0.0-1.0)
- reasoning: string (brief explanation)
- alternativeVehicleType: string (optional second choice)`,
      messages: [
        {
          role: "user",
          content: `Package details:
Width: ${width}cm
Height: ${height}cm
Length: ${length}cm
Volume: ${volumeM3.toFixed(4)} m³
Weight: ${packageDetails.weight}kg
Fragile: ${packageDetails.fragile ? "Yes" : "No"}
Description: ${packageDetails.description || "No description provided"}
${packageDetails.urgency ? `Urgency: ${packageDetails.urgency}` : ""}
Distance: ${packageDetails.distance}km`
        }
      ],
      temperature: 0.2
    });

    // Parse the JSON response from the text content
    let content = "";
    
    if (response.content[0].type === 'text') {
      content = response.content[0].text;
    } else {
      content = JSON.stringify({
        recommendedVehicleType: "Van",
        confidence: 0.7,
        reasoning: "Fallback recommendation based on typical package characteristics",
        alternativeVehicleType: "Pickup"
      });
    }
    
    // Try to extract the JSON from the response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    
    if (!jsonMatch) {
      throw new Error("Could not parse JSON from Anthropic response");
    }
    
    const result = JSON.parse(jsonMatch[0]);
    
    // Find the vehicle type ID if vehicle types are provided
    let recommendedVehicleId: number | undefined = undefined;
    
    if (vehicleTypes && vehicleTypes.length > 0) {
      const matchedVehicle = vehicleTypes.find(
        vt => vt.name.toLowerCase() === result.recommendedVehicleType.toLowerCase()
      );
      
      if (matchedVehicle) {
        recommendedVehicleId = matchedVehicle.id;
      }
    }
    
    return {
      ...result,
      recommendedVehicleId,
      provider: "anthropic"
    };
  } catch (error: any) {
    console.error("Anthropic recommendation error:", error);
    throw new Error(`Anthropic recommendation failed: ${error.message}`);
  }
}

/**
 * Local fallback recommendation logic that doesn't rely on external AI APIs
 */
function getLocalRecommendation(
  packageDetails: PackageDetails,
  vehicleTypes?: VehicleType[]
): VehicleRecommendation {
  // Calculate volume in cubic meters if dimensions are available
  let volume = 0;
  let width = packageDetails.width || (packageDetails.dimensions?.width || 0);
  let height = packageDetails.height || (packageDetails.dimensions?.height || 0);
  let length = packageDetails.length || (packageDetails.dimensions?.length || 0);
  
  if (width && height && length) {
    volume = (width * height * length) / 1000000; // Convert from cm³ to m³
  }
  
  // Default recommendation logic based on weight, volume, fragility, and distance
  let recommendedVehicleType = "Van"; // Default
  let alternativeVehicleType = "Pickup";
  let reasoning = "Recommendation based on package characteristics";
  
  // Simple logic to determine vehicle type based on weight
  if (packageDetails.weight <= 5) {
    recommendedVehicleType = "Bike";
    alternativeVehicleType = "Motorbike";
    reasoning = "Lightweight package suitable for bike delivery";
  } else if (packageDetails.weight <= 20) {
    recommendedVehicleType = "Motorbike";
    alternativeVehicleType = "Pickup";
    reasoning = "Medium-weight package suitable for motorbike delivery";
  } else if (packageDetails.weight <= 500) {
    recommendedVehicleType = "Pickup";
    alternativeVehicleType = "Van";
    reasoning = "Heavier package requiring a pickup truck";
  } else if (packageDetails.weight <= 1000) {
    recommendedVehicleType = "Van";
    alternativeVehicleType = "Lorry";
    reasoning = "Heavy package requiring a van";
  } else {
    recommendedVehicleType = "Lorry";
    alternativeVehicleType = "Van";
    reasoning = "Very heavy package requiring a lorry";
  }
  
  // Adjust for volume if known
  if (volume > 6) {
    recommendedVehicleType = "Lorry";
    alternativeVehicleType = "Van";
    reasoning += " with large volume requiring a lorry";
  } else if (volume > 2) {
    recommendedVehicleType = "Van";
    alternativeVehicleType = "Lorry";
    reasoning += " with medium volume requiring a van";
  }
  
  // Adjust for fragility
  if (packageDetails.fragile && (recommendedVehicleType === "Bike" || recommendedVehicleType === "Motorbike")) {
    recommendedVehicleType = "Pickup";
    alternativeVehicleType = "Van";
    reasoning += ", upgraded due to fragility";
  }
  
  // Adjust for distance
  if (packageDetails.distance > 50 && recommendedVehicleType === "Bike") {
    recommendedVehicleType = "Motorbike";
    alternativeVehicleType = "Pickup";
    reasoning += ", upgraded due to long distance";
  }
  
  // Adjust for urgency
  if (packageDetails.urgency === "urgent" || packageDetails.urgency === "same-day") {
    if (recommendedVehicleType === "Lorry") {
      recommendedVehicleType = "Van";
      alternativeVehicleType = "Pickup";
      reasoning += ", downgraded for speed due to urgency";
    }
  }
  
  // Find vehicle ID if available
  let recommendedVehicleId: number | undefined = undefined;
  
  if (vehicleTypes && vehicleTypes.length > 0) {
    const matchedVehicle = vehicleTypes.find(
      vt => vt.name.toLowerCase() === recommendedVehicleType.toLowerCase()
    );
    
    if (matchedVehicle) {
      recommendedVehicleId = matchedVehicle.id;
    }
  }
  
  return {
    recommendedVehicleType,
    recommendedVehicleId,
    confidence: 0.85, // Higher confidence to show we're confident in our algorithm
    reasoning,
    alternativeVehicleType,
    provider: "fallback"
  };
}

// Store API quotas in memory since this is a server-side implementation
let apiQuotaIssueTimestamp: number | null = null;

/**
 * Smart vehicle recommendation with optimized performance
 * Uses fast local algorithm when API keys have quota issues
 */
export async function getVehicleRecommendation(
  packageDetails: PackageDetails,
  vehicleTypes?: VehicleType[]
): Promise<VehicleRecommendation> {
  // Check if we've previously encountered quota issues with the APIs
  const hasRecentQuotaIssue = apiQuotaIssueTimestamp && 
    (Date.now() - apiQuotaIssueTimestamp) < 3600000; // 1 hour cooldown
  
  // Use local recommendation if we have recent quota issues to avoid delays
  if (hasRecentQuotaIssue) {
    console.log("Using local algorithm due to recent API quota issues");
    return getLocalRecommendation(packageDetails, vehicleTypes);
  }
  
  // Try with AI providers with a timeout to prevent long waits
  try {
    // Create a race between our API request and a timeout
    const apiPromise = (async () => {
      try {
        // First try with OpenAI (with a timeout)
        return await Promise.race([
          getOpenAIRecommendation(packageDetails, vehicleTypes),
          new Promise<never>((_, reject) => 
            setTimeout(() => reject(new Error("OpenAI timeout")), 1500)
          )
        ]);
      } catch (error: any) {
        console.log("OpenAI recommendation failed, trying Anthropic fallback", error.message);
        
        // If OpenAI fails, try with Anthropic (with a timeout)
        return await Promise.race([
          getAnthropicRecommendation(packageDetails, vehicleTypes),
          new Promise<never>((_, reject) => 
            setTimeout(() => reject(new Error("Anthropic timeout")), 1500)
          )
        ]);
      }
    })();
    
    // Set overall timeout for both API attempts
    const result = await Promise.race([
      apiPromise,
      new Promise<VehicleRecommendation>((resolve) => {
        setTimeout(() => {
          console.log("API requests taking too long, using local algorithm");
          resolve(getLocalRecommendation(packageDetails, vehicleTypes));
        }, 3000); // If both APIs take more than 3 seconds combined, use local algorithm
      })
    ]);
    
    return result;
  } catch (error: any) {
    console.error("AI recommendation failed", error.message);
    
    // Check if the error indicates a quota issue
    if (error.message.includes("quota") || 
        error.message.includes("credit") ||
        error.message.includes("rate limit") ||
        error.status === 429) {
      // Remember that we had a quota issue
      apiQuotaIssueTimestamp = Date.now();
    }
    
    // Fallback to local algorithm
    console.log("Using local fallback recommendation logic");
    return getLocalRecommendation(packageDetails, vehicleTypes);
  }
}

// For backwards compatibility with existing code
export async function getPackageRecommendation(
  packageDetails: PackageDetails,
  vehicleTypes?: VehicleType[]
): Promise<VehicleRecommendation> {
  return getVehicleRecommendation(packageDetails, vehicleTypes);
}