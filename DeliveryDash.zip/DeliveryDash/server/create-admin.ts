import { storage } from "./storage";

async function createAdminUser() {
  try {
    console.log("Creating admin user...");
    
    // Admin credentials
    const username = "admin";
    const password = "admin123"; // For testing purposes only
    
    // Check if admin already exists
    const existingAdmin = await storage.getUserByUsername(username);
    
    if (existingAdmin) {
      console.log("Admin user already exists:", {
        id: existingAdmin.id,
        username: existingAdmin.username,
        fullName: existingAdmin.fullName,
        userType: existingAdmin.userType
      });
      console.log("\nYou can use these credentials to login:");
      console.log(`Username: ${username}`);
      console.log(`Password: ${password}`);
      process.exit(0);
    }
    
    // Create new admin user
    const admin = await storage.createUser({
      username,
      password, // Note: In production, use a proper password hashing library
      fullName: "System Administrator",
      email: "admin@askfortransport.com",
      phone: "+1234567890",
      userType: "admin"
    });
    
    console.log("Admin user created successfully:", {
      id: admin.id,
      username: admin.username,
      fullName: admin.fullName,
      userType: admin.userType
    });
    
    console.log(`
    =======================
    ADMIN LOGIN CREDENTIALS
    =======================
    Username: ${username}
    Password: ${password}
    =======================
    IMPORTANT: Change this password in production!
    `);
    
  } catch (error) {
    console.error("Error creating admin user:", error);
  } finally {
    process.exit(0);
  }
}

// Run the function
createAdminUser();