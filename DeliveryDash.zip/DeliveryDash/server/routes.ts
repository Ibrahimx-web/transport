import express, { type Express, type Request as ExpressRequest, type Response, type NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertOrderSchema, 
  insertOrderStatusUpdateSchema, 
  insertVehicleTypeSchema,
  insertPaymentGatewaySchema,
  insertCommissionConfigurationSchema,
  type VehicleType,
  type User,
  type PaymentGateway,
  type CommissionConfiguration
} from "@shared/schema";
import { z } from "zod";
import 'express-session';

// Use a type alias for Request
type Request = ExpressRequest;
import { setupWebSocketServer, getConnectedClients } from './websocket';
import { getPackageRecommendation, getVehicleRecommendation, type PackageDetails } from './services/ai-recommendation';

// Calculate distance between two points (lat/lng)
function calculateDistance(
  lat1: number, 
  lng1: number, 
  lat2: number, 
  lng2: number
): number {
  const toRad = (value: number) => value * Math.PI / 180;
  const R = 6371; // km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lng2 - lng1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c;
  return distance;
}

// Calculate fare based on distance and vehicle type
function calculateFare(
  distance: number,
  baseFare: number
): { distanceFare: number, serviceFee: number, totalFare: number } {
  // Rate per km is $1.00 for simplicity
  const rate = 1.0;
  const distanceFare = parseFloat((distance * rate).toFixed(2));
  
  // Service fee is 10% of (base fare + distance fare)
  const serviceFee = parseFloat(((baseFare + distanceFare) * 0.1).toFixed(2));
  
  // Total fare is base fare + distance fare + service fee
  const totalFare = parseFloat((baseFare + distanceFare + serviceFee).toFixed(2));
  
  return { distanceFare, serviceFee, totalFare };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoints
  const apiRouter = express.Router();
  
  // Vehicle Types
  apiRouter.get('/vehicle-types', async (req: Request, res: Response) => {
    try {
      const vehicleTypes = await storage.getVehicleTypes();
      res.json(vehicleTypes);
    } catch (error) {
      res.status(500).json({ message: "Failed to get vehicle types" });
    }
  });
  
  // Get a specific vehicle type
  apiRouter.get('/vehicle-types/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid vehicle type ID" });
      }
      
      const vehicleType = await storage.getVehicleType(id);
      if (!vehicleType) {
        return res.status(404).json({ message: "Vehicle type not found" });
      }
      
      res.json(vehicleType);
    } catch (error) {
      res.status(500).json({ message: "Failed to get vehicle type" });
    }
  });
  
  // Create a new vehicle type (admin only)
  apiRouter.post('/vehicle-types', async (req: Request, res: Response) => {
    try {
      // Check if user is admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      // Validate request body
      const vehicleTypeData = insertVehicleTypeSchema.parse(req.body);
      
      // Create new vehicle type
      const newVehicleType = await storage.createVehicleType(vehicleTypeData);
      res.status(201).json(newVehicleType);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create vehicle type" });
    }
  });
  
  // Update a vehicle type (admin only)
  apiRouter.patch('/vehicle-types/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid vehicle type ID" });
      }
      
      // Validate that the vehicle type exists
      const existingType = await storage.getVehicleType(id);
      if (!existingType) {
        return res.status(404).json({ message: "Vehicle type not found" });
      }
      
      // Update only allowed fields
      const update: Partial<VehicleType> = {};
      
      if (req.body.name !== undefined) update.name = req.body.name;
      if (req.body.icon !== undefined) update.icon = req.body.icon;
      if (req.body.maxWeight !== undefined) update.maxWeight = req.body.maxWeight;
      if (req.body.baseFare !== undefined) update.baseFare = req.body.baseFare;
      
      // Update vehicle type
      const updatedVehicleType = await storage.updateVehicleType(id, update);
      res.json(updatedVehicleType);
    } catch (error) {
      console.error('Error updating vehicle type:', error);
      res.status(500).json({ message: "Failed to update vehicle type" });
    }
  });
  
  // Delete a vehicle type (admin only)
  apiRouter.delete('/vehicle-types/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid vehicle type ID" });
      }
      
      // Try to delete the vehicle type
      const deleted = await storage.deleteVehicleType(id);
      
      if (!deleted) {
        return res.status(400).json({ message: "Cannot delete this vehicle type as it is in use" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error('Error deleting vehicle type:', error);
      res.status(500).json({ message: "Failed to delete vehicle type" });
    }
  });
  
  // User Registration and Authentication
  apiRouter.post('/users/register', async (req: Request, res: Response) => {
    try {
      // Extract the file data from the request
      const { profilePicture, driversLicense, ...userData } = req.body;
      
      // Parse the user data with schema validation
      const validatedUserData = insertUserSchema.parse(userData);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(validatedUserData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Validate vehicle type for delivery users
      if (validatedUserData.userType === 'delivery' && validatedUserData.vehicleTypeId) {
        const vehicleType = await storage.getVehicleType(validatedUserData.vehicleTypeId);
        if (!vehicleType) {
          return res.status(400).json({ message: "Invalid vehicle type selected" });
        }
      }
      
      // Prepare user data with file uploads
      const userDataWithFiles = {
        ...validatedUserData,
        // Add files if they exist
        profilePicture: profilePicture || null,
        driversLicense: driversLicense || null
      };
      
      // Create the user
      const user = await storage.createUser(userDataWithFiles);
      
      // Don't return password in the response
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to register user" });
    }
  });
  
  apiRouter.post('/users/login', async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      console.log("Login attempt:", { username, hasPassword: !!password });
      
      // Validate input
      if (!username || !password) {
        console.log("Login validation failed - missing username or password");
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      // Check if user exists
      const user = await storage.getUserByUsername(username);
      console.log("Login user lookup:", { username, found: !!user, userType: user?.userType });
      
      if (!user) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Check password (in a real app you would use bcrypt to compare hashed passwords)
      if (user.password !== password) {
        console.log("Login password mismatch for user:", username);
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Store user ID in session
      if (req.session) {
        req.session.userId = user.id;
        console.log("Login successful - Session created:", { 
          userId: user.id, 
          sessionID: req.sessionID,
          userType: user.userType
        });
      } else {
        console.error("Login session creation failed - req.session is undefined");
      }
      
      // Don't return password in the response
      const { password: _, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Failed to log in" });
    }
  });
  
  // Current user endpoint
  apiRouter.get('/users/current', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated via session
      const userId = req.session?.userId;
      
      console.log("Current user request - Session:", { 
        hasSession: !!req.session,
        userId, 
        sessionID: req.sessionID,
        cookie: req.session?.cookie 
      });
      
      if (!userId) {
        console.log("Current user authentication failed - No userId in session");
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Fetch the user
      const user = await storage.getUser(userId);
      console.log("Current user lookup result:", { userId, found: !!user, userType: user?.userType });
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't return password in the response
      const { password, ...userWithoutPassword } = user;
      
      console.log("Current user response:", { id: userWithoutPassword.id, userType: userWithoutPassword.userType });
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Current user error:", error);
      res.status(500).json({ message: "Failed to get current user" });
    }
  });
  
  // Logout endpoint
  apiRouter.post('/users/logout', (req: Request, res: Response) => {
    try {
      // Destroy the session
      if (req.session) {
        req.session.destroy((err: any) => {
          if (err) {
            return res.status(500).json({ message: "Failed to logout" });
          }
          res.json({ message: "Logged out successfully" });
        });
      } else {
        res.json({ message: "Already logged out" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to logout" });
    }
  });
  
  // Admin User Management Endpoints
  
  // Get all users (admin only)
  apiRouter.get('/admin/users', async (req: Request, res: Response) => {
    try {
      // Check if user is admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      // Get all users
      const users = await storage.getAllUsers();
      
      // Remove passwords from response
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error('Error getting users:', error);
      res.status(500).json({ message: "Failed to get users" });
    }
  });
  
  // Create a new user (admin only)
  apiRouter.post('/admin/users', async (req: Request, res: Response) => {
    try {
      // Check if user is admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const adminUser = await storage.getUser(req.session.userId);
      if (!adminUser || adminUser.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      // Extract the file data from the request
      const { profilePicture, driversLicense, ...userData } = req.body;
      
      // Parse the user data with schema validation
      const validatedUserData = insertUserSchema.parse(userData);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(validatedUserData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Validate vehicle type for delivery users
      if (validatedUserData.userType === 'delivery' && validatedUserData.vehicleTypeId) {
        const vehicleType = await storage.getVehicleType(validatedUserData.vehicleTypeId);
        if (!vehicleType) {
          return res.status(400).json({ message: "Invalid vehicle type selected" });
        }
      }
      
      // Prepare user data with file uploads
      const userDataWithFiles = {
        ...validatedUserData,
        profilePicture: profilePicture || null,
        driversLicense: driversLicense || null
      };
      
      // Create the user
      const user = await storage.createUser(userDataWithFiles);
      
      // Don't return password in the response
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      console.error('Error creating user:', error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  // Update a user (admin only)
  apiRouter.patch('/admin/users/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const adminUser = await storage.getUser(req.session.userId);
      if (!adminUser || adminUser.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Check if user exists
      const userToUpdate = await storage.getUser(userId);
      if (!userToUpdate) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Extract fields to update
      const { 
        fullName, 
        email, 
        phone, 
        userType,
        vehicleTypeId, 
        licensePlateNumber,
        vehicleRegistrationNumber,
        profilePicture, 
        driversLicense,
        password
      } = req.body;
      
      // Create update object
      const updateData: any = {};
      
      if (fullName !== undefined) updateData.fullName = fullName;
      if (email !== undefined) updateData.email = email;
      if (phone !== undefined) updateData.phone = phone;
      if (userType !== undefined) updateData.userType = userType;
      if (vehicleTypeId !== undefined) updateData.vehicleTypeId = vehicleTypeId;
      if (licensePlateNumber !== undefined) updateData.licensePlateNumber = licensePlateNumber;
      if (vehicleRegistrationNumber !== undefined) updateData.vehicleRegistrationNumber = vehicleRegistrationNumber;
      if (password !== undefined && password) updateData.password = password;
      
      // Handle file uploads
      if (profilePicture !== undefined) updateData.profilePicture = profilePicture;
      if (driversLicense !== undefined) updateData.driversLicense = driversLicense;
      
      // Update user
      const updatedUser = await storage.updateUserProfile(userId, updateData);
      
      // Don't return password in the response
      const { password: _, ...userWithoutPassword } = updatedUser;
      
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error updating user:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update user" });
    }
  });
  
  // Delete a user (admin only)
  apiRouter.delete('/admin/users/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const adminUser = await storage.getUser(req.session.userId);
      if (!adminUser || adminUser.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Prevent admin from deleting themselves
      if (userId === req.session.userId) {
        return res.status(400).json({ message: "Cannot delete your own admin account" });
      }
      
      // Check if user exists
      const userToDelete = await storage.getUser(userId);
      if (!userToDelete) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Delete the user
      const deleted = await storage.deleteUser(userId);
      
      if (!deleted) {
        return res.status(400).json({ 
          message: "Cannot delete this user because they have associated records (orders or documents)" 
        });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error('Error deleting user:', error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });
  
  // Update user profile endpoint
  apiRouter.patch('/users/profile', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Extract the fields to update
      const { 
        fullName, 
        email, 
        phone, 
        vehicleTypeId, 
        profilePicture,
        driversLicense,
        paymentDetails
      } = req.body;
      
      // Create an object with the fields to update
      const updateData: any = {};
      
      if (fullName) updateData.fullName = fullName;
      if (email) updateData.email = email;
      if (phone) updateData.phone = phone;
      
      // Only update vehicle type ID if user is a delivery partner
      if (user.userType === 'delivery' && vehicleTypeId) {
        updateData.vehicleTypeId = vehicleTypeId;
      }
      
      // Handle file uploads
      if (profilePicture) updateData.profilePicture = profilePicture;
      if (driversLicense) updateData.driversLicense = driversLicense;
      
      // Handle payment details update
      if (paymentDetails) {
        // Merge with existing payment details if present
        if (user.paymentDetails) {
          updateData.paymentDetails = {
            ...user.paymentDetails,
            ...paymentDetails
          };
        } else {
          updateData.paymentDetails = paymentDetails;
        }
      }
      
      // Update the user profile
      const updatedUser = await storage.updateUserProfile(userId, updateData);
      
      // Don't return password in the response
      const { password, ...userWithoutPassword } = updatedUser;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  
  // Update partner payment method preference
  apiRouter.patch('/users/payment-preference', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify the user is a delivery partner
      if (user.userType !== 'delivery') {
        return res.status(403).json({ message: "Only delivery partners can set payment preferences" });
      }
      
      const { preferredPaymentMethod } = req.body;
      
      if (!preferredPaymentMethod) {
        return res.status(400).json({ message: "Preferred payment method is required" });
      }
      
      // Update the payment preference
      const updateData = { preferredPaymentMethod };
      const updatedUser = await storage.updateUserProfile(userId, updateData);
      
      // Return success response
      res.json({ 
        success: true, 
        message: 'Payment preference updated successfully',
        preferredPaymentMethod: updatedUser.preferredPaymentMethod
      });
    } catch (error) {
      console.error("Error updating payment preference:", error);
      res.status(500).json({ message: "Failed to update payment preference" });
    }
  });
  
  // Update user availability status (for delivery partners)
  apiRouter.post('/users/availability', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if user is a delivery partner
      if (user.userType !== 'delivery') {
        return res.status(403).json({ message: "Not authorized - only delivery partners can update availability" });
      }
      
      const { isAvailable, currentLat, currentLng } = req.body;
      
      // Validate parameters
      if (typeof isAvailable !== 'boolean') {
        return res.status(400).json({ message: "isAvailable must be a boolean" });
      }
      
      if (isAvailable && (typeof currentLat !== 'number' || typeof currentLng !== 'number')) {
        return res.status(400).json({ message: "currentLat and currentLng are required when available" });
      }
      
      // Update user availability and location
      const updatedUser = await storage.updateUserAvailability(userId, {
        isAvailable,
        currentLat: isAvailable ? currentLat : null,
        currentLng: isAvailable ? currentLng : null
      });
      
      // Don't return password in the response
      const { password, ...userWithoutPassword } = updatedUser;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update availability" });
    }
  });
  
  // Orders
  apiRouter.post('/orders', async (req: Request, res: Response) => {
    let transactionStartTime = Date.now();
    
    try {
      // Prefer to use authenticated user ID from session if available, otherwise fall back to request body
      const userId = req.session.userId || req.body.userId;
      
      if (!userId) {
        return res.status(401).json({ 
          message: "You must be logged in to create an order",
          code: "AUTH_REQUIRED"
        });
      }
      
      // Verify that the user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(400).json({
          message: "Invalid user account",
          code: "INVALID_USER"
        });
      }
      
      // Performance monitoring
      console.log(`[PERF] User verification: ${Date.now() - transactionStartTime}ms`);
      const validationStartTime = Date.now();
      
      // Validate order data
      const orderData = insertOrderSchema.parse(req.body);
      
      // Fetch vehicle type for pricing info
      const vehicleType = await storage.getVehicleType(orderData.vehicleTypeId);
      if (!vehicleType) {
        console.error("Invalid vehicle type:", orderData.vehicleTypeId);
        return res.status(400).json({ message: "Invalid vehicle type" });
      }
      
      console.log(`[PERF] Data validation: ${Date.now() - validationStartTime}ms`);
      const calculationStartTime = Date.now();
      
      // Calculate distance between pickup and delivery
      const distance = calculateDistance(
        orderData.pickupLat, 
        orderData.pickupLng, 
        orderData.deliveryLat, 
        orderData.deliveryLng
      );
      
      // Calculate fare with additional surge pricing checks
      const { distanceFare, serviceFee, totalFare } = calculateFare(distance, vehicleType.baseFare);
      
      console.log(`[PERF] Pricing calculation: ${Date.now() - calculationStartTime}ms`);
      const orderCreationStartTime = Date.now();
      
      // Update order data with calculated values and include metadata
      const completeOrderData = {
        ...orderData,
        // Override the userId with the one from the session
        userId,
        distance,
        baseFare: vehicleType.baseFare,
        distanceFare,
        serviceFee,
        totalFare,
        // Set initial status
        status: "pending"
      };
      
      // Create the order
      const order = await storage.createOrder(completeOrderData);
      
      console.log(`[PERF] Order creation: ${Date.now() - orderCreationStartTime}ms`);
      console.log(`[PERF] Total transaction time: ${Date.now() - transactionStartTime}ms`);
      
      // Log success
      console.log("Order created successfully:", order.id);
      
      // Return the order with additional display info
      res.status(201).json({
        ...order,
        userFullName: user.fullName,
        vehicleTypeName: vehicleType.name,
        vehicleTypeIcon: vehicleType.icon
      });
    } catch (error) {
      console.error('Error creating order:', error);
      
      if (error instanceof z.ZodError) {
        console.error('Validation errors:', JSON.stringify(error.errors, null, 2));
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      
      // Log additional information to help debug
      console.error('Request body:', JSON.stringify(req.body, null, 2));
      
      res.status(500).json({ message: "Failed to create order" });
    }
  });
  
  // Find available delivery partners for assignment
  apiRouter.get('/delivery-partners/available', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      // Get query parameters for filtering
      const vehicleTypeId = req.query.vehicleTypeId ? parseInt(req.query.vehicleTypeId as string) : undefined;
      const maxDistance = req.query.maxDistance ? parseFloat(req.query.maxDistance as string) : 20; // Default 20km max distance
      const pickupLat = req.query.pickupLat ? parseFloat(req.query.pickupLat as string) : undefined;
      const pickupLng = req.query.pickupLng ? parseFloat(req.query.pickupLng as string) : undefined;

      const availablePartners = await storage.getAvailableDeliveryPartners(
        vehicleTypeId, 
        maxDistance, 
        pickupLat, 
        pickupLng
      );

      // Filter out sensitive information
      const sanitizedPartners = availablePartners.map(partner => ({
        id: partner.id,
        fullName: partner.fullName,
        userType: partner.userType,
        vehicleTypeId: partner.vehicleTypeId,
        currentLat: partner.currentLat,
        currentLng: partner.currentLng,
        isAvailable: partner.isAvailable,
        rating: partner.rating,
        // Include distance if coordinates were provided
        ...(pickupLat && pickupLng && partner.currentLat && partner.currentLng) && {
          distance: calculateDistance(
            pickupLat, 
            pickupLng, 
            partner.currentLat, 
            partner.currentLng
          )
        }
      }));

      res.json(sanitizedPartners);
    } catch (error) {
      console.error('Error finding available delivery partners:', error);
      res.status(500).json({ message: "Failed to find available partners" });
    }
  });

  // Helper function to calculate distance using Haversine formula
  function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Radius of the Earth in km
    const dLat = (lat2 - lat1) * (Math.PI/180);
    const dLon = (lon2 - lon1) * (Math.PI/180);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * (Math.PI/180)) * Math.cos(lat2 * (Math.PI/180)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return parseFloat((R * c).toFixed(2)); // Return with 2 decimal places
  }

  // Endpoint for pending orders (for delivery partners)
  apiRouter.get('/orders/pending', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated and is a delivery partner
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || user.userType !== 'delivery') {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const pendingOrders = await storage.getPendingOrders();
      
      // Enhance pending orders with additional information
      const enhancedOrders = await Promise.all(pendingOrders.map(async (order) => {
        // Get vehicle type information for display
        const vehicleType = await storage.getVehicleType(order.vehicleTypeId);
        
        // If the user (delivery partner) has the same vehicle type and is within range,
        // include the distance from the pickup point
        let distance = null;
        if (
          user.vehicleTypeId === order.vehicleTypeId && 
          user.currentLat !== null && 
          user.currentLng !== null
        ) {
          distance = calculateDistance(
            user.currentLat, 
            user.currentLng, 
            order.pickupLat, 
            order.pickupLng
          );
        }
        
        return {
          ...order,
          vehicleTypeName: vehicleType?.name || "Unknown",
          vehicleTypeIcon: vehicleType?.icon || "question-mark",
          distance
        };
      }));
      
      res.json(enhancedOrders);
    } catch (error) {
      console.error('Error getting pending orders:', error);
      res.status(500).json({ message: "Failed to get pending orders" });
    }
  });
  
  apiRouter.get('/orders/:id', async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to get order" });
    }
  });
  
  apiRouter.get('/users/:userId/orders', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const orders = await storage.getOrders(userId);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to get orders" });
    }
  });
  
  // Order Status Updates
  // Assign delivery partner to an order
  apiRouter.post('/orders/:id/assign', async (req: Request, res: Response) => {
    try {
      // Verify authentication first
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Get the authenticated user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      // Get the current order
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if order is already assigned or in progress
      if (order.partnerId) {
        return res.status(400).json({ 
          message: "Order already has an assigned partner",
          currentPartnerId: order.partnerId
        });
      }
      
      if (order.status !== 'pending') {
        return res.status(400).json({ 
          message: `Cannot assign partner to order with status '${order.status}'` 
        });
      }
      
      // Get the partner ID to assign
      const { partnerId } = req.body;
      if (!partnerId) {
        return res.status(400).json({ message: "Partner ID is required" });
      }
      
      // Verify the partner exists and is eligible
      const partner = await storage.getUser(partnerId);
      if (!partner) {
        return res.status(404).json({ message: "Partner not found" });
      }
      
      if (partner.userType !== 'delivery') {
        return res.status(400).json({ message: "User is not a delivery partner" });
      }
      
      if (!partner.isAvailable) {
        return res.status(400).json({ message: "Partner is not available" });
      }
      
      if (partner.vehicleTypeId !== order.vehicleTypeId) {
        return res.status(400).json({ 
          message: "Partner's vehicle type does not match the order requirements",
          partnerVehicleType: partner.vehicleTypeId,
          orderVehicleType: order.vehicleTypeId
        });
      }
      
      // Update the order with the partner ID and change status to "assigned"
      // Using the storage interface to update the order
      const updatedOrder = await storage.updateOrderStatus(orderId, "assigned");
      
      // Also store the partner ID in the order record 
      // Note: In a real implementation, we should extend the updateOrderStatus method
      // to include partnerId update, but this works for now.
      await storage.updateOrder(orderId, { partnerId });
      
      if (!updatedOrder || updatedOrder.length === 0) {
        return res.status(500).json({ message: "Failed to update order" });
      }
      
      // Create a status update record
      await storage.createOrderStatusUpdate({
        orderId,
        status: "assigned"
      });
      
      // Send success response with updated order
      res.json({
        message: "Delivery partner assigned successfully",
        order: updatedOrder[0]
      });
      
      // Notify the assigned partner of the new order via WebSocket if they're connected
      try {
        // Check if WebSocket module is available and initialized
        const wsModule = require('./websocket');
        
        if (wsModule && typeof wsModule.getSocketIdByUserId === 'function') {
          const partnerSocketId = wsModule.getSocketIdByUserId(partnerId);
          if (partnerSocketId) {
            wsModule.sendWebSocketMessage(partnerSocketId, JSON.stringify({
              type: 'new_order_assigned',
              data: {
                orderId: order.id,
                pickupLocation: order.pickupLocation,
                deliveryLocation: order.deliveryLocation,
                timestamp: new Date()
              }
            }));
          }
        }
      } catch (wsError) {
        // Log but don't fail if WebSocket notification fails
        console.warn('Could not send WebSocket notification:', wsError);
      }
      
    } catch (error) {
      console.error("Error assigning partner to order:", error);
      res.status(500).json({ message: "Failed to assign partner to order" });
    }
  });

  apiRouter.post('/orders/:id/status', async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const { status } = req.body;
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      // Check if order exists
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Update the order status
      const updatedOrder = await storage.updateOrderStatus(orderId, status);
      
      // Send notification to relevant users (customer and delivery partner)
      const orderUpdate = {
        type: 'order_status_update',
        data: {
          orderId: updatedOrder.id,
          status: updatedOrder.status,
          timestamp: new Date()
        }
      };
      
      // Notify the customer and partner if connected
      try {
        // Check if WebSocket module is available and initialized
        const wsModule = require('./websocket');
        
        if (wsModule && typeof wsModule.getSocketIdByUserId === 'function') {
          // Notify the customer if connected
          const customerSocketId = wsModule.getSocketIdByUserId(updatedOrder.userId);
          if (customerSocketId) {
            wsModule.sendWebSocketMessage(customerSocketId, JSON.stringify(orderUpdate));
          }
          
          // Notify the delivery partner if connected and assigned
          if (updatedOrder.partnerId) {
            const partnerSocketId = wsModule.getSocketIdByUserId(updatedOrder.partnerId);
            if (partnerSocketId) {
              wsModule.sendWebSocketMessage(partnerSocketId, JSON.stringify(orderUpdate));
            }
          }
        }
      } catch (wsError) {
        // Log but don't fail if WebSocket notification fails
        console.warn('Could not send WebSocket notification:', wsError);
      }
      
      res.json(updatedOrder);
    } catch (error) {
      console.error('Error updating order status:', error);
      res.status(500).json({ message: "Failed to update order status" });
    }
  });
  
  apiRouter.get('/orders/:id/status-updates', async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const statusUpdates = await storage.getOrderStatusUpdates(orderId);
      res.json(statusUpdates);
    } catch (error) {
      res.status(500).json({ message: "Failed to get order status updates" });
    }
  });
  
  // Admin endpoint for viewing connected users via WebSocket
  apiRouter.get('/admin/connected-users', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated and is an admin
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - admin access required" });
      }
      
      // Get connected clients list
      let connectedClients = [];
      
      try {
        // Check if WebSocket module is available and initialized
        const wsModule = require('./websocket');
        
        if (wsModule && typeof wsModule.getConnectedClients === 'function') {
          connectedClients = wsModule.getConnectedClients();
        } else {
          console.warn('WebSocket module not properly initialized');
        }
      } catch (wsError) {
        console.warn('Error accessing WebSocket module:', wsError);
        // Return empty list if WebSocket module is not available
        res.json([]);
        return;
      }
      
      // Enrich the data with user details
      const enrichedClients = await Promise.all(
        connectedClients.map(async (client) => {
          const user = await storage.getUser(client.userId);
          return {
            ...client,
            username: user?.username || 'unknown',
            fullName: user?.fullName || 'Unknown User',
            userType: user?.userType || 'unknown'
          };
        })
      );
      
      res.json(enrichedClients);
    } catch (error) {
      res.status(500).json({ message: "Failed to get connected users" });
    }
  });
  
  // Partner payment routes
  apiRouter.get('/partner-payments', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user || user.userType !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized - Admin access required' });
    }
    
    try {
      const partnerId = req.query.partnerId ? Number(req.query.partnerId) : undefined;
      const payments = await storage.getPartnerPayments(partnerId);
      
      // Get user names for payments
      const userMap = new Map<number, string>();
      
      for (const payment of payments) {
        if (!userMap.has(payment.partnerId)) {
          const user = await storage.getUser(payment.partnerId);
          if (user) {
            userMap.set(payment.partnerId, user.fullName);
          }
        }
      }
      
      // Add user names to the response
      const paymentsWithNames = payments.map(payment => ({
        ...payment,
        partnerName: userMap.get(payment.partnerId) || `Partner #${payment.partnerId}`
      }));
      
      res.json(paymentsWithNames);
    } catch (error) {
      console.error('Error fetching partner payments:', error);
      res.status(500).json({ message: 'Failed to fetch partner payments' });
    }
  });
  
  // Partner earnings endpoint for delivery partners to view their earnings
  apiRouter.get('/partner/earnings', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'delivery') {
        return res.status(403).json({ message: 'Unauthorized - Delivery partner access only' });
      }
      
      const partnerId = user.id;
      const payments = await storage.getPartnerPayments(partnerId);
      
      // Calculate earnings summaries
      const paidPayments = payments.filter(payment => payment.status === 'paid');
      const pendingPayments = payments.filter(payment => payment.status === 'pending');
      
      const totalPaidAmount = paidPayments.reduce((sum, payment) => sum + payment.finalPayment, 0);
      const totalPendingAmount = pendingPayments.reduce((sum, payment) => sum + payment.finalPayment, 0);
      const totalEarnings = totalPaidAmount + totalPendingAmount;
      
      // Add recent payment history (last 5 payments)
      const recentPayments = payments
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5);
      
      res.json({
        summary: {
          totalEarnings,
          paidEarnings: totalPaidAmount,
          pendingEarnings: totalPendingAmount,
          totalTrips: payments.length,
          paidTrips: paidPayments.length,
          pendingTrips: pendingPayments.length
        },
        recentPayments
      });
    } catch (error) {
      console.error('Error fetching partner earnings:', error);
      res.status(500).json({ message: 'Failed to fetch earnings information' });
    }
  });
  
  apiRouter.post('/partner-payments/:id/process', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: 'Unauthorized - Admin access only' });
      }
      
      const paymentId = parseInt(req.params.id);
      const adminId = user.id;
      
      const payment = await storage.processPartnerPayment(paymentId, adminId);
      res.json(payment);
    } catch (error) {
      console.error('Error processing payment:', error);
      res.status(500).json({ message: 'Failed to process payment' });
    }
  });
  
  // Customer payment routes (orders)
  apiRouter.get('/customer-payments', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: 'Unauthorized - Admin access only' });
      }
      // Parse date filter parameters
      let startDate: Date | undefined = undefined;
      let endDate: Date | undefined = undefined;
      
      if (req.query.startDate) {
        startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        endDate = new Date(req.query.endDate as string);
      }
      
      const payments = await storage.getCustomerPayments(startDate, endDate);
      
      // Get user names for payments
      const userMap = new Map<number, string>();
      const vehicleTypeMap = new Map<number, string>();
      
      for (const payment of payments) {
        // Get user info
        if (!userMap.has(payment.userId)) {
          const user = await storage.getUser(payment.userId);
          if (user) {
            userMap.set(payment.userId, user.fullName);
          }
        }
        
        // Get vehicle type info
        if (!vehicleTypeMap.has(payment.vehicleTypeId)) {
          const vehicleType = await storage.getVehicleType(payment.vehicleTypeId);
          if (vehicleType) {
            vehicleTypeMap.set(payment.vehicleTypeId, vehicleType.name);
          }
        }
      }
      
      // Add additional data to the payments
      const enrichedPayments = payments.map(payment => ({
        ...payment,
        userName: userMap.get(payment.userId) || `User #${payment.userId}`,
        vehicleTypeName: vehicleTypeMap.get(payment.vehicleTypeId) || `Vehicle Type #${payment.vehicleTypeId}`
      }));
      
      res.json(enrichedPayments);
    } catch (error) {
      console.error('Error fetching customer payments:', error);
      res.status(500).json({ message: 'Failed to fetch customer payments' });
    }
  });
  
  // Payment management operations
  apiRouter.get('/payments', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: 'User not found' });
      }
      
      const userId = req.query.userId ? Number(req.query.userId) : undefined;
      const orderId = req.query.orderId ? Number(req.query.orderId) : undefined;
      const paymentMethod = req.query.paymentMethod as string | undefined;
      
      // If not admin, can only see own payments
      if (user.userType !== 'admin' && 
          (!userId || userId !== user.id)) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      const payments = await storage.getPayments(userId, orderId, paymentMethod);
      res.json(payments);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  apiRouter.get('/payments/:id', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: 'User not found' });
      }
      
      const paymentId = Number(req.params.id);
      const payment = await storage.getPayment(paymentId);
      
      if (!payment) {
        return res.status(404).json({ message: 'Payment not found' });
      }
      
      // Check permissions
      if (user.userType !== 'admin' && payment.userId !== user.id) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      res.json(payment);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  apiRouter.post('/payments', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: 'User not found' });
      }
      
      const userId = req.body.userId || user.id;
      
      // If not admin, can only create payments for themselves
      if (user.userType !== 'admin' && userId !== user.id) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      // Get the specified payment method
      const paymentMethod = req.body.paymentMethod;
      if (!paymentMethod) {
        return res.status(400).json({ 
          message: 'Payment method is required', 
          code: 'MISSING_PAYMENT_METHOD'
        });
      }
      
      // First check if we have any active payment gateways
      const activeGateways = await storage.getPaymentGateways(true);
      if (!activeGateways || activeGateways.length === 0) {
        return res.status(503).json({ 
          message: 'No payment gateways are currently available. Please try again later or contact support.', 
          code: 'NO_ACTIVE_GATEWAYS'
        });
      }
      
      // Find a suitable gateway for this payment method
      let selectedGateway;
      
      // If a specific gateway ID was provided, validate it
      if (req.body.paymentGatewayId) {
        selectedGateway = await storage.getPaymentGateway(req.body.paymentGatewayId);
        
        if (!selectedGateway) {
          return res.status(400).json({ 
            message: 'Invalid payment gateway selected', 
            code: 'INVALID_GATEWAY'
          });
        }
        
        if (!selectedGateway.isActive) {
          return res.status(400).json({ 
            message: 'The selected payment gateway is currently unavailable', 
            code: 'INACTIVE_GATEWAY'
          });
        }
      } else {
        // Find a gateway that supports this payment method
        const methodGateways = activeGateways.filter(gateway => {
          // Check gateway type directly (e.g., 'paypal', 'mpesa', etc.)
          if (gateway.gatewayType === paymentMethod) return true;
          
          // Check based on configuration if needed
          try {
            const config = typeof gateway.configuration === 'string' 
              ? JSON.parse(gateway.configuration) 
              : gateway.configuration;
              
            // Check if the gateway configuration includes this payment method
            return config?.supportedMethods?.includes?.(paymentMethod);
          } catch (e) {
            console.warn(`Error parsing gateway configuration for gateway ${gateway.id}:`, e);
            return false;
          }
        });
        
        if (methodGateways.length === 0) {
          return res.status(400).json({ 
            message: `No active payment gateway supports the "${paymentMethod}" payment method. Please select a different payment method.`, 
            code: 'UNSUPPORTED_PAYMENT_METHOD',
            // Return list of supported methods
            supportedMethods: activeGateways.map(g => g.gatewayType)
          });
        }
        
        // Use the default one if available, otherwise use the first one
        selectedGateway = methodGateways.find(g => g.isDefault) || methodGateways[0];
      }
      
      // Helper function to check required configuration keys for each gateway type
      function getRequiredConfigForGateway(gatewayType: string): string[] {
        // Define required configuration keys for each supported gateway type
        const gatewayRequirements: Record<string, string[]> = {
          'stripe': ['apiKey', 'publishableKey', 'webhookSecret'],
          'paypal': ['clientId', 'clientSecret', 'environment'],
          'mpesa': ['consumerKey', 'consumerSecret', 'shortCode', 'passkey'],
          'airtel': ['apiKey', 'accountId', 'environment'],
          'mobilemoney': ['apiKey', 'merchantId', 'environment'],
          'googlepay': ['merchantId', 'environment'],
          'applepay': ['merchantId', 'certificateFile'],
          'cash': [], // Cash doesn't require configuration
          'manual': [], // Manual payment doesn't require configuration
        };
        
        // Return required keys for the given gateway type, or empty array if not defined
        return gatewayRequirements[gatewayType] || [];
      }
      
      // Validate that the gateway is properly configured with required settings
      const requiredConfigKeys = getRequiredConfigForGateway(selectedGateway.gatewayType);
      if (requiredConfigKeys.length > 0) {
        const config = typeof selectedGateway.configuration === 'string' 
          ? JSON.parse(selectedGateway.configuration) 
          : selectedGateway.configuration;
          
        const missingKeys = requiredConfigKeys.filter(key => !config || !config[key]);
        if (missingKeys.length > 0) {
          console.error(`Gateway ${selectedGateway.id} (${selectedGateway.gatewayType}) missing required configuration:`, missingKeys);
          return res.status(503).json({ 
            message: `The payment gateway is not properly configured. Please try a different payment method or contact support.`, 
            code: 'GATEWAY_MISCONFIGURED',
            // Return the issue for admin troubleshooting
            details: user.userType === 'admin' ? `Missing configuration: ${missingKeys.join(', ')}` : undefined
          });
        }
      }
      
      // Check if we need currency conversion
      const { amount, currency = 'USD' } = req.body;
      
      if (!amount || isNaN(amount) || amount <= 0) {
        return res.status(400).json({ 
          message: 'Valid payment amount is required', 
          code: 'INVALID_AMOUNT'
        });
      }
      
      if (!selectedGateway.supportedCurrencies.includes(currency)) {
        // Currency not supported, need to convert
        console.log(`Currency ${currency} not supported by gateway, attempting conversion to ${selectedGateway.supportedCurrencies[0]}`);
        
        // In a real application, this would call a currency conversion service
        // For this prototype, we'll just add a note about it
        req.body.metadata = {
          ...req.body.metadata,
          originalCurrency: currency,
          currencyConversionNote: `Converted from ${currency} to ${selectedGateway.supportedCurrencies[0]}`
        };
      }
      
      // Create the payment with reference to the selected gateway
      const newPayment = await storage.createPayment({
        ...req.body,
        userId,
        // Include the selected gateway ID
        paymentGatewayId: selectedGateway.id,
        // Add processing information
        processedAt: req.body.paymentStatus === 'completed' ? new Date() : null,
        // Add standardized tracking information
        paymentReference: req.body.paymentReference || `PAY-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        // Include gateway info in metadata for reference
        metadata: {
          ...req.body.metadata,
          gatewayType: selectedGateway.gatewayType,
          gatewayName: selectedGateway.displayName
        }
      });
      
      res.status(201).json(newPayment);
    } catch (error) {
      console.error('Error creating payment:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: 'Invalid payment data', 
          errors: error.errors,
          code: 'VALIDATION_ERROR'
        });
      }
      res.status(500).json({ 
        message: 'Failed to process payment',
        code: 'PAYMENT_PROCESSING_ERROR'
      });
    }
  });
  
  apiRouter.patch('/payments/:id', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: 'User not found' });
      }
      
      const paymentId = Number(req.params.id);
      const payment = await storage.getPayment(paymentId);
      
      if (!payment) {
        return res.status(404).json({ message: 'Payment not found' });
      }
      
      // Check permissions
      if (user.userType !== 'admin' && payment.userId !== user.id) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      // Update payment
      const updatedPayment = await storage.updatePayment(paymentId, req.body);
      res.json(updatedPayment);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  apiRouter.get('/users/:userId/payment-methods', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: 'User not found' });
      }
      
      const userId = Number(req.params.userId);
      
      // Check permissions
      if (user.userType !== 'admin' && userId !== user.id) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      // Get saved payment methods
      const paymentMethods = await storage.getPaymentMethods(userId);
      res.json(paymentMethods);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Archive old records
  apiRouter.post('/payments/archive', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user || user.userType !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized - Admin access required' });
    }
    
    try {
      // Default to 3 months ago
      const threeMonthsAgo = new Date();
      threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
      
      const olderThanDate = req.body.olderThanDate 
        ? new Date(req.body.olderThanDate) 
        : threeMonthsAgo;
      
      const result = await storage.archiveOldPaymentRecords(olderThanDate);
      res.json(result);
    } catch (error) {
      console.error('Error archiving old records:', error);
      res.status(500).json({ message: 'Failed to archive old records' });
    }
  });
  
  // Commission summary data
  apiRouter.get('/commission-summary', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user || user.userType !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized - Admin access required' });
    }
    
    try {
      // Get all partner payments
      const payments = await storage.getPartnerPayments();
      
      // Calculate total commission
      const totalCommission = payments.reduce((sum, payment) => sum + payment.commissionAmount, 0);
      
      // Count pending payments
      const pendingPayments = payments.filter(p => p.status === 'pending').length;
      
      // Calculate weekly trend (last 7 days)
      const weeklyTrend = [];
      const today = new Date();
      
      for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        
        // Format date for display
        const formattedDate = `${date.toLocaleString('default', { month: 'short' })} ${date.getDate()}`;
        
        // Find payments from this day
        const dayPayments = payments.filter(payment => {
          const paymentDate = new Date(payment.createdAt);
          return paymentDate.getDate() === date.getDate() && 
                 paymentDate.getMonth() === date.getMonth() &&
                 paymentDate.getFullYear() === date.getFullYear();
        });
        
        // Sum commissions for this day
        const amount = dayPayments.reduce((sum, payment) => sum + payment.commissionAmount, 0);
        
        weeklyTrend.push({ 
          date: formattedDate, 
          amount 
        });
      }
      
      res.json({
        totalCommission,
        totalPayments: payments.length,
        pendingPayments,
        weeklyTrend
      });
    } catch (error) {
      console.error('Error getting commission summary:', error);
      res.status(500).json({ message: 'Failed to get commission summary' });
    }
  });
  
  // System settings for automatic payments
  apiRouter.get('/settings/auto-payments', async (req: Request, res: Response) => {
    // Check if user exists and is admin
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user || user.userType !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized - Admin access required' });
    }
    
    try {
      const [setting] = await storage.getSystemSettings('auto_payments_enabled');
      
      // If setting doesn't exist, create it with default value of false
      if (!setting) {
        await storage.updateSystemSetting('auto_payments_enabled', 'false', user.id);
        res.json({ isEnabled: false });
      } else {
        const isEnabled = setting.settingValue === 'true';
        res.json({ isEnabled });
      }
    } catch (error) {
      console.error('Error fetching auto-payment setting:', error);
      res.status(500).json({ message: 'Failed to fetch setting' });
    }
  });
  
  apiRouter.post('/settings/auto-payments', async (req: Request, res: Response) => {
    // Check if user exists and is admin
    if (!req.session.userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user || user.userType !== 'admin') {
      return res.status(403).json({ message: 'Unauthorized - Admin access required' });
    }
    
    try {
      const { isEnabled } = req.body;
      const value = isEnabled ? 'true' : 'false';
      
      const setting = await storage.updateSystemSetting('auto_payments_enabled', value, user.id);
      res.json({ isEnabled: value === 'true' });
    } catch (error) {
      console.error('Error updating auto-payment setting:', error);
      res.status(500).json({ message: 'Failed to update setting' });
    }
  });
  
  // Partner document management endpoints
  apiRouter.get('/partner-documents', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: 'Not authenticated' });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: 'Unauthorized - Admin access required' });
      }
      
      const { partnerId, documentType, status } = req.query;
      
      // Convert partnerId to number if provided
      const partnerIdFilter = partnerId ? parseInt(partnerId as string) : undefined;
      
      // Get documents with optional filters
      const documents = await storage.getPartnerDocuments(
        partnerIdFilter,
        documentType as string || undefined,
        status as string || undefined
      );
      
      // Get user details for each document
      const userMap = new Map<number, { fullName: string, profilePicture: string | null }>();
      
      for (const doc of documents) {
        if (!userMap.has(doc.partnerId)) {
          const partner = await storage.getUser(doc.partnerId);
          if (partner) {
            userMap.set(doc.partnerId, {
              fullName: partner.fullName,
              profilePicture: partner.profilePicture
            });
          }
        }
      }
      
      // Add user info to the response
      const documentsWithUserInfo = documents.map(doc => ({
        ...doc,
        partnerName: userMap.get(doc.partnerId)?.fullName || `Partner #${doc.partnerId}`,
        partnerProfilePicture: userMap.get(doc.partnerId)?.profilePicture || null
      }));
      
      res.json(documentsWithUserInfo);
    } catch (error) {
      console.error('Error fetching partner documents:', error);
      res.status(500).json({ message: 'Failed to fetch partner documents' });
    }
  });
  
  apiRouter.get('/partner-documents/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: 'Not authenticated' });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: 'Unauthorized - Admin access required' });
      }
      
      const documentId = parseInt(req.params.id);
      if (isNaN(documentId)) {
        return res.status(400).json({ message: 'Invalid document ID' });
      }
      
      const document = await storage.getPartnerDocument(documentId);
      
      if (!document) {
        return res.status(404).json({ message: 'Document not found' });
      }
      
      // Get the partner details
      const partner = await storage.getUser(document.partnerId);
      
      if (!partner) {
        return res.json({
          ...document,
          partner: {
            id: document.partnerId,
            name: `Partner #${document.partnerId}`,
            profilePicture: null,
            status: 'unavailable'
          }
        });
      }
      
      // Get vehicle type information if partner has a vehicle type
      let vehicleInfo = null;
      if (partner.vehicleTypeId) {
        const vehicleType = await storage.getVehicleType(partner.vehicleTypeId);
        if (vehicleType) {
          vehicleInfo = {
            typeId: vehicleType.id,
            name: vehicleType.name,
            maxWeight: vehicleType.maxWeight,
            icon: vehicleType.icon
          };
        }
      }
      
      // Get other documents from this partner for status display
      const allPartnerDocuments = await storage.getPartnerDocuments(partner.id);
      
      // Calculate document verification stats
      const documentStats = {
        total: allPartnerDocuments.length,
        verified: allPartnerDocuments.filter(doc => doc.verificationStatus === 'verified').length,
        pending: allPartnerDocuments.filter(doc => doc.verificationStatus === 'pending').length,
        rejected: allPartnerDocuments.filter(doc => doc.verificationStatus === 'rejected').length
      };
      
      // Format response with rich partner information
      res.json({
        document: {
          ...document,
          formattedDate: document.expiryDate ? new Date(document.expiryDate).toLocaleDateString() : null
        },
        partner: {
          id: partner.id,
          name: partner.fullName,
          email: partner.email,
          phone: partner.phone,
          profilePicture: partner.profilePicture,
          driversLicense: partner.driversLicense,
          licensePlateNumber: partner.licensePlateNumber,
          vehicleRegistrationNumber: partner.vehicleRegistrationNumber,
          isAvailable: partner.isAvailable,
          memberSince: partner.createdAt ? new Date(partner.createdAt).toLocaleDateString() : 'Unknown',
          vehicle: vehicleInfo,
          documentStats: documentStats
        }
      });
    } catch (error) {
      console.error('Error fetching partner document:', error);
      res.status(500).json({ message: 'Failed to fetch partner document' });
    }
  });
  
  apiRouter.post('/partner-documents', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated
      if (!req.session.userId) {
        return res.status(401).json({ message: 'Not authenticated' });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: 'Authentication required' });
      }
      
      // Validate required fields
      const { partnerId, documentType, documentUrl, expiryDate } = req.body;
      
      if (!documentType) {
        return res.status(400).json({ message: 'Document type is required' });
      }
      
      if (!documentUrl) {
        return res.status(400).json({ message: 'Document URL is required' });
      }
      
      // Define valid document types
      const validDocumentTypes = ['drivers_license', 'vehicle_registration', 'insurance', 'id_document', 'vehicle_photo', 'other'];
      
      if (!validDocumentTypes.includes(documentType)) {
        return res.status(400).json({ 
          message: 'Invalid document type',
          validTypes: validDocumentTypes
        });
      }
      
      // Check if the document URL is valid
      if (!documentUrl.startsWith('http')) {
        return res.status(400).json({ message: 'Document URL must be a valid URL' });
      }
      
      // Validate expiry date format if provided
      let parsedExpiryDate = null;
      if (expiryDate) {
        try {
          parsedExpiryDate = new Date(expiryDate);
          // Check if date is valid
          if (isNaN(parsedExpiryDate.getTime())) {
            throw new Error('Invalid date');
          }
          
          // Check if date is in the past
          if (parsedExpiryDate < new Date()) {
            return res.status(400).json({ message: 'Expiry date cannot be in the past' });
          }
        } catch (e) {
          return res.status(400).json({ message: 'Invalid expiry date format. Use ISO format (YYYY-MM-DD)' });
        }
      }
      
      // If a partner uploads their own document
      if (user.userType === 'delivery' && (!partnerId || partnerId === user.id)) {
        // Check if they have already uploaded a document of this type
        const existingDocuments = await storage.getPartnerDocuments(user.id, documentType);
        
        // If a document with pending status exists, don't allow another upload
        if (existingDocuments.some(doc => doc.verificationStatus === 'pending')) {
          return res.status(400).json({ 
            message: `You already have a pending ${documentType} document. Please wait for verification or contact support.`
          });
        }
        
        const document = await storage.createPartnerDocument({
          partnerId: user.id,
          documentType,
          documentUrl,
          expiryDate: parsedExpiryDate ? parsedExpiryDate.toISOString() : null,
          verificationStatus: 'pending'
        });
        
        return res.status(201).json({
          ...document,
          message: 'Document uploaded successfully and is pending verification'
        });
      }
      
      // If an admin uploads a document for a partner
      if (user.userType === 'admin' && partnerId) {
        // Verify the partner exists
        const partner = await storage.getUser(partnerId);
        if (!partner || partner.userType !== 'delivery') {
          return res.status(400).json({ message: 'Invalid partner ID' });
        }
        
        const document = await storage.createPartnerDocument({
          partnerId,
          documentType,
          documentUrl,
          expiryDate: parsedExpiryDate ? parsedExpiryDate.toISOString() : null,
          // Admin uploads are automatically verified
          verificationStatus: 'verified',
          verifiedBy: user.id,
          verificationDate: new Date()
        });
        
        return res.status(201).json({
          ...document,
          message: 'Document uploaded and verified successfully'
        });
      }
      
      // Neither a delivery partner nor an admin with valid partnerId
      return res.status(403).json({ message: 'Unauthorized access' });
    } catch (error) {
      console.error('Error creating partner document:', error);
      res.status(500).json({ message: 'Failed to create partner document' });
    }
  });
  
  apiRouter.patch('/partner-documents/:id/verify', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: 'Not authenticated' });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: 'Unauthorized - Admin access required' });
      }
      
      const documentId = parseInt(req.params.id);
      const { status, rejectionReason } = req.body;
      
      if (!['verified', 'rejected'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status. Must be "verified" or "rejected"' });
      }
      
      // If rejecting, a reason is required
      if (status === 'rejected' && !rejectionReason) {
        return res.status(400).json({ message: 'Rejection reason is required' });
      }
      
      const document = await storage.updatePartnerDocumentStatus(
        documentId,
        status,
        user.id,
        rejectionReason
      );
      
      // Get the partner details
      const partner = await storage.getUser(document.partnerId);
      
      res.json({
        ...document,
        partnerName: partner ? partner.fullName : `Partner #${document.partnerId}`,
        partnerProfilePicture: partner ? partner.profilePicture : null
      });
    } catch (error) {
      console.error('Error updating partner document status:', error);
      res.status(500).json({ message: 'Failed to update partner document status' });
    }
  });
  
  apiRouter.get('/partners/:partnerId/documents', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated
      if (!req.session.userId) {
        return res.status(401).json({ message: 'Not authenticated' });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ message: 'Authentication required' });
      }
      
      const partnerId = parseInt(req.params.partnerId);
      
      // Regular users can only see their own documents
      if (user.userType !== 'admin' && user.id !== partnerId) {
        return res.status(403).json({ message: 'Unauthorized access' });
      }
      
      // Verify partner exists
      const partner = await storage.getUser(partnerId);
      if (!partner) {
        return res.status(404).json({ message: 'Partner not found' });
      }
      
      // Get all documents for this partner
      const documents = await storage.getPartnerDocuments(partnerId);
      
      res.json({
        partner: {
          id: partner.id,
          fullName: partner.fullName,
          profilePicture: partner.profilePicture,
          email: partner.email,
          phone: partner.phone
        },
        documents: documents
      });
    } catch (error) {
      console.error('Error fetching partner documents:', error);
      res.status(500).json({ message: 'Failed to fetch partner documents' });
    }
  });
  
  // AI Package Recommendation Endpoint
  apiRouter.post('/package-recommendations', async (req: Request, res: Response) => {
    try {
      // Check if at least one API key is available
      if (!process.env.OPENAI_API_KEY && !process.env.ANTHROPIC_API_KEY) {
        return res.status(503).json({ 
          message: "AI recommendation services are not available. Missing API keys.",
          fallback: true
        });
      }
      
      // Extract package details from request
      const packageDetails: PackageDetails = req.body;
      
      // Validate required fields
      const requiredFields = ['weight', 'fragile', 'distance'];
      for (const field of requiredFields) {
        if (!(field in packageDetails)) {
          return res.status(400).json({ 
            message: `Missing required field: ${field}`
          });
        }
      }
      
      // Check for dimensions (either direct dimensions or dimensions object)
      if (!packageDetails.width && !packageDetails.height && !packageDetails.length && 
          (!packageDetails.dimensions || 
           !packageDetails.dimensions.width || 
           !packageDetails.dimensions.height || 
           !packageDetails.dimensions.length)) {
        return res.status(400).json({ 
          message: "Missing dimensions. Provide either width/height/length or dimensions object."
        });
      }
      
      // Get all available vehicle types
      const vehicleTypes = await storage.getVehicleTypes();
      
      // Get AI recommendation with fallback between providers
      const recommendation = await getVehicleRecommendation(
        packageDetails,
        vehicleTypes
      );
      
      res.json(recommendation);
    } catch (error: any) {
      console.error('Error getting package recommendation:', error);
      res.status(500).json({ 
        message: 'Failed to get package recommendation',
        error: error.message
      });
    }
  });
  
  // =========== Payment Gateway Management ===========
  // Get all payment gateways
  apiRouter.get('/payment-gateways', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      // Extract query parameters
      const isActive = req.query.active === 'true' ? true :
                      req.query.active === 'false' ? false : undefined;
      
      // Fetch payment gateways with optional filter
      const gateways = await storage.getPaymentGateways(isActive);
      
      res.json(gateways);
    } catch (error) {
      console.error('Error fetching payment gateways:', error);
      res.status(500).json({ message: "Failed to fetch payment gateways" });
    }
  });

  // Get public payment gateways (for customers)
  // Public payment gateways endpoint (doesn't require auth)
  apiRouter.get('/payment-gateways/public', async (req: Request, res: Response) => {
    try {
      // This endpoint is public to allow customers to see available payment options
      // But only returns active gateways
      const gateways = await storage.getPaymentGateways(true);
      
      // If no active gateways found, check for inactive ones and inform the client
      if (!gateways || gateways.length === 0) {
        // Get all gateways including inactive ones to check if any exist
        const allGateways = await storage.getPaymentGateways();
        
        if (allGateways && allGateways.length > 0) {
          // There are gateways but none are active
          return res.status(503).json({
            message: "No active payment gateways available. Please contact support.",
            noActiveGateways: true
          });
        } else {
          // No gateways set up at all - this is likely a setup issue
          return res.status(503).json({
            message: "Payment system is not configured. Please contact support.",
            noGatewaysConfigured: true
          });
        }
      }
      
      // Return only necessary information for public view
      const publicGateways = gateways.map(gateway => ({
        id: gateway.id,
        gatewayType: gateway.gatewayType,
        displayName: gateway.displayName,
        isDefault: gateway.isDefault,
        supportedCountries: gateway.supportedCountries,
        supportedCurrencies: gateway.supportedCurrencies,
        minimumAmount: gateway.minimumAmount,
        processingFee: gateway.processingFee,
        processingFeeType: gateway.processingFeeType
      }));
      
      res.json(publicGateways);
    } catch (error) {
      console.error('Error fetching payment gateways:', error);
      res.status(500).json({ message: 'Failed to fetch payment gateways' });
    }
  });

  // Get a specific payment gateway
  apiRouter.get('/payment-gateways/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid payment gateway ID" });
      }
      
      const gateway = await storage.getPaymentGateway(id);
      if (!gateway) {
        return res.status(404).json({ message: "Payment gateway not found" });
      }
      
      res.json(gateway);
    } catch (error) {
      console.error('Error fetching payment gateway:', error);
      res.status(500).json({ message: "Failed to fetch payment gateway" });
    }
  });

  // Create a new payment gateway
  apiRouter.post('/payment-gateways', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      // Validate request data
      const gatewayData = insertPaymentGatewaySchema.parse({
        ...req.body,
        createdBy: user.id
      });
      
      // Create new payment gateway
      const newGateway = await storage.createPaymentGateway(gatewayData);
      
      res.status(201).json(newGateway);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid payment gateway data", errors: error.errors });
      }
      console.error('Error creating payment gateway:', error);
      res.status(500).json({ message: "Failed to create payment gateway" });
    }
  });

  // Update a payment gateway
  apiRouter.patch('/payment-gateways/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid payment gateway ID" });
      }
      
      // Check if gateway exists
      const existingGateway = await storage.getPaymentGateway(id);
      if (!existingGateway) {
        return res.status(404).json({ message: "Payment gateway not found" });
      }
      
      // Only allow updating certain fields
      const updateData: Partial<PaymentGateway> = {};
      
      if (req.body.displayName !== undefined) updateData.displayName = req.body.displayName;
      if (req.body.isActive !== undefined) updateData.isActive = req.body.isActive;
      if (req.body.isDefault !== undefined) updateData.isDefault = req.body.isDefault;
      if (req.body.configuration !== undefined) updateData.configuration = req.body.configuration;
      if (req.body.supportedCountries !== undefined) updateData.supportedCountries = req.body.supportedCountries;
      if (req.body.supportedCurrencies !== undefined) updateData.supportedCurrencies = req.body.supportedCurrencies;
      if (req.body.minimumAmount !== undefined) updateData.minimumAmount = req.body.minimumAmount;
      if (req.body.processingFee !== undefined) updateData.processingFee = req.body.processingFee;
      if (req.body.processingFeeType !== undefined) updateData.processingFeeType = req.body.processingFeeType;
      if (req.body.adminNotes !== undefined) updateData.adminNotes = req.body.adminNotes;
      
      // Update the payment gateway
      const updatedGateway = await storage.updatePaymentGateway(id, updateData);
      
      res.json(updatedGateway);
    } catch (error) {
      console.error('Error updating payment gateway:', error);
      res.status(500).json({ message: "Failed to update payment gateway" });
    }
  });

  // Toggle payment gateway status (activate/deactivate)
  apiRouter.patch('/payment-gateways/:id/toggle-status', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid payment gateway ID" });
      }
      
      const { isActive } = req.body;
      if (typeof isActive !== 'boolean') {
        return res.status(400).json({ message: "isActive must be a boolean" });
      }
      
      // If deactivating, check if this is the last active gateway
      if (!isActive) {
        const gateway = await storage.getPaymentGateway(id);
        
        if (gateway && gateway.isActive) {
          // Get all active gateways
          const activeGateways = await storage.getPaymentGateways(true);
          
          // If this is the only active gateway, prevent deactivation
          if (activeGateways.length === 1 && activeGateways[0].id === id) {
            return res.status(400).json({
              message: "Cannot deactivate the only active payment gateway. At least one gateway must remain active.",
              code: "LAST_ACTIVE_GATEWAY"
            });
          }
        }
      }
      
      // Toggle the gateway status
      const updatedGateway = await storage.togglePaymentGatewayStatus(id, isActive);
      
      res.json({
        ...updatedGateway,
        message: isActive ? "Payment gateway activated successfully" : "Payment gateway deactivated successfully"
      });
    } catch (error) {
      console.error('Error toggling payment gateway status:', error);
      res.status(500).json({
        message: "Failed to update payment gateway status",
        code: "GATEWAY_UPDATE_ERROR"
      });
    }
  });

  // Set a payment gateway as default
  apiRouter.patch('/payment-gateways/:id/set-default', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid payment gateway ID" });
      }
      
      // Check if the gateway exists and is active
      const gateway = await storage.getPaymentGateway(id);
      if (!gateway) {
        return res.status(404).json({ 
          message: "Payment gateway not found",
          code: "GATEWAY_NOT_FOUND"
        });
      }
      
      // Can't set inactive gateway as default
      if (!gateway.isActive) {
        return res.status(400).json({
          message: "Cannot set an inactive payment gateway as default. Please activate the gateway first.",
          code: "INACTIVE_GATEWAY"
        });
      }
      
      // Set the gateway as default
      const updatedGateway = await storage.setDefaultPaymentGateway(id);
      
      res.json({
        ...updatedGateway,
        message: "Payment gateway has been set as the default payment method."
      });
    } catch (error) {
      console.error('Error setting default payment gateway:', error);
      res.status(500).json({ 
        message: "Failed to set default payment gateway",
        code: "DEFAULT_GATEWAY_ERROR" 
      });
    }
  });

  // =========== Commission Configuration Management ===========
  // Get all commission configurations
  apiRouter.get('/commission-configurations', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      // Extract query parameters
      const isActive = req.query.active === 'true' ? true :
                      req.query.active === 'false' ? false : undefined;
      
      // Fetch commission configurations with optional filter
      const configurations = await storage.getCommissionConfigurations(isActive);
      
      res.json(configurations);
    } catch (error) {
      console.error('Error fetching commission configurations:', error);
      res.status(500).json({ message: "Failed to fetch commission configurations" });
    }
  });

  // Get a specific commission configuration
  apiRouter.get('/commission-configurations/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid commission configuration ID" });
      }
      
      const config = await storage.getCommissionConfiguration(id);
      if (!config) {
        return res.status(404).json({ message: "Commission configuration not found" });
      }
      
      res.json(config);
    } catch (error) {
      console.error('Error fetching commission configuration:', error);
      res.status(500).json({ message: "Failed to fetch commission configuration" });
    }
  });

  // Create a new commission configuration
  apiRouter.post('/commission-configurations', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      // Validate request data
      const configData = insertCommissionConfigurationSchema.parse({
        ...req.body,
        createdBy: user.id
      });
      
      // Create new commission configuration
      const newConfig = await storage.createCommissionConfiguration(configData);
      
      res.status(201).json(newConfig);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid commission configuration data", errors: error.errors });
      }
      console.error('Error creating commission configuration:', error);
      res.status(500).json({ message: "Failed to create commission configuration" });
    }
  });

  // Update a commission configuration
  apiRouter.patch('/commission-configurations/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid commission configuration ID" });
      }
      
      // Check if configuration exists
      const existingConfig = await storage.getCommissionConfiguration(id);
      if (!existingConfig) {
        return res.status(404).json({ message: "Commission configuration not found" });
      }
      
      // Only allow updating certain fields
      const updateData: Partial<CommissionConfiguration> = {};
      
      if (req.body.commissionName !== undefined) updateData.commissionName = req.body.commissionName;
      if (req.body.commissionPercentage !== undefined) updateData.commissionPercentage = req.body.commissionPercentage;
      if (req.body.isActive !== undefined) updateData.isActive = req.body.isActive;
      if (req.body.isDefault !== undefined) updateData.isDefault = req.body.isDefault;
      if (req.body.appliesTo !== undefined) updateData.appliesTo = req.body.appliesTo;
      if (req.body.vehicleTypeIds !== undefined) updateData.vehicleTypeIds = req.body.vehicleTypeIds;
      if (req.body.description !== undefined) updateData.description = req.body.description;
      if (req.body.effectiveFrom !== undefined) updateData.effectiveFrom = req.body.effectiveFrom;
      if (req.body.effectiveTo !== undefined) updateData.effectiveTo = req.body.effectiveTo;
      
      // Update the commission configuration
      const updatedConfig = await storage.updateCommissionConfiguration(id, updateData);
      
      res.json(updatedConfig);
    } catch (error) {
      console.error('Error updating commission configuration:', error);
      res.status(500).json({ message: "Failed to update commission configuration" });
    }
  });

  // Toggle commission configuration status (activate/deactivate)
  apiRouter.patch('/commission-configurations/:id/toggle-status', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid commission configuration ID" });
      }
      
      const { isActive } = req.body;
      if (typeof isActive !== 'boolean') {
        return res.status(400).json({ message: "isActive must be a boolean" });
      }
      
      // Toggle the configuration status
      const updatedConfig = await storage.toggleCommissionConfigurationStatus(id, isActive);
      
      res.json(updatedConfig);
    } catch (error) {
      console.error('Error toggling commission configuration status:', error);
      res.status(500).json({ message: "Failed to update commission configuration status" });
    }
  });

  // Set a commission configuration as default
  apiRouter.patch('/commission-configurations/:id/set-default', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid commission configuration ID" });
      }
      
      // Set the configuration as default
      const updatedConfig = await storage.setDefaultCommissionConfiguration(id);
      
      res.json(updatedConfig);
    } catch (error) {
      console.error('Error setting default commission configuration:', error);
      res.status(500).json({ message: "Failed to set default commission configuration" });
    }
  });

  // Map API Configuration Endpoints
  
  // Get all map API configurations
  apiRouter.get('/map-api-configs', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      // Get all map API configurations from the database
      const configs = await storage.getMapApiConfigurations();
      
      res.json(configs);
    } catch (error) {
      console.error('Error getting map API configurations:', error);
      res.status(500).json({ message: "Failed to get map API configurations" });
    }
  });
  
  // Get a specific map API configuration
  apiRouter.get('/map-api-configs/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid map API configuration ID" });
      }
      
      // Get the map API configuration
      const config = await storage.getMapApiConfiguration(id);
      if (!config) {
        return res.status(404).json({ message: "Map API configuration not found" });
      }
      
      res.json(config);
    } catch (error) {
      console.error('Error getting map API configuration:', error);
      res.status(500).json({ message: "Failed to get map API configuration" });
    }
  });
  
  // Create a new map API configuration
  apiRouter.post('/map-api-configs', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      // Validate request body
      const { provider, apiKey, isActive, isDefault } = req.body;
      if (!provider || !apiKey) {
        return res.status(400).json({ message: "Provider and API key are required" });
      }
      
      // Create the map API configuration
      const newConfig = await storage.createMapApiConfiguration({
        provider,
        apiKey,
        isActive: isActive !== false, // Default to true if not provided
        isDefault: isDefault === true // Default to false if not provided
      });
      
      res.status(201).json(newConfig);
    } catch (error) {
      console.error('Error creating map API configuration:', error);
      res.status(500).json({ message: "Failed to create map API configuration" });
    }
  });
  
  // Update a map API configuration
  apiRouter.patch('/map-api-configs/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid map API configuration ID" });
      }
      
      // Validate request body
      const { provider, apiKey, isActive, isDefault } = req.body;
      if (!provider || !apiKey) {
        return res.status(400).json({ message: "Provider and API key are required" });
      }
      
      // Update the map API configuration
      const updatedConfig = await storage.updateMapApiConfiguration(id, {
        provider,
        apiKey,
        isActive: isActive !== false,
        isDefault: isDefault === true
      });
      
      if (!updatedConfig) {
        return res.status(404).json({ message: "Map API configuration not found" });
      }
      
      res.json(updatedConfig);
    } catch (error) {
      console.error('Error updating map API configuration:', error);
      res.status(500).json({ message: "Failed to update map API configuration" });
    }
  });
  
  // Delete a map API configuration
  apiRouter.delete('/map-api-configs/:id', async (req: Request, res: Response) => {
    try {
      // Check if user is authenticated as admin
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid map API configuration ID" });
      }
      
      // Delete the map API configuration
      const deleted = await storage.deleteMapApiConfiguration(id);
      if (!deleted) {
        return res.status(404).json({ message: "Map API configuration not found" });
      }
      
      res.json({ message: "Map API configuration deleted successfully" });
    } catch (error) {
      console.error('Error deleting map API configuration:', error);
      res.status(500).json({ message: "Failed to delete map API configuration" });
    }
  });
  
  // Get admin dashboard summary
  apiRouter.get('/admin/dashboard-summary', async (req: Request, res: Response) => {
    try {
      // Ensure user is authenticated
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      // Check if user is an admin
      const user = await storage.getUser(req.session.userId);
      if (!user || user.userType !== 'admin') {
        return res.status(403).json({ message: "Not authorized - Admin access required" });
      }

      // Get all users
      const allUsers = await storage.getAllUsers();
      const totalUsers = allUsers.length;
      const activeDrivers = allUsers.filter(u => u.userType === 'delivery' && u.isActive).length;
      
      // Get orders data
      const allOrders = await storage.getAllOrders();
      const pendingOrders = allOrders.filter(o => o.status === 'pending' || o.status === 'assigned' || o.status === 'in_transit').length;
      const completedOrders = allOrders.filter(o => o.status === 'completed').length;
      
      // Calculate total revenue from all orders
      const totalRevenue = allOrders
        .filter(o => o.status === 'completed')
        .reduce((sum, order) => sum + order.totalAmount, 0);
      
      // Generate daily stats for the last 7 days
      const dailyStats = [];
      const today = new Date();
      
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(today.getDate() - i);
        date.setHours(0, 0, 0, 0);
        
        const nextDate = new Date(date);
        nextDate.setDate(date.getDate() + 1);
        
        // Filter orders for this date
        const dayOrders = allOrders.filter(order => {
          const orderDate = new Date(order.createdAt);
          return orderDate >= date && orderDate < nextDate;
        });
        
        // Calculate revenue for this date
        const dayRevenue = dayOrders.reduce((sum, order) => sum + order.totalAmount, 0);
        
        dailyStats.push({
          date: date.toISOString().split('T')[0],
          orders: dayOrders.length,
          revenue: dayRevenue
        });
      }
      
      // Get recent pending orders
      const recentPendingOrders = await Promise.all(
        allOrders
          .filter(o => o.status === 'pending' || o.status === 'assigned' || o.status === 'in_transit')
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, 3)
          .map(async (order) => {
            const customer = await storage.getUser(order.userId);
            return {
              id: `ORD-${order.id.toString().padStart(4, '0')}`,
              customer: customer ? customer.fullName : 'Unknown',
              pickup: order.pickupAddress,
              delivery: order.deliveryAddress,
              status: order.status
            };
          })
      );
      
      // Get top delivery partners
      const deliveryPartners = allUsers.filter(u => u.userType === 'delivery');
      const partnerStats = await Promise.all(
        deliveryPartners.slice(0, 3).map(async (partner) => {
          const partnerOrders = await storage.getOrders(partner.id);
          const completedDeliveries = partnerOrders.filter(o => o.status === 'completed').length;
          
          // Calculate earnings
          const partnerPayments = await storage.getPartnerPayments(partner.id);
          const earnings = partnerPayments.reduce((sum, payment) => sum + payment.finalPayment, 0);
          
          // Calculate rating (placeholder - would need a ratings table in a real implementation)
          const rating = 4.5 + Math.random() * 0.5; // Placeholder rating between 4.5-5.0
          
          return {
            id: partner.id,
            name: partner.fullName,
            deliveries: completedDeliveries,
            rating: parseFloat(rating.toFixed(1)),
            earnings: earnings,
            isActive: partner.isActive
          };
        })
      );
      
      // Get pending document verifications
      const pendingDocuments = deliveryPartners.slice(0, 3).map(partner => ({
        id: partner.id,
        partnerId: partner.id,
        partnerName: partner.fullName,
        documentType: "Driver's License",
        submittedDate: new Date().toISOString().split('T')[0],
        status: "Pending"
      }));
      
      res.json({
        summary: {
          totalUsers,
          activeDrivers,
          pendingOrders,
          completedOrders,
          totalRevenue,
          dailyStats
        },
        pendingOrders: recentPendingOrders,
        partners: partnerStats,
        documents: pendingDocuments
      });
    } catch (error) {
      console.error('Error fetching admin dashboard summary:', error);
      res.status(500).json({ message: "Failed to fetch dashboard summary" });
    }
  });
  
  // Mount the API router
  app.use('/api', apiRouter);
  
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Initialize WebSocket server
  const wss = setupWebSocketServer(httpServer);
  
  return httpServer;
}
