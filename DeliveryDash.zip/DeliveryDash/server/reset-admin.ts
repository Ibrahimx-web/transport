import { storage } from "./storage";
import { db } from "./db";
import { users } from "../shared/schema";
import { eq } from "drizzle-orm";

async function resetAdminUser() {
  try {
    console.log("Resetting admin user...");
    
    // Admin credentials
    const username = "admin";
    const password = "admin123"; // For testing purposes only
    
    // Delete the existing admin user if exists
    console.log("Deleting existing admin user if exists...");
    
    // Find the user first to get the ID
    const existingAdmin = await storage.getUserByUsername(username);
    
    if (existingAdmin) {
      console.log(`Found existing admin user with ID: ${existingAdmin.id}`);
      
      // Delete using Drizzle ORM
      await db.delete(users).where(eq(users.username, username));
      console.log("Existing admin user deleted");
    }
    
    // Create new admin user
    console.log("Creating new admin user...");
    const admin = await storage.createUser({
      username,
      password, // Note: In production, use a proper password hashing library
      fullName: "System Administrator",
      email: "admin@askfortransport.com",
      phone: "+1234567890",
      userType: "admin"
    });
    
    console.log("Admin user reset successfully:", {
      id: admin.id,
      username: admin.username,
      fullName: admin.fullName,
      userType: admin.userType
    });
    
    console.log(`
    =======================
    ADMIN LOGIN CREDENTIALS
    =======================
    Username: ${username}
    Password: ${password}
    =======================
    IMPORTANT: Change this password in production!
    `);
    
  } catch (error) {
    console.error("Error resetting admin user:", error);
  } finally {
    process.exit(0);
  }
}

// Run the function
resetAdminUser();