import { storage } from "./storage";

async function checkAdminCredentials() {
  try {
    // Admin credentials
    const username = "admin";
    const password = "admin123"; // For testing purposes only
    
    // Check if admin exists
    const admin = await storage.getUserByUsername(username);
    
    if (!admin) {
      console.log("Admin user not found!");
      return;
    }
    
    console.log("Admin user found:", {
      id: admin.id,
      username: admin.username,
      password: admin.password, // This will show the stored password for comparison
      fullName: admin.fullName,
      userType: admin.userType
    });
  } catch (error) {
    console.error("Error checking admin credentials:", error);
  } finally {
    process.exit(0);
  }
}

// Run the function
checkAdminCredentials();