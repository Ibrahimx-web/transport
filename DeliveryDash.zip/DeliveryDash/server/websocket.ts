import { Server as HttpServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { storage } from './storage';
import { log } from './vite';

// Connection tracking
interface ConnectedUser {
  userId: number;
  userType: string;
  ws: WebSocket;
  lastSeen: number;
}

// Connected clients
const clients = new Map<number, ConnectedUser>();

// Heartbeat interval (in milliseconds)
const HEARTBEAT_INTERVAL = 30000;
const CLIENT_TIMEOUT = 60000;

// Message types
export enum MessageType {
  CONNECT = 'connect',
  IDENTIFY = 'identify',
  LOCATION_UPDATE = 'location_update', 
  USER_CONNECT = 'user_connect',
  USER_DISCONNECT = 'user_disconnect',
  HEARTBEAT = 'heartbeat',
  HEARTBEAT_ACK = 'heartbeat_ack',
  ERROR = 'error',
}

// WebSocket message interface
export interface WebSocketMessage {
  type: MessageType | string; // Accept string to handle 'identify' type from clients
  userId?: number;  
  userType?: string;
  data?: any;
  timestamp?: number;
}

function setupHeartbeat(wss: WebSocketServer) {
  // Main heartbeat interval
  const interval = setInterval(() => {
    const now = Date.now();
    
    // Send heartbeats and check for inactive clients
    clients.forEach((client, userId) => {
      // Check if client has been inactive for too long
      if (now - client.lastSeen > CLIENT_TIMEOUT) {
        log(`Client ${userId} timed out after ${Math.round((now - client.lastSeen)/1000)}s - closing connection`, 'websocket');
        try {
          client.ws.terminate();
        } catch (err) {
          log(`Error terminating connection for timed out client ${userId}: ${err}`, 'websocket');
        }
        clients.delete(userId);
        // Broadcast disconnect to other users
        broadcastUserDisconnect(userId, client.userType);
        return;
      }
      
      // Send heartbeat if connection is still open
      if (client.ws.readyState === WebSocket.OPEN) {
        try {
          client.ws.send(JSON.stringify({
            type: MessageType.HEARTBEAT,
            timestamp: now
          }));
          log(`Heartbeat sent to user ${userId}`, 'websocket');
        } catch (error) {
          log(`Error sending heartbeat to user ${userId}: ${error}`, 'websocket');
          // Handle potential socket errors by cleaning up
          try {
            client.ws.terminate();
          } catch (err) {
            // Ignore errors during termination
          }
          clients.delete(userId);
          broadcastUserDisconnect(userId, client.userType);
        }
      } else if (client.ws.readyState !== WebSocket.CONNECTING) {
        // Connection is not open or connecting, cleanup
        log(`Client ${userId} has invalid state (${client.ws.readyState}), removing`, 'websocket');
        try {
          client.ws.terminate();
        } catch (err) {
          // Ignore errors during termination
        }
        clients.delete(userId);
        broadcastUserDisconnect(userId, client.userType);
      }
    });
  }, HEARTBEAT_INTERVAL);

  // Clean up on server close
  wss.on('close', () => {
    clearInterval(interval);
    
    // Terminate all clients when server closes
    clients.forEach((client, userId) => {
      try {
        client.ws.terminate();
        log(`Terminated connection for user ${userId} due to server shutdown`, 'websocket');
      } catch (err) {
        // Ignore errors during termination
      }
    });
    
    // Clear clients map
    clients.clear();
  });
}

// Utility function to safely send a message to a client
function safeSend(client: ConnectedUser, message: string | object) {
  if (client.ws.readyState !== WebSocket.OPEN) {
    return false;
  }
  
  try {
    const messageStr = typeof message === 'string' ? message : JSON.stringify(message);
    client.ws.send(messageStr);
    return true;
  } catch (error) {
    log(`Error sending message to user ${client.userId}: ${error}`, 'websocket');
    
    // If sending fails, the connection might be in a bad state
    try {
      client.ws.terminate();
    } catch (err) {
      // Ignore errors during termination
    }
    
    // Remove the client from our tracking
    clients.delete(client.userId);
    return false;
  }
}

function broadcastUserConnect(userId: number, userType: string) {
  const message: WebSocketMessage = {
    type: MessageType.USER_CONNECT,
    userId,
    userType,
    timestamp: Date.now()
  };
  
  let successCount = 0;
  clients.forEach((client) => {
    if (client.userId !== userId && safeSend(client, message)) {
      successCount++;
    }
  });
  
  log(`Broadcasted user connect event for ${userId} to ${successCount} clients`, 'websocket');
}

function broadcastUserDisconnect(userId: number, userType: string) {
  const message: WebSocketMessage = {
    type: MessageType.USER_DISCONNECT,
    userId,
    userType,
    timestamp: Date.now()
  };
  
  let successCount = 0;
  clients.forEach((client) => {
    if (client.userId !== userId && safeSend(client, message)) {
      successCount++;
    }
  });
  
  log(`Broadcasted user disconnect event for ${userId} to ${successCount} clients`, 'websocket');
}

function broadcastLocationUpdate(userId: number, userType: string, location: { lat: number, lng: number }) {
  const message: WebSocketMessage = {
    type: MessageType.LOCATION_UPDATE,
    userId,
    userType,
    data: location,
    timestamp: Date.now()
  };
  
  let successCount = 0;
  clients.forEach((client) => {
    // Don't send location updates back to the sender
    if (client.userId !== userId && safeSend(client, message)) {
      successCount++;
    }
  });
  
  if (successCount > 0) {
    log(`Broadcasted location update for ${userId} to ${successCount} clients`, 'websocket');
  }
}

export function setupWebSocketServer(httpServer: HttpServer) {
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  log('WebSocket server initialized', 'websocket');
  
  // Set up the heartbeat mechanism
  setupHeartbeat(wss);
  
  // Track connection attempts to limit potential abuse
  const connectionAttempts = new Map<string, { count: number, lastAttempt: number }>();
  const MAX_CONNECTIONS_PER_MINUTE = 400; // Rate limit connections - increased for development
  const CONNECTION_TRACKING_WINDOW = 60000; // 1 minute

  wss.on('connection', (ws, req) => {
    let userId: number | null = null;
    let userType: string | null = null;
    
    // Get client IP for rate limiting
    const ip = req.socket.remoteAddress || 'unknown';
    
    // Check for connection rate limits
    const now = Date.now();
    if (connectionAttempts.has(ip)) {
      const attempt = connectionAttempts.get(ip)!;
      
      // Reset counter if window has expired
      if (now - attempt.lastAttempt > CONNECTION_TRACKING_WINDOW) {
        attempt.count = 1;
        attempt.lastAttempt = now;
      } else {
        // Increment counter
        attempt.count++;
        attempt.lastAttempt = now;
        
        // Check if rate limit is exceeded
        if (attempt.count > MAX_CONNECTIONS_PER_MINUTE) {
          log(`Rate limit exceeded for ${ip}: ${attempt.count} connections in < 1 minute`, 'websocket');
          ws.close(1008, 'Too many connection attempts');
          return;
        }
      }
    } else {
      // First connection from this IP
      connectionAttempts.set(ip, { count: 1, lastAttempt: now });
    }
    
    // Clean up old connection tracking entries every 5 minutes
    if (connectionAttempts.size > 1000) {
      const cutoff = now - CONNECTION_TRACKING_WINDOW;
      connectionAttempts.forEach((value, key) => {
        if (value.lastAttempt < cutoff) {
          connectionAttempts.delete(key);
        }
      });
    }
    
    log('New WebSocket connection established', 'websocket');
    
    // Set a connection timeout if client doesn't identify within 10 seconds
    const identifyTimeout = setTimeout(() => {
      if (!userId && ws.readyState === WebSocket.OPEN) {
        log('Client did not identify within timeout period', 'websocket');
        ws.close(1000, 'Identification timeout');
      }
    }, 10000);
    
    ws.on('message', async (message) => {
      try {
        // Basic size check to prevent DoS
        if (message.toString().length > 4096) {
          log(`Oversized message rejected: ${message.toString().length} bytes`, 'websocket');
          ws.close(1009, 'Message too large');
          return;
        }
        
        const msg = JSON.parse(message.toString()) as WebSocketMessage;
        
        // Always update lastSeen timestamp on any message
        if (userId && clients.has(userId)) {
          const client = clients.get(userId)!;
          client.lastSeen = Date.now();
        }
        
        switch (msg.type) {
          case 'identify': // Using string literal to match client-side usage
          case MessageType.CONNECT:
            if (msg.userId) {
              userId = msg.userId;
              userType = msg.userType || 'unknown';
              
              // Remove any existing connection for this user
              if (clients.has(userId)) {
                const existingClient = clients.get(userId)!;
                if (existingClient.ws && existingClient.ws.readyState === WebSocket.OPEN) {
                  existingClient.ws.close();
                  log(`Closing previous connection for user ${userId}`, 'websocket');
                }
              }
              
              // Store client connection
              clients.set(userId, {
                userId,
                userType: userType,
                ws,
                lastSeen: Date.now()
              });
              
              log(`User ${userId} (${userType}) connected via WebSocket`, 'websocket');
              
              // Notify other clients about the new connection
              broadcastUserConnect(userId, userType);
              
              // Send confirmation to the client
              safeSend({
                userId,
                userType,
                ws,
                lastSeen: Date.now()
              }, {
                type: MessageType.CONNECT,
                userId,
                userType,
                data: { success: true },
                timestamp: Date.now()
              });
            }
            break;
            
          case MessageType.LOCATION_UPDATE:
            if (userId && msg.data) {
              const { lat, lng } = msg.data;
              
              // Update user's location in the database
              if (userType === 'delivery' && typeof lat === 'number' && typeof lng === 'number') {
                await storage.updateUserAvailability(userId, {
                  isAvailable: true,  // Assume available if they're sending location updates
                  currentLat: lat,
                  currentLng: lng
                });
                
                log(`Updated location for user ${userId}: ${lat}, ${lng}`, 'websocket');
                
                // Broadcast location update to other clients
                broadcastLocationUpdate(userId, userType, { lat, lng });
              }
            }
            break;
            
          case MessageType.HEARTBEAT:
            // Client sent a heartbeat, respond with ack
            if (userId && clients.has(userId)) {
              safeSend(clients.get(userId)!, {
                type: MessageType.HEARTBEAT_ACK,
                timestamp: Date.now()
              });
              log(`Heartbeat received from user ${userId}, sent ack`, 'websocket');
            }
            break;
            
          case MessageType.HEARTBEAT_ACK:
            // Client acknowledged our heartbeat
            if (userId) {
              log(`Heartbeat ack received from user ${userId}`, 'websocket');
            }
            break;
            
          default:
            log(`Unknown message type: ${msg.type}`, 'websocket');
        }
      } catch (error) {
        log(`Error processing WebSocket message: ${error}`, 'websocket');
        
        // Only try to send an error message if we have a valid connection
        if (ws.readyState === WebSocket.OPEN) {
          try {
            ws.send(JSON.stringify({
              type: MessageType.ERROR,
              data: { message: 'Invalid message format' },
              timestamp: Date.now()
            }));
          } catch (sendError) {
            log(`Error sending error message: ${sendError}`, 'websocket');
          }
        }
      }
    });
    
    ws.on('close', (code, reason) => {
      // Clear the identification timeout if it exists
      if (identifyTimeout) {
        clearTimeout(identifyTimeout);
      }
      
      if (userId) {
        log(`WebSocket connection closed for user ${userId} with code ${code} and reason: ${reason}`, 'websocket');
        
        // Check if this client is still in our map
        if (clients.has(userId)) {
          const client = clients.get(userId)!;
          
          // Only delete if this is the same connection that's registered
          if (client.ws === ws) {
            clients.delete(userId);
            if (userType) {
              broadcastUserDisconnect(userId, userType);
            }
          } else {
            log(`Ignoring close for outdated connection of user ${userId}`, 'websocket');
          }
        }
      } else {
        log(`WebSocket connection closed for unknown user with code ${code} and reason: ${reason}`, 'websocket');
      }
    });
    
    ws.on('error', (error) => {
      log(`WebSocket error: ${error}`, 'websocket');
    });
  });
  
  return wss;
}

// Utility to get all connected clients for admin purposes
export function getConnectedClients() {
  const result: { userId: number; userType: string; lastSeen: number }[] = [];
  
  clients.forEach((client) => {
    result.push({
      userId: client.userId,
      userType: client.userType,
      lastSeen: client.lastSeen
    });
  });
  
  return result;
}