import { storage } from "./storage";
import { vehicleTypes } from "../shared/schema";
import { db } from "./db";

async function seedVehicleTypes() {
  try {
    console.log("Checking existing vehicle types...");
    const existingVehicleTypes = await storage.getVehicleTypes();
    
    if (existingVehicleTypes.length > 0) {
      console.log(`Found ${existingVehicleTypes.length} existing vehicle types. Skipping seed.`);
      console.log("Existing vehicle types:", existingVehicleTypes);
      return;
    }
    
    console.log("Seeding vehicle types...");
    
    const vehicleTypesToSeed = [
      {
        name: "Bike",
        icon: "🚲",
        maxWeight: 5.0,
        baseFare: 3.0
      },
      {
        name: "Motorbike",
        icon: "🛵",
        maxWeight: 20.0,
        baseFare: 5.0
      },
      {
        name: "Car",
        icon: "🚗",
        maxWeight: 100.0,
        baseFare: 8.0
      },
      {
        name: "Pickup",
        icon: "🛻",
        maxWeight: 500.0,
        baseFare: 15.0
      },
      {
        name: "Van",
        icon: "🚐",
        maxWeight: 800.0,
        baseFare: 20.0
      },
      {
        name: "Lorry",
        icon: "🚚",
        maxWeight: 5000.0,
        baseFare: 40.0
      },
      {
        name: "Motor Breakdown",
        icon: "🚨",
        maxWeight: 3000.0,
        baseFare: 30.0
      }
    ];
    
    for (const vehicleType of vehicleTypesToSeed) {
      await storage.createVehicleType(vehicleType);
      console.log(`Created vehicle type: ${vehicleType.name}`);
    }
    
    console.log("Vehicle types seeded successfully!");
    
    // Display seeded vehicle types
    const seededVehicleTypes = await storage.getVehicleTypes();
    console.log("Seeded vehicle types:", seededVehicleTypes);
    
  } catch (error) {
    console.error("Error seeding vehicle types:", error);
  }
}

async function seed() {
  try {
    console.log("Starting database seed...");
    
    // Seed vehicle types
    await seedVehicleTypes();
    
    console.log("Database seed completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  } finally {
    process.exit(0);
  }
}

// Run the seed function
seed();