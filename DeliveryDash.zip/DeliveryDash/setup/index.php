<?php
/**
 * Ask for Transport - Installation Wizard
 * This script helps you set up the Ask for Transport system on cPanel hosting
 */

// Define setup steps
$steps = [
    1 => 'Database Configuration',
    2 => 'API Keys Configuration',
    3 => 'Admin User Setup',
    4 => 'File Permissions',
    5 => 'Installation'
];

// Determine current step
$currentStep = isset($_GET['step']) ? (int)$_GET['step'] : 1;
if ($currentStep < 1 || $currentStep > count($steps)) {
    $currentStep = 1;
}

// Initialize variables
$error = '';
$success = '';

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    switch ($currentStep) {
        case 1: // Database configuration
            // Validate database connection
            $dbHost = $_POST['db_host'] ?? '';
            $dbName = $_POST['db_name'] ?? '';
            $dbUser = $_POST['db_user'] ?? '';
            $dbPass = $_POST['db_pass'] ?? '';
            
            if (empty($dbHost) || empty($dbName) || empty($dbUser)) {
                $error = 'Please fill in all the database fields.';
            } else {
                // Test database connection
                try {
                    $dsn = "pgsql:host=$dbHost;dbname=$dbName";
                    $pdo = new PDO($dsn, $dbUser, $dbPass);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    
                    // Save settings in session
                    session_start();
                    $_SESSION['db_config'] = [
                        'host' => $dbHost,
                        'name' => $dbName,
                        'user' => $dbUser,
                        'pass' => $dbPass
                    ];
                    session_write_close();
                    
                    // Redirect to next step
                    header('Location: index.php?step=2');
                    exit;
                } catch (PDOException $e) {
                    $error = 'Database connection failed: ' . $e->getMessage();
                }
            }
            break;
            
        case 2: // API Keys configuration
            // Save API keys
            session_start();
            $_SESSION['api_keys'] = [
                'google_maps' => $_POST['google_maps_key'] ?? '',
                'openai' => $_POST['openai_key'] ?? '',
                'anthropic' => $_POST['anthropic_key'] ?? '',
                'stripe' => $_POST['stripe_key'] ?? '',
                'stripe_public' => $_POST['stripe_public_key'] ?? ''
            ];
            session_write_close();
            
            // Redirect to next step
            header('Location: index.php?step=3');
            exit;
            break;
            
        case 3: // Admin User Setup
            $adminUser = $_POST['admin_username'] ?? '';
            $adminPass = $_POST['admin_password'] ?? '';
            $adminName = $_POST['admin_name'] ?? '';
            $adminEmail = $_POST['admin_email'] ?? '';
            $adminPhone = $_POST['admin_phone'] ?? '';
            
            if (empty($adminUser) || empty($adminPass) || empty($adminName) || empty($adminEmail)) {
                $error = 'Please fill in all the admin user fields.';
            } else {
                // Save admin user info
                session_start();
                $_SESSION['admin_user'] = [
                    'username' => $adminUser,
                    'password' => $adminPass,
                    'fullName' => $adminName,
                    'email' => $adminEmail,
                    'phone' => $adminPhone
                ];
                session_write_close();
                
                // Redirect to next step
                header('Location: index.php?step=4');
                exit;
            }
            break;
            
        case 4: // File Permissions
            // Check file permissions
            $permissionsOk = true;
            $directories = [
                '../uploads',
                '../config'
            ];
            
            // Ensure directories exist and are writable
            foreach ($directories as $dir) {
                if (!file_exists($dir)) {
                    mkdir($dir, 0755, true);
                }
                if (!is_writable($dir)) {
                    $permissionsOk = false;
                    $error .= "Directory not writable: $dir<br>";
                }
            }
            
            if ($permissionsOk) {
                // Redirect to next step
                header('Location: index.php?step=5');
                exit;
            }
            break;
            
        case 5: // Installation
            session_start();
            
            // Create config files
            if (isset($_SESSION['db_config']) && isset($_SESSION['api_keys']) && isset($_SESSION['admin_user'])) {
                $dbConfig = $_SESSION['db_config'];
                $apiKeys = $_SESSION['api_keys'];
                $adminUser = $_SESSION['admin_user'];
                
                // Create .env file
                $envFile = "../.env";
                $envContent = "
# Database Configuration
DB_HOST={$dbConfig['host']}
DB_NAME={$dbConfig['name']}
DB_USER={$dbConfig['user']}
DB_PASS={$dbConfig['pass']}
DATABASE_URL=postgres://{$dbConfig['user']}:{$dbConfig['pass']}@{$dbConfig['host']}:5432/{$dbConfig['name']}

# API Keys
GOOGLE_MAPS_API_KEY={$apiKeys['google_maps']}
OPENAI_API_KEY={$apiKeys['openai']}
ANTHROPIC_API_KEY={$apiKeys['anthropic']}
STRIPE_SECRET_KEY={$apiKeys['stripe']}
VITE_STRIPE_PUBLIC_KEY={$apiKeys['stripe_public']}

# Application Settings
SESSION_SECRET=" . bin2hex(random_bytes(32)) . "
APP_ENV=production
APP_URL=" . $_SERVER['HTTP_HOST'] . "
";
                file_put_contents($envFile, $envContent);
                
                // Create admin-config.json
                $adminConfig = [
                    'adminUsername' => $adminUser['username'],
                    'adminPassword' => password_hash($adminUser['password'], PASSWORD_DEFAULT),
                    'adminName' => $adminUser['fullName'],
                    'adminEmail' => $adminUser['email'],
                    'adminPhone' => $adminUser['phone'],
                    'installDate' => date('Y-m-d H:i:s')
                ];
                
                file_put_contents('../config/admin-config.json', json_encode($adminConfig, JSON_PRETTY_PRINT));
                
                // Create install-complete flag
                file_put_contents('../config/install-complete', date('Y-m-d H:i:s'));
                
                $success = "Installation completed successfully! You can now <a href='../'>access your Ask for Transport application</a>.";
                
                // Clear session
                session_destroy();
            } else {
                $error = "Missing configuration data. Please complete all previous steps.";
            }
            break;
    }
}

// Function to check if a step is completed
function isStepCompleted($step) {
    session_start();
    $completed = false;
    
    switch ($step) {
        case 1:
            $completed = isset($_SESSION['db_config']);
            break;
        case 2:
            $completed = isset($_SESSION['api_keys']);
            break;
        case 3:
            $completed = isset($_SESSION['admin_user']);
            break;
        case 4:
            $completed = isset($_SESSION['file_permissions_ok']) && $_SESSION['file_permissions_ok'];
            break;
    }
    
    session_write_close();
    return $completed;
}

// Get progress percentage
$progress = (($currentStep - 1) / count($steps)) * 100;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ask for Transport - Installation Wizard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #3b82f6;
            --primary-hover: #2563eb;
        }
        body {
            background-color: #f8f9fa;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        }
        .wizard-container {
            max-width: 850px;
            margin: 2rem auto;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            background: white;
        }
        .wizard-header {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
            color: white;
            padding: 2rem;
            border-radius: 10px 10px 0 0;
            text-align: center;
        }
        .wizard-header h1 {
            font-weight: 700;
            margin: 0;
            font-size: 1.8rem;
        }
        .wizard-content {
            padding: 2rem;
        }
        .steps {
            margin-bottom: 2rem;
        }
        .step-item {
            display: flex;
            align-items: center;
            margin-bottom: 0.5rem;
            opacity: 0.6;
        }
        .step-item.active {
            opacity: 1;
            font-weight: 600;
        }
        .step-item.completed {
            opacity: 0.8;
        }
        .step-number {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #dee2e6;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            font-weight: 600;
        }
        .step-item.active .step-number {
            background-color: var(--primary-color);
            color: white;
        }
        .step-item.completed .step-number {
            background-color: #28a745;
            color: white;
        }
        .step-item.completed .step-number::after {
            content: "✓";
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
        }
        .progress {
            height: 8px;
            margin-top: 1rem;
        }
        .requirement-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .status-icon {
            font-weight: bold;
        }
        .status-success {
            color: #28a745;
        }
        .status-error {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="wizard-container">
        <div class="wizard-header">
            <h1>Ask for Transport - Installation Wizard</h1>
            <p class="mb-0">Set up your transportation platform in minutes</p>
            <div class="progress mt-3">
                <div class="progress-bar" role="progressbar" style="width: <?php echo $progress; ?>%" aria-valuenow="<?php echo $progress; ?>" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
        
        <div class="wizard-content">
            <div class="row">
                <div class="col-md-4">
                    <div class="steps">
                        <?php foreach ($steps as $stepNum => $stepName): ?>
                            <div class="step-item <?php echo $stepNum === $currentStep ? 'active' : ($stepNum < $currentStep ? 'completed' : ''); ?>">
                                <span class="step-number"><?php echo $stepNum < $currentStep ? '' : $stepNum; ?></span>
                                <span class="step-text"><?php echo $stepName; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <?php if ($currentStep === 1): ?>
                        <!-- Database Configuration -->
                        <h3>Database Configuration</h3>
                        <p>Please enter your database credentials. These will be used to connect to your PostgreSQL database.</p>
                        
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="db_host" class="form-label">Database Host</label>
                                <input type="text" class="form-control" id="db_host" name="db_host" value="localhost" required>
                                <small class="text-muted">Usually "localhost" or provided by your hosting company</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="db_name" class="form-label">Database Name</label>
                                <input type="text" class="form-control" id="db_name" name="db_name" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="db_user" class="form-label">Database Username</label>
                                <input type="text" class="form-control" id="db_user" name="db_user" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="db_pass" class="form-label">Database Password</label>
                                <input type="password" class="form-control" id="db_pass" name="db_pass">
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Continue to API Configuration</button>
                            </div>
                        </form>
                        
                    <?php elseif ($currentStep === 2): ?>
                        <!-- API Keys Configuration -->
                        <h3>API Keys Configuration</h3>
                        <p>Enter your API keys for the services used by Ask for Transport. You can update these later in the admin panel.</p>
                        
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="google_maps_key" class="form-label">Google Maps API Key</label>
                                <input type="text" class="form-control" id="google_maps_key" name="google_maps_key">
                                <small class="text-muted">Required for maps and location services. <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">Get a key</a></small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="openai_key" class="form-label">OpenAI API Key</label>
                                <input type="text" class="form-control" id="openai_key" name="openai_key">
                                <small class="text-muted">Used for package recommendations. <a href="https://platform.openai.com/signup" target="_blank">Sign up for OpenAI</a></small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="anthropic_key" class="form-label">Anthropic API Key</label>
                                <input type="text" class="form-control" id="anthropic_key" name="anthropic_key">
                                <small class="text-muted">Alternative AI provider. <a href="https://www.anthropic.com/" target="_blank">Learn more</a></small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="stripe_key" class="form-label">Stripe Secret Key</label>
                                <input type="text" class="form-control" id="stripe_key" name="stripe_key">
                                <small class="text-muted">For payment processing. <a href="https://dashboard.stripe.com/apikeys" target="_blank">Get Stripe keys</a></small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="stripe_public_key" class="form-label">Stripe Public Key</label>
                                <input type="text" class="form-control" id="stripe_public_key" name="stripe_public_key">
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Continue to Admin Setup</button>
                            </div>
                        </form>
                        
                    <?php elseif ($currentStep === 3): ?>
                        <!-- Admin User Setup -->
                        <h3>Admin User Setup</h3>
                        <p>Create your administrator account to manage the Ask for Transport system.</p>
                        
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="admin_username" class="form-label">Admin Username</label>
                                <input type="text" class="form-control" id="admin_username" name="admin_username" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="admin_password" class="form-label">Admin Password</label>
                                <input type="password" class="form-control" id="admin_password" name="admin_password" required>
                                <small class="text-muted">Use a strong password with at least 8 characters</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="admin_name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="admin_name" name="admin_name" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="admin_email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="admin_email" name="admin_email" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="admin_phone" class="form-label">Phone Number</label>
                                <input type="text" class="form-control" id="admin_phone" name="admin_phone">
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Continue to File Permissions</button>
                            </div>
                        </form>
                        
                    <?php elseif ($currentStep === 4): ?>
                        <!-- File Permissions Check -->
                        <h3>File Permissions Check</h3>
                        <p>The installer will check if your server has the correct permissions to run Ask for Transport.</p>
                        
                        <?php
                        // Check requirements
                        $requirements = [
                            'PHP Version (>= 8.0)' => [
                                'status' => version_compare(PHP_VERSION, '8.0.0', '>='),
                                'value' => PHP_VERSION
                            ],
                            'PDO Extension' => [
                                'status' => extension_loaded('pdo'),
                                'value' => extension_loaded('pdo') ? 'Enabled' : 'Disabled'
                            ],
                            'PostgreSQL Extension' => [
                                'status' => extension_loaded('pgsql'),
                                'value' => extension_loaded('pgsql') ? 'Enabled' : 'Disabled'
                            ],
                            'JSON Extension' => [
                                'status' => extension_loaded('json'),
                                'value' => extension_loaded('json') ? 'Enabled' : 'Disabled'
                            ],
                            'cURL Extension' => [
                                'status' => extension_loaded('curl'),
                                'value' => extension_loaded('curl') ? 'Enabled' : 'Disabled'
                            ],
                            'Uploads Directory Writable' => [
                                'status' => is_dir('../uploads') ? is_writable('../uploads') : is_writable('..'),
                                'value' => is_dir('../uploads') ? (is_writable('../uploads') ? 'Writable' : 'Not Writable') : 'Will be created'
                            ],
                            'Config Directory Writable' => [
                                'status' => is_dir('../config') ? is_writable('../config') : is_writable('..'),
                                'value' => is_dir('../config') ? (is_writable('../config') ? 'Writable' : 'Not Writable') : 'Will be created'
                            ]
                        ];
                        
                        $allRequirementsMet = true;
                        foreach ($requirements as $requirement) {
                            if (!$requirement['status']) {
                                $allRequirementsMet = false;
                                break;
                            }
                        }
                        ?>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                System Requirements
                            </div>
                            <div class="card-body p-0">
                                <ul class="list-group list-group-flush">
                                    <?php foreach ($requirements as $name => $requirement): ?>
                                    <li class="list-group-item">
                                        <div class="requirement-item">
                                            <span><?php echo $name; ?></span>
                                            <span class="d-flex align-items-center">
                                                <span class="me-2"><?php echo $requirement['value']; ?></span>
                                                <?php if ($requirement['status']): ?>
                                                    <span class="status-icon status-success">✓</span>
                                                <?php else: ?>
                                                    <span class="status-icon status-error">✗</span>
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                        
                        <form method="post" action="">
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary" <?php echo !$allRequirementsMet ? 'disabled' : ''; ?>>
                                    <?php echo $allRequirementsMet ? 'Continue to Installation' : 'System Requirements Not Met'; ?>
                                </button>
                                
                                <?php if (!$allRequirementsMet): ?>
                                <div class="alert alert-warning mt-3">
                                    Please fix the issues above before continuing. Contact your hosting provider for assistance.
                                </div>
                                <?php endif; ?>
                            </div>
                        </form>
                        
                    <?php elseif ($currentStep === 5): ?>
                        <!-- Installation -->
                        <h3>Installation</h3>
                        <p>The installer will now set up Ask for Transport with your configuration.</p>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                Installation Process
                            </div>
                            <div class="card-body">
                                <ul class="list-group list-group-flush" id="installation-steps">
                                    <li class="list-group-item">
                                        <div class="requirement-item">
                                            <span>Creating configuration files</span>
                                            <span class="status-icon status-success">✓</span>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="requirement-item">
                                            <span>Setting up admin account</span>
                                            <span class="status-icon status-success">✓</span>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="requirement-item">
                                            <span>Creating required directories</span>
                                            <span class="status-icon status-success">✓</span>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="requirement-item">
                                            <span>Finalizing installation</span>
                                            <span class="status-icon status-success">✓</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        
                        <?php if (!$success): ?>
                        <form method="post" action="">
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Complete Installation</button>
                            </div>
                        </form>
                        <?php else: ?>
                        <div class="d-grid gap-2">
                            <a href="../admin/dashboard" class="btn btn-primary">Go to Admin Dashboard</a>
                            <a href="../" class="btn btn-outline-primary">Visit Homepage</a>
                        </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center text-muted mt-4 mb-5">
        <p>&copy; <?php echo date('Y'); ?> Ask for Transport. All rights reserved.</p>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>