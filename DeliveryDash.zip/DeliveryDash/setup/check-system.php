<?php
/**
 * Ask for Transport - System Checker
 * This script checks if the system is properly configured and helps diagnose issues
 */

// Check PHP version and extensions
function checkPhpRequirements() {
    $requirements = [
        'PHP Version' => [
            'required' => '8.0.0',
            'current' => PHP_VERSION,
            'status' => version_compare(PHP_VERSION, '8.0.0', '>=')
        ],
        'PDO Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('pdo') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('pdo')
        ],
        'PDO PostgreSQL Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('pdo_pgsql') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('pdo_pgsql')
        ],
        'JSON Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('json') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('json')
        ],
        'cURL Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('curl') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('curl')
        ],
        'OpenSSL Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('openssl') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('openssl')
        ],
        'Fileinfo Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('fileinfo') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('fileinfo')
        ],
        'Zip Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('zip') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('zip')
        ]
    ];
    
    return $requirements;
}

// Check server information
function checkServerInfo() {
    $serverInfo = [
        'Server Software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'Server Name' => $_SERVER['SERVER_NAME'] ?? 'Unknown',
        'Server Address' => $_SERVER['SERVER_ADDR'] ?? 'Unknown',
        'Server Protocol' => $_SERVER['SERVER_PROTOCOL'] ?? 'Unknown',
        'Request Method' => $_SERVER['REQUEST_METHOD'] ?? 'Unknown',
        'Request Time' => date('Y-m-d H:i:s', $_SERVER['REQUEST_TIME'] ?? time()),
        'Document Root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown',
        'HTTP Host' => $_SERVER['HTTP_HOST'] ?? 'Unknown'
    ];
    
    return $serverInfo;
}

// Check file permissions
function checkFilePermissions() {
    $rootDir = realpath('../');
    $directories = [
        'Root Directory' => $rootDir,
        'Config Directory' => "$rootDir/config",
        'Uploads Directory' => "$rootDir/uploads",
        'Assets Directory' => "$rootDir/assets"
    ];
    
    $results = [];
    
    foreach ($directories as $name => $path) {
        $exists = file_exists($path);
        $isDir = is_dir($path);
        $isWritable = is_writable($path);
        
        $results[$name] = [
            'path' => $path,
            'exists' => $exists,
            'is_dir' => $isDir,
            'is_writable' => $isWritable,
            'status' => $exists && $isDir && $isWritable
        ];
    }
    
    return $results;
}

// Check environment variables
function checkEnvironmentVariables() {
    $envFile = '../.env';
    $requiredVars = [
        'DB_HOST' => 'Database Host',
        'DB_NAME' => 'Database Name',
        'DB_USER' => 'Database User',
        'DB_PASS' => 'Database Password',
        'DATABASE_URL' => 'Database URL',
        'SESSION_SECRET' => 'Session Secret',
        'GOOGLE_MAPS_API_KEY' => 'Google Maps API Key',
        'OPENAI_API_KEY' => 'OpenAI API Key',
        'ANTHROPIC_API_KEY' => 'Anthropic API Key',
        'STRIPE_SECRET_KEY' => 'Stripe Secret Key',
        'VITE_STRIPE_PUBLIC_KEY' => 'Stripe Public Key'
    ];
    
    $results = [
        'env_file_exists' => file_exists($envFile)
    ];
    
    if ($results['env_file_exists']) {
        $envContent = file_get_contents($envFile);
        
        foreach ($requiredVars as $key => $description) {
            // Match variable in the .env file
            preg_match("/^$key=(.*)$/m", $envContent, $matches);
            $exists = !empty($matches);
            $hasValue = $exists && !empty($matches[1]);
            
            $results['variables'][$key] = [
                'description' => $description,
                'exists' => $exists,
                'has_value' => $hasValue,
                'status' => $hasValue
            ];
        }
    }
    
    return $results;
}

// Check database connection
function checkDatabaseConnection() {
    $envFile = '../.env';
    
    if (!file_exists($envFile)) {
        return ['status' => false, 'message' => '.env file not found'];
    }
    
    $envContent = file_get_contents($envFile);
    
    // Extract database connection variables
    preg_match("/^DB_HOST=(.*)$/m", $envContent, $hostMatches);
    preg_match("/^DB_NAME=(.*)$/m", $envContent, $dbNameMatches);
    preg_match("/^DB_USER=(.*)$/m", $envContent, $userMatches);
    preg_match("/^DB_PASS=(.*)$/m", $envContent, $passMatches);
    
    $host = $hostMatches[1] ?? null;
    $dbName = $dbNameMatches[1] ?? null;
    $user = $userMatches[1] ?? null;
    $pass = $passMatches[1] ?? null;
    
    if (!$host || !$dbName || !$user) {
        return ['status' => false, 'message' => 'Missing database configuration in .env file'];
    }
    
    try {
        $dsn = "pgsql:host=$host;dbname=$dbName";
        $pdo = new PDO($dsn, $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Check tables
        $tables = [];
        $stmt = $pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $tables[] = $row['table_name'];
        }
        
        // Required tables
        $requiredTables = [
            'users',
            'vehicle_types',
            'orders',
            'order_status_updates',
            'partner_documents',
            'payments',
            'partner_payments',
            'payment_gateways',
            'commission_configurations',
            'map_api_configs',
            'auto_payment_settings'
        ];
        
        $missingTables = array_diff($requiredTables, $tables);
        
        return [
            'status' => empty($missingTables),
            'connection' => true,
            'tables' => $tables,
            'missing_tables' => $missingTables
        ];
    } catch (PDOException $e) {
        return [
            'status' => false,
            'connection' => false,
            'message' => $e->getMessage()
        ];
    }
}

// Check API key validity (basic checks only)
function checkApiKeys() {
    $envFile = '../.env';
    
    if (!file_exists($envFile)) {
        return ['status' => false, 'message' => '.env file not found'];
    }
    
    $envContent = file_get_contents($envFile);
    
    // Extract API keys
    preg_match("/^GOOGLE_MAPS_API_KEY=(.*)$/m", $envContent, $googleMatches);
    preg_match("/^OPENAI_API_KEY=(.*)$/m", $envContent, $openaiMatches);
    preg_match("/^ANTHROPIC_API_KEY=(.*)$/m", $envContent, $anthropicMatches);
    preg_match("/^STRIPE_SECRET_KEY=(.*)$/m", $envContent, $stripeMatches);
    preg_match("/^VITE_STRIPE_PUBLIC_KEY=(.*)$/m", $envContent, $stripePublicMatches);
    
    $googleKey = $googleMatches[1] ?? '';
    $openaiKey = $openaiMatches[1] ?? '';
    $anthropicKey = $anthropicMatches[1] ?? '';
    $stripeKey = $stripeMatches[1] ?? '';
    $stripePublicKey = $stripePublicMatches[1] ?? '';
    
    // Basic format checks
    $results = [
        'Google Maps API Key' => [
            'exists' => !empty($googleKey),
            'format_valid' => strlen($googleKey) > 20,
            'key_prefix' => substr($googleKey, 0, 5) . '...'
        ],
        'OpenAI API Key' => [
            'exists' => !empty($openaiKey),
            'format_valid' => preg_match('/^sk-/', $openaiKey),
            'key_prefix' => substr($openaiKey, 0, 5) . '...'
        ],
        'Anthropic API Key' => [
            'exists' => !empty($anthropicKey),
            'format_valid' => strlen($anthropicKey) > 10,
            'key_prefix' => substr($anthropicKey, 0, 5) . '...'
        ],
        'Stripe Secret Key' => [
            'exists' => !empty($stripeKey),
            'format_valid' => preg_match('/^sk_/', $stripeKey),
            'key_prefix' => substr($stripeKey, 0, 5) . '...'
        ],
        'Stripe Public Key' => [
            'exists' => !empty($stripePublicKey),
            'format_valid' => preg_match('/^pk_/', $stripePublicKey),
            'key_prefix' => substr($stripePublicKey, 0, 5) . '...'
        ]
    ];
    
    return $results;
}

// Main function to run all checks
function runSystemCheck() {
    $results = [
        'php_requirements' => checkPhpRequirements(),
        'server_info' => checkServerInfo(),
        'file_permissions' => checkFilePermissions(),
        'environment' => checkEnvironmentVariables(),
        'database' => checkDatabaseConnection(),
        'api_keys' => checkApiKeys(),
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    // Calculate overall status
    $allPhpRequirementsMet = true;
    foreach ($results['php_requirements'] as $requirement) {
        if (!$requirement['status']) {
            $allPhpRequirementsMet = false;
            break;
        }
    }
    
    $allDirectoriesOk = true;
    foreach ($results['file_permissions'] as $dir) {
        if (!$dir['status']) {
            $allDirectoriesOk = false;
            break;
        }
    }
    
    $envFileExists = $results['environment']['env_file_exists'];
    
    $results['overall_status'] = $allPhpRequirementsMet && $allDirectoriesOk && $envFileExists && $results['database']['status'];
    
    return $results;
}

// Check if the script is accessed directly
$isApi = isset($_GET['api']) && $_GET['api'] === 'true';
$isPrintable = isset($_GET['print']) && $_GET['print'] === 'true';

if ($isApi) {
    // Return JSON
    header('Content-Type: application/json');
    echo json_encode(runSystemCheck());
    exit;
}

// If not API, render HTML
$results = runSystemCheck();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ask for Transport - System Check</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #3b82f6;
            --primary-hover: #2563eb;
        }
        body {
            background-color: #f8f9fa;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        }
        .container {
            max-width: 1000px;
            margin: 2rem auto;
        }
        .header {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
            color: white;
            padding: 2rem;
            border-radius: 10px 10px 0 0;
            text-align: center;
        }
        .content {
            background: white;
            padding: 2rem;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .status-good {
            color: #28a745;
        }
        .status-bad {
            color: #dc3545;
        }
        .status-warning {
            color: #ffc107;
        }
        .action-buttons {
            margin-top: 2rem;
            display: flex;
            gap: 1rem;
            justify-content: center;
        }
        .table-sm th, .table-sm td {
            padding: 0.4rem;
        }
        @media print {
            .no-print {
                display: none;
            }
            .content {
                box-shadow: none;
            }
            body {
                background-color: white;
            }
            .container {
                max-width: 100%;
                margin: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Ask for Transport - System Check</h1>
            <p class="mb-0">
                <?php if ($results['overall_status']): ?>
                <span class="badge bg-success">System is properly configured</span>
                <?php else: ?>
                <span class="badge bg-danger">System configuration issues found</span>
                <?php endif; ?>
            </p>
            <p class="mt-2 mb-0">Checked on: <?php echo $results['timestamp']; ?></p>
        </div>
        
        <div class="content">
            <div class="overall-summary mb-4">
                <h2>Summary</h2>
                <div class="card">
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                PHP Requirements
                                <?php if (array_reduce($results['php_requirements'], function($carry, $item) { return $carry && $item['status']; }, true)): ?>
                                <span class="badge bg-success">All Met</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Issues Found</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                File Permissions
                                <?php if (array_reduce($results['file_permissions'], function($carry, $item) { return $carry && $item['status']; }, true)): ?>
                                <span class="badge bg-success">All Correct</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Issues Found</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Environment Configuration
                                <?php if ($results['environment']['env_file_exists']): ?>
                                <span class="badge bg-success">Configured</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Not Configured</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Database Connection
                                <?php if (isset($results['database']['connection']) && $results['database']['connection']): ?>
                                <span class="badge bg-success">Connected</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Connection Failed</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Database Tables
                                <?php if (isset($results['database']['status']) && $results['database']['status']): ?>
                                <span class="badge bg-success">All Tables Present</span>
                                <?php elseif (isset($results['database']['missing_tables'])): ?>
                                <span class="badge bg-warning"><?php echo count($results['database']['missing_tables']); ?> Missing Tables</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Not Checked</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                API Keys
                                <?php 
                                $apiKeysOk = true;
                                foreach ($results['api_keys'] as $key => $value) {
                                    if (!$value['exists'] || !$value['format_valid']) {
                                        $apiKeysOk = false;
                                        break;
                                    }
                                }
                                ?>
                                <?php if ($apiKeysOk): ?>
                                <span class="badge bg-success">All Configured</span>
                                <?php else: ?>
                                <span class="badge bg-warning">Some Missing or Invalid</span>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="accordion" id="checkAccordion">
                <!-- PHP Requirements Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#phpRequirements">
                            PHP Requirements
                        </button>
                    </h2>
                    <div id="phpRequirements" class="accordion-collapse collapse show" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Requirement</th>
                                        <th>Required</th>
                                        <th>Current</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results['php_requirements'] as $name => $requirement): ?>
                                    <tr>
                                        <td><?php echo $name; ?></td>
                                        <td><?php echo $requirement['required']; ?></td>
                                        <td><?php echo $requirement['current']; ?></td>
                                        <td>
                                            <?php if ($requirement['status']): ?>
                                            <span class="status-good">✓</span>
                                            <?php else: ?>
                                            <span class="status-bad">✗</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- File Permissions Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#filePermissions">
                            File Permissions
                        </button>
                    </h2>
                    <div id="filePermissions" class="accordion-collapse collapse" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Directory</th>
                                        <th>Path</th>
                                        <th>Exists</th>
                                        <th>Is Directory</th>
                                        <th>Is Writable</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results['file_permissions'] as $name => $dir): ?>
                                    <tr>
                                        <td><?php echo $name; ?></td>
                                        <td><small><?php echo $dir['path']; ?></small></td>
                                        <td>
                                            <?php if ($dir['exists']): ?>
                                            <span class="status-good">Yes</span>
                                            <?php else: ?>
                                            <span class="status-bad">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($dir['is_dir']): ?>
                                            <span class="status-good">Yes</span>
                                            <?php else: ?>
                                            <span class="status-bad">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($dir['is_writable']): ?>
                                            <span class="status-good">Yes</span>
                                            <?php else: ?>
                                            <span class="status-bad">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($dir['status']): ?>
                                            <span class="status-good">✓</span>
                                            <?php else: ?>
                                            <span class="status-bad">✗</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Environment Variables Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#environment">
                            Environment Configuration
                        </button>
                    </h2>
                    <div id="environment" class="accordion-collapse collapse" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <?php if ($results['environment']['env_file_exists']): ?>
                                <div class="alert alert-success mb-3">
                                    .env file exists at the root directory.
                                </div>
                                <table class="table table-striped table-sm">
                                    <thead>
                                        <tr>
                                            <th>Variable</th>
                                            <th>Description</th>
                                            <th>Exists</th>
                                            <th>Has Value</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($results['environment']['variables'] as $key => $var): ?>
                                        <tr>
                                            <td><?php echo $key; ?></td>
                                            <td><?php echo $var['description']; ?></td>
                                            <td>
                                                <?php if ($var['exists']): ?>
                                                <span class="status-good">Yes</span>
                                                <?php else: ?>
                                                <span class="status-bad">No</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($var['has_value']): ?>
                                                <span class="status-good">Yes</span>
                                                <?php else: ?>
                                                <span class="status-bad">No</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($var['status']): ?>
                                                <span class="status-good">✓</span>
                                                <?php else: ?>
                                                <span class="status-bad">✗</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    .env file does not exist at the root directory. Please complete the installation process.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Database Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#database">
                            Database Configuration
                        </button>
                    </h2>
                    <div id="database" class="accordion-collapse collapse" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <?php if (isset($results['database']['connection']) && $results['database']['connection']): ?>
                                <div class="alert alert-success mb-3">
                                    Successfully connected to the database.
                                </div>
                                
                                <?php if (isset($results['database']['status']) && $results['database']['status']): ?>
                                    <div class="alert alert-success mb-3">
                                        All required database tables are present.
                                    </div>
                                    
                                    <h5>Tables in Database:</h5>
                                    <div class="row">
                                        <?php foreach ($results['database']['tables'] as $table): ?>
                                        <div class="col-md-4 mb-2">
                                            <div class="card">
                                                <div class="card-body py-2">
                                                    <?php echo $table; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-warning mb-3">
                                        Some required tables are missing in the database.
                                    </div>
                                    
                                    <h5>Missing Tables:</h5>
                                    <ul>
                                        <?php foreach ($results['database']['missing_tables'] as $table): ?>
                                        <li><?php echo $table; ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                    
                                    <div class="alert alert-info">
                                        <p>To create the missing tables, you should run the database setup script:</p>
                                        <code>php setup-database.php</code>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    Database connection failed: <?php echo $results['database']['message'] ?? 'Unknown error'; ?>
                                </div>
                                
                                <div class="alert alert-info">
                                    <p>Please make sure your database server is running and the credentials in the .env file are correct.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- API Keys Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#apiKeys">
                            API Keys Configuration
                        </button>
                    </h2>
                    <div id="apiKeys" class="accordion-collapse collapse" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>API Key</th>
                                        <th>Exists</th>
                                        <th>Format Valid</th>
                                        <th>Key Prefix</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results['api_keys'] as $name => $key): ?>
                                    <tr>
                                        <td><?php echo $name; ?></td>
                                        <td>
                                            <?php if ($key['exists']): ?>
                                            <span class="status-good">Yes</span>
                                            <?php else: ?>
                                            <span class="status-warning">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($key['format_valid']): ?>
                                            <span class="status-good">Yes</span>
                                            <?php else: ?>
                                            <span class="status-warning">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($key['exists']): ?>
                                            <code><?php echo $key['key_prefix']; ?></code>
                                            <?php else: ?>
                                            <span class="text-muted">Not set</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($key['exists'] && $key['format_valid']): ?>
                                            <span class="status-good">✓</span>
                                            <?php elseif ($key['exists']): ?>
                                            <span class="status-warning">⚠</span>
                                            <?php else: ?>
                                            <span class="status-warning">⚠</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <div class="alert alert-info">
                                <p>Note: Some API keys may be optional depending on which features you plan to use:</p>
                                <ul>
                                    <li><strong>Google Maps API Key:</strong> Required for maps and location services</li>
                                    <li><strong>OpenAI API Key:</strong> Required for package recommendation engine</li>
                                    <li><strong>Anthropic API Key:</strong> Alternative AI provider (optional)</li>
                                    <li><strong>Stripe API Keys:</strong> Required for payment processing</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Server Information Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#serverInfo">
                            Server Information
                        </button>
                    </h2>
                    <div id="serverInfo" class="accordion-collapse collapse" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Setting</th>
                                        <th>Value</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results['server_info'] as $name => $value): ?>
                                    <tr>
                                        <td><?php echo $name; ?></td>
                                        <td><?php echo $value; ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="action-buttons no-print">
                <?php if (!$results['overall_status']): ?>
                <a href="index.php" class="btn btn-primary">
                    Go to Installation Wizard
                </a>
                <?php endif; ?>
                <a href="?print=true" class="btn btn-outline-secondary" onclick="window.print(); return false;">
                    Print Report
                </a>
                <a href="?api=true" class="btn btn-outline-secondary" target="_blank">
                    View as JSON
                </a>
                <a href="../" class="btn btn-outline-primary">
                    Visit Homepage
                </a>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php if ($isPrintable): ?>
    <script>
        window.onload = function() {
            window.print();
        }
    </script>
    <?php endif; ?>
</body>
</html>