<?php
/**
 * Ask for Transport - cPanel Environment Checker
 * This script checks if the cPanel environment meets the requirements
 */

// Check if script is running in a cPanel environment
function isCpanelEnvironment() {
    // Look for cPanel-specific environment variables or directories
    return (
        file_exists('/usr/local/cpanel') || 
        !empty($_SERVER['CPANEL']) || 
        !empty($_SERVER['CP_USER']) ||
        (isset($_SERVER['SERVER_SOFTWARE']) && stripos($_SERVER['SERVER_SOFTWARE'], 'cpanel') !== false)
    );
}

// Check PHP version and extensions
function checkPhpRequirements() {
    $requirements = [
        'PHP Version' => [
            'required' => '8.0.0',
            'current' => PHP_VERSION,
            'status' => version_compare(PHP_VERSION, '8.0.0', '>=')
        ],
        'PDO Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('pdo') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('pdo')
        ],
        'PDO PostgreSQL Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('pdo_pgsql') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('pdo_pgsql')
        ],
        'JSON Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('json') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('json')
        ],
        'cURL Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('curl') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('curl')
        ],
        'OpenSSL Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('openssl') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('openssl')
        ],
        'Fileinfo Extension' => [
            'required' => 'Enabled',
            'current' => extension_loaded('fileinfo') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('fileinfo')
        ],
        'mod_rewrite Module' => [
            'required' => 'Enabled',
            'current' => function_exists('apache_get_modules') && in_array('mod_rewrite', apache_get_modules()) ? 'Enabled' : 'Unknown',
            'status' => function_exists('apache_get_modules') && in_array('mod_rewrite', apache_get_modules())
        ]
    ];
    
    return $requirements;
}

// Check PHP configuration
function checkPhpConfiguration() {
    $configs = [
        'file_uploads' => [
            'recommended' => 'On',
            'current' => ini_get('file_uploads') ? 'On' : 'Off',
            'status' => ini_get('file_uploads') ? true : false
        ],
        'upload_max_filesize' => [
            'recommended' => '20M',
            'current' => ini_get('upload_max_filesize'),
            'status' => compareSize(ini_get('upload_max_filesize'), '20M')
        ],
        'post_max_size' => [
            'recommended' => '20M',
            'current' => ini_get('post_max_size'),
            'status' => compareSize(ini_get('post_max_size'), '20M')
        ],
        'max_execution_time' => [
            'recommended' => '300',
            'current' => ini_get('max_execution_time'),
            'status' => (int)ini_get('max_execution_time') >= 300 || (int)ini_get('max_execution_time') === 0
        ],
        'max_input_time' => [
            'recommended' => '300',
            'current' => ini_get('max_input_time'),
            'status' => (int)ini_get('max_input_time') >= 300 || (int)ini_get('max_input_time') === 0
        ],
        'memory_limit' => [
            'recommended' => '128M',
            'current' => ini_get('memory_limit'),
            'status' => compareSize(ini_get('memory_limit'), '128M')
        ],
        'allow_url_fopen' => [
            'recommended' => 'On',
            'current' => ini_get('allow_url_fopen') ? 'On' : 'Off',
            'status' => ini_get('allow_url_fopen') ? true : false
        ],
        'display_errors' => [
            'recommended' => 'Off',
            'current' => ini_get('display_errors') ? 'On' : 'Off',
            'status' => !ini_get('display_errors') || strtolower(ini_get('display_errors')) === 'off'
        ]
    ];
    
    return $configs;
}

// Compare sizes like 64M, 128M, etc.
function compareSize($actual, $required) {
    if (preg_match('/^(\d+)([KMG])?$/i', $actual, $actual_matches) &&
        preg_match('/^(\d+)([KMG])?$/i', $required, $required_matches)) {
        
        $actual_value = (int)$actual_matches[1];
        $actual_unit = strtoupper($actual_matches[2] ?? '');
        
        $required_value = (int)$required_matches[1];
        $required_unit = strtoupper($required_matches[2] ?? '');
        
        // Convert to bytes
        $units = ['K' => 1, 'M' => 2, 'G' => 3];
        $actual_bytes = $actual_value * pow(1024, isset($units[$actual_unit]) ? $units[$actual_unit] : 0);
        $required_bytes = $required_value * pow(1024, isset($units[$required_unit]) ? $units[$required_unit] : 0);
        
        return $actual_bytes >= $required_bytes;
    }
    
    // If we couldn't parse, just do string comparison
    return $actual >= $required;
}

// Check file permissions
function checkFilePermissions() {
    $rootDir = realpath('../');
    $directories = [
        '.' => $rootDir,
        './config' => "$rootDir/config",
        './uploads' => "$rootDir/uploads",
        './assets' => "$rootDir/assets"
    ];
    
    $results = [];
    
    foreach ($directories as $name => $path) {
        $exists = file_exists($path);
        $isDir = is_dir($path);
        $isWritable = is_writable($path);
        
        if (!$exists && $name !== '.') {
            // Try to create the directory
            $parent = dirname($path);
            if (is_writable($parent)) {
                mkdir($path, 0755, true);
                $exists = file_exists($path);
                $isDir = is_dir($path);
                $isWritable = is_writable($path);
            }
        }
        
        $results[$name] = [
            'path' => $path,
            'exists' => $exists,
            'is_dir' => $isDir,
            'is_writable' => $isWritable,
            'status' => $exists && $isDir && $isWritable
        ];
    }
    
    return $results;
}

// Check if mod_rewrite is available and working
function checkModRewrite() {
    $testFile = 'mod-rewrite-test-' . uniqid() . '.html';
    $testContent = '<html><body>Test</body></html>';
    
    // Create test file
    file_put_contents($testFile, $testContent);
    
    // Create .htaccess with a test rule
    $htaccessFile = '.htaccess-test-' . uniqid();
    $htaccessContent = "
    <IfModule mod_rewrite.c>
        RewriteEngine On
        RewriteRule ^mod-rewrite-test-([0-9a-f]+)\.html$ mod-rewrite-test.php?id=$1 [L]
    </IfModule>
    ";
    file_put_contents($htaccessFile, $htaccessContent);
    
    // Create PHP handler file
    $handlerFile = 'mod-rewrite-test.php';
    $handlerContent = '<?php echo "MOD_REWRITE_WORKING"; ?>';
    file_put_contents($handlerFile, $handlerContent);
    
    // Try to access with curl
    $ch = curl_init();
    $url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/' . $testFile;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $result = curl_exec($ch);
    curl_close($ch);
    
    // Clean up test files
    @unlink($testFile);
    @unlink($htaccessFile);
    @unlink($handlerFile);
    
    return strpos($result, 'MOD_REWRITE_WORKING') !== false;
}

// Check if PostgreSQL is available in cPanel
function checkPostgresAvailability() {
    // Check for PostgreSQL extensions
    $pgsqlAvailable = extension_loaded('pgsql');
    $pdoPgsqlAvailable = extension_loaded('pdo_pgsql');
    
    // Check for PostgreSQL support in cPanel
    $cpanelPgsqlSupport = false;
    
    // Try to detect if cPanel PostgreSQL package is installed
    if (file_exists('/usr/bin/psql')) {
        // PostgreSQL client is installed
        $cpanelPgsqlSupport = true;
    }
    
    return [
        'pgsql_extension' => $pgsqlAvailable,
        'pdo_pgsql_extension' => $pdoPgsqlAvailable,
        'cpanel_pgsql_support' => $cpanelPgsqlSupport,
        'status' => $pgsqlAvailable && $pdoPgsqlAvailable
    ];
}

// Check required tools for building the application
function checkBuildTools() {
    $tools = [
        'Node.js' => [
            'command' => 'node -v',
            'required' => 'v14.0.0',
            'status' => false,
            'version' => 'Not installed'
        ],
        'npm' => [
            'command' => 'npm -v',
            'required' => '6.0.0',
            'status' => false,
            'version' => 'Not installed'
        ],
        'PostgreSQL Client' => [
            'command' => 'psql --version',
            'required' => 'Any version',
            'status' => false,
            'version' => 'Not installed'
        ]
    ];
    
    foreach ($tools as $name => &$tool) {
        $output = '';
        $returnVar = 0;
        
        @exec($tool['command'] . " 2>&1", $output, $returnVar);
        
        if ($returnVar === 0) {
            $version = is_array($output) ? implode(' ', $output) : $output;
            $tool['status'] = true;
            $tool['version'] = $version;
        }
    }
    
    return $tools;
}

// Run all checks
function runEnvironmentCheck() {
    $results = [
        'is_cpanel' => isCpanelEnvironment(),
        'php_requirements' => checkPhpRequirements(),
        'php_configuration' => checkPhpConfiguration(),
        'file_permissions' => checkFilePermissions(),
        'mod_rewrite' => checkModRewrite(),
        'postgresql' => checkPostgresAvailability(),
        'build_tools' => checkBuildTools(),
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    // Calculate overall status
    $allPhpRequirementsMet = true;
    foreach ($results['php_requirements'] as $requirement) {
        if (!$requirement['status']) {
            $allPhpRequirementsMet = false;
            break;
        }
    }
    
    $allDirectoriesOk = true;
    foreach ($results['file_permissions'] as $dir) {
        if (!$dir['status']) {
            $allDirectoriesOk = false;
            break;
        }
    }
    
    $postgresAvailable = $results['postgresql']['status'];
    
    $results['overall_status'] = $allPhpRequirementsMet && $allDirectoriesOk && $postgresAvailable;
    
    return $results;
}

// Check if the script is accessed directly
$isApi = isset($_GET['api']) && $_GET['api'] === 'true';
$isPrintable = isset($_GET['print']) && $_GET['print'] === 'true';

if ($isApi) {
    // Return JSON
    header('Content-Type: application/json');
    echo json_encode(runEnvironmentCheck());
    exit;
}

// If not API, render HTML
$results = runEnvironmentCheck();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ask for Transport - cPanel Environment Check</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #3b82f6;
            --primary-hover: #2563eb;
        }
        body {
            background-color: #f8f9fa;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        }
        .container {
            max-width: 1000px;
            margin: 2rem auto;
        }
        .header {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
            color: white;
            padding: 2rem;
            border-radius: 10px 10px 0 0;
            text-align: center;
        }
        .content {
            background: white;
            padding: 2rem;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .status-good {
            color: #28a745;
        }
        .status-bad {
            color: #dc3545;
        }
        .status-warning {
            color: #ffc107;
        }
        .action-buttons {
            margin-top: 2rem;
            display: flex;
            gap: 1rem;
            justify-content: center;
        }
        .table-sm th, .table-sm td {
            padding: 0.4rem;
        }
        @media print {
            .no-print {
                display: none;
            }
            .content {
                box-shadow: none;
            }
            body {
                background-color: white;
            }
            .container {
                max-width: 100%;
                margin: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Ask for Transport - cPanel Environment Check</h1>
            <?php if ($results['is_cpanel']): ?>
                <p class="mb-2">
                    <span class="badge bg-success">cPanel Environment Detected</span>
                </p>
            <?php else: ?>
                <p class="mb-2">
                    <span class="badge bg-warning">cPanel Environment Not Detected</span>
                </p>
            <?php endif; ?>
            <p class="mb-0">
                <?php if ($results['overall_status']): ?>
                <span class="badge bg-success">Environment Ready for Installation</span>
                <?php else: ?>
                <span class="badge bg-danger">Environment Not Ready - Issues Found</span>
                <?php endif; ?>
            </p>
            <p class="mt-2 mb-0">Checked on: <?php echo $results['timestamp']; ?></p>
        </div>
        
        <div class="content">
            <div class="overall-summary mb-4">
                <h2>Summary</h2>
                <div class="card">
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                PHP Requirements
                                <?php if (array_reduce($results['php_requirements'], function($carry, $item) { return $carry && $item['status']; }, true)): ?>
                                <span class="badge bg-success">All Met</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Issues Found</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                PHP Configuration
                                <?php if (array_reduce($results['php_configuration'], function($carry, $item) { return $carry && $item['status']; }, true)): ?>
                                <span class="badge bg-success">Optimal</span>
                                <?php else: ?>
                                <span class="badge bg-warning">Could Be Improved</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                File Permissions
                                <?php if (array_reduce($results['file_permissions'], function($carry, $item) { return $carry && $item['status']; }, true)): ?>
                                <span class="badge bg-success">All Correct</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Issues Found</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                mod_rewrite
                                <?php if ($results['mod_rewrite']): ?>
                                <span class="badge bg-success">Working</span>
                                <?php else: ?>
                                <span class="badge bg-warning">Not Working or Not Tested</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                PostgreSQL
                                <?php if ($results['postgresql']['status']): ?>
                                <span class="badge bg-success">Available</span>
                                <?php else: ?>
                                <span class="badge bg-danger">Not Available</span>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="accordion" id="checkAccordion">
                <!-- PHP Requirements Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#phpRequirements">
                            PHP Requirements
                        </button>
                    </h2>
                    <div id="phpRequirements" class="accordion-collapse collapse show" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Requirement</th>
                                        <th>Required</th>
                                        <th>Current</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results['php_requirements'] as $name => $requirement): ?>
                                    <tr>
                                        <td><?php echo $name; ?></td>
                                        <td><?php echo $requirement['required']; ?></td>
                                        <td><?php echo $requirement['current']; ?></td>
                                        <td>
                                            <?php if ($requirement['status']): ?>
                                            <span class="status-good">✓</span>
                                            <?php else: ?>
                                            <span class="status-bad">✗</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- PHP Configuration Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#phpConfiguration">
                            PHP Configuration
                        </button>
                    </h2>
                    <div id="phpConfiguration" class="accordion-collapse collapse" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Setting</th>
                                        <th>Recommended</th>
                                        <th>Current</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results['php_configuration'] as $name => $config): ?>
                                    <tr>
                                        <td><?php echo $name; ?></td>
                                        <td><?php echo $config['recommended']; ?></td>
                                        <td><?php echo $config['current']; ?></td>
                                        <td>
                                            <?php if ($config['status']): ?>
                                            <span class="status-good">✓</span>
                                            <?php else: ?>
                                            <span class="status-warning">⚠</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <div class="alert alert-info mt-3">
                                <h5>How to change PHP settings in cPanel:</h5>
                                <ol>
                                    <li>Login to your cPanel account</li>
                                    <li>Go to "Software" > "MultiPHP INI Editor"</li>
                                    <li>Select your domain or the path to your application</li>
                                    <li>Modify the values for the settings above</li>
                                    <li>Click "Apply" to save your changes</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- File Permissions Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#filePermissions">
                            File Permissions
                        </button>
                    </h2>
                    <div id="filePermissions" class="accordion-collapse collapse" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Directory</th>
                                        <th>Path</th>
                                        <th>Exists</th>
                                        <th>Is Directory</th>
                                        <th>Is Writable</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results['file_permissions'] as $name => $dir): ?>
                                    <tr>
                                        <td><?php echo $name; ?></td>
                                        <td><small><?php echo $dir['path']; ?></small></td>
                                        <td>
                                            <?php if ($dir['exists']): ?>
                                            <span class="status-good">Yes</span>
                                            <?php else: ?>
                                            <span class="status-bad">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($dir['is_dir']): ?>
                                            <span class="status-good">Yes</span>
                                            <?php else: ?>
                                            <span class="status-bad">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($dir['is_writable']): ?>
                                            <span class="status-good">Yes</span>
                                            <?php else: ?>
                                            <span class="status-bad">No</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($dir['status']): ?>
                                            <span class="status-good">✓</span>
                                            <?php else: ?>
                                            <span class="status-bad">✗</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <div class="alert alert-info mt-3">
                                <h5>How to fix file permissions in cPanel:</h5>
                                <ol>
                                    <li>Login to your cPanel account</li>
                                    <li>Go to "File Manager"</li>
                                    <li>Navigate to the directories listed above</li>
                                    <li>Right-click on the directory and select "Change Permissions"</li>
                                    <li>Set permissions to 755 for directories</li>
                                    <li>Set permissions to 644 for files</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- PostgreSQL Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#postgresql">
                            PostgreSQL Database
                        </button>
                    </h2>
                    <div id="postgresql" class="accordion-collapse collapse" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Check</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>PostgreSQL Extension</td>
                                        <td>
                                            <?php if ($results['postgresql']['pgsql_extension']): ?>
                                            <span class="status-good">Available</span>
                                            <?php else: ?>
                                            <span class="status-bad">Not Available</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>PDO PostgreSQL Extension</td>
                                        <td>
                                            <?php if ($results['postgresql']['pdo_pgsql_extension']): ?>
                                            <span class="status-good">Available</span>
                                            <?php else: ?>
                                            <span class="status-bad">Not Available</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>cPanel PostgreSQL Support</td>
                                        <td>
                                            <?php if ($results['postgresql']['cpanel_pgsql_support']): ?>
                                            <span class="status-good">Available</span>
                                            <?php else: ?>
                                            <span class="status-warning">Not Detected</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            
                            <?php if (!$results['postgresql']['status']): ?>
                            <div class="alert alert-warning mt-3">
                                <h5>PostgreSQL Support is Required</h5>
                                <p>Ask for Transport requires PostgreSQL database support. Please contact your hosting provider to enable PostgreSQL support for your account.</p>
                            </div>
                            <?php endif; ?>
                            
                            <div class="alert alert-info mt-3">
                                <h5>How to create a PostgreSQL database in cPanel:</h5>
                                <ol>
                                    <li>Login to your cPanel account</li>
                                    <li>Go to "Databases" > "PostgreSQL Databases"</li>
                                    <li>Create a new database and note the name</li>
                                    <li>Create a new user and assign it to the database with all privileges</li>
                                    <li>Note the database name, username, and password for the installation process</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Build Tools Section -->
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#buildTools">
                            Build Tools
                        </button>
                    </h2>
                    <div id="buildTools" class="accordion-collapse collapse" data-bs-parent="#checkAccordion">
                        <div class="accordion-body">
                            <div class="alert alert-info mb-3">
                                <p>The following tools are not required for running the application on a hosting environment but would be needed if you plan to build or modify the application:</p>
                            </div>
                            
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Tool</th>
                                        <th>Required</th>
                                        <th>Current</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($results['build_tools'] as $name => $tool): ?>
                                    <tr>
                                        <td><?php echo $name; ?></td>
                                        <td><?php echo $tool['required']; ?></td>
                                        <td><?php echo $tool['version']; ?></td>
                                        <td>
                                            <?php if ($tool['status']): ?>
                                            <span class="status-good">✓</span>
                                            <?php else: ?>
                                            <span class="status-warning">⚠</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <div class="alert alert-warning mt-3">
                                <p>Note: Most shared hosting environments don't provide these tools. If you need to build or modify the application, it's recommended to do so locally and then upload the built files to your hosting.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="action-buttons no-print">
                <?php if ($results['overall_status']): ?>
                <a href="index.php" class="btn btn-primary">
                    Continue to Installation Wizard
                </a>
                <?php else: ?>
                <a href="#" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#fixIssuesModal">
                    How to Fix Issues
                </a>
                <?php endif; ?>
                <a href="?print=true" class="btn btn-outline-secondary" onclick="window.print(); return false;">
                    Print Report
                </a>
                <a href="?api=true" class="btn btn-outline-secondary" target="_blank">
                    View as JSON
                </a>
            </div>
        </div>
    </div>
    
    <!-- Modal for fixing issues -->
    <div class="modal fade" id="fixIssuesModal" tabindex="-1" aria-labelledby="fixIssuesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="fixIssuesModalLabel">How to Fix Common Issues</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h5>PHP Version Issues</h5>
                    <p>If your PHP version is below 8.0.0:</p>
                    <ol>
                        <li>Login to your cPanel account</li>
                        <li>Go to "Software" > "MultiPHP Manager"</li>
                        <li>Select PHP 8.0 or higher for your domain</li>
                        <li>Click "Apply" to save changes</li>
                    </ol>
                    
                    <h5>Missing PHP Extensions</h5>
                    <p>If you're missing required PHP extensions:</p>
                    <ol>
                        <li>Contact your hosting provider to enable the missing extensions</li>
                        <li>Some hosting providers allow you to enable extensions through cPanel in "Software" > "PHP Extensions"</li>
                    </ol>
                    
                    <h5>File Permission Issues</h5>
                    <p>To fix file permission issues:</p>
                    <ol>
                        <li>Login to your cPanel account</li>
                        <li>Go to "File Manager"</li>
                        <li>Navigate to the directories with permission issues</li>
                        <li>Right-click on the directory and select "Change Permissions"</li>
                        <li>Set permissions to 755 for directories</li>
                        <li>Set permissions to 644 for files</li>
                    </ol>
                    
                    <h5>PostgreSQL Issues</h5>
                    <p>If PostgreSQL is not available:</p>
                    <ol>
                        <li>Contact your hosting provider to enable PostgreSQL support</li>
                        <li>If your hosting doesn't support PostgreSQL, you may need to choose a different hosting provider</li>
                    </ol>
                    
                    <h5>mod_rewrite Issues</h5>
                    <p>If mod_rewrite is not working:</p>
                    <ol>
                        <li>Contact your hosting provider to enable mod_rewrite</li>
                        <li>Check if .htaccess files are allowed in your hosting</li>
                    </ol>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php if ($isPrintable): ?>
    <script>
        window.onload = function() {
            window.print();
        }
    </script>
    <?php endif; ?>
</body>
</html>