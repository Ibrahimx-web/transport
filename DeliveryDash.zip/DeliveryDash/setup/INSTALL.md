# Ask for Transport - Installation Guide for cPanel

This guide will walk you through the process of installing Ask for Transport on a shared cPanel hosting environment.

## System Requirements

- PHP 8.0 or higher
- PostgreSQL database
- PDO PHP extension with PostgreSQL driver
- JSON, cURL, OpenSSL, and Fileinfo PHP extensions
- 100MB of free disk space
- ModRewrite enabled (for Apache)

## Step 1: Upload the Files

1. Download the latest version of Ask for Transport.
2. Extract the files on your local computer.
3. Upload all the files to your hosting account using FTP or the cPanel File Manager.
   - You can upload to the root directory (public_html) or a subdirectory.

## Step 2: Create a PostgreSQL Database

1. Login to your cPanel account.
2. Click on the "PostgreSQL Databases" icon.
3. Create a new database.
4. Create a database user and assign it to the new database with all privileges.
5. Make note of the database name, username, and password.

## Step 3: Run the Installation Wizard

1. Open your web browser and navigate to your website's URL followed by `/setup`.
   Example: `https://yourdomain.com/setup` or `https://yourdomain.com/subdirectory/setup`

2. The installation wizard will guide you through the following steps:
   - Database Configuration: Enter your PostgreSQL database details.
   - API Keys Configuration: Enter your API keys for various services.
   - Admin User Setup: Create your administrator account.
   - File Permissions Check: The system will check if all required directories are writable.
   - Installation: The system will set up the database and create configuration files.

3. After all steps are completed successfully, the system will inform you that the installation is complete.

## Step 4: Run the Database Setup Script

After completing the installation wizard, you need to run the database setup script to create all the necessary tables and seed initial data.

1. Click on the "Run Database Setup" button on the final page of the installation wizard, or
2. Navigate to `https://yourdomain.com/setup/setup-database.php` in your browser.

## Step 5: Verify the Installation

1. After the database setup is complete, navigate to `https://yourdomain.com/setup/check-system.php` to verify that your installation is properly configured.
2. Fix any issues that are reported by the system checker.

## Step 6: Access Your Application

1. Once everything is set up, you can access your Ask for Transport application by navigating to your website's URL.
2. Login with the administrator credentials you created during the installation process.

## API Keys (Optional)

Depending on which features you want to use, you'll need to obtain API keys for the following services:

- **Google Maps API Key**: Required for maps and location services.
  - Get it from: [Google Cloud Console](https://console.cloud.google.com)
  - Enable the following APIs: Maps JavaScript API, Geocoding API, Directions API

- **OpenAI API Key**: Used for the Smart Package Recommendation Engine.
  - Get it from: [OpenAI Platform](https://platform.openai.com)

- **Anthropic API Key**: Alternative AI provider (optional).
  - Get it from: [Anthropic Console](https://console.anthropic.com)

- **Stripe API Keys**: Required for payment processing.
  - Get them from: [Stripe Dashboard](https://dashboard.stripe.com/apikeys)

## Troubleshooting

### File Permissions

If you encounter file permission issues during installation:

1. Make sure the following directories are writable by the web server:
   - `/config`
   - `/uploads`
   - `/assets`

2. You can set the correct permissions using your FTP client or the cPanel File Manager:
   - Directories: `755` (drwxr-xr-x)
   - Files: `644` (rw-r--r--)

### Database Connection Issues

If you're having trouble connecting to the PostgreSQL database:

1. Double-check your database name, username, and password.
2. Make sure your database user has been granted all privileges on the database.
3. Verify that your hosting provider supports external connections to PostgreSQL.

### URL Rewriting Issues

If you're seeing "Page Not Found" errors or issues with URL routing:

1. Make sure mod_rewrite is enabled on your hosting.
2. Check that the .htaccess files were uploaded correctly.
3. If your hosting uses Nginx instead of Apache, you'll need to adjust the URL rewriting rules accordingly.

## Security Recommendations

After installation, consider these security measures:

1. Change the session secret in the .env file to a long, random string.
2. Regularly update your admin password.
3. Set up SSL/TLS for your domain if not already configured.
4. Restrict access to the `/setup` directory after installation is complete.

## Updating

To update Ask for Transport to a newer version:

1. Back up your database and files.
2. Replace the application files with the new version.
3. Run the database setup script again to apply any database updates.
4. Clear your browser cache.

## Support

If you need help with your installation, please contact support at support@askfortransport.com or visit our community forum at https://community.askfortransport.com.

---

Copyright © 2025 Ask for Transport. All rights reserved.