<?php
/**
 * Ask for Transport - Database Setup Script
 * This script creates the necessary database tables for the application
 */

// Load environment variables from the .env file
function loadEnv() {
    $envFile = '../.env';
    
    if (!file_exists($envFile)) {
        die('Error: .env file not found. Please complete the installation process first.');
    }
    
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '#') === 0) {
            continue;
        }
        
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        
        if (!empty($name)) {
            putenv("$name=$value");
            $_ENV[$name] = $value;
            $_SERVER[$name] = $value;
        }
    }
}

// Connect to the database
function connectDb() {
    $dbHost = getenv('DB_HOST');
    $dbName = getenv('DB_NAME');
    $dbUser = getenv('DB_USER');
    $dbPass = getenv('DB_PASS');
    
    try {
        $dsn = "pgsql:host=$dbHost;dbname=$dbName";
        $pdo = new PDO($dsn, $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die('Connection failed: ' . $e->getMessage());
    }
}

// Run database migrations
function runMigrations($pdo) {
    $migrationResults = [];
    
    try {
        // Create users table
        $sql = "
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(20),
            user_type VARCHAR(20) NOT NULL DEFAULT 'customer',
            vehicle_type_id INTEGER NULL,
            profile_picture VARCHAR(255) NULL,
            drivers_license VARCHAR(255) NULL,
            current_lat DECIMAL(10, 7) NULL,
            current_lng DECIMAL(10, 7) NULL,
            is_available BOOLEAN DEFAULT FALSE,
            vehicle_registration_number VARCHAR(50) NULL,
            id_number VARCHAR(50) NULL,
            preferred_payment_method VARCHAR(50) NULL,
            payment_details JSONB NULL,
            auto_payout_enabled BOOLEAN NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'users', 'status' => 'created'];

        // Create vehicle_types table
        $sql = "
        CREATE TABLE IF NOT EXISTS vehicle_types (
            id SERIAL PRIMARY KEY,
            name VARCHAR(50) NOT NULL,
            description TEXT,
            base_fare DECIMAL(10, 2) NOT NULL,
            price_per_km DECIMAL(10, 2) NOT NULL,
            capacity_kg DECIMAL(10, 2) NOT NULL,
            icon_url VARCHAR(255),
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'vehicle_types', 'status' => 'created'];

        // Create orders table
        $sql = "
        CREATE TABLE IF NOT EXISTS orders (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            partner_id INTEGER NULL REFERENCES users(id),
            vehicle_type_id INTEGER NOT NULL REFERENCES vehicle_types(id),
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            pickup_location VARCHAR(255) NOT NULL,
            pickup_lat DECIMAL(10, 7) NOT NULL,
            pickup_lng DECIMAL(10, 7) NOT NULL,
            delivery_location VARCHAR(255) NOT NULL,
            delivery_lat DECIMAL(10, 7) NOT NULL,
            delivery_lng DECIMAL(10, 7) NOT NULL,
            distance_km DECIMAL(10, 2) NOT NULL,
            base_fare DECIMAL(10, 2) NOT NULL,
            distance_fare DECIMAL(10, 2) NOT NULL,
            total_amount DECIMAL(10, 2) NOT NULL,
            payment_status VARCHAR(20) DEFAULT 'pending',
            payment_method VARCHAR(50) NULL,
            package_details JSONB NULL,
            pickup_address TEXT NULL,
            delivery_address TEXT NULL,
            estimated_delivery_time TIMESTAMP NULL,
            actual_delivery_time TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'orders', 'status' => 'created'];

        // Create order_status_updates table
        $sql = "
        CREATE TABLE IF NOT EXISTS order_status_updates (
            id SERIAL PRIMARY KEY,
            order_id INTEGER NOT NULL REFERENCES orders(id),
            status VARCHAR(20) NOT NULL,
            latitude DECIMAL(10, 7) NULL,
            longitude DECIMAL(10, 7) NULL,
            note TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'order_status_updates', 'status' => 'created'];

        // Create partner_documents table
        $sql = "
        CREATE TABLE IF NOT EXISTS partner_documents (
            id SERIAL PRIMARY KEY,
            partner_id INTEGER NOT NULL REFERENCES users(id),
            document_type VARCHAR(50) NOT NULL,
            document_url VARCHAR(255) NOT NULL,
            verification_status VARCHAR(20) DEFAULT 'pending',
            verified_by INTEGER NULL REFERENCES users(id),
            verification_date TIMESTAMP NULL,
            rejection_reason TEXT NULL,
            expiry_date DATE NULL,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'partner_documents', 'status' => 'created'];

        // Create payments table
        $sql = "
        CREATE TABLE IF NOT EXISTS payments (
            id SERIAL PRIMARY KEY,
            order_id INTEGER NOT NULL REFERENCES orders(id),
            amount DECIMAL(10, 2) NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            payment_status VARCHAR(20) NOT NULL,
            transaction_id VARCHAR(100) NULL,
            currency VARCHAR(3) DEFAULT 'USD',
            payment_details JSONB NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'payments', 'status' => 'created'];

        // Create partner_payments table
        $sql = "
        CREATE TABLE IF NOT EXISTS partner_payments (
            id SERIAL PRIMARY KEY,
            partner_id INTEGER NOT NULL REFERENCES users(id),
            amount DECIMAL(10, 2) NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            payment_status VARCHAR(20) NOT NULL,
            transaction_id VARCHAR(100) NULL,
            currency VARCHAR(3) DEFAULT 'USD',
            payment_details JSONB NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'partner_payments', 'status' => 'created'];

        // Create payment_gateways table
        $sql = "
        CREATE TABLE IF NOT EXISTS payment_gateways (
            id SERIAL PRIMARY KEY,
            gateway_type VARCHAR(50) NOT NULL,
            display_name VARCHAR(100) NOT NULL,
            configuration JSONB NOT NULL,
            supported_countries VARCHAR(255)[] NULL,
            supported_currencies VARCHAR(255)[] NULL,
            minimum_amount DECIMAL(10, 2) DEFAULT 0,
            maximum_amount DECIMAL(10, 2) NULL,
            processing_fee DECIMAL(10, 2) DEFAULT 0,
            processing_fee_percentage DECIMAL(5, 2) DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            is_default BOOLEAN DEFAULT FALSE,
            admin_notes TEXT NULL,
            created_by INTEGER NULL REFERENCES users(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'payment_gateways', 'status' => 'created'];

        // Create commission_configurations table
        $sql = "
        CREATE TABLE IF NOT EXISTS commission_configurations (
            id SERIAL PRIMARY KEY,
            commission_name VARCHAR(100) NOT NULL,
            description TEXT NULL,
            applies_to VARCHAR(50) NOT NULL DEFAULT 'all',
            vehicle_type_ids INTEGER[] NULL,
            commission_percentage DECIMAL(5, 2) NOT NULL,
            is_active BOOLEAN DEFAULT TRUE,
            is_default BOOLEAN DEFAULT FALSE,
            effective_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            effective_to TIMESTAMP NULL,
            created_by INTEGER NULL REFERENCES users(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'commission_configurations', 'status' => 'created'];

        // Create map_api_configs table
        $sql = "
        CREATE TABLE IF NOT EXISTS map_api_configs (
            id SERIAL PRIMARY KEY,
            provider VARCHAR(50) NOT NULL,
            api_key VARCHAR(255) NOT NULL,
            is_active BOOLEAN DEFAULT TRUE,
            is_default BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'map_api_configs', 'status' => 'created'];

        // Create auto_payment_settings table
        $sql = "
        CREATE TABLE IF NOT EXISTS auto_payment_settings (
            id SERIAL PRIMARY KEY,
            enabled BOOLEAN DEFAULT FALSE,
            min_balance DECIMAL(10, 2) DEFAULT 100,
            payment_day INTEGER DEFAULT 1,
            payment_frequency VARCHAR(20) DEFAULT 'monthly',
            last_run_date TIMESTAMP NULL,
            next_run_date TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $pdo->exec($sql);
        $migrationResults[] = ['table' => 'auto_payment_settings', 'status' => 'created'];

        return $migrationResults;
    } catch (PDOException $e) {
        die('Migration failed: ' . $e->getMessage());
    }
}

// Seed initial data
function seedData($pdo) {
    $seedResults = [];
    
    try {
        // Check if there are any vehicle types
        $stmt = $pdo->query("SELECT COUNT(*) FROM vehicle_types");
        $count = $stmt->fetchColumn();
        
        if ($count == 0) {
            // Seed vehicle types
            $vehicleTypes = [
                [
                    'name' => 'Bike', 
                    'description' => 'Small packages up to 5kg',
                    'base_fare' => 2.00,
                    'price_per_km' => 0.50,
                    'capacity_kg' => 5.00,
                    'icon_url' => '/assets/images/bike.svg'
                ],
                [
                    'name' => 'Motorbike', 
                    'description' => 'Medium packages up to 15kg',
                    'base_fare' => 3.00,
                    'price_per_km' => 0.80,
                    'capacity_kg' => 15.00,
                    'icon_url' => '/assets/images/motorbike.svg'
                ],
                [
                    'name' => 'Pickup', 
                    'description' => 'Large packages up to 500kg',
                    'base_fare' => 10.00,
                    'price_per_km' => 1.50,
                    'capacity_kg' => 500.00,
                    'icon_url' => '/assets/images/pickup.svg'
                ],
                [
                    'name' => 'Van', 
                    'description' => 'Bulky items up to 1000kg',
                    'base_fare' => 15.00,
                    'price_per_km' => 2.00,
                    'capacity_kg' => 1000.00,
                    'icon_url' => '/assets/images/van.svg'
                ],
                [
                    'name' => 'Lorry', 
                    'description' => 'Heavy cargo up to 3000kg',
                    'base_fare' => 25.00,
                    'price_per_km' => 3.50,
                    'capacity_kg' => 3000.00,
                    'icon_url' => '/assets/images/lorry.svg'
                ],
                [
                    'name' => 'Motor Breakdown', 
                    'description' => 'Towing and roadside assistance',
                    'base_fare' => 20.00,
                    'price_per_km' => 2.50,
                    'capacity_kg' => 2000.00,
                    'icon_url' => '/assets/images/tow-truck.svg'
                ]
            ];
            
            $stmt = $pdo->prepare("
                INSERT INTO vehicle_types (name, description, base_fare, price_per_km, capacity_kg, icon_url)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            foreach ($vehicleTypes as $vehicleType) {
                $stmt->execute([
                    $vehicleType['name'],
                    $vehicleType['description'],
                    $vehicleType['base_fare'],
                    $vehicleType['price_per_km'],
                    $vehicleType['capacity_kg'],
                    $vehicleType['icon_url']
                ]);
            }
            
            $seedResults[] = ['data' => 'vehicle_types', 'count' => count($vehicleTypes)];
        }
        
        // Create admin user if one doesn't exist yet
        $configFile = '../config/admin-config.json';
        if (file_exists($configFile)) {
            $adminConfig = json_decode(file_get_contents($configFile), true);
            
            // Check if user exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
            $stmt->execute([$adminConfig['adminUsername']]);
            $count = $stmt->fetchColumn();
            
            if ($count == 0) {
                $stmt = $pdo->prepare("
                    INSERT INTO users (username, password, full_name, email, phone, user_type)
                    VALUES (?, ?, ?, ?, ?, 'admin')
                ");
                
                $stmt->execute([
                    $adminConfig['adminUsername'],
                    $adminConfig['adminPassword'],
                    $adminConfig['adminName'],
                    $adminConfig['adminEmail'],
                    $adminConfig['adminPhone']
                ]);
                
                $seedResults[] = ['data' => 'admin_user', 'username' => $adminConfig['adminUsername']];
            }
        }
        
        // Default map API config
        $googleMapsKey = getenv('GOOGLE_MAPS_API_KEY');
        if ($googleMapsKey) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM map_api_configs");
            $stmt->execute();
            $count = $stmt->fetchColumn();
            
            if ($count == 0) {
                $stmt = $pdo->prepare("
                    INSERT INTO map_api_configs (provider, api_key, is_active, is_default)
                    VALUES (?, ?, TRUE, TRUE)
                ");
                
                $stmt->execute(['google_maps', $googleMapsKey]);
                $seedResults[] = ['data' => 'map_api_config', 'provider' => 'google_maps'];
            }
        }
        
        // Default commission configuration
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM commission_configurations");
        $stmt->execute();
        $count = $stmt->fetchColumn();
        
        if ($count == 0) {
            $stmt = $pdo->prepare("
                INSERT INTO commission_configurations (
                    commission_name, 
                    description, 
                    applies_to, 
                    commission_percentage, 
                    is_active, 
                    is_default
                )
                VALUES (?, ?, ?, ?, TRUE, TRUE)
            ");
            
            $stmt->execute([
                'Standard Commission',
                'Default commission for all vehicle types',
                'all',
                20.00  // 20% commission
            ]);
            
            $seedResults[] = ['data' => 'commission_configuration', 'name' => 'Standard Commission'];
        }
        
        // Default auto payment settings
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM auto_payment_settings");
        $stmt->execute();
        $count = $stmt->fetchColumn();
        
        if ($count == 0) {
            $stmt = $pdo->prepare("
                INSERT INTO auto_payment_settings (
                    enabled, 
                    min_balance, 
                    payment_day, 
                    payment_frequency,
                    next_run_date
                )
                VALUES (?, ?, ?, ?, ?)
            ");
            
            // Set next run date to the 1st of next month
            $nextRunDate = new DateTime();
            $nextRunDate->modify('first day of next month');
            
            $stmt->execute([
                false,  // Disabled by default
                100.00,  // Minimum balance for auto payout
                1,  // 1st of the month
                'monthly',
                $nextRunDate->format('Y-m-d 00:00:00')
            ]);
            
            $seedResults[] = ['data' => 'auto_payment_settings', 'enabled' => false];
        }
        
        return $seedResults;
    } catch (PDOException $e) {
        die('Seeding failed: ' . $e->getMessage());
    }
}

// Create assets directories
function createAssetDirectories() {
    $directories = [
        '../uploads',
        '../uploads/profile_pictures',
        '../uploads/documents',
        '../uploads/vehicles',
        '../assets',
        '../assets/images'
    ];
    
    $results = [];
    
    foreach ($directories as $dir) {
        if (!file_exists($dir)) {
            if (mkdir($dir, 0755, true)) {
                $results[] = ['directory' => $dir, 'status' => 'created'];
            } else {
                $results[] = ['directory' => $dir, 'status' => 'failed'];
            }
        } else {
            $results[] = ['directory' => $dir, 'status' => 'exists'];
        }
    }
    
    return $results;
}

// Create vehicle icons
function createVehicleIcons() {
    $baseDir = '../assets/images';
    
    // Basic SVG icons for vehicles
    $icons = [
        'bike.svg' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 0L9 3m3 1.5l3-1.5M5.5 21a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/><path d="M16 21h-3.6a2 2 0 0 1-1.9-1.4l-3-7.6 2-.8m9.1 9.8-2.3-6.5a1 1 0 0 0-1.1-.7l-5.3 1.5m6.9 2.2L9 15l-4-3 1-3h5"/></svg>',
        
        'motorbike.svg' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 21a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm15 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm-3-9 5 4m-9-8s0 4-4 5l-5 1 2 3h5m6-9 1 9h-6m-4-5V6.5a.5.5 0 0 1 .5-.5h2.5"/></svg>',
        
        'pickup.svg' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 17h4V5c0-1.1-.9-2-2-2s-2 .9-2 2v12zm-4 0h4V9H3c-.6 0-1 .4-1 1v5c0 1.1.9 2 2 2zm12 0h3c1.1 0 2-.9 2-2v-5c0-.6-.4-1-1-1h-4v8z"/><circle cx="7" cy="19" r="2"/><circle cx="17" cy="19" r="2"/></svg>',
        
        'van.svg' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 17h4V5a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12h4m0 0h8m-8 0-1 3m9-3h3a2 2 0 0 0 2-2v-4.5L19 5H10m8 12-1 3m-8-3v3m8-3v3"/><circle cx="7.5" cy="17" r="1.5"/><circle cx="16.5" cy="17" r="1.5"/></svg>',
        
        'lorry.svg' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 6h4l3 6v5a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1v-1H7v1a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-5m0 0V9c0-1.7 1.3-3 3-3h8"/><path d="M3 17h11V4H6c-1.7 0-3 1.3-3 3v10z"/><path d="M15 17h6V9l-3-3h-3m-2 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm10 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/></svg>',
        
        'tow-truck.svg' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 14c0-1-1-2-3-2h-2v6m7 0h-8m2-6V7c0-1-1-2-2-2h-2.5l1 11m-4-4 3-1-1-3H6v4m2 4a2 2 0 1 1-4 0m2 2V5m10 13a2 2 0 1 0 4 0m-2 2v-3"/></svg>'
    ];
    
    $results = [];
    
    if (!file_exists($baseDir)) {
        mkdir($baseDir, 0755, true);
    }
    
    foreach ($icons as $filename => $svg) {
        $filePath = "$baseDir/$filename";
        if (!file_exists($filePath)) {
            if (file_put_contents($filePath, $svg)) {
                $results[] = ['icon' => $filename, 'status' => 'created'];
            } else {
                $results[] = ['icon' => $filename, 'status' => 'failed'];
            }
        } else {
            $results[] = ['icon' => $filename, 'status' => 'exists'];
        }
    }
    
    return $results;
}

// Main function
function main() {
    echo "Starting Ask for Transport database setup...\n\n";
    
    // Load environment variables
    loadEnv();
    echo "Environment variables loaded.\n";
    
    // Connect to database
    $pdo = connectDb();
    echo "Database connection successful.\n";
    
    // Run migrations
    $migrations = runMigrations($pdo);
    echo "\nDatabase migrations completed:\n";
    foreach ($migrations as $migration) {
        echo "- {$migration['table']}: {$migration['status']}\n";
    }
    
    // Seed initial data
    $seedResults = seedData($pdo);
    echo "\nData seeding completed:\n";
    foreach ($seedResults as $result) {
        if (isset($result['count'])) {
            echo "- {$result['data']}: {$result['count']} records inserted\n";
        } else if (isset($result['username'])) {
            echo "- {$result['data']}: {$result['username']} created\n";
        } else if (isset($result['provider'])) {
            echo "- {$result['data']}: {$result['provider']} configured\n";
        } else if (isset($result['name'])) {
            echo "- {$result['data']}: {$result['name']} created\n";
        } else {
            echo "- {$result['data']}: configured\n";
        }
    }
    
    // Create asset directories
    $dirResults = createAssetDirectories();
    echo "\nDirectory setup completed:\n";
    foreach ($dirResults as $result) {
        echo "- {$result['directory']}: {$result['status']}\n";
    }
    
    // Create vehicle icons
    $iconResults = createVehicleIcons();
    echo "\nVehicle icons setup:\n";
    foreach ($iconResults as $result) {
        echo "- {$result['icon']}: {$result['status']}\n";
    }
    
    echo "\nSetup completed successfully!\n";
    echo "You can now access the Ask for Transport application.\n";
}

// Run the main function
main();
?>