import { useState, useEffect, useCallback, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { OrderStatusUpdate, Order } from '@/types';
import { useRouteTracking } from './use-route-tracking';
import { useToast } from '@/hooks/use-toast';

interface UseParcelTrackingProps {
  orderId?: number;
  order?: Order | null;
  statusUpdates?: OrderStatusUpdate[];
}

interface UseParcelTrackingResult {
  order: Order | null;
  statusUpdates: OrderStatusUpdate[];
  driverLocation: { lat: number; lng: number } | null;
  isLoading: boolean;
  error: Error | null;
  routeInfo: ReturnType<typeof useRouteTracking>['routeInfo'];
  activeSegment: number; 
  progress: number;
  estimatedTimeRemaining: number;
  lastUpdate: Date | null;
  isConnected: boolean;
  isAutoRefreshEnabled: boolean;
  setIsAutoRefreshEnabled: (enabled: boolean) => void;
  refreshInterval: number;
  setRefreshInterval: (interval: number) => void;
  toggleMapExpand: () => void;
  refreshTracking: () => void;
  isRefreshing: boolean;
}

/**
 * A hook for tracking a parcel delivery with enhanced real-time features
 * Fetches order details, status updates, and simulates driver location updates
 */
export function useParcelTracking({ orderId, order: providedOrder, statusUpdates: providedStatusUpdates }: UseParcelTrackingProps): UseParcelTrackingResult {
  const { toast } = useToast();
  const refreshTimerRef = useRef<number | null>(null);
  
  // State for expanded map view
  const [isMapExpanded, setIsMapExpanded] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(new Date());
  const [isConnected, setIsConnected] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Real-time tracking settings
  const [isAutoRefreshEnabled, setIsAutoRefreshEnabled] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(10000); // 10 seconds default

  // Use provided order or fetch from API with enhanced logging
  const { 
    data: fetchedOrder, 
    isLoading: isOrderLoading, 
    error: orderError,
    refetch: refetchOrder
  } = useQuery<Order>({
    queryKey: [`/api/orders/${orderId}`],
    refetchInterval: isAutoRefreshEnabled ? refreshInterval : false,
    enabled: !!orderId && !providedOrder, // Only run query if we have an orderId and no provided order
    queryFn: async () => {
      console.log(`[TRACKING] Fetching order details for order #${orderId}`);
      const startTime = Date.now();
      
      const response = await fetch(`/api/orders/${orderId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch order details');
      }
      
      const data = await response.json();
      const fetchTime = Date.now() - startTime;
      console.log(`[TRACKING] Received order data in ${fetchTime}ms`);
      
      return data;
    }
  });
  
  // Use provided status updates or fetch from API with enhanced logging
  const { 
    data: fetchedStatusUpdates = [], 
    isLoading: isUpdatesLoading,
    error: updatesError,
    refetch: refetchStatusUpdates
  } = useQuery<OrderStatusUpdate[]>({
    queryKey: [`/api/orders/${orderId}/status-updates`],
    refetchInterval: isAutoRefreshEnabled ? refreshInterval : false,
    enabled: !!orderId && !providedStatusUpdates, // Only run query if we have an orderId and no provided updates
    queryFn: async () => {
      console.log(`[TRACKING] Fetching status updates for order #${orderId}`);
      const startTime = Date.now();
      
      const response = await fetch(`/api/orders/${orderId}/status-updates`);
      if (!response.ok) {
        throw new Error('Failed to fetch status updates');
      }
      
      const data = await response.json();
      const fetchTime = Date.now() - startTime;
      console.log(`[TRACKING] Received ${data.length} status updates in ${fetchTime}ms`);
      
      return data;
    }
  });
  
  // Use provided data or fetched data
  const order = providedOrder || fetchedOrder || null;
  const statusUpdates = providedStatusUpdates || fetchedStatusUpdates || [];
  
  // State for driver's current location
  const [driverLocation, setDriverLocation] = useState<{ lat: number; lng: number } | null>(null);
  
  // Setup WebSocket connection for real-time driver location updates
  useEffect(() => {
    if (!order) return;
    
    // In a real app, this would connect to a WebSocket server
    // For demo purposes, we'll simulate location updates
    
    // Start with the pickup location
    let currentLat = order.pickupLat;
    let currentLng = order.pickupLng;
    
    // Calculate step size to move toward delivery location
    const latStep = (order.deliveryLat - order.pickupLat) / 50;
    const lngStep = (order.deliveryLng - order.pickupLng) / 50;
    
    // Set initial location based on order status
    const initializeDriverLocation = () => {
      // Only show driver location for active deliveries
      if (order.status === 'pending' || order.status === 'delivered') {
        setDriverLocation(null);
        return;
      }
      
      // Calculate position based on status
      let progress = 0;
      
      // Create a mapping of status to progress percentage
      const statusProgressMap: Record<string, number> = {
        'driver_assigned': 0,
        'on_way_to_pickup': 0.2,
        'arrived_at_pickup': 0.4,
        'package_picked_up': 0.6,
        'on_way_to_delivery': 0.8,
        'delivered': 1
      };
      
      // Get progress from map or default to 0
      progress = statusProgressMap[order.status] || 0;
      
      // Calculate position along the direct route
      const lat = order.pickupLat + (order.deliveryLat - order.pickupLat) * progress;
      const lng = order.pickupLng + (order.deliveryLng - order.pickupLng) * progress;
      
      // Add a small random variation to simulate real movement
      const latVariation = (Math.random() - 0.5) * 0.001;
      const lngVariation = (Math.random() - 0.5) * 0.001;
      
      setDriverLocation({
        lat: lat + latVariation,
        lng: lng + lngVariation
      });
      
      // Update the current position for animation
      currentLat = lat;
      currentLng = lng;
    };
    
    // Initialize the driver location
    initializeDriverLocation();
    
    // Only animate for active deliveries
    const activeStatuses = ['on_way_to_pickup', 'on_way_to_delivery'] as const;
    if (!activeStatuses.includes(order.status as any)) {
      return;
    }
    
    // Simulate movement updates
    const interval = setInterval(() => {
      // Add some randomness to the movement
      const randomFactor = 0.5 + Math.random();
      
      // Update current position
      currentLat += latStep * randomFactor;
      currentLng += lngStep * randomFactor;
      
      // Add a small random variation
      const latVariation = (Math.random() - 0.5) * 0.0005;
      const lngVariation = (Math.random() - 0.5) * 0.0005;
      
      setDriverLocation({
        lat: currentLat + latVariation,
        lng: currentLng + lngVariation
      });
      
      // Stop animation if driver has reached destination
      const isCloseToDestination = 
        Math.abs(currentLat - order.deliveryLat) < Math.abs(latStep) * 2 &&
        Math.abs(currentLng - order.deliveryLng) < Math.abs(lngStep) * 2;
        
      if (isCloseToDestination) {
        clearInterval(interval);
        
        // Set final position at the destination
        setDriverLocation({
          lat: order.deliveryLat,
          lng: order.deliveryLng
        });
      }
    }, 2000);
    
    return () => clearInterval(interval);
  }, [order]);
  
  // Use the route tracking hook to calculate route progress
  const routeTrackingResult = useRouteTracking({
    pickupLocation: order ? { lat: order.pickupLat, lng: order.pickupLng } : { lat: 0, lng: 0 },
    deliveryLocation: order ? { lat: order.deliveryLat, lng: order.deliveryLng } : { lat: 0, lng: 0 },
    driverLocation: driverLocation || undefined,
    orderStatus: order?.status || 'pending',
    distance: order?.distance || 0
  });
  
  // Function to toggle map expansion
  const toggleMapExpand = useCallback(() => {
    setIsMapExpanded(prev => !prev);
  }, []);
  
  // Function to manually refresh tracking data
  const refreshTracking = useCallback(() => {
    if (orderId) {
      refetchOrder();
      refetchStatusUpdates();
    }
    
    // Update last update timestamp
    setLastUpdate(new Date());
    
    // Simulate connection status
    setIsConnected(true);
  }, [orderId, refetchOrder, refetchStatusUpdates]);
  
  // Update last update timestamp whenever the driver location changes
  useEffect(() => {
    if (driverLocation) {
      setLastUpdate(new Date());
    }
  }, [driverLocation]);
  
  // Enhanced function to manually refresh tracking data with animation and feedback
  const refreshTrackingWithFeedback = useCallback(() => {
    setIsRefreshing(true);
    
    if (orderId) {
      console.log(`[TRACKING] Manual refresh requested for order #${orderId}`);
      const startTime = Date.now();
      
      // Execute the refresh
      Promise.all([refetchOrder(), refetchStatusUpdates()])
        .then(() => {
          const refreshTime = Date.now() - startTime;
          console.log(`[TRACKING] Manual refresh completed in ${refreshTime}ms`);
          
          // Show user feedback on successful refresh
          toast({
            title: "Tracking Updated",
            description: `Latest delivery information loaded`,
          });
        })
        .catch(error => {
          console.error('[TRACKING] Refresh failed:', error);
          toast({
            title: "Update Failed",
            description: "Could not refresh tracking data. Please try again.",
            variant: "destructive"
          });
        })
        .finally(() => {
          setIsRefreshing(false);
          setLastUpdate(new Date());
          setIsConnected(true);
        });
    } else {
      // No order ID to refresh
      setIsRefreshing(false);
    }
  }, [orderId, refetchOrder, refetchStatusUpdates, toast]);

  return {
    order: order || null,
    statusUpdates,
    driverLocation,
    isLoading: isOrderLoading || isUpdatesLoading,
    isRefreshing,
    error: orderError || updatesError,
    lastUpdate,
    isConnected,
    isAutoRefreshEnabled,
    setIsAutoRefreshEnabled,
    refreshInterval,
    setRefreshInterval,
    toggleMapExpand,
    refreshTracking: refreshTrackingWithFeedback,
    ...routeTrackingResult
  };
}