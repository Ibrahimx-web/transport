import * as React from "react";

interface LoadingContextProps {
  isLoading: boolean;
  setLoading: (loading: boolean) => void;
  loadingText: string;
  setLoadingText: (text: string) => void;
  showLoader: (text?: string) => void;
  hideLoader: () => void;
}

const LoadingContext = React.createContext<LoadingContextProps | undefined>(undefined);

export function LoadingProvider({ children }: { children: React.ReactNode }) {
  const [isLoading, setIsLoading] = React.useState(false);
  const [loadingText, setLoadingText] = React.useState("Loading...");

  const setLoading = React.useCallback((loading: boolean) => {
    setIsLoading(loading);
  }, []);

  const showLoader = React.useCallback((text?: string) => {
    if (text) setLoadingText(text);
    setIsLoading(true);
  }, []);

  const hideLoader = React.useCallback(() => {
    setIsLoading(false);
  }, []);

  const value = React.useMemo(
    () => ({
      isLoading,
      setLoading,
      loadingText,
      setLoadingText,
      showLoader,
      hideLoader,
    }),
    [isLoading, setLoading, loadingText, setLoadingText, showLoader, hideLoader]
  );

  return <LoadingContext.Provider value={value}>{children}</LoadingContext.Provider>;
}

export function useLoading() {
  const context = React.useContext(LoadingContext);
  if (context === undefined) {
    throw new Error("useLoading must be used within a LoadingProvider");
  }
  return context;
}

// Hook to automatically show/hide loader for async operations
export function useAsyncTask<T>(task: () => Promise<T>, options?: { loadingText?: string }) {
  const { showLoader, hideLoader } = useLoading();
  
  const runTask = React.useCallback(async () => {
    try {
      showLoader(options?.loadingText);
      const result = await task();
      hideLoader();
      return result;
    } catch (error) {
      hideLoader();
      throw error;
    }
  }, [task, showLoader, hideLoader, options?.loadingText]);

  return runTask;
}