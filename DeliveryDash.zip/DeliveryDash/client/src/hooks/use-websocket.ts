import { useState, useEffect, useCallback, useRef } from 'react';

// WebSocket message types
export enum MessageType {
  CONNECT = 'connect',
  LOCATION_UPDATE = 'location_update',
  USER_CONNECT = 'user_connect',
  USER_DISCONNECT = 'user_disconnect',
  HEARTBEAT = 'heartbeat',
  HEARTBEAT_ACK = 'heartbeat_ack',
  ERROR = 'error',
}

// WebSocket message interface
export interface WebSocketMessage {
  type: MessageType;
  userId?: number;
  userType?: string;
  data?: any;
  timestamp?: number;
}

// Message handler type
type MessageHandler = (message: WebSocketMessage) => void;

interface ConnectionOptions {
  userId?: number;
  userType?: string;
  onConnect?: (message: WebSocketMessage) => void;
  onDisconnect?: () => void;
  onMessage?: MessageHandler;
  reconnectDelay?: number;
  debug?: boolean;
}

export function useWebSocket(options: ConnectionOptions = {}) {
  const {
    userId,
    userType,
    onConnect,
    onDisconnect,
    onMessage,
    reconnectDelay = 3000,
    debug = false
  } = options;

  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const webSocketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const messageHandlersRef = useRef<Map<MessageType, Set<MessageHandler>>>(new Map());

  const log = useCallback((...args: any[]) => {
    if (debug) {
      console.log('[WebSocket]', ...args);
    }
  }, [debug]);

  // Send a message through the WebSocket
  const sendMessage = useCallback((message: WebSocketMessage) => {
    if (webSocketRef.current?.readyState === WebSocket.OPEN) {
      webSocketRef.current.send(JSON.stringify(message));
      log('Sent message:', message);
      return true;
    }
    log('Failed to send message (not connected):', message);
    return false;
  }, [log]);

  // Send a location update
  const sendLocationUpdate = useCallback((lat: number, lng: number) => {
    if (!userId) {
      log('Cannot send location without userId');
      return false;
    }
    
    return sendMessage({
      type: MessageType.LOCATION_UPDATE,
      userId,
      data: { lat, lng }
    });
  }, [userId, sendMessage, log]);

  // Add a message handler for a specific message type
  const addMessageHandler = useCallback((type: MessageType, handler: MessageHandler) => {
    if (!messageHandlersRef.current.has(type)) {
      messageHandlersRef.current.set(type, new Set());
    }
    messageHandlersRef.current.get(type)?.add(handler);
    
    // Return a function to remove the handler
    return () => {
      messageHandlersRef.current.get(type)?.delete(handler);
    };
  }, []);

  // Connect to the WebSocket server
  const connect = useCallback(() => {
    // Clean up any existing connection
    if (webSocketRef.current) {
      webSocketRef.current.close();
    }

    // Clear any reconnect timeout
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    try {
      // Create WebSocket connection
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      log('Connecting to WebSocket server:', wsUrl);
      const socket = new WebSocket(wsUrl);
      webSocketRef.current = socket;

      socket.onopen = () => {
        log('WebSocket connection established');
        setIsConnected(true);
        setError(null);
        
        // Send connect message if userId is provided
        if (userId) {
          sendMessage({
            type: MessageType.CONNECT,
            userId,
            userType
          });
        }
      };

      socket.onclose = (event) => {
        log('WebSocket connection closed:', event.code, event.reason);
        setIsConnected(false);
        
        // Call onDisconnect callback if provided
        onDisconnect?.();
        
        // Attempt to reconnect after delay
        reconnectTimeoutRef.current = setTimeout(() => {
          log('Attempting to reconnect...');
          connect();
        }, reconnectDelay);
      };

      socket.onerror = (error) => {
        log('WebSocket error:', error);
        setError('WebSocket connection error');
      };

      socket.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data) as WebSocketMessage;
          log('Received message:', message);
          
          // Handle specific message types
          switch (message.type) {
            case MessageType.CONNECT:
              // Connection confirmation received
              if (message.userId === userId) {
                log('Connection confirmed for user:', userId);
                onConnect?.(message);
              }
              break;
              
            case MessageType.HEARTBEAT:
              // Respond to heartbeat
              sendMessage({
                type: MessageType.HEARTBEAT_ACK,
                userId,
                timestamp: Date.now()
              });
              break;
          }
          
          // Call the general onMessage callback if provided
          onMessage?.(message);
          
          // Call any registered handlers for this message type
          const handlers = messageHandlersRef.current.get(message.type);
          if (handlers) {
            handlers.forEach(handler => handler(message));
          }
        } catch (error) {
          log('Error parsing WebSocket message:', error);
        }
      };
    } catch (error) {
      log('Error creating WebSocket connection:', error);
      setError('Failed to create WebSocket connection');
      
      // Attempt to reconnect after delay
      reconnectTimeoutRef.current = setTimeout(() => {
        log('Attempting to reconnect...');
        connect();
      }, reconnectDelay);
    }
  }, [userId, userType, reconnectDelay, sendMessage, onConnect, onDisconnect, onMessage, log]);

  // Disconnect from the WebSocket server
  const disconnect = useCallback(() => {
    log('Manually disconnecting WebSocket');
    
    if (webSocketRef.current) {
      webSocketRef.current.close();
      webSocketRef.current = null;
    }
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    setIsConnected(false);
  }, [log]);

  // Connect to WebSocket server on mount and clean up on unmount
  useEffect(() => {
    connect();
    
    return () => {
      if (webSocketRef.current) {
        webSocketRef.current.close();
      }
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [connect]);

  return {
    isConnected,
    error,
    sendMessage,
    sendLocationUpdate,
    connect,
    disconnect,
    addMessageHandler
  };
}