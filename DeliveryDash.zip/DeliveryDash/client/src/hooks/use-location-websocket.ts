import { useState, useEffect, useCallback, useRef } from 'react';

interface UseLocationWebSocketProps {
  userId?: number;
  userType: 'customer' | 'delivery';
  onConnect?: () => void;
  onMessage?: (data: any) => void;
  onDisconnect?: () => void;
}

export function useLocationWebSocket({
  userId,
  userType,
  onConnect,
  onMessage,
  onDisconnect
}: UseLocationWebSocketProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<any>(null);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [circuitBreakerStatus, setCircuitBreakerStatus] = useState<{
    active: boolean;
    remainingTime: number;
  }>({ active: false, remainingTime: 0 });
  
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const pingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const lastPongTimeRef = useRef<number>(Date.now());
  const connectionIdRef = useRef<number>(0);
  const circuitBreakerRef = useRef<boolean>(false);
  const successiveFailuresRef = useRef<number>(0);
  const lastReconnectTimeRef = useRef<number>(0);
  const circuitBreakerTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  const MAX_RECONNECT_ATTEMPTS = 50;  // Significantly increase max reconnect attempts
  const RECONNECT_INTERVAL = 1000; // 1 second base
  const PING_INTERVAL = 10000; // 10 seconds
  const PONG_TIMEOUT = 8000; // 8 seconds
  const MAX_SUCCESSIVE_FAILURES = 5; // Number of successive failures before circuit breaker
  const CIRCUIT_BREAKER_RESET_TIME = 60000; // 1 minute in ms
  const CIRCUIT_BREAKER_UPDATE_INTERVAL = 1000; // Update circuit breaker status every second
  const CONSOLE_LOGGING = true; // Toggle for debugging

  // Logger
  const log = useCallback((message: string, obj?: any) => {
    if (CONSOLE_LOGGING) {
      if (obj) {
        console.log(`[WS-${userId}] ${message}`, obj);
      } else {
        console.log(`[WS-${userId}] ${message}`);
      }
    }
  }, [userId]);

  // Safe send function with error handling and logging
  const safeSend = useCallback((data: any): boolean => {
    if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
      log('Cannot send message, socket not open');
      return false;
    }
    
    try {
      const messageStr = typeof data === 'string' ? data : JSON.stringify(data);
      socketRef.current.send(messageStr);
      return true;
    } catch (error) {
      log('Error sending message to WebSocket', error);
      
      // Try to close the socket to trigger reconnection
      try {
        if (socketRef.current) {
          socketRef.current.close();
        }
      } catch (closeError) {
        log('Error closing broken socket', closeError);
      }
      
      return false;
    }
  }, [log]);

  // Send a ping to keep the connection alive
  const sendPing = useCallback(() => {
    if (userId) {
      const pingMessage = {
        type: 'heartbeat',
        userId,
        userType,
        timestamp: Date.now()
      };
      
      const sent = safeSend(pingMessage);
      
      if (sent) {
        log('Sent ping');
        
        // Check if we've received a pong recently
        const now = Date.now();
        if (now - lastPongTimeRef.current > PONG_TIMEOUT) {
          log('No pong received in time, reconnecting...');
          if (socketRef.current) {
            socketRef.current.close();
            // The onclose handler will trigger reconnect
          }
        }
      }
    }
  }, [userId, userType, safeSend, log]);

  // Update circuit breaker status
  const updateCircuitBreakerStatus = useCallback(() => {
    if (circuitBreakerRef.current) {
      const now = Date.now();
      const timeElapsed = now - lastReconnectTimeRef.current;
      const remainingTime = Math.max(0, CIRCUIT_BREAKER_RESET_TIME - timeElapsed);
      
      setCircuitBreakerStatus({
        active: circuitBreakerRef.current,
        remainingTime: remainingTime
      });
      
      if (remainingTime <= 0) {
        circuitBreakerRef.current = false;
        successiveFailuresRef.current = 0;
        setConnectionError(null);
        setCircuitBreakerStatus({ active: false, remainingTime: 0 });
      }
    } else {
      setCircuitBreakerStatus({ active: false, remainingTime: 0 });
    }
  }, []);
  
  // Initialize WebSocket connection
  const connectWebSocket = useCallback(() => {
    // Don't connect if no userId is provided
    if (!userId) {
      log('No userId provided to useLocationWebSocket');
      return;
    }
    
    // Update circuit breaker status before checking
    updateCircuitBreakerStatus();
    
    // Check circuit breaker
    if (circuitBreakerRef.current) {
      log('Circuit breaker active, preventing connection attempt');
      setConnectionError('Connection temporarily disabled due to repeated failures');
      return;
    }

    try {
      // Generate unique connection ID for this attempt
      const currentConnectionId = ++connectionIdRef.current;
      
      // Track reconnect time
      lastReconnectTimeRef.current = Date.now();
      
      // Clear any existing intervals to avoid duplicates
      if (pingIntervalRef.current) {
        clearInterval(pingIntervalRef.current);
        pingIntervalRef.current = null;
      }
      
      // Close existing connection if any
      if (socketRef.current) {
        if (socketRef.current.readyState === WebSocket.OPEN || 
            socketRef.current.readyState === WebSocket.CONNECTING) {
          socketRef.current.close();
        }
        socketRef.current = null;
      }

      // Determine correct WebSocket URL
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      log(`Connecting to ${wsUrl} (connectionId: ${currentConnectionId})`);
      
      // Create new WebSocket connection
      const socket = new WebSocket(wsUrl);
      socketRef.current = socket;

      // Bind socket events to local functions
      socket.onopen = () => {
        // Verify this is still the current connection attempt
        if (currentConnectionId !== connectionIdRef.current) {
          log(`Ignoring onopen for stale connection ${currentConnectionId}`);
          socket.close();
          return;
        }
        
        log('Connection established');
        setIsConnected(true);
        reconnectAttemptsRef.current = 0; // Reset reconnect attempts on successful connection
        lastPongTimeRef.current = Date.now(); // Reset last pong time
        
        // Send initial identification message
        const identifyMessage = {
          type: 'identify',
          userId,
          userType,
          timestamp: Date.now()
        };
        
        if (safeSend(identifyMessage)) {
          log('Sent identify message');
          
          // Set up ping interval to keep connection alive
          pingIntervalRef.current = setInterval(sendPing, PING_INTERVAL);
          
          if (onConnect) {
            onConnect();
          }
        } else {
          log('Failed to send identify message');
          socket.close();
        }
      };

      socket.onclose = (event) => {
        // Verify this is still the current connection
        if (currentConnectionId !== connectionIdRef.current) {
          log(`Ignoring onclose for stale connection ${currentConnectionId}`);
          return;
        }
        
        log(`Connection closed: code=${event.code}, reason=${event.reason}`);
        setIsConnected(false);
        
        // Clear ping interval
        if (pingIntervalRef.current) {
          clearInterval(pingIntervalRef.current);
          pingIntervalRef.current = null;
        }
        
        if (onDisconnect) {
          onDisconnect();
        }
        
        // Handle successive failures for circuit breaker
        const now = Date.now();
        const timeSinceLastAttempt = now - lastReconnectTimeRef.current;
        
        // If reconnection failed quickly, increment successive failures counter
        if (timeSinceLastAttempt < 3000) { // If connection closed within 3 seconds
          successiveFailuresRef.current += 1;
          log(`Quick disconnect detected: ${successiveFailuresRef.current}/${MAX_SUCCESSIVE_FAILURES}`);
          
          // Trigger circuit breaker if too many rapid reconnection failures
          if (successiveFailuresRef.current >= MAX_SUCCESSIVE_FAILURES) {
            log('Circuit breaker triggered - pausing reconnection attempts');
            circuitBreakerRef.current = true;
            
            // Clear any pending reconnect timeout
            if (reconnectTimeoutRef.current) {
              clearTimeout(reconnectTimeoutRef.current);
              reconnectTimeoutRef.current = null;
            }
            
            // Schedule circuit breaker reset after timeout
            setTimeout(() => {
              log('Circuit breaker reset');
              circuitBreakerRef.current = false;
              successiveFailuresRef.current = 0;
              reconnectAttemptsRef.current = 0;
              setConnectionError(null);
              connectWebSocket(); // Try again
            }, CIRCUIT_BREAKER_RESET_TIME);
            
            setConnectionError('Connection temporarily disabled due to multiple failures. Will retry automatically.');
            return;
          }
        } else {
          // Connection was stable for a while before disconnecting, reset failure counter
          if (successiveFailuresRef.current > 0) {
            successiveFailuresRef.current = Math.max(0, successiveFailuresRef.current - 1);
          }
        }
        
        // Attempt to reconnect with exponential backoff
        if (reconnectAttemptsRef.current < MAX_RECONNECT_ATTEMPTS && !circuitBreakerRef.current) {
          if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
          }
          
          const backoffDelay = Math.min(
            RECONNECT_INTERVAL * Math.pow(1.2, reconnectAttemptsRef.current),
            15000 // Cap at 15 seconds
          );
          
          log(`Scheduling reconnect in ${backoffDelay}ms (attempt ${reconnectAttemptsRef.current + 1})`);
          
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttemptsRef.current += 1;
            connectWebSocket();
          }, backoffDelay);
        } else if (!circuitBreakerRef.current) {
          log('Maximum reconnection attempts reached');
          setConnectionError('Maximum reconnection attempts reached. Please try again later.');
        }
      };

      socket.onerror = (error) => {
        log('WebSocket error', error);
        // Don't call close() here - the onclose handler will be called automatically
      };

      socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          // Update last pong time on any message from server
          lastPongTimeRef.current = Date.now();
          
          // Handle specific message types
          switch (data.type) {
            case 'heartbeat':
              log('Received heartbeat, sending ack');
              safeSend({
                type: 'heartbeat_ack',
                userId,
                userType,
                timestamp: Date.now()
              });
              break;
              
            case 'heartbeat_ack':
              log('Received heartbeat ack');
              break;
              
            case 'connect':
              log('Connection confirmed by server');
              break;
              
            default:
              // Store the message and notify handlers for all other types
              setLastMessage(data);
              if (onMessage) {
                onMessage(data);
              }
          }
        } catch (error) {
          log('Error parsing WebSocket message', error);
        }
      };
    } catch (error) {
      log('Error establishing WebSocket connection', error);
    }
  }, [userId, userType, onConnect, onMessage, onDisconnect, sendPing, safeSend, updateCircuitBreakerStatus, log]);

  // Circuit breaker status update timer
  useEffect(() => {
    // Setup timer to update circuit breaker status
    const statusTimer = setInterval(() => {
      if (circuitBreakerRef.current) {
        updateCircuitBreakerStatus();
      }
    }, CIRCUIT_BREAKER_UPDATE_INTERVAL);
    
    return () => {
      clearInterval(statusTimer);
      if (circuitBreakerTimerRef.current) {
        clearTimeout(circuitBreakerTimerRef.current);
        circuitBreakerTimerRef.current = null;
      }
    };
  }, [updateCircuitBreakerStatus]);

  // Connect on mount and when dependencies change
  useEffect(() => {
    if (userId) {
      connectWebSocket();
    }
    
    // Cleanup on unmount
    return () => {
      // Clean up circuit breaker state
      circuitBreakerRef.current = false;
      successiveFailuresRef.current = 0;
      reconnectAttemptsRef.current = 0;
      
      // Clean up websocket connection
      if (socketRef.current) {
        socketRef.current.close(1000, 'Component unmounted');
        socketRef.current = null;
      }
      
      // Clear all timers
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
      
      if (pingIntervalRef.current) {
        clearInterval(pingIntervalRef.current);
        pingIntervalRef.current = null;
      }
      
      if (circuitBreakerTimerRef.current) {
        clearTimeout(circuitBreakerTimerRef.current);
        circuitBreakerTimerRef.current = null;
      }
    };
  }, [userId, connectWebSocket]);

  // Send location update
  const sendLocationUpdate = useCallback((lat: number, lng: number) => {
    if (!userId) return false;
    
    const locationMessage = {
      type: 'location_update',
      userId,
      userType,
      data: { lat, lng }, // Match the server's expected format
      timestamp: Date.now()
    };
    
    const sent = safeSend(locationMessage);
    
    if (sent) {
      log(`Sent location update: lat=${lat}, lng=${lng}`);
      return true;
    }
    
    // If connection isn't open, try to start a reconnect 
    if (!isConnected && reconnectAttemptsRef.current === 0 && !circuitBreakerRef.current) {
      log('Connection not open during location update, triggering reconnect');
      reconnectAttemptsRef.current = 0;
      connectWebSocket();
    }
    
    return false;
  }, [userId, userType, isConnected, safeSend, connectWebSocket, log]);

  // Manually reconnect
  const reconnect = useCallback(() => {
    log('Manual reconnect triggered');
    // Reset all connection state
    reconnectAttemptsRef.current = 0;
    successiveFailuresRef.current = 0;
    circuitBreakerRef.current = false;
    setCircuitBreakerStatus({ active: false, remainingTime: 0 });
    setConnectionError(null);
    
    // Reconnect
    connectWebSocket();
    return true;
  }, [connectWebSocket, log]);

  // Manually disconnect
  const disconnect = useCallback(() => {
    if (socketRef.current) {
      log('Manual disconnect triggered');
      socketRef.current.close(1000, 'Manual disconnect');
      socketRef.current = null;
      setIsConnected(false);
      
      if (pingIntervalRef.current) {
        clearInterval(pingIntervalRef.current);
        pingIntervalRef.current = null;
      }
      
      return true;
    }
    return false;
  }, [log]);

  return {
    isConnected,
    lastMessage,
    connectionError,
    circuitBreakerStatus,
    sendLocationUpdate,
    reconnect,
    disconnect
  };
}