import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useState, useEffect } from "react";
import { 
  PackageDetails, 
  VehicleRecommendation 
} from "@/types/recommendations";

// Default local recommendation function for quick fallback
function getLocalRecommendation(packageDetails: PackageDetails): VehicleRecommendation {
  // Calculate volume in cubic meters if dimensions are available
  let volume = 0;
  let width = packageDetails.width || (packageDetails.dimensions?.width || 0);
  let height = packageDetails.height || (packageDetails.dimensions?.height || 0);
  let length = packageDetails.length || (packageDetails.dimensions?.length || 0);
  
  if (width && height && length) {
    volume = (width * height * length) / 1000000; // Convert from cm³ to m³
  }
  
  // Default recommendation logic based on weight, volume, fragility, and distance
  let recommendedVehicleType = "Van"; // Default
  let alternativeVehicleType = "Pickup";
  let reasoning = "Quick recommendation based on package characteristics";
  
  // Simple logic to determine vehicle type based on weight
  if (packageDetails.weight <= 5) {
    recommendedVehicleType = "Bike";
    alternativeVehicleType = "Motorbike";
    reasoning = "Lightweight package suitable for bike delivery";
  } else if (packageDetails.weight <= 20) {
    recommendedVehicleType = "Motorbike";
    alternativeVehicleType = "Pickup";
    reasoning = "Medium-weight package suitable for motorbike delivery";
  } else if (packageDetails.weight <= 500) {
    recommendedVehicleType = "Pickup";
    alternativeVehicleType = "Van";
    reasoning = "Heavier package requiring a pickup truck";
  } else if (packageDetails.weight <= 1000) {
    recommendedVehicleType = "Van";
    alternativeVehicleType = "Lorry";
    reasoning = "Heavy package requiring a van";
  } else {
    recommendedVehicleType = "Lorry";
    alternativeVehicleType = "Van";
    reasoning = "Very heavy package requiring a lorry";
  }
  
  // Adjust for volume if known
  if (volume > 6) {
    recommendedVehicleType = "Lorry";
    alternativeVehicleType = "Van";
    reasoning += " with large volume requiring a lorry";
  } else if (volume > 2) {
    recommendedVehicleType = "Van";
    alternativeVehicleType = "Lorry";
    reasoning += " with medium volume requiring a van";
  }
  
  // Adjust for fragility
  if (packageDetails.fragile && (recommendedVehicleType === "Bike" || recommendedVehicleType === "Motorbike")) {
    recommendedVehicleType = "Pickup";
    alternativeVehicleType = "Van";
    reasoning += ", upgraded due to fragility";
  }
  
  // Adjust for distance
  if (packageDetails.distance > 50 && recommendedVehicleType === "Bike") {
    recommendedVehicleType = "Motorbike";
    alternativeVehicleType = "Pickup";
    reasoning += ", upgraded due to long distance";
  }
  
  return {
    recommendedVehicleType,
    recommendedVehicleId: null, // Will be mapped later
    confidence: 0.9, // High confidence for fast local recommendation
    reasoning,
    alternativeVehicleType,
    provider: "local" // Identify this as a local recommendation
  };
}

export function usePackageRecommendation() {
  // State for our quick local recommendation
  const [quickRecommendation, setQuickRecommendation] = useState<VehicleRecommendation | null>(null);
  
  // Track if we should use the local recommendation (will be true immediately)
  const [useLocal, setUseLocal] = useState(true);
  
  // Traditional API-based recommendation
  const {
    mutate: fetchApiRecommendation,
    data: apiRecommendation,
    isPending,
    isError,
    error,
    reset
  } = useMutation({
    mutationFn: async (packageDetails: PackageDetails): Promise<VehicleRecommendation> => {
      const response = await apiRequest(
        "POST",
        "/api/package-recommendations",
        packageDetails
      );
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to get recommendation");
      }
      
      return response.json();
    }
  });
  
  // Enhanced function that gets both quick local and API recommendations
  const getRecommendation = (packageDetails: PackageDetails) => {
    // Reset states
    setUseLocal(true);
    setQuickRecommendation(null);
    reset();
    
    // Immediately generate a local recommendation for fast UI response
    const localRec = getLocalRecommendation(packageDetails);
    setQuickRecommendation(localRec);
    
    // Also fetch the API recommendation (which might be better quality but slower)
    fetchApiRecommendation(packageDetails);
    
    // After a brief delay, switch to the API recommendation if it's available
    setTimeout(() => {
      setUseLocal(false);
    }, 300);
  };
  
  // Determine which recommendation to use
  const recommendation = useLocal ? quickRecommendation : (apiRecommendation || quickRecommendation);
  
  // Loading state is true only if we don't have any recommendation yet
  const isLoading = isPending && !quickRecommendation;

  return {
    getRecommendation,
    recommendation,
    isLoading,
    isError: isError && !quickRecommendation,
    error
  };
}