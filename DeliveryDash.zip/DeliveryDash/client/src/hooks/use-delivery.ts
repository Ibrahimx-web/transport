import { create } from 'zustand';
import { DeliveryFormState, VehicleType, OrderLocation, PackageDetails } from '@/types';
import { geocodeAddress, calculateDistance, useCurrentLocation, reverseGeocode } from '@/lib/map';
import { calculatePricing } from '@/lib/constants';

interface DeliveryStore extends DeliveryFormState {
  priceEstimation: {
    baseFare: number;
    distanceFare: number;
    serviceFee: number;
    totalFare: number;
    distance: number;
  } | null;
  isDetectingLocation: boolean;
  setPickup: (location: OrderLocation) => void;
  setDelivery: (location: OrderLocation) => void;
  setVehicleTypeId: (id: number) => void;
  setPackageDetails: (details: PackageDetails) => void;
  detectCurrentLocation: () => Promise<void>;
  calculatePriceEstimation: (vehicleTypes: VehicleType[]) => Promise<void>;
  reset: () => void;
}

// Initial state
const initialState: DeliveryFormState = {
  pickup: { address: 'Current Location', lat: 0, lng: 0 },
  delivery: { address: '', lat: 0, lng: 0 },
  vehicleTypeId: 3, // Default to pickup truck
  packageDetails: {
    description: '',
    weight: undefined,
    dimensions: '',
    specialInstructions: ''
  }
};

export const useDelivery = create<DeliveryStore>((set, get) => ({
  ...initialState,
  priceEstimation: null,
  isDetectingLocation: false,
  
  setPickup: (location) => {
    set({ pickup: location });
    // Automatically calculate price estimation if both points are set
    const { delivery, vehicleTypeId } = get();
    if (location.lat !== 0 && location.lng !== 0 && 
        delivery.lat !== 0 && delivery.lng !== 0) {
      get().calculatePriceEstimation([]); // Empty array as we'll fetch types inside
    }
  },
  
  setDelivery: (location) => {
    set({ delivery: location });
    // Automatically calculate price estimation if both points are set
    const { pickup, vehicleTypeId } = get();
    if (pickup.lat !== 0 && pickup.lng !== 0 && 
        location.lat !== 0 && location.lng !== 0) {
      get().calculatePriceEstimation([]); // Empty array as we'll fetch types inside
    }
  },
  
  setVehicleTypeId: (id) => {
    set({ vehicleTypeId: id });
    // Update price estimation if locations are set
    const { pickup, delivery } = get();
    if (pickup.lat !== 0 && pickup.lng !== 0 && 
        delivery.lat !== 0 && delivery.lng !== 0) {
      get().calculatePriceEstimation([]); // Empty array as we'll fetch types inside
    }
  },
  
  setPackageDetails: (details) => set({
    packageDetails: {
      ...get().packageDetails,
      ...details
    }
  }),
  
  // Detect current location automatically
  detectCurrentLocation: async () => {
    set({ isDetectingLocation: true });
    
    try {
      // Use browser's geolocation API to get current position
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        if (!navigator.geolocation) {
          reject(new Error('Geolocation is not supported by your browser'));
        } else {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          });
        }
      });
      
      // Get the current coordinates
      const currentLat = position.coords.latitude;
      const currentLng = position.coords.longitude;
      
      // Try to get a human-readable address for the current location
      let addressText = 'Current Location';
      try {
        addressText = await reverseGeocode(currentLat, currentLng);
      } catch (error) {
        console.warn('Could not reverse geocode current location, using fallback text', error);
      }
      
      // Update pickup location
      set({
        pickup: {
          address: addressText,
          lat: currentLat,
          lng: currentLng
        }
      });
      
      console.log('Current location detected:', { lat: currentLat, lng: currentLng, address: addressText });
      
      // If delivery location is also set, calculate price estimation
      const { delivery } = get();
      if (delivery.lat !== 0 && delivery.lng !== 0) {
        get().calculatePriceEstimation([]);
      }
      
    } catch (error) {
      console.error('Failed to detect current location:', error);
    } finally {
      set({ isDetectingLocation: false });
    }
  },
  
  calculatePriceEstimation: async (vehicleTypes) => {
    const { pickup, delivery, vehicleTypeId } = get();
    
    // If vehicleTypes is empty, fetch them from the API
    let validVehicleTypes = vehicleTypes;
    if (vehicleTypes.length === 0) {
      try {
        const response = await fetch('/api/vehicle-types');
        if (response.ok) {
          validVehicleTypes = await response.json();
        } else {
          // Fallback to default vehicle types from constants (should be imported from constants.js)
          console.warn('Failed to fetch vehicle types, using default types.');
          validVehicleTypes = [
            { 
              id: 1, 
              name: "Bike", 
              icon: "bicycle", 
              maxWeight: 5, 
              baseFare: 5.99,
              basePrice: 5.99, 
              pricePerKm: 1.0,
              createdAt: new Date().toISOString()
            },
            { 
              id: 2, 
              name: "Motorbike", 
              icon: "motorcycle", 
              maxWeight: 20, 
              baseFare: 8.99,
              basePrice: 8.99, 
              pricePerKm: 1.2,
              createdAt: new Date().toISOString()
            },
            { 
              id: 3, 
              name: "Pickup", 
              icon: "truck-pickup", 
              maxWeight: 100, 
              baseFare: 14.99,
              basePrice: 14.99, 
              pricePerKm: 1.5,
              createdAt: new Date().toISOString()
            },
            { 
              id: 4, 
              name: "Van", 
              icon: "shuttle-van", 
              maxWeight: 500, 
              baseFare: 24.99,
              basePrice: 24.99, 
              pricePerKm: 1.8,
              createdAt: new Date().toISOString()
            },
            { 
              id: 5, 
              name: "Lorry", 
              icon: "truck", 
              maxWeight: 2000, 
              baseFare: 44.99,
              basePrice: 44.99, 
              pricePerKm: 2.5,
              createdAt: new Date().toISOString()
            },
            { 
              id: 6, 
              name: "Motor Breakdown", 
              icon: "wrench", 
              maxWeight: 0, 
              baseFare: 29.99,
              basePrice: 29.99, 
              pricePerKm: 1.5,
              createdAt: new Date().toISOString()
            }
          ];
        }
      } catch (error) {
        console.error('Error fetching vehicle types:', error);
        return;
      }
    }
    
    // Ensure we have valid coordinates
    if (pickup.lat === 0 || pickup.lng === 0 || delivery.lat === 0 || delivery.lng === 0) {
      // Try to geocode addresses if coordinates are not available
      try {
        const geocodedPickup = await geocodeAddress(pickup.address);
        const geocodedDelivery = await geocodeAddress(delivery.address);
        
        // Update coordinates
        set({
          pickup: {
            ...pickup,
            lat: geocodedPickup.lat,
            lng: geocodedPickup.lng
          },
          delivery: {
            ...delivery,
            lat: geocodedDelivery.lat,
            lng: geocodedDelivery.lng
          }
        });
        
        // Calculate distance
        const distance = calculateDistance(
          geocodedPickup.lat,
          geocodedPickup.lng,
          geocodedDelivery.lat,
          geocodedDelivery.lng
        );
        
        // Find selected vehicle type
        const vehicleType = validVehicleTypes.find(v => v.id === vehicleTypeId);
        if (!vehicleType) return;
        
        // Calculate pricing
        const pricing = calculatePricing(distance, vehicleType.baseFare);
        
        // Update price estimation
        set({
          priceEstimation: {
            ...pricing,
            distance
          }
        });
      } catch (error) {
        console.error('Failed to calculate price estimation:', error);
      }
    } else {
      // Calculate distance using existing coordinates
      const distance = calculateDistance(
        pickup.lat,
        pickup.lng,
        delivery.lat,
        delivery.lng
      );
      
      // Find selected vehicle type
      const vehicleType = validVehicleTypes.find(v => v.id === vehicleTypeId);
      if (!vehicleType) return;
      
      // Calculate pricing
      const pricing = calculatePricing(distance, vehicleType.baseFare);
      
      // Update price estimation
      set({
        priceEstimation: {
          ...pricing,
          distance
        }
      });
    }
  },
  
  reset: () => set(initialState)
}));
