import { useState, useEffect } from 'react';
import { RouteInfo } from '@/types';

interface UseRouteTrackingProps {
  pickupLocation: { lat: number; lng: number };
  deliveryLocation: { lat: number; lng: number };
  driverLocation?: { lat: number; lng: number };
  orderStatus: string;
  distance: number; // Total distance in km
}

interface UseRouteTrackingResult {
  routeInfo: RouteInfo | null;
  activeSegment: number;
  progress: number;
  estimatedTimeRemaining: number; // in minutes
}

/**
 * This hook calculates and tracks the progress of a delivery route
 * It simulates route tracking with segments for demonstration purposes
 * In a production environment, this would be replaced with actual route data from a maps API
 */
export function useRouteTracking({
  pickupLocation,
  deliveryLocation,
  driverLocation,
  orderStatus,
  distance
}: UseRouteTrackingProps): UseRouteTrackingResult {
  const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);
  const [activeSegment, setActiveSegment] = useState(0);
  const [progress, setProgress] = useState(0);
  const [estimatedTimeRemaining, setEstimatedTimeRemaining] = useState(0);
  
  // Simulate route data based on pickup and delivery locations
  useEffect(() => {
    // Create a simplified route with 3 segments between pickup and delivery
    const generateSimplifiedRoute = () => {
      // Calculate intermediate points along a straight line
      const calculateIntermediatePoint = (
        p1: { lat: number; lng: number }, 
        p2: { lat: number; lng: number }, 
        ratio: number
      ) => {
        return {
          lat: p1.lat + (p2.lat - p1.lat) * ratio,
          lng: p1.lng + (p2.lng - p1.lng) * ratio
        };
      };
      
      // Generate path points for a segment with some randomness to simulate real routes
      const generatePathPoints = (start: { lat: number; lng: number }, end: { lat: number; lng: number }, pointCount: number) => {
        const path = [start];
        
        for (let i = 1; i < pointCount - 1; i++) {
          const ratio = i / pointCount;
          const basePoint = calculateIntermediatePoint(start, end, ratio);
          
          // Add small random variation (except for very short distances)
          const latVariation = (Math.random() - 0.5) * 0.005;
          const lngVariation = (Math.random() - 0.5) * 0.005;
          
          path.push({
            lat: basePoint.lat + latVariation,
            lng: basePoint.lng + lngVariation
          });
        }
        
        path.push(end);
        return path;
      };
      
      // Create 3 segments that form the route
      const midPoint1 = calculateIntermediatePoint(pickupLocation, deliveryLocation, 0.33);
      const midPoint2 = calculateIntermediatePoint(pickupLocation, deliveryLocation, 0.66);
      
      // Generate paths with enough points for smooth visualization
      const path1 = generatePathPoints(pickupLocation, midPoint1, 10);
      const path2 = generatePathPoints(midPoint1, midPoint2, 10);
      const path3 = generatePathPoints(midPoint2, deliveryLocation, 10);
      
      // Calculate segment distances (in km using a simplified formula)
      const calculateDistance = (p1: { lat: number; lng: number }, p2: { lat: number; lng: number }) => {
        const R = 6371; // Earth radius in km
        const dLat = (p2.lat - p1.lat) * Math.PI / 180;
        const dLon = (p2.lng - p1.lng) * Math.PI / 180;
        const a = 
          Math.sin(dLat/2) * Math.sin(dLat/2) +
          Math.cos(p1.lat * Math.PI / 180) * Math.cos(p2.lat * Math.PI / 180) * 
          Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
      };
      
      // Calculate average speed based on the total distance (faster for longer routes)
      // This is a simplified model - real world would use traffic data, road types, etc.
      const baseSpeed = 30; // km/h for short distances
      const avgSpeed = Math.min(60, baseSpeed + distance * 2); // Cap at 60 km/h
      
      // Create the segment objects with distances and estimated times
      const segments = [
        {
          path: path1,
          distance: calculateDistance(pickupLocation, midPoint1),
          estimatedTime: (calculateDistance(pickupLocation, midPoint1) / avgSpeed) * 60 // minutes
        },
        {
          path: path2,
          distance: calculateDistance(midPoint1, midPoint2),
          estimatedTime: (calculateDistance(midPoint1, midPoint2) / avgSpeed) * 60 // minutes
        },
        {
          path: path3,
          distance: calculateDistance(midPoint2, deliveryLocation),
          estimatedTime: (calculateDistance(midPoint2, deliveryLocation) / avgSpeed) * 60 // minutes
        }
      ];
      
      // Return the complete route info
      return {
        distance,
        estimatedTime: segments.reduce((total, segment) => total + segment.estimatedTime, 0),
        segments
      };
    };
    
    // Generate the route data
    setRouteInfo(generateSimplifiedRoute());
  }, [pickupLocation, deliveryLocation, distance]);
  
  // Update progress based on order status and driver location
  useEffect(() => {
    if (!routeInfo) return;
    
    // Map order status to route progress
    switch (orderStatus) {
      case 'pending':
      case 'driver_assigned':
        setActiveSegment(0);
        setProgress(0);
        break;
        
      case 'on_way_to_pickup':
        setActiveSegment(0);
        // Simulate progress in the first segment
        setProgress(0.5);
        break;
        
      case 'arrived_at_pickup':
        setActiveSegment(0);
        setProgress(1);
        break;
        
      case 'package_picked_up':
        setActiveSegment(1);
        setProgress(0.3);
        break;
        
      case 'on_way_to_delivery':
        setActiveSegment(1);
        setProgress(0.8);
        break;
        
      case 'arrived_at_delivery':
        setActiveSegment(2);
        setProgress(0.5);
        break;
        
      case 'delivered':
        setActiveSegment(2);
        setProgress(1);
        break;
        
      default:
        setActiveSegment(0);
        setProgress(0);
    }
    
    // If we have driver location, we could use it to calculate more accurate progress
    if (driverLocation && routeInfo && orderStatus !== 'delivered') {
      // This would be replaced with actual distance calculation along the route
      // For now, we'll use a simplified approach
      // (In a real app, you would use maps API distance matrix service)
      
      // Calculate remaining distance to delivery location
      const calculateRemainingDistance = () => {
        const R = 6371; // Earth radius in km
        const dLat = (deliveryLocation.lat - driverLocation.lat) * Math.PI / 180;
        const dLon = (deliveryLocation.lng - driverLocation.lng) * Math.PI / 180;
        const a = 
          Math.sin(dLat/2) * Math.sin(dLat/2) +
          Math.cos(driverLocation.lat * Math.PI / 180) * Math.cos(deliveryLocation.lat * Math.PI / 180) * 
          Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c; // in km
      };
      
      // Calculate the remaining distance
      const remainingDistance = calculateRemainingDistance();
      
      // Calculate estimated time remaining
      const averageSpeed = 30; // km/h (adjust based on delivery method, traffic, etc.)
      const estimatedMinutes = (remainingDistance / averageSpeed) * 60;
      
      setEstimatedTimeRemaining(Math.max(1, Math.round(estimatedMinutes)));
    } else if (orderStatus === 'delivered') {
      setEstimatedTimeRemaining(0);
    } else if (routeInfo) {
      // If no driver location but we have route info, estimate based on segments
      let remainingTime = 0;
      
      // Add up estimated time for remaining segments
      for (let i = activeSegment; i < routeInfo.segments.length; i++) {
        if (i === activeSegment) {
          // For the active segment, consider only the remaining portion
          remainingTime += routeInfo.segments[i].estimatedTime * (1 - progress);
        } else {
          // For future segments, add their full estimated time
          remainingTime += routeInfo.segments[i].estimatedTime;
        }
      }
      
      setEstimatedTimeRemaining(Math.round(remainingTime));
    }
  }, [routeInfo, orderStatus, driverLocation, deliveryLocation, activeSegment, progress]);
  
  return { routeInfo, activeSegment, progress, estimatedTimeRemaining };
}