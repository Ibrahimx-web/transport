import { useLocation } from 'wouter';
import { BottomNavigation } from '@/components/layout/BottomNavigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  ArrowLeft, ChevronRight, User, Mail, Phone, LogOut, 
  Truck, History, FileEdit, Settings, ShieldCheck 
} from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { User as UserType } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Skeleton } from '@/components/ui/skeleton';
import { CurrencySelector } from '@/components/common/CurrencySelector';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';

export default function Profile() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Get current user from API
  const { data: user, isLoading, error } = useQuery<UserType>({
    queryKey: ['/api/users/current'],
  });
  
  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/users/logout");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/current'] });
      toast({ title: "Logged out successfully" });
      navigate('/');
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: error.message || "Please try again",
      });
    }
  });
  
  // If no user is authenticated, redirect to login
  if (error) {
    navigate('/login');
    return null;
  }
  
  const handleBack = () => {
    navigate('/');
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };
  
  return (
    <div className="app-container">
      {/* Header */}
      <header className="page-header">
        <div className="flex items-center">
          <button onClick={handleBack} className="mr-3">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-lg font-semibold">Profile</h1>
        </div>
        <CurrencySelector />
      </header>
      
      {/* Profile Information */}
      <div className="px-4 py-6">
        <div className="flex items-center space-x-4 mb-6">
          <Avatar className="w-20 h-20 border-4 border-primary/10">
            <AvatarImage src={user?.profilePicture} />
            <AvatarFallback className="bg-primary/10 text-primary text-xl">
              {isLoading ? '...' : user?.fullName ? getInitials(user.fullName) : 'U'}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            {isLoading ? (
              <Skeleton className="h-7 w-40 mb-2" />
            ) : (
              <h2 className="text-xl font-bold">{user?.fullName || 'User'}</h2>
            )}
            <div className="flex items-center text-sm text-muted-foreground">
              <Mail className="h-3.5 w-3.5 mr-1.5" />
              {isLoading ? (
                <Skeleton className="h-4 w-32" />
              ) : (
                <span className="truncate max-w-[200px]">{user?.email}</span>
              )}
            </div>
            <div className="mt-3">
              <Button 
                size="sm" 
                variant="outline"
                onClick={() => navigate('/profile/edit')}
                className="text-xs h-8"
              >
                <FileEdit className="h-3.5 w-3.5 mr-1.5" />
                Edit Profile
              </Button>
            </div>
          </div>
        </div>
        
        {/* User Type Badge */}
        {user && (
          <div className="mb-6">
            <div className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium ${
              user.userType === 'delivery' 
                ? 'bg-blue-100 text-blue-800' 
                : 'bg-emerald-100 text-emerald-800'
            }`}>
              <ShieldCheck className="h-3.5 w-3.5 mr-1.5" />
              {user.userType === 'delivery' ? 'Delivery Partner' : 'Customer'}
            </div>
          </div>
        )}
      </div>
      
      <Separator />
      
      {/* Quick Actions */}
      <div className="px-4 py-5">
        <h3 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wider">Quick Actions</h3>
        
        <div className="space-y-1">
          {user?.userType === 'customer' && (
            <Card className="border-0 shadow-none">
              <CardContent className="p-0">
                <button 
                  className="w-full py-3 flex items-center justify-between text-foreground hover:bg-muted/50 rounded-md transition-colors"
                  onClick={() => navigate('/book')}
                >
                  <div className="flex items-center">
                    <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                      <Truck className="h-5 w-5 text-primary" />
                    </div>
                    <span className="font-medium">Request Transport</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </button>
              </CardContent>
            </Card>
          )}
          
          {user?.userType === 'delivery' && (
            <Card className="border-0 shadow-none">
              <CardContent className="p-0">
                <button 
                  className="w-full py-3 flex items-center justify-between text-foreground hover:bg-muted/50 rounded-md transition-colors"
                  onClick={() => navigate('/')}
                >
                  <div className="flex items-center">
                    <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                      <Truck className="h-5 w-5 text-primary" />
                    </div>
                    <span className="font-medium">View Delivery Requests</span>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </button>
              </CardContent>
            </Card>
          )}
          
          <Card className="border-0 shadow-none">
            <CardContent className="p-0">
              <button 
                className="w-full py-3 flex items-center justify-between text-foreground hover:bg-muted/50 rounded-md transition-colors"
                onClick={() => navigate('/history')}
              >
                <div className="flex items-center">
                  <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                    <History className="h-5 w-5 text-primary" />
                  </div>
                  <span className="font-medium">Order History</span>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </button>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-none">
            <CardContent className="p-0">
              <button 
                className="w-full py-3 flex items-center justify-between text-foreground hover:bg-muted/50 rounded-md transition-colors"
                onClick={() => navigate('/profile/edit')}
              >
                <div className="flex items-center">
                  <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                    <Settings className="h-5 w-5 text-primary" />
                  </div>
                  <span className="font-medium">Settings</span>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </button>
            </CardContent>
          </Card>
          
          <Card className="border-0 shadow-none">
            <CardContent className="p-0">
              <button 
                className="w-full py-3 flex items-center justify-between hover:bg-red-50 rounded-md transition-colors"
                onClick={handleLogout}
              >
                <div className="flex items-center">
                  <div className="h-9 w-9 rounded-full bg-red-100 flex items-center justify-center mr-3">
                    <LogOut className="h-5 w-5 text-red-500" />
                  </div>
                  <span className="font-medium text-red-500">Log Out</span>
                </div>
                <ChevronRight className="h-5 w-5 text-red-300" />
              </button>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="px-4 py-8 text-center text-xs text-muted-foreground mt-auto">
        <p>Ask for Transport v1.0.0</p>
        <p className="mt-1">© 2023 Ask for Transport Inc.</p>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
