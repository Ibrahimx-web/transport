import * as React from "react";
import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShieldAlert, ArrowLeft } from "lucide-react";
import { UserCredentials, User } from "@/types";

// Admin login schema
const adminLoginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required")
});

export default function AdminLogin() {
  const [, setLocation] = useLocation();
  const [showAdminRegistration, setShowAdminRegistration] = useState(false);
  const { toast } = useToast();

  // Admin login form
  const form = useForm<UserCredentials>({
    resolver: zodResolver(adminLoginSchema),
    defaultValues: {
      username: "",
      password: ""
    }
  });

  const loginMutation = useMutation({
    mutationFn: async (data: UserCredentials) => {
      const response = await apiRequest("POST", "/api/users/login", data);
      const responseData = await response.json();
      console.log("Login response:", responseData);
      return responseData;
    },
    onSuccess: (data) => {
      // Check if user is an admin
      console.log("Login success:", data);
      if (data && data.userType === 'admin') {
        toast({
          title: "Login successful",
          description: "Welcome back to the admin dashboard",
        });
        // Use window.location.href to ensure a full page reload with fresh session
        console.log("Redirecting admin to dashboard");
        window.location.href = "/admin/dashboard";
      } else {
        toast({
          title: "Access denied",
          description: "This login is only for administrators",
          variant: "destructive"
        });
        form.reset();
      }
    },
    onError: (error: any) => {
      console.error("Login error:", error);
      toast({
        title: "Login failed",
        description: error.message || "Invalid username or password",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: UserCredentials) => {
    loginMutation.mutate(data);
  };

  // Toggle admin registration
  const toggleAdminRegistration = () => {
    setShowAdminRegistration(!showAdminRegistration);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-slate-900 text-white p-4 flex items-center gap-2">
        <Button 
          variant="ghost" 
          size="icon"
          className="text-white" 
          onClick={() => setLocation("/")}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold">Administrator Login</h1>
      </header>

      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="bg-slate-900 text-white rounded-t-lg">
            <div className="flex items-center gap-2">
              <ShieldAlert className="h-6 w-6" />
              <CardTitle>Admin Access</CardTitle>
            </div>
            <CardDescription className="text-slate-300">
              Secure administrator login portal
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Administrator Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter admin username" 
                          {...field} 
                          className="bg-slate-50"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Administrator Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Enter admin password" 
                          {...field} 
                          className="bg-slate-50"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full bg-slate-800 hover:bg-slate-700" 
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? "Authenticating..." : "Login to Admin Panel"}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-center border-t pt-4 flex-col gap-2">
            <Button 
              variant="link" 
              className="text-sm text-slate-500"
              onClick={toggleAdminRegistration}
            >
              {showAdminRegistration ? "Hide registration" : "Need to register as admin?"}
            </Button>
            
            {showAdminRegistration && (
              <div className="text-center text-sm text-slate-600 p-2 bg-slate-50 rounded-md">
                <p>To register as an administrator, use the standard registration page and enter the secure admin code.</p>
                <Button 
                  variant="link" 
                  onClick={() => {
                    setLocation("/register?admin=true");
                  }}
                  className="mt-2"
                >
                  Go to registration
                </Button>
              </div>
            )}
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}