import { SimpleMapTest } from '@/components/test/SimpleMapTest';
import { SafeRouteVisualizationDemo } from '@/components/test/SafeRouteVisualizationDemo';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Map, Route } from 'lucide-react';

export default function MapTest() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Map Integration Test Page</h1>
        <Link href="/">
          <Button variant="outline" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </Link>
      </div>
      
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
        <div className="flex items-start gap-3">
          <Map className="h-6 w-6 text-blue-600 mt-0.5" />
          <div>
            <h2 className="text-lg font-medium text-blue-800 mb-1">Map Testing Suite</h2>
            <p className="text-sm text-blue-700 mb-2">
              This page contains various test components to verify our Google Maps integration. 
              The components include error boundaries to prevent map failures from crashing the application.
            </p>
          </div>
        </div>
      </div>
      
      <div className="grid gap-8">
        {/* Basic Map Test */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Map className="h-5 w-5 text-gray-700" />
            <h2 className="text-xl font-semibold">Basic Map Test</h2>
          </div>
          <SimpleMapTest />
        </section>
        
        {/* Route Visualization Test */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Route className="h-5 w-5 text-gray-700" />
            <h2 className="text-xl font-semibold">Route Visualization Test</h2>
          </div>
          <div className="bg-white p-4 rounded-lg border shadow-sm">
            <p className="text-sm text-gray-600 mb-4">
              This component tests the route visualization with animated markers and error boundaries.
            </p>
            <SafeRouteVisualizationDemo />
          </div>
        </section>
      </div>
    </div>
  );
}