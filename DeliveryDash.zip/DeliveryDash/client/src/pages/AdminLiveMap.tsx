import * as React from 'react';
import { useEffect } from 'react';
import UserLocationsMap from '@/components/admin/UserLocationsMap';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { User } from '@shared/schema';
import { AdminSidebar } from '@/components/admin/AdminSidebar';
import { 
  RefreshCw, 
  MapPin, 
  Truck, 
  User as UserIcon, 
  CheckCircle2 
} from 'lucide-react';

export default function AdminLiveMap() {
  // Check if current user is an admin
  const { data: currentUser, isLoading: userLoading } = useQuery<User>({
    queryKey: ['/api/users/current'],
    refetchOnWindowFocus: false
  });

  // Redirect to login if not admin
  useEffect(() => {
    if (!userLoading && (!currentUser || currentUser.userType !== 'admin')) {
      window.location.href = '/admin/login';
    }
  }, [currentUser, userLoading]);

  if (userLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!currentUser || currentUser.userType !== 'admin') {
    return null;
  }

  return (
    <div className="container mx-auto p-4">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">Live Location Tracking</h1>
        <p className="text-muted-foreground">Monitor real-time locations of users and delivery partners</p>
      </header>
      
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* Sidebar navigation */}
        <div className="md:col-span-1">
          <AdminSidebar />
        </div>

        {/* Main content */}
        <div className="md:col-span-4 space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Live Map</h2>
              <p className="text-muted-foreground">
                Real-time tracking of customers and delivery personnel
              </p>
            </div>
            <Button variant="outline" onClick={() => window.location.reload()}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
          
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mb-4">
            <div className="flex gap-3">
              <div className="rounded-full bg-blue-500 p-2 h-fit">
                <MapPin className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-800">Enhanced Real-time User Tracking</h3>
                <p className="text-blue-700 text-sm mt-1">
                  This improved live map now allows you to search and filter connected users by type and name. 
                  You can view all locations on the map or browse through the user list.
                  Click on any user to view detailed information or locate them on the map.
                </p>
                <div className="flex gap-2 mt-2">
                  <div className="flex items-center text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-md">
                    <Truck className="h-3 w-3 mr-1 text-blue-600" />
                    Driver
                  </div>
                  <div className="flex items-center text-xs bg-green-100 text-green-800 px-2 py-1 rounded-md">
                    <UserIcon className="h-3 w-3 mr-1 text-green-600" />
                    Customer
                  </div>
                  <div className="flex items-center text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-md">
                    <CheckCircle2 className="h-3 w-3 mr-1 text-purple-600" />
                    Admin
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow border">
            <UserLocationsMap />
          </div>
        </div>
      </div>
    </div>
  );
}