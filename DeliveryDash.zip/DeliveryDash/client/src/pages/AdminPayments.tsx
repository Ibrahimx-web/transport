import * as React from "react";
import { useState, useEffect } from "react";
import { format, subMonths } from "date-fns";
import { 
  AlertCircle, 
  Download, 
  FileText, 
  CreditCard, 
  DollarSign, 
  Calendar, 
  ChevronsUpDown, 
  Check,
  X,
  Printer,
  MailOpen,
  RefreshCw
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/currency";
import { PageTransition } from "@/components/ui/page-transition";

import { AdminSidebar } from "@/components/admin/AdminSidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import { LoadingAnimation } from "@/components/ui/loading-spinner";

// Types for our payment data
interface PartnerPayment {
  id: number;
  partnerId: number;
  orderId: number;
  amount: number;
  commissionPercentage: number;
  commissionAmount: number;
  finalPayment: number;
  status: string;
  paymentDate: string | null;
  createdAt: string;
  processedBy: number | null;
  partnerName?: string;
}

interface CustomerPayment {
  id: number;
  userId: number;
  vehicleTypeId: number;
  status: string;
  distance: number;
  baseFare: number;
  distanceFare: number;
  serviceFee: number;
  totalFare: number;
  createdAt: string;
  userName?: string;
  vehicleTypeName?: string;
}

interface DeliveryPartner {
  id: number;
  username: string;
}

// Commission chart data structure
interface CommissionSummary {
  totalCommission: number;
  totalPayments: number;
  pendingPayments: number;
  weeklyTrend: { date: string; amount: number }[];
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return format(date, "MMM dd, yyyy h:mm a");
}

// Component for data export functionality
function ExportControls({ type, onExport }: { type: 'customer' | 'partner', onExport: (format: string) => void }) {
  const [exportFormat, setExportFormat] = useState("pdf");
  
  return (
    <div className="flex items-center space-x-2">
      <Select value={exportFormat} onValueChange={setExportFormat}>
        <SelectTrigger className="w-[120px]">
          <SelectValue placeholder="Format" />
        </SelectTrigger>
        <SelectContent>
          <SelectGroup>
            <SelectLabel>Export Format</SelectLabel>
            <SelectItem value="pdf">PDF</SelectItem>
            <SelectItem value="csv">CSV</SelectItem>
            <SelectItem value="excel">Excel</SelectItem>
          </SelectGroup>
        </SelectContent>
      </Select>
      
      <Button 
        variant="outline" 
        size="sm" 
        onClick={() => onExport(exportFormat)}
        className="flex items-center space-x-1"
      >
        <Download size={16} />
        <span>Export</span>
      </Button>
      
      <Button 
        variant="outline" 
        size="sm"
        onClick={() => onExport("print")}
        className="flex items-center space-x-1"
      >
        <Printer size={16} />
        <span>Print</span>
      </Button>
    </div>
  );
}

function PartnerPaymentsTable({ payments, refetch }: { payments: PartnerPayment[], refetch: () => void }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const processPaymentMutation = useMutation({
    mutationFn: async (paymentId: number) => {
      const response = await apiRequest("POST", `/api/partner-payments/${paymentId}/process`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/partner-payments'] });
      toast({
        title: "Payment Processed",
        description: "The payment has been marked as paid",
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Failed to process payment",
        description: "There was an error processing the payment",
        variant: "destructive",
      });
    }
  });
  
  return (
    <Table>
      <TableCaption>Partner payments and commissions</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead>Partner</TableHead>
          <TableHead>Order ID</TableHead>
          <TableHead>Total Amount</TableHead>
          <TableHead>Commission</TableHead>
          <TableHead>Final Payment</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Created</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {payments.length === 0 ? (
          <TableRow>
            <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
              No partner payments found
            </TableCell>
          </TableRow>
        ) : (
          payments.map((payment) => (
            <TableRow key={payment.id}>
              <TableCell>
                <div className="font-medium">{payment.partnerName || `Partner #${payment.partnerId}`}</div>
              </TableCell>
              <TableCell>{payment.orderId}</TableCell>
              <TableCell>{formatCurrency(payment.amount)}</TableCell>
              <TableCell>{payment.commissionPercentage}% ({formatCurrency(payment.commissionAmount)})</TableCell>
              <TableCell className="font-semibold">{formatCurrency(payment.finalPayment)}</TableCell>
              <TableCell>
                {payment.status === "pending" ? (
                  <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                    Pending
                  </Badge>
                ) : payment.status === "paid" ? (
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    Paid on {payment.paymentDate ? formatDate(payment.paymentDate) : "N/A"}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                    {payment.status}
                  </Badge>
                )}
              </TableCell>
              <TableCell>{formatDate(payment.createdAt)}</TableCell>
              <TableCell>
                {payment.status === "pending" && (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                        Pay Now
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Process Payment</DialogTitle>
                        <DialogDescription>
                          Are you sure you want to process this payment for {formatCurrency(payment.finalPayment)}?
                        </DialogDescription>
                      </DialogHeader>
                      <div className="py-4">
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Partner:</span>
                            <span>{payment.partnerName || `Partner #${payment.partnerId}`}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Order ID:</span>
                            <span>#{payment.orderId}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Total Amount:</span>
                            <span>{formatCurrency(payment.amount)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Commission ({payment.commissionPercentage}%):</span>
                            <span>{formatCurrency(payment.commissionAmount)}</span>
                          </div>
                          <div className="flex justify-between font-medium">
                            <span>Final Payment:</span>
                            <span>{formatCurrency(payment.finalPayment)}</span>
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <DialogClose asChild>
                          <Button variant="outline">Cancel</Button>
                        </DialogClose>
                        <Button 
                          onClick={() => {
                            processPaymentMutation.mutate(payment.id);
                          }}
                          disabled={processPaymentMutation.isPending}
                        >
                          {processPaymentMutation.isPending ? "Processing..." : "Confirm Payment"}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                )}
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );
}

function CustomerPaymentsTable({ payments }: { payments: CustomerPayment[] }) {
  return (
    <Table>
      <TableCaption>Customer payment transactions</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead>Customer</TableHead>
          <TableHead>Order ID</TableHead>
          <TableHead>Vehicle Type</TableHead>
          <TableHead>Distance</TableHead>
          <TableHead>Base Fare</TableHead>
          <TableHead>Distance Fare</TableHead>
          <TableHead>Service Fee</TableHead>
          <TableHead>Total</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Date</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {payments.length === 0 ? (
          <TableRow>
            <TableCell colSpan={10} className="text-center py-8 text-muted-foreground">
              No customer payments found
            </TableCell>
          </TableRow>
        ) : (
          payments.map((payment) => (
            <TableRow key={payment.id}>
              <TableCell>
                <div className="font-medium">{payment.userName || `User #${payment.userId}`}</div>
              </TableCell>
              <TableCell>{payment.id}</TableCell>
              <TableCell>{payment.vehicleTypeName || `Type #${payment.vehicleTypeId}`}</TableCell>
              <TableCell>{payment.distance.toFixed(2)} km</TableCell>
              <TableCell>{formatCurrency(payment.baseFare)}</TableCell>
              <TableCell>{formatCurrency(payment.distanceFare)}</TableCell>
              <TableCell>{formatCurrency(payment.serviceFee)}</TableCell>
              <TableCell className="font-semibold">{formatCurrency(payment.totalFare)}</TableCell>
              <TableCell>
                {payment.status === "delivered" ? (
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    Completed
                  </Badge>
                ) : payment.status === "pending" ? (
                  <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                    {payment.status}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    {payment.status}
                  </Badge>
                )}
              </TableCell>
              <TableCell>{formatDate(payment.createdAt)}</TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );
}

function DateRangeSelector({ 
  startDate, 
  endDate, 
  onRangeChange 
}: { 
  startDate: Date; 
  endDate: Date; 
  onRangeChange: (startDate: Date, endDate: Date) => void;
}) {
  const ranges = [
    { label: 'Last 7 days', days: 7 },
    { label: 'Last 30 days', days: 30 },
    { label: 'Last 90 days', days: 90 },
    { label: 'All time', days: 1095 }  // ~3 years
  ];
  
  return (
    <div className="flex items-center space-x-2">
      <Label>Date Range:</Label>
      <Select 
        value={ranges.find(r => 
          r.days === Math.round((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
        )?.days.toString() || 'custom'}
        onValueChange={(value) => {
          if (value !== 'custom') {
            const days = parseInt(value);
            const newStartDate = subMonths(new Date(), days / 30);
            onRangeChange(newStartDate, new Date());
          }
        }}
      >
        <SelectTrigger className="w-[150px]">
          <SelectValue placeholder="Select range" />
        </SelectTrigger>
        <SelectContent>
          {ranges.map((range) => (
            <SelectItem key={range.days} value={range.days.toString()}>
              {range.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      
      <div className="text-sm text-muted-foreground">
        {format(startDate, "MMM dd, yyyy")} - {format(endDate, "MMM dd, yyyy")}
      </div>
    </div>
  );
}

function RetentionPolicyAlert({ onArchive }: { onArchive: () => void }) {
  return (
    <Alert variant="default" className="bg-blue-50 border-blue-200 my-4">
      <AlertCircle className="h-4 w-4 text-blue-600" />
      <AlertTitle>Data Retention Policy</AlertTitle>
      <AlertDescription>
        Transaction data is kept for 3 months. Older records are archived and emailed to the admin before being removed from the system.
      </AlertDescription>
      <div className="mt-2">
        <Button 
          variant="outline" 
          size="sm" 
          className="border-blue-600 text-blue-600 hover:bg-blue-100"
          onClick={onArchive}
        >
          <MailOpen className="mr-2 h-4 w-4" />
          Archive Old Records
        </Button>
      </div>
    </Alert>
  );
}

function CommissionSettingsDialog() {
  const [defaultCommission, setDefaultCommission] = useState(15);
  const { toast } = useToast();
  
  const saveSettings = () => {
    // This would call an API to save the commission settings
    // For now we just show a toast
    toast({
      title: "Settings Saved",
      description: `Default commission set to ${defaultCommission}%`,
    });
  };
  
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">Configure Commission</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Commission Settings</DialogTitle>
          <DialogDescription>
            Configure the default commission percentage for delivery partners.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="default-commission">Default Commission Percentage</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="default-commission"
                  type="number"
                  min="0"
                  max="100"
                  value={defaultCommission}
                  onChange={(e) => setDefaultCommission(parseInt(e.target.value))}
                  className="w-24"
                />
                <span>%</span>
              </div>
              <p className="text-sm text-muted-foreground">
                This is the standard percentage that will be deducted from partner payments.
              </p>
            </div>
            
            <div className="space-y-2">
              <Label>Commission Tiers</Label>
              <div className="text-sm text-muted-foreground">
                Configure different commission rates based on order value or partner rating.
              </div>
              <Button variant="outline" size="sm" className="mt-2">
                <FileText className="h-4 w-4 mr-2" />
                Configure Tiers
              </Button>
            </div>
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Cancel</Button>
          </DialogClose>
          <Button onClick={saveSettings}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AutomaticPaymentsSwitch({ isEnabled, onChange }: { isEnabled: boolean, onChange: (enabled: boolean) => void }) {
  return (
    <div className="flex items-center space-x-2">
      <Switch
        id="automatic-payments"
        checked={isEnabled}
        onCheckedChange={onChange}
      />
      <Label htmlFor="automatic-payments" className="font-normal text-sm">
        Auto-process payments
      </Label>
    </div>
  );
}

function AdminPayments() {
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState<string>("customer");
  
  // Date range for filtering
  const [startDate, setStartDate] = useState<Date>(subMonths(new Date(), 1));
  const [endDate, setEndDate] = useState<Date>(new Date());
  
  // State for automatic payments toggle
  const [automaticPayments, setAutomaticPayments] = useState<boolean>(false);
  
  // Fetch the automatic payments setting from the API
  useEffect(() => {
    const fetchAutoPaymentsSetting = async () => {
      try {
        const res = await apiRequest('GET', '/api/settings/auto-payments');
        if (res.ok) {
          const data = await res.json();
          setAutomaticPayments(data.enabled);
        }
      } catch (error) {
        console.error('Failed to fetch automatic payments setting:', error);
      }
    };
    
    fetchAutoPaymentsSetting();
  }, []);
  
  // Query for customer payments (orders) with real-time data
  const { 
    data: customerPayments = [], 
    isLoading: isLoadingCustomerPayments,
    refetch: refetchCustomerPayments,
    dataUpdatedAt: customerPaymentsUpdatedAt
  } = useQuery<CustomerPayment[]>({
    queryKey: ['/api/customer-payments', startDate.toISOString(), endDate.toISOString()],
    queryFn: async ({ queryKey }) => {
      const [_, startDateStr, endDateStr] = queryKey;
      console.log(`[ADMIN] Fetching customer payments from ${startDateStr} to ${endDateStr}`);
      const res = await apiRequest('GET', `/api/customer-payments?startDate=${startDateStr}&endDate=${endDateStr}`);
      if (!res.ok) {
        throw new Error('Failed to fetch customer payments');
      }
      
      const data = await res.json();
      console.log(`[ADMIN] Received ${data.length} customer payments`);
      return data;
    },
    staleTime: 60000, // Consider data stale after 1 minute
  });
  
  // Query for partner payments with performance tracking
  const { 
    data: partnerPayments = [], 
    isLoading: isLoadingPartnerPayments,
    refetch: refetchPartnerPayments,
    dataUpdatedAt: partnerPaymentsUpdatedAt
  } = useQuery<PartnerPayment[]>({
    queryKey: ['/api/partner-payments', startDate.toISOString(), endDate.toISOString()],
    queryFn: async ({ queryKey }) => {
      const fetchStartTime = Date.now();
      const [_, startDateStr, endDateStr] = queryKey;
      console.log(`[ADMIN] Fetching partner payments from ${startDateStr} to ${endDateStr}`);
      
      const res = await apiRequest('GET', `/api/partner-payments?startDate=${startDateStr}&endDate=${endDateStr}`);
      if (!res.ok) {
        throw new Error('Failed to fetch partner payments');
      }
      
      const data = await res.json();
      const fetchDuration = Date.now() - fetchStartTime;
      console.log(`[ADMIN] Received ${data.length} partner payments in ${fetchDuration}ms`);
      
      return data;
    },
    staleTime: 60000, // Consider data stale after 1 minute
  });
  
  // State to track last refresh time
  const [lastRefreshTime, setLastRefreshTime] = useState<Date>(new Date());
  const [isAutoRefresh, setIsAutoRefresh] = useState<boolean>(true);
  const [refreshInterval, setRefreshInterval] = useState<number>(30000); // 30 seconds by default
  
  // Function to manually refresh data
  const handleManualRefresh = () => {
    setLastRefreshTime(new Date());
    refetchCustomerPayments();
    refetchPartnerPayments();
    toast({
      title: "Dashboard Refreshed",
      description: "Payment data has been updated",
    });
  };
  
  // Auto refresh based on interval
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    
    if (isAutoRefresh) {
      timer = setInterval(() => {
        setLastRefreshTime(new Date());
        refetchCustomerPayments();
        refetchPartnerPayments();
        console.log("[ADMIN] Auto-refreshing payment dashboard data");
      }, refreshInterval);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isAutoRefresh, refreshInterval, refetchCustomerPayments, refetchPartnerPayments]);
  
  // For partners dropdown in filtering
  const { data: partners = [] } = useQuery<DeliveryPartner[]>({
    queryKey: ['/api/admin/users'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/admin/users');
      if (!res.ok) {
        throw new Error('Failed to fetch users');
      }
      const users = await res.json();
      // Filter out just the delivery partners
      return users.filter((user: any) => user.userType === 'delivery_partner');
    }
  });
  
  // For commission summary chart
  const { data: commissionSummary } = useQuery<CommissionSummary>({
    queryKey: ['/api/commission-summary'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/commission-summary');
      if (!res.ok) {
        throw new Error('Failed to fetch commission summary');
      }
      return await res.json();
    }
  });
  
  // Mutation for archiving old records
  const archiveRecordsMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/payments/archive', {
        olderThanDate: subMonths(new Date(), 3).toISOString()
      });
      if (!res.ok) {
        throw new Error('Failed to archive records');
      }
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Records Archived",
        description: `${data.archived || 0} records have been archived.`,
      });
      refetchCustomerPayments();
      refetchPartnerPayments();
    },
    onError: (error) => {
      toast({
        title: "Archive Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Handler for date range changes
  const handleDateRangeChange = (newStartDate: Date, newEndDate: Date) => {
    setStartDate(newStartDate);
    setEndDate(newEndDate);
    // This will trigger refetching the data with the new date range
  };
  
  // Handler for exporting data
  const handleExport = (type: 'customer' | 'partner', format: string) => {
    toast({
      title: "Export Started",
      description: `Exporting ${type} payments as ${format.toUpperCase()}...`,
    });
    
    // In a real application, this would make an API call to generate and download the file
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: `${type === 'customer' ? 'Customer' : 'Partner'} payments have been exported.`,
      });
    }, 1500);
  };
  
  return (
    <PageTransition transitionKey="admin-payments" direction="fade">
      <div className="container mx-auto p-4">
        <header className="mb-8">
          <h1 className="text-3xl font-bold">Payment Dashboard</h1>
          <p className="text-muted-foreground">Manage customer payments and delivery partner commissions</p>
        </header>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          {/* Sidebar navigation */}
          <div className="md:col-span-1">
            <AdminSidebar />
          </div>
          
          {/* Main content */}
          <div className="md:col-span-4 space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold tracking-tight">Payment Records</h2>
                <p className="text-muted-foreground">
                  View and manage all payment transactions
                </p>
              </div>
            </div>
            
            <RetentionPolicyAlert 
              onArchive={() => archiveRecordsMutation.mutate()}
            />
            
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Payment Records</CardTitle>
                    <CardDescription>
                      View and manage all payment transactions
                    </CardDescription>
                    <div className="flex items-center mt-2 text-xs text-muted-foreground">
                      <span>
                        Last updated: {new Date(Math.max(customerPaymentsUpdatedAt || 0, partnerPaymentsUpdatedAt || 0)).toLocaleTimeString()}
                      </span>
                      {isAutoRefresh && (
                        <span className="ml-2 text-primary-600">· Auto refresh: ON</span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    {/* Refresh controls */}
                    <div className="flex items-center gap-3 mr-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleManualRefresh}
                        disabled={isLoadingCustomerPayments || isLoadingPartnerPayments}
                        className="h-9 flex items-center gap-1"
                      >
                        <RefreshCw className={cn(
                          "h-4 w-4",
                          (isLoadingCustomerPayments || isLoadingPartnerPayments) ? "animate-spin" : ""
                        )} />
                        Refresh
                      </Button>
                      
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="auto-refresh"
                          checked={isAutoRefresh}
                          onCheckedChange={setIsAutoRefresh}
                        />
                        <Label htmlFor="auto-refresh" className="text-sm">Auto</Label>
                      </div>
                    </div>
                  
                    <DateRangeSelector 
                      startDate={startDate}
                      endDate={endDate}
                      onRangeChange={handleDateRangeChange}
                    />
                    
                    <div className="hidden md:block">
                      <CommissionSettingsDialog />
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <Tabs defaultValue="customer" value={selectedTab} onValueChange={setSelectedTab}>
                <div className="px-4 flex items-center justify-between">
                  <TabsList>
                    <TabsTrigger value="customer" className="relative">
                      Customer Payments
                    </TabsTrigger>
                    <TabsTrigger value="partner" className="relative">
                      Partner Commissions
                      {partnerPayments.filter(p => p.status === "pending").length > 0 && (
                        <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] text-white">
                          {partnerPayments.filter(p => p.status === "pending").length}
                        </span>
                      )}
                    </TabsTrigger>
                  </TabsList>
                  
                  <div className="flex items-center space-x-2">
                    {selectedTab === "partner" && (
                      <AutomaticPaymentsSwitch 
                        isEnabled={automaticPayments}
                        onChange={setAutomaticPayments}
                      />
                    )}
                    
                    <ExportControls 
                      type={selectedTab as 'customer' | 'partner'} 
                      onExport={(format) => handleExport(selectedTab as 'customer' | 'partner', format)}
                    />
                  </div>
                </div>
                
                <TabsContent value="customer" className="p-0">
                  <CardContent className="p-0 overflow-auto">
                    {isLoadingCustomerPayments ? (
                      <div className="p-8 flex justify-center">
                        <LoadingAnimation size="lg" text="Loading payment data..." />
                      </div>
                    ) : (
                      <CustomerPaymentsTable payments={customerPayments} />
                    )}
                  </CardContent>
                </TabsContent>
                
                <TabsContent value="partner" className="p-0">
                  <CardContent className="p-0 overflow-auto">
                    {isLoadingPartnerPayments ? (
                      <div className="p-8 flex justify-center">
                        <LoadingAnimation size="lg" text="Loading partner payments..." />
                      </div>
                    ) : (
                      <PartnerPaymentsTable 
                        payments={partnerPayments} 
                        refetch={refetchPartnerPayments}
                      />
                    )}
                  </CardContent>
                </TabsContent>
              </Tabs>
              
              <CardFooter className="flex justify-between border-t p-4">
                <div className="text-sm text-muted-foreground">
                  {selectedTab === "customer" ? (
                    <span>Total: {customerPayments.length} transactions</span>
                  ) : (
                    <span>
                      Total: {partnerPayments.length} payments
                      ({partnerPayments.filter(p => p.status === "pending").length} pending)
                    </span>
                  )}
                </div>
                
                <div className="md:hidden">
                  <CommissionSettingsDialog />
                </div>
              </CardFooter>
            </Card>
            
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(customerPayments.reduce((sum, payment) => sum + payment.totalFare, 0))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    +{formatCurrency(customerPayments.reduce((sum, payment) => sum + payment.serviceFee, 0))} service fees
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Partner Earnings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(partnerPayments.reduce((sum, payment) => sum + payment.finalPayment, 0))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {partnerPayments.length} payments
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Commission Earned</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(partnerPayments.reduce((sum, payment) => sum + payment.commissionAmount, 0))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Avg. {partnerPayments.length > 0 ? (partnerPayments.reduce((sum, payment) => sum + payment.commissionPercentage, 0) / partnerPayments.length).toFixed(1) : 0}% rate
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(partnerPayments.filter(p => p.status === "pending").reduce((sum, payment) => sum + payment.finalPayment, 0))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {partnerPayments.filter(p => p.status === "pending").length} payments need processing
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}

export default AdminPayments;