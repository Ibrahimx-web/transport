import * as React from "react";
import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { CircleUser, Users, ClipboardList, LogOut } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AdminSidebar } from "@/components/admin/AdminSidebar";

import { 
  AdminDashboardSummary, 
  DeliveryPartnerStats, 
  User,
  AdminDashboardData,
  PendingOrderItem,
  DocumentVerificationItem
} from "@/types";

// Demo data for the admin dashboard
const demoSummary: AdminDashboardSummary = {
  totalUsers: 248,
  activeDrivers: 32,
  pendingOrders: 15,
  completedOrders: 1249,
  totalRevenue: 52689.75,
  dailyStats: [
    { date: "2025-03-26", orders: 42, revenue: 1250.50 },
    { date: "2025-03-27", orders: 38, revenue: 1120.25 },
    { date: "2025-03-28", orders: 45, revenue: 1350.00 },
    { date: "2025-03-29", orders: 51, revenue: 1520.75 },
    { date: "2025-03-30", orders: 48, revenue: 1410.50 },
    { date: "2025-03-31", orders: 52, revenue: 1580.25 },
    { date: "2025-04-01", orders: 55, revenue: 1650.00 }
  ]
};

// Demo pending orders
const demoPendingOrders = [
  { id: "ORD-9385", customer: "John Doe", pickup: "Nairobi CBD", delivery: "Westlands", status: "Pending" },
  { id: "ORD-9386", customer: "Jane Smith", pickup: "Mombasa Rd", delivery: "Kilimani", status: "Assigned" },
  { id: "ORD-9387", customer: "Alex Johnson", pickup: "Ngong Rd", delivery: "Karen", status: "In Transit" }
];

// Demo delivery partners
const demoPartners = [
  { id: 1, name: "Michael Waweru", deliveries: 128, rating: 4.8, earnings: 3850, isActive: true },
  { id: 2, name: "Sarah Kamau", deliveries: 95, rating: 4.9, earnings: 2950, isActive: true },
  { id: 3, name: "David Ochieng", deliveries: 112, rating: 4.7, earnings: 3250, isActive: false }
];

// Demo document verification
const demoDocuments = [
  { id: 1, partnerId: 4, partnerName: "John Kimani", documentType: "Driver's License", submittedDate: "2025-03-28", status: "Pending" },
  { id: 2, partnerId: 5, partnerName: "Alice Njeri", documentType: "Vehicle Registration", submittedDate: "2025-03-29", status: "Pending" },
  { id: 3, partnerId: 6, partnerName: "Peter Maina", documentType: "Insurance Certificate", submittedDate: "2025-03-30", status: "Pending" }
];

export default function AdminDashboard() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  // Get current admin user
  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ['/api/users/current'],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });
  
  // Fetch dashboard data from API
  const { data: dashboardData, isLoading: dashboardLoading } = useQuery<AdminDashboardData>({
    queryKey: ['/api/admin/dashboard-summary'],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!user && user.userType === 'admin'
  });
  
  // Define empty object with the correct type
  const emptyDashboardData: AdminDashboardData = {
    summary: demoSummary,
    pendingOrders: demoPendingOrders,
    partners: demoPartners,
    documents: demoDocuments
  };
  
  // Use real data if available, otherwise fallback to demo data
  const data = dashboardData || emptyDashboardData;
  const summary = data.summary;
  const pendingOrders = data.pendingOrders;
  const partners = data.partners;
  const documents = data.documents;
  
  // Handle logout
  const handleLogout = async () => {
    setIsLoading(true);
    try {
      await apiRequest("POST", "/api/users/logout");
      toast({
        title: "Logged out",
        description: "You have been logged out successfully"
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error logging out",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Combined loading state
  const isDataLoading = userLoading || dashboardLoading;

  return (
    <div className="container mx-auto p-4">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage your transportation platform</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* Sidebar navigation */}
        <div className="md:col-span-1">
          <AdminSidebar />
        </div>
        
        {/* Main content area */}
        <div className="md:col-span-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Total Users</CardDescription>
                <CardTitle className="text-2xl">{summary.totalUsers}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Active Drivers</CardDescription>
                <CardTitle className="text-2xl">{summary.activeDrivers}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Pending Orders</CardDescription>
                <CardTitle className="text-2xl">{summary.pendingOrders}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Total Revenue</CardDescription>
                <CardTitle className="text-2xl">${summary.totalRevenue.toFixed(2)}</CardTitle>
              </CardHeader>
            </Card>
          </div>
          
          <Tabs defaultValue="pending" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="pending">Pending Orders</TabsTrigger>
              <TabsTrigger value="verification">Document Verification</TabsTrigger>
              <TabsTrigger value="partners">Delivery Partners</TabsTrigger>
            </TabsList>
            
            <TabsContent value="pending">
              <Card>
                <CardHeader>
                  <CardTitle>Pending Orders</CardTitle>
                  <CardDescription>
                    Orders that need attention or assignment
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="py-2">
                    {isDataLoading ? (
                      <p className="text-center py-6 text-muted-foreground">Loading pending orders...</p>
                    ) : pendingOrders.length === 0 ? (
                      <p className="text-center py-6 text-muted-foreground">No pending orders available</p>
                    ) : (
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Order ID</th>
                            <th className="text-left py-2">Customer</th>
                            <th className="text-left py-2">Pickup</th>
                            <th className="text-left py-2">Delivery</th>
                            <th className="text-left py-2">Status</th>
                            <th className="text-right py-2">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {pendingOrders.map((order: PendingOrderItem) => (
                            <tr key={order.id} className="border-b">
                              <td className="py-3">{order.id}</td>
                              <td className="py-3">{order.customer}</td>
                              <td className="py-3">{order.pickup}</td>
                              <td className="py-3">{order.delivery}</td>
                              <td className="py-3">
                                <span className={
                                  order.status === "Pending" 
                                    ? "px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800" 
                                    : order.status === "Assigned" 
                                    ? "px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800"
                                    : "px-2 py-1 rounded-full text-xs bg-green-100 text-green-800"
                                }>
                                  {order.status}
                                </span>
                              </td>
                              <td className="py-3 text-right">
                                <Button variant="ghost" size="sm">
                                  View
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="verification">
              <Card>
                <CardHeader>
                  <CardTitle>Document Verification</CardTitle>
                  <CardDescription>
                    Partner documents awaiting verification
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="py-2">
                    {isDataLoading ? (
                      <p className="text-center py-6 text-muted-foreground">Loading documents...</p>
                    ) : documents.length === 0 ? (
                      <p className="text-center py-6 text-muted-foreground">No documents awaiting verification</p>
                    ) : (
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Partner</th>
                            <th className="text-left py-2">Document Type</th>
                            <th className="text-left py-2">Submitted Date</th>
                            <th className="text-left py-2">Status</th>
                            <th className="text-right py-2">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {documents.map((doc: DocumentVerificationItem) => (
                            <tr key={doc.id} className="border-b">
                              <td className="py-3">{doc.partnerName}</td>
                              <td className="py-3">{doc.documentType}</td>
                              <td className="py-3">{doc.submittedDate}</td>
                              <td className="py-3">
                                <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">
                                  {doc.status}
                                </span>
                              </td>
                              <td className="py-3 text-right">
                                <div className="flex justify-end gap-2">
                                  <Button variant="outline" size="sm" className="border-green-600 text-green-600 hover:bg-green-50">
                                    Approve
                                  </Button>
                                  <Button variant="outline" size="sm" className="border-red-600 text-red-600 hover:bg-red-50">
                                    Reject
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="partners">
              <Card>
                <CardHeader>
                  <CardTitle>Delivery Partners</CardTitle>
                  <CardDescription>
                    Active delivery partners and their performance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="py-2">
                    {isDataLoading ? (
                      <p className="text-center py-6 text-muted-foreground">Loading partners...</p>
                    ) : partners.length === 0 ? (
                      <p className="text-center py-6 text-muted-foreground">No delivery partners available</p>
                    ) : (
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2">Partner</th>
                            <th className="text-left py-2">Deliveries</th>
                            <th className="text-left py-2">Rating</th>
                            <th className="text-left py-2">Earnings</th>
                            <th className="text-left py-2">Status</th>
                            <th className="text-right py-2">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {partners.map((partner: DeliveryPartnerStats) => (
                            <tr key={partner.id} className="border-b">
                              <td className="py-3">{partner.name}</td>
                              <td className="py-3">{partner.deliveries}</td>
                              <td className="py-3">⭐ {partner.rating.toFixed(1)}</td>
                              <td className="py-3">${partner.earnings.toFixed(2)}</td>
                              <td className="py-3">
                                <span className={partner.isActive 
                                  ? "px-2 py-1 rounded-full text-xs bg-green-100 text-green-800"
                                  : "px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-800"
                                }>
                                  {partner.isActive ? 'Active' : 'Offline'}
                                </span>
                              </td>
                              <td className="py-3 text-right">
                                <Button variant="ghost" size="sm">
                                  View
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}