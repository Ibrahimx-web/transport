import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { 
  ArrowLeft, 
  Maximize2, 
  Minimize2, 
  Info, 
  LayoutDashboard, 
  RefreshCw, 
  Clock, 
  Wifi, 
  WifiOff 
} from 'lucide-react';
import { MapView } from '@/components/booking/MapView';
import { DeliveryStatus } from '@/components/tracking/DeliveryStatus';
import { PackageInfo } from '@/components/tracking/PackageInfo';
import { AnimatedDeliveryProgress } from '@/components/tracking/AnimatedDeliveryProgress';
import { AnimatedVehicleTracker } from '@/components/tracking/AnimatedVehicleTracker';
import { InteractiveTrackingCard } from '@/components/tracking/InteractiveTrackingCard';
import { ParcelTrackingMinimap } from '@/components/tracking/ParcelTrackingMinimap';
import { ShareDeliveryLink } from '@/components/tracking/ShareDeliveryLink';
import { Order, OrderStatusUpdate, RouteInfo } from '@/types';
import { useParcelTracking } from '@/hooks/use-parcel-tracking';
import { formatDistanceToNow } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { LoadingAnimation } from '@/components/ui/loading-animation';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface TrackDeliveryProps {
  params: {
    id: string;
  };
}

export default function TrackDelivery({ params }: TrackDeliveryProps) {
  const [_, navigate] = useLocation();
  const orderId = parseInt(params.id);
  
  // State for UI controls
  const [isMapExpanded, setIsMapExpanded] = useState(false);
  const [viewMode, setViewMode] = useState<'classic' | 'interactive'>('interactive');
  const [routeInfo, setRouteInfo] = useState<RouteInfo | null>(null);
  
  // Fetch order details
  const { data: order, isLoading: orderLoading, error: orderError } = useQuery<Order>({
    queryKey: [`/api/orders/${orderId}`],
    enabled: !isNaN(orderId),
  });
  
  // Fetch order status updates
  const { data: statusUpdates, isLoading: updatesLoading } = useQuery<OrderStatusUpdate[]>({
    queryKey: [`/api/orders/${orderId}/status-updates`],
    enabled: !isNaN(orderId),
  });
  
  // Use enhanced parcel tracking hook with real-time capabilities
  const {
    driverLocation,
    lastUpdate,
    isConnected,
    toggleMapExpand,
    refreshTracking,
    isRefreshing,
    isAutoRefreshEnabled,
    setIsAutoRefreshEnabled,
    refreshInterval,
    setRefreshInterval
  } = useParcelTracking({
    order,
    statusUpdates: statusUpdates || []
  });
  
  // Set route info for animated vehicle tracker (classic view)
  useEffect(() => {
    if (order && driverLocation) {
      // For demo purposes - in a real application this would come from a maps API
      const midPoint1 = {
        lat: order.pickupLat + (order.deliveryLat - order.pickupLat) * 0.33,
        lng: order.pickupLng + (order.deliveryLng - order.pickupLng) * 0.33
      };
      
      const midPoint2 = {
        lat: order.pickupLat + (order.deliveryLat - order.pickupLat) * 0.66,
        lng: order.pickupLng + (order.deliveryLng - order.pickupLng) * 0.66
      };
      
      // Create sample route segments 
      const segments = [
        {
          path: [
            { lat: order.pickupLat, lng: order.pickupLng },
            midPoint1
          ],
          distance: order.distance * 0.33,
          estimatedTime: 10
        },
        {
          path: [
            midPoint1,
            midPoint2
          ],
          distance: order.distance * 0.33,
          estimatedTime: 15
        },
        {
          path: [
            midPoint2,
            { lat: order.deliveryLat, lng: order.deliveryLng }
          ],
          distance: order.distance * 0.34,
          estimatedTime: 10
        }
      ];
      
      // Set the route info
      setRouteInfo({
        distance: order.distance,
        estimatedTime: 35, // Total estimated time in minutes 
        segments
      });
    }
  }, [order, driverLocation]);
  
  const handleBack = () => {
    navigate('/');
  };
  
  const toggleMapExpansion = () => {
    setIsMapExpanded(!isMapExpanded);
  };
  
  if (orderLoading || updatesLoading) {
    return (
      <div className="min-h-screen max-w-md mx-auto bg-white relative flex justify-center items-center">
        <LoadingAnimation 
          size="lg" 
          text="Loading delivery details..." 
        />
      </div>
    );
  }
  
  if (orderError || !order) {
    return (
      <div className="min-h-screen max-w-md mx-auto bg-white relative flex justify-center items-center">
        <div className="bg-red-50 p-4 rounded-lg border border-red-200 text-center">
          <p className="text-red-500 font-medium">Destination Not Found</p>
          <p className="text-gray-600 mt-2 mb-3">
            The delivery order you're looking for could not be found. This may be because:
          </p>
          <ul className="text-sm text-left mb-4 text-gray-600">
            <li className="flex items-start mb-2">
              <span className="mr-2">•</span>
              <span>The order ID is incorrect</span>
            </li>
            <li className="flex items-start mb-2">
              <span className="mr-2">•</span>
              <span>The order has been deleted or archived</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">•</span>
              <span>You don't have permission to view this order</span>
            </li>
          </ul>
          <button 
            onClick={() => navigate('/')}
            className="mt-3 px-4 py-2 bg-primary text-white rounded-md text-sm"
          >
            Return to Home
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white relative pb-4">
      {/* Header */}
      <header className="bg-white p-4 shadow-sm flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center">
          <button onClick={handleBack} className="mr-3">
            <ArrowLeft className="text-gray-600" />
          </button>
          <span className="font-bold">Track Delivery #{order.id}</span>
        </div>
        <div className="flex items-center gap-2">
          <ShareDeliveryLink 
            orderId={order.id} 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8"
            showLabel={false}
          />
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-8 w-8"
                  onClick={refreshTracking}
                  disabled={isRefreshing}
                >
                  <RefreshCw className={cn(
                    "h-4 w-4", 
                    isRefreshing && "animate-spin text-primary"
                  )} />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom">
                <p>Refresh tracking data</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-8 gap-1"
            onClick={() => setViewMode(viewMode === 'classic' ? 'interactive' : 'classic')}
          >
            <LayoutDashboard className="h-4 w-4" />
            <span className="text-xs">{viewMode === 'classic' ? 'New View' : 'Classic View'}</span>
          </Button>
        </div>
      </header>
      
      {/* Live indicator and refresh settings */}
      <div className={`px-3 py-1.5 flex items-center justify-between text-xs ${isConnected ? 'bg-green-50' : 'bg-amber-50'}`}>
        <div className="flex items-center gap-1.5">
          {isConnected ? (
            <>
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              <span className="text-green-800 font-medium">Live Tracking</span>
            </>
          ) : (
            <>
              <WifiOff className="h-3 w-3 text-amber-600" />
              <span className="text-amber-800 font-medium">Connection Lost</span>
            </>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Clock className="h-3 w-3 text-gray-500" />
          <span className="text-gray-500">
            Updated {formatDistanceToNow(lastUpdate, { addSuffix: true })}
          </span>
        </div>
      </div>
      
      {/* Auto-refresh settings */}
      <div className="bg-gray-50 border-b px-3 py-2">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Switch 
              id="auto-refresh" 
              checked={isAutoRefreshEnabled}
              onCheckedChange={setIsAutoRefreshEnabled}
            />
            <Label htmlFor="auto-refresh" className="text-sm font-medium">
              Auto refresh
            </Label>
          </div>
          
          <Select 
            value={refreshInterval.toString()} 
            onValueChange={(value) => setRefreshInterval(parseInt(value))}
            disabled={!isAutoRefreshEnabled}
          >
            <SelectTrigger className="h-7 w-[110px] text-xs">
              <SelectValue placeholder="Refresh rate" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="5000">Every 5s</SelectItem>
              <SelectItem value="10000">Every 10s</SelectItem>
              <SelectItem value="15000">Every 15s</SelectItem>
              <SelectItem value="30000">Every 30s</SelectItem>
              <SelectItem value="60000">Every 1m</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {viewMode === 'interactive' ? (
        <div className="p-4">
          {/* Interactive Tracking Card (New UI) */}
          <InteractiveTrackingCard 
            order={order} 
            statusUpdates={statusUpdates || []} 
            className="mb-4"
          />
          
          {/* Show Delivery Status and Package Info below */}
          <DeliveryStatus order={order} statusUpdates={statusUpdates} />
          <PackageInfo order={order} />
        </div>
      ) : (
        <>
          {/* Classic Map with driver location */}
          <MapView
            pickupLocation={{
              address: order.pickupLocation,
              lat: order.pickupLat,
              lng: order.pickupLng
            }}
            deliveryLocation={{
              address: order.deliveryLocation,
              lat: order.deliveryLat,
              lng: order.deliveryLng
            }}
            showDriverLocation={true}
            driverLocation={driverLocation || undefined}
            orderStatus={order.status}
            distance={order.distance}
            showDetailedRoute={true}
            height={isMapExpanded ? "h-96" : "h-48"}
          />
          
          {/* Map instruction */}
          <div className="px-4 py-1 text-center text-xs text-gray-500 flex items-center justify-center gap-1">
            <Info size={12} />
            <span>Tap on any marker for more information</span>
          </div>
          
          {/* Animated Delivery Progress */}
          <div className="px-4 mt-3 mb-4">
            <AnimatedDeliveryProgress 
              order={order} 
              statusUpdates={statusUpdates || []} 
              className="mb-4"
            />
          </div>
          
          {/* Animated Vehicle Tracker */}
          {routeInfo && driverLocation && (
            <div className="px-4 mb-4">
              <AnimatedVehicleTracker 
                order={order}
                routeInfo={routeInfo}
                driverLocation={driverLocation || undefined}
                className="mb-4"
              />
            </div>
          )}
          
          {/* Delivery Status */}
          <DeliveryStatus order={order} statusUpdates={statusUpdates} />
          
          {/* Package Info */}
          <PackageInfo order={order} />
        </>
      )}
    </div>
  );
}
