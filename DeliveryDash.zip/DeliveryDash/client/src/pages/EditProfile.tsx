import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { User, UserType, VehicleType } from '@/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft, User as UserIcon, Truck, FileEdit, Save, X } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

// Define a schema for profile updates
const profileUpdateSchema = z.object({
  fullName: z.string().min(2, "Full name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  phone: z.string().min(6, "Phone number must be at least 6 characters"),
  vehicleTypeId: z.number().optional(),
  licensePlateNumber: z.string().min(3, "License plate number must be at least 3 characters").optional(),
  vehicleRegistrationNumber: z.string().min(3, "Vehicle registration number must be at least 3 characters").optional(),
  profilePicture: z.any().optional(),
  driversLicense: z.any().optional(),
  isAvailable: z.boolean().optional(),
});

type ProfileFormValues = z.infer<typeof profileUpdateSchema>;

export default function EditProfile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [userType, setUserType] = useState<UserType>('customer');
  
  // Get current user
  const { data: user, isLoading: isLoadingUser } = useQuery<User>({
    queryKey: ['/api/users/current'],
  });
  
  // Get vehicle types for delivery partners
  const { data: vehicleTypes = [] } = useQuery<VehicleType[]>({
    queryKey: ['/api/vehicle-types'],
  });
  
  // Create form
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileUpdateSchema),
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      vehicleTypeId: undefined,
      licensePlateNumber: '',
      vehicleRegistrationNumber: '',
      isAvailable: true,
    },
  });
  
  // Set form values when user data is loaded
  useEffect(() => {
    if (user) {
      setUserType(user.userType);
      form.reset({
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        vehicleTypeId: user.vehicleTypeId === null ? undefined : user.vehicleTypeId as number | undefined,
        licensePlateNumber: user.licensePlateNumber || '',
        vehicleRegistrationNumber: user.vehicleRegistrationNumber || '',
        isAvailable: user.isAvailable !== undefined ? user.isAvailable : true,
      });
    }
  }, [user, form]);
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      const response = await apiRequest('PATCH', '/api/users/profile', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/current'] });
      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated.",
      });
      setLocation('/profile');
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Failed to update profile",
        description: error.message || "Please try again later.",
      });
    },
  });
  
  // Handle file changes
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, field: 'profilePicture' | 'driversLicense') => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    form.setValue(field, file);
  };
  
  // Convert file to base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        // Image compression for large files
        if (file.type.startsWith('image/') && file.size > 500000) { // > 500KB
          const img = new Image();
          
          img.onload = () => {
            // Calculate new dimensions while maintaining aspect ratio
            let width = img.width;
            let height = img.height;
            const maxDimension = 800;
            
            if (width > height && width > maxDimension) {
              height = (height / width) * maxDimension;
              width = maxDimension;
            } else if (height > maxDimension) {
              width = (width / height) * maxDimension;
              height = maxDimension;
            }
            
            // Create canvas and compress
            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            
            const ctx = canvas.getContext('2d');
            if (!ctx) {
              reject(new Error('Could not get canvas context'));
              return;
            }
            
            ctx.drawImage(img, 0, 0, width, height);
            
            // Convert to base64 with reduced quality (0.7 is 70% quality)
            const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7);
            resolve(compressedBase64);
          };
          
          img.onerror = () => {
            // Fallback to original method if image compression fails
            if (reader.result && typeof reader.result === 'string') {
              resolve(reader.result);
            } else {
              reject(new Error('Failed to load image for compression'));
            }
          };
          
          // Set the image source to the file data
          if (event.target && event.target.result) {
            img.src = event.target.result.toString();
          } else {
            reject(new Error('No file data available'));
          }
        } else {
          // For PDF files or small images, just use the original file
          if (event.target && event.target.result && typeof event.target.result === 'string') {
            resolve(event.target.result);
          } else {
            reject(new Error('Failed to read file'));
          }
        }
      };
      
      reader.onerror = reject;
      
      // Read the appropriate format
      if (file.type === 'application/pdf') {
        reader.readAsDataURL(file);
      } else {
        reader.readAsDataURL(file);
      }
    });
  };
  
  // Handle form submission
  const onSubmit = async (data: ProfileFormValues) => {
    try {
      // Convert files to base64 if they exist
      const formData: any = { ...data };
      
      if (data.profilePicture instanceof File) {
        formData.profilePicture = await fileToBase64(data.profilePicture);
      }
      
      if (data.driversLicense instanceof File) {
        formData.driversLicense = await fileToBase64(data.driversLicense);
      }
      
      // Submit the data with base64 encoded files
      updateProfileMutation.mutate(formData);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error processing files",
        description: "There was a problem with your uploaded files. Please try again.",
      });
    }
  };
  
  if (isLoadingUser) {
    return <div className="flex items-center justify-center min-h-screen"><p>Loading...</p></div>;
  }
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white pb-16">
      {/* Header */}
      <header className="bg-white p-4 flex items-center border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setLocation("/profile")}
          className="mr-2"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold">Edit Profile</h1>
      </header>

      <div className="p-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileEdit className="h-5 w-5" />
              Edit Your Profile
            </CardTitle>
            <CardDescription>
              Update your personal information and documents
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your full name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="your@email.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="Phone number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Vehicle type selector for delivery partners */}
                {userType === "delivery" && (
                  <>
                    <FormField
                      control={form.control}
                      name="vehicleTypeId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Vehicle Type</FormLabel>
                          <Select
                            onValueChange={(value) => field.onChange(parseInt(value))}
                            value={field.value?.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select your vehicle type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {vehicleTypes.map((vehicle: VehicleType) => (
                                <SelectItem 
                                  key={vehicle.id} 
                                  value={vehicle.id.toString()}
                                >
                                  {vehicle.name} (max {vehicle.maxWeight}kg)
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Select the vehicle you use for deliveries
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="licensePlateNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>License Plate Number</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., KBY-123A" {...field} />
                            </FormControl>
                            <FormDescription>
                              Your vehicle's license plate
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="vehicleRegistrationNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Vehicle Registration</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., REG12345678" {...field} />
                            </FormControl>
                            <FormDescription>
                              Vehicle registration number
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Profile Picture Upload */}
                    <FormField
                      control={form.control}
                      name="profilePicture"
                      render={() => (
                        <FormItem>
                          <FormLabel>Profile Picture</FormLabel>
                          <FormControl>
                            <Input 
                              type="file" 
                              accept="image/*"
                              onChange={(e) => handleFileChange(e, 'profilePicture')}
                            />
                          </FormControl>
                          <FormDescription>
                            Upload a clear photo of yourself
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Driver's License Upload */}
                    <FormField
                      control={form.control}
                      name="driversLicense"
                      render={() => (
                        <FormItem>
                          <FormLabel>Driver's License</FormLabel>
                          <FormControl>
                            <Input 
                              type="file" 
                              accept="image/*,application/pdf"
                              onChange={(e) => handleFileChange(e, 'driversLicense')}
                            />
                          </FormControl>
                          <FormDescription>
                            Upload a photo or PDF of your valid driver's license
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Availability Status Toggle */}
                    <FormField
                      control={form.control}
                      name="isAvailable"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">
                              Available for Deliveries
                            </FormLabel>
                            <FormDescription>
                              Turn off when you're not available to receive delivery requests
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </>
                )}

                <div className="flex gap-2 pt-2">
                  <Button 
                    type="submit" 
                    className="flex-1"
                    disabled={updateProfileMutation.isPending}
                  >
                    {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setLocation("/profile")}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}