import * as React from "react";
import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { AdminSidebar } from "@/components/admin/AdminSidebar";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  FileCheck, 
  FileX, 
  Download, 
  Printer, 
  Eye, 
  Search, 
  UserCircle,
  CreditCard,
  Info,
  Car,
  FileType,
  Calendar,
  Clock,
  AlertTriangle,
  FileText
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { LoadingAnimation } from "@/components/ui/loading-animation";
import { PageTransition } from "@/components/ui/page-transition";

// Types for our documents
interface PartnerDocument {
  id: number;
  partnerId: number;
  partnerName: string;
  partnerProfilePicture: string | null;
  documentType: string;
  documentUrl: string;
  verificationStatus: 'pending' | 'verified' | 'rejected';
  verifiedBy: number | null;
  verificationDate: string | null;
  rejectionReason: string | null;
  expiryDate: string | null;
  uploadedAt: string;
}

interface Partner {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  profilePicture: string | null;
  driversLicense?: string | null;
  licensePlateNumber?: string | null;
  vehicleRegistrationNumber?: string | null;
  vehicleTypeId?: number;
  vehicleTypeName?: string;
  isActive?: boolean;
  createdAt?: string;
}

interface PartnerWithDocuments {
  partner: Partner;
  documents: PartnerDocument[];
}

export default function AdminDocuments() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [documentFilter, setDocumentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedDocument, setSelectedDocument] = useState<PartnerDocument | null>(null);
  const [rejectionReason, setRejectionReason] = useState<string>('');
  const [isVerifyDialogOpen, setIsVerifyDialogOpen] = useState(false);
  const [isViewDocumentDialogOpen, setIsViewDocumentDialogOpen] = useState(false);
  const [isProfileViewOpen, setIsProfileViewOpen] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState<Partner | null>(null);
  const printFrameRef = useRef<HTMLIFrameElement>(null);

  // Query to fetch partner documents
  const { data: documents = [], isLoading: isDocumentsLoading } = useQuery<PartnerDocument[]>({
    queryKey: ['/api/partner-documents'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/partner-documents');
      const data = await response.json();
      return data;
    }
  });

  // Mutation for updating document verification status
  const verifyDocumentMutation = useMutation({
    mutationFn: async ({ 
      documentId, 
      status, 
      rejectionReason 
    }: { 
      documentId: number; 
      status: 'verified' | 'rejected'; 
      rejectionReason?: string;
    }) => {
      const response = await apiRequest('PATCH', `/api/partner-documents/${documentId}/verify`, {
        status,
        rejectionReason
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/partner-documents'] });
      toast({
        title: "Document updated",
        description: "The document verification status has been updated successfully.",
      });
      setIsVerifyDialogOpen(false);
      setRejectionReason('');
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: "There was an error updating the document status.",
        variant: "destructive"
      });
    }
  });

  // Query to fetch partner details and documents
  const { data: partnerDetails, isLoading: isPartnerLoading } = useQuery<PartnerWithDocuments>({
    queryKey: ['/api/partners', selectedPartner?.id, 'documents'],
    queryFn: async () => {
      if (!selectedPartner?.id) {
        return { partner: {} as Partner, documents: [] };
      }
      const response = await apiRequest('GET', `/api/partners/${selectedPartner.id}/documents`);
      return response.json();
    },
    enabled: !!selectedPartner?.id
  });

  // Filter documents based on user selection
  const filteredDocuments = documents.filter(doc => {
    const matchesDocType = documentFilter === 'all' || doc.documentType === documentFilter;
    const matchesStatus = statusFilter === 'all' || doc.verificationStatus === statusFilter;
    const matchesSearch = searchTerm === '' || 
      doc.partnerName.toLowerCase().includes(searchTerm.toLowerCase()) || 
      doc.documentType.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesDocType && matchesStatus && matchesSearch;
  });

  // Handle verify/reject document
  const handleVerifyDialogOpen = (document: PartnerDocument) => {
    setSelectedDocument(document);
    setIsVerifyDialogOpen(true);
  };

  // Handle view document
  const handleViewDocument = (document: PartnerDocument) => {
    setSelectedDocument(document);
    setIsViewDocumentDialogOpen(true);
  };

  // Handle view partner profile
  const handleViewPartnerProfile = async (partnerId: number, partnerName: string, profilePicture: string | null) => {
    setSelectedPartner({
      id: partnerId,
      fullName: partnerName,
      email: '', // Will be filled from the API response
      phone: '', // Will be filled from the API response
      profilePicture
    });
    setIsProfileViewOpen(true);
  };

  // Handle document approval
  const handleApproveDocument = () => {
    if (selectedDocument) {
      verifyDocumentMutation.mutate({
        documentId: selectedDocument.id,
        status: 'verified'
      });
    }
  };

  // Handle document rejection
  const handleRejectDocument = () => {
    if (selectedDocument && rejectionReason.trim()) {
      verifyDocumentMutation.mutate({
        documentId: selectedDocument.id,
        status: 'rejected',
        rejectionReason: rejectionReason
      });
    } else {
      toast({
        title: "Rejection reason required",
        description: "Please provide a reason for rejecting this document.",
        variant: "destructive"
      });
    }
  };

  // Handle document download
  const handleDownloadDocument = () => {
    if (selectedDocument) {
      // Create a temporary link and trigger download
      const a = document.createElement('a');
      a.href = selectedDocument.documentUrl;
      a.download = `${selectedDocument.partnerName}-${selectedDocument.documentType}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      toast({
        title: "Download started",
        description: "Your document download has started."
      });
    }
  };

  // Handle document printing
  const handlePrintDocument = () => {
    if (selectedDocument && printFrameRef.current) {
      // Set the iframe source
      printFrameRef.current.src = selectedDocument.documentUrl;
      
      // Wait for the iframe to load, then print
      printFrameRef.current.onload = () => {
        if (printFrameRef.current?.contentWindow) {
          try {
            printFrameRef.current.contentWindow.print();
          } catch (error) {
            toast({
              title: "Print failed",
              description: "There was an error printing the document.",
              variant: "destructive"
            });
          }
        }
      };
    }
  };

  // Get unique document types for filtering
  const documentTypes = Array.from(new Set(documents.map(doc => doc.documentType)));

  // Badge color based on verification status
  const getStatusBadgeVariant = (status: string) => {
    switch(status) {
      case 'verified': return "success";
      case 'rejected': return "destructive";
      case 'pending': return "warning";
      default: return "secondary";
    }
  };

  // Format date for display
  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  };

  // Helper function to render documents table
  function renderDocumentsTable(docs: PartnerDocument[], isLoading: boolean) {
    if (isLoading) {
      return (
        <div className="flex justify-center items-center p-12">
          <LoadingAnimation 
            size="lg" 
            text="Loading document data..." 
          />
        </div>
      );
    }

    if (docs.length === 0) {
      return (
        <div className="text-center py-12 text-muted-foreground">
          <FileText className="h-12 w-12 mx-auto mb-4 opacity-20" />
          <p className="font-medium">No documents found</p>
          <p className="text-sm">
            {statusFilter !== 'all' || documentFilter !== 'all' || searchTerm 
              ? "Try changing your filters or search term to see more results"
              : "When delivery partners upload documents, they will appear here"}
          </p>
        </div>
      );
    }

    return (
      <div className="overflow-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left py-3 px-4">Partner</th>
              <th className="text-left py-3 px-4">Document Type</th>
              <th className="text-left py-3 px-4">Uploaded</th>
              <th className="text-left py-3 px-4">Status</th>
              <th className="text-right py-3 px-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {docs.map((doc) => (
              <tr key={doc.id} className="border-b hover:bg-muted/50">
                <td className="py-3 px-4">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={doc.partnerProfilePicture || undefined} alt={doc.partnerName} />
                      <AvatarFallback>{doc.partnerName?.substring(0, 2).toUpperCase() || "DP"}</AvatarFallback>
                    </Avatar>
                    <button 
                      className="hover:underline cursor-pointer text-left"
                      onClick={() => handleViewPartnerProfile(doc.partnerId, doc.partnerName, doc.partnerProfilePicture)}
                    >
                      {doc.partnerName}
                    </button>
                  </div>
                </td>
                <td className="py-3 px-4">{doc.documentType}</td>
                <td className="py-3 px-4">{formatDate(doc.uploadedAt)}</td>
                <td className="py-3 px-4">
                  <Badge variant={getStatusBadgeVariant(doc.verificationStatus) as any}>
                    {doc.verificationStatus}
                  </Badge>
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex justify-end gap-2">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="outline" size="icon" onClick={() => handleViewDocument(doc)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>View Document</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>

                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="outline" size="icon" onClick={() => {
                            setSelectedDocument(doc);
                            handleDownloadDocument();
                          }}>
                            <Download className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Download</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>

                    {doc.verificationStatus === 'pending' && (
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon" onClick={() => handleVerifyDialogOpen(doc)}>
                              <FileCheck className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Verify Document</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <PageTransition transitionKey="admin-documents" direction="fade">
      <div className="container mx-auto p-4">
        <header className="mb-8">
          <h1 className="text-3xl font-bold">Partner Documents</h1>
          <p className="text-muted-foreground">Manage and verify delivery partner documents</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          {/* Sidebar navigation */}
          <div className="md:col-span-1">
            <AdminSidebar />
          </div>
          
          {/* Main content area */}
          <div className="md:col-span-4">
            {documents.length === 0 && !isDocumentsLoading ? (
              <Alert className="mb-6">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>No Documents Found</AlertTitle>
                <AlertDescription>
                  There are no partner documents uploaded yet. Documents will appear here when delivery partners upload their identification, vehicle registrations, and other required documents.
                </AlertDescription>
              </Alert>
            ) : null}
            
            <Tabs defaultValue="all-documents" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="all-documents">All Documents</TabsTrigger>
                <TabsTrigger value="pending-verification" className="relative">
                  Pending Verification
                  {documents.filter(d => d.verificationStatus === 'pending').length > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-orange-500 text-[10px] text-white">
                      {documents.filter(d => d.verificationStatus === 'pending').length}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="verified">Verified</TabsTrigger>
                <TabsTrigger value="rejected">Rejected</TabsTrigger>
              </TabsList>
            
              {/* Search and filter bar */}
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="w-full md:w-1/2">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input 
                      placeholder="Search documents..." 
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-2 w-full md:w-1/2">
                  <Select value={documentFilter} onValueChange={setDocumentFilter}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Document Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Document Types</SelectItem>
                      {documentTypes.map(type => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="verified">Verified</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <TabsContent value="all-documents">
                <Card>
                  <CardHeader>
                    <CardTitle>All Partner Documents</CardTitle>
                    <CardDescription>
                      View and manage all delivery partner documents
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {renderDocumentsTable(filteredDocuments, isDocumentsLoading)}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="pending-verification">
                <Card>
                  <CardHeader>
                    <CardTitle>Pending Verification</CardTitle>
                    <CardDescription>
                      Documents awaiting verification
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {renderDocumentsTable(
                      filteredDocuments.filter(doc => doc.verificationStatus === 'pending'),
                      isDocumentsLoading
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="verified">
                <Card>
                  <CardHeader>
                    <CardTitle>Verified Documents</CardTitle>
                    <CardDescription>
                      Documents that have been verified
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {renderDocumentsTable(
                      filteredDocuments.filter(doc => doc.verificationStatus === 'verified'),
                      isDocumentsLoading
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="rejected">
                <Card>
                  <CardHeader>
                    <CardTitle>Rejected Documents</CardTitle>
                    <CardDescription>
                      Documents that have been rejected
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {renderDocumentsTable(
                      filteredDocuments.filter(doc => doc.verificationStatus === 'rejected'),
                      isDocumentsLoading
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Document verification dialog */}
        <Dialog open={isVerifyDialogOpen} onOpenChange={setIsVerifyDialogOpen}>
          <DialogContent className="sm:max-w-[650px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileCheck className="h-5 w-5 text-primary" />
                Document Verification
              </DialogTitle>
              <DialogDescription>
                Review and verify {selectedDocument?.documentType?.toLowerCase()} for {selectedDocument?.partnerName}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6">
              {selectedDocument && (
                <div className="border rounded-lg overflow-hidden bg-muted">
                  <div className="aspect-video">
                    <img 
                      src={selectedDocument.documentUrl} 
                      alt={`${selectedDocument.documentType} preview`}
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium text-muted-foreground">Document Type</p>
                  <p>{selectedDocument?.documentType}</p>
                </div>
                <div>
                  <p className="font-medium text-muted-foreground">Uploaded</p>
                  <p>{formatDate(selectedDocument?.uploadedAt || null)}</p>
                </div>
                <div>
                  <p className="font-medium text-muted-foreground">Partner</p>
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={selectedDocument?.partnerProfilePicture || undefined} />
                      <AvatarFallback>{selectedDocument?.partnerName?.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <span>{selectedDocument?.partnerName}</span>
                  </div>
                </div>
                {selectedDocument?.expiryDate && (
                  <div>
                    <p className="font-medium text-muted-foreground">Expires</p>
                    <p>{selectedDocument.expiryDate}</p>
                  </div>
                )}
              </div>
              
              <div className="space-y-2 pt-2 border-t">
                <div className="flex justify-between items-center">
                  <p className="text-sm font-medium">Verification Decision</p>
                  {verifyDocumentMutation.isPending && (
                    <div className="flex items-center text-xs text-muted-foreground">
                      <div className="animate-spin w-3 h-3 mr-2 border border-primary border-t-transparent rounded-full"></div>
                      Processing...
                    </div>
                  )}
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-start space-x-2">
                      <Button 
                        variant="outline" 
                        className="w-full border-green-200 bg-green-50 hover:bg-green-100 hover:text-green-900 hover:border-green-200"
                        onClick={handleApproveDocument}
                        disabled={verifyDocumentMutation.isPending}
                      >
                        <FileCheck className="mr-2 h-4 w-4 text-green-600" />
                        <span className="text-green-700">Approve Document</span>
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground px-2">
                      Approve if the document is valid, legible, and meets all requirements.
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Button 
                      variant="outline"
                      className="w-full border-destructive/20 bg-destructive/10 hover:bg-destructive/20 hover:text-destructive hover:border-destructive/30"
                      onClick={handleRejectDocument}
                      disabled={verifyDocumentMutation.isPending || !rejectionReason.trim()}
                    >
                      <FileX className="mr-2 h-4 w-4 text-destructive" />
                      <span className="text-destructive">Reject Document</span>
                    </Button>
                    <div className="px-2">
                      <Textarea
                        placeholder="Enter reason for rejection (required)..."
                        value={rejectionReason}
                        onChange={(e) => setRejectionReason(e.target.value)}
                        className="min-h-[80px] text-xs"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setIsVerifyDialogOpen(false)}
                disabled={verifyDocumentMutation.isPending}
              >
                Cancel
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Document view dialog */}
        <Dialog open={isViewDocumentDialogOpen} onOpenChange={setIsViewDocumentDialogOpen}>
          <DialogContent className="sm:max-w-[800px]">
            <DialogHeader>
              <DialogTitle>View Document</DialogTitle>
              <DialogDescription>
                {selectedDocument?.documentType} - {selectedDocument?.partnerName}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              {selectedDocument && (
                <div className="rounded-lg overflow-hidden border bg-muted">
                  <div className="aspect-video relative">
                    <img 
                      src={selectedDocument.documentUrl} 
                      alt={`${selectedDocument.documentType} preview`}
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="p-2 bg-muted border-t flex justify-end space-x-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={handlePrintDocument}
                    >
                      <Printer className="mr-2 h-4 w-4" />
                      Print
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={handleDownloadDocument}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-start space-x-2">
                  <FileType className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Document Type</p>
                    <p className="text-sm">{selectedDocument?.documentType}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Clock className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Uploaded</p>
                    <p className="text-sm">{formatDate(selectedDocument?.uploadedAt || null)}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Info className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Status</p>
                    <p className="text-sm">
                      <Badge variant={getStatusBadgeVariant(selectedDocument?.verificationStatus || "") as any}>
                        {selectedDocument?.verificationStatus}
                      </Badge>
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Expires</p>
                    <p className="text-sm">{selectedDocument?.expiryDate || 'No expiry date'}</p>
                  </div>
                </div>
                {selectedDocument?.verificationStatus === 'rejected' && selectedDocument?.rejectionReason && (
                  <div className="col-span-2 border-t pt-2 mt-2">
                    <p className="text-sm font-medium">Rejection Reason</p>
                    <p className="text-sm text-destructive">{selectedDocument.rejectionReason}</p>
                  </div>
                )}
              </div>
            </div>
            
            <DialogFooter>
              {selectedDocument?.verificationStatus === 'pending' && (
                <Button 
                  variant="default"
                  onClick={() => {
                    setIsViewDocumentDialogOpen(false);
                    handleVerifyDialogOpen(selectedDocument);
                  }}
                >
                  <FileCheck className="mr-2 h-4 w-4" />
                  Verify Now
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Partner profile dialog */}
        <Dialog open={isProfileViewOpen} onOpenChange={setIsProfileViewOpen}>
          <DialogContent className="sm:max-w-[650px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <UserCircle className="h-5 w-5 text-primary" />
                Partner Profile
              </DialogTitle>
              <DialogDescription>
                View partner details and documents
              </DialogDescription>
            </DialogHeader>
            
            {isPartnerLoading ? (
              <div className="py-8">
                <LoadingAnimation text="Loading partner details..." />
              </div>
            ) : partnerDetails?.partner ? (
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={partnerDetails.partner.profilePicture || undefined} />
                    <AvatarFallback>{partnerDetails.partner.fullName.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="space-y-1">
                    <h3 className="text-lg font-semibold">{partnerDetails.partner.fullName}</h3>
                    {partnerDetails.partner.email && (
                      <p className="text-sm text-muted-foreground">{partnerDetails.partner.email}</p>
                    )}
                    {partnerDetails.partner.phone && (
                      <p className="text-sm text-muted-foreground">{partnerDetails.partner.phone}</p>
                    )}
                    {partnerDetails.partner.isActive !== undefined && (
                      <Badge variant={partnerDetails.partner.isActive ? "success" : "destructive" as any}>
                        {partnerDetails.partner.isActive ? "Active" : "Inactive"}
                      </Badge>
                    )}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 pt-4 border-t text-sm">
                  <div className="flex items-start space-x-2">
                    <Car className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="font-medium">Vehicle Type</p>
                      <p>{partnerDetails.partner.vehicleTypeName || 'Not specified'}</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CreditCard className="h-5 w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="font-medium">License Plate</p>
                      <p>{partnerDetails.partner.licensePlateNumber || 'Not specified'}</p>
                    </div>
                  </div>
                  {partnerDetails.partner.vehicleRegistrationNumber && (
                    <div className="flex items-start space-x-2">
                      <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="font-medium">Vehicle Registration</p>
                        <p>{partnerDetails.partner.vehicleRegistrationNumber}</p>
                      </div>
                    </div>
                  )}
                  {partnerDetails.partner.createdAt && (
                    <div className="flex items-start space-x-2">
                      <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="font-medium">Partner Since</p>
                        <p>{formatDate(partnerDetails.partner.createdAt)}</p>
                      </div>
                    </div>
                  )}
                </div>
                
                {partnerDetails.documents && partnerDetails.documents.length > 0 && (
                  <div className="space-y-4 pt-4 border-t">
                    <h4 className="text-sm font-semibold">Documents ({partnerDetails.documents.length})</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {partnerDetails.documents.map(doc => (
                        <div key={doc.id} className="border rounded-md overflow-hidden hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleViewDocument(doc)}>
                          <div className="aspect-video bg-muted">
                            <img src={doc.documentUrl} alt={doc.documentType} className="w-full h-full object-cover" />
                          </div>
                          <div className="p-2 text-xs">
                            <div className="font-medium truncate">{doc.documentType}</div>
                            <div className="flex justify-between items-center mt-1">
                              <span className="text-muted-foreground">{formatDate(doc.uploadedAt)}</span>
                              <Badge variant={getStatusBadgeVariant(doc.verificationStatus) as any} className="text-[10px]">
                                {doc.verificationStatus}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="py-8 text-center text-muted-foreground">
                <p>Partner details not available</p>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Hidden iframe for printing */}
        <iframe 
          ref={printFrameRef} 
          style={{ display: 'none' }} 
          title="Print Document"
        />
      </div>
    </PageTransition>
  );
}