import * as React from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Truck, Home, ArrowLeft, MapPin, X } from "lucide-react";
import { PageTransition } from "@/components/ui/page-transition";

export default function NotFound() {
  const [, navigate] = useLocation();

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-xl p-8 w-full max-w-md text-center border border-blue-100">
          <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6 relative">
            <Truck className="h-10 w-10 text-primary absolute transform translate-x-2" />
            <div className="absolute transform -translate-x-2 flex items-center justify-center">
              <MapPin className="h-8 w-8 text-red-500" />
              <X className="h-4 w-4 text-white absolute" />
            </div>
          </div>
          
          <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-primary to-blue-700 bg-clip-text text-transparent">Destination Not Found</h1>
          <h2 className="text-xl font-medium text-muted-foreground mb-6">Oops! We took a wrong turn</h2>
          
          <p className="text-muted-foreground mb-8">
            The page you're looking for doesn't exist or has been moved. Our delivery truck can't find this destination.
          </p>
          
          <div className="flex flex-col gap-3">
            <Button 
              onClick={() => navigate("/")}
              className="w-full bg-gradient-to-r from-primary to-blue-600 hover:from-blue-600 hover:to-primary transition-all duration-300"
              size="lg"
            >
              <Home className="mr-2 h-5 w-5" />
              Back to Home Base
            </Button>
            
            <Button 
              variant="outline"
              onClick={() => window.history.back()}
              className="w-full border-primary hover:bg-blue-50 transition-all duration-300"
              size="lg"
            >
              <ArrowLeft className="mr-2 h-5 w-5" />
              Return to Previous Stop
            </Button>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
