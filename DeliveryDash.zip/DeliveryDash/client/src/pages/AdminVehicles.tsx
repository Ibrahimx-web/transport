import * as React from 'react';
import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Trash2, Pencil, Plus } from 'lucide-react';
import { z } from 'zod';
import { useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link } from 'wouter';
import { AdminSidebar } from '@/components/admin/AdminSidebar';

// UI Components
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';

// Data fetching and application utilities
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useCurrency } from '@/lib/currency';
import { VehicleType, insertVehicleTypeSchema } from '@shared/schema';
import { User } from '@/types';

// Define extended schema for the form with validation
const VehicleTypeFormSchema = insertVehicleTypeSchema.extend({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  icon: z.string().min(1, 'Icon is required'),
  maxWeight: z.coerce.number().positive('Maximum weight must be positive'),
  baseFare: z.coerce.number().positive('Base fare must be positive'),
});

type VehicleTypeFormValues = z.infer<typeof VehicleTypeFormSchema>;

// Icon options for vehicle types
const ICON_OPTIONS = [
  { value: 'bicycle', label: 'Bicycle' },
  { value: 'motorcycle', label: 'Motorcycle' },
  { value: 'truck-pickup', label: 'Pickup Truck' },
  { value: 'shuttle-van', label: 'Van' },
  { value: 'truck', label: 'Lorry' },
  { value: 'wrench', label: 'Motor Breakdown' },
  { value: 'car', label: 'Car' },
  { value: 'ship', label: 'Ship' },
  { value: 'plane', label: 'Airplane' },
  { value: 'train', label: 'Train' }
];

export default function AdminVehicles() {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { formatCurrency } = useCurrency();
  const [location, setLocation] = useLocation();

  // Check if current user is an admin
  const { data: currentUser, isLoading: userLoading } = useQuery<User>({
    queryKey: ['/api/users/current'],
    refetchOnWindowFocus: false
  });

  // Redirect to login if not admin
  useEffect(() => {
    if (!userLoading && (!currentUser || currentUser.userType !== 'admin')) {
      window.location.href = '/admin/login';
    }
  }, [currentUser, userLoading]);

  // Fetch vehicle types
  const { data: vehicleTypes = [], isLoading, error } = useQuery<VehicleType[]>({
    queryKey: ['/api/vehicle-types'],
    enabled: !userLoading && currentUser?.userType === 'admin',
  });

  // Form setup for adding/editing vehicle types
  const addForm = useForm<VehicleTypeFormValues>({
    resolver: zodResolver(VehicleTypeFormSchema),
    defaultValues: {
      name: '',
      icon: 'truck',
      maxWeight: 100,
      baseFare: 15.99,
    }
  });

  const editForm = useForm<VehicleTypeFormValues>({
    resolver: zodResolver(VehicleTypeFormSchema),
    defaultValues: {
      name: selectedVehicle?.name || '',
      icon: selectedVehicle?.icon || 'truck',
      maxWeight: selectedVehicle?.maxWeight || 100,
      baseFare: selectedVehicle?.baseFare || 15.99,
    }
  });

  useEffect(() => {
    if (selectedVehicle) {
      editForm.reset({
        name: selectedVehicle.name,
        icon: selectedVehicle.icon,
        maxWeight: selectedVehicle.maxWeight,
        baseFare: selectedVehicle.baseFare,
      });
    }
  }, [selectedVehicle, editForm]);

  // Mutations
  const createVehicleType = useMutation({
    mutationFn: async (data: VehicleTypeFormValues) => {
      const response = await apiRequest('POST', '/api/vehicle-types', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Vehicle type created successfully',
      });
      setIsAddModalOpen(false);
      addForm.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/vehicle-types'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to create vehicle type',
        variant: 'destructive',
      });
    }
  });

  const updateVehicleType = useMutation({
    mutationFn: async (data: { id: number, vehicle: VehicleTypeFormValues }) => {
      const response = await apiRequest('PATCH', `/api/vehicle-types/${data.id}`, data.vehicle);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Vehicle type updated successfully',
      });
      setIsEditModalOpen(false);
      setSelectedVehicle(null);
      queryClient.invalidateQueries({ queryKey: ['/api/vehicle-types'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to update vehicle type',
        variant: 'destructive',
      });
    }
  });

  const deleteVehicleType = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/vehicle-types/${id}`);
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Vehicle type deleted successfully',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/vehicle-types'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Vehicle type may be in use',
        variant: 'destructive',
      });
    }
  });

  // Form handlers
  const onAddSubmit = (data: VehicleTypeFormValues) => createVehicleType.mutate(data);
  const onEditSubmit = (data: VehicleTypeFormValues) => {
    if (selectedVehicle) {
      updateVehicleType.mutate({ id: selectedVehicle.id, vehicle: data });
    }
  };
  const handleDelete = (id: number) => deleteVehicleType.mutate(id);
  const openEditModal = (vehicle: VehicleType) => {
    setSelectedVehicle(vehicle);
    setIsEditModalOpen(true);
  };

  if (userLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!currentUser || currentUser.userType !== 'admin') {
    return null;
  }

  return (
    <div className="container mx-auto p-4">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">Vehicle Types</h1>
        <p className="text-muted-foreground">Manage your platform vehicles</p>
      </header>
      
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* Sidebar navigation */}
        <div className="md:col-span-1">
          <AdminSidebar />
        </div>

        {/* Main content */}
        <div className="md:col-span-4 space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Vehicle Types</h2>
              <p className="text-muted-foreground">
                Manage vehicle types and their configurations
              </p>
            </div>
            <Button onClick={() => setIsAddModalOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Vehicle Type
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Available Vehicles</CardTitle>
              <CardDescription>
                List of all vehicle types configured in the system
              </CardDescription>
            </CardHeader>
            <CardContent>
              {error ? (
                <Alert variant="destructive">
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>Failed to load vehicle types</AlertDescription>
                </Alert>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Icon</TableHead>
                      <TableHead>Max Weight</TableHead>
                      <TableHead>Base Fare</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center">
                          Loading...
                        </TableCell>
                      </TableRow>
                    ) : vehicleTypes.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center">
                          No vehicle types found
                        </TableCell>
                      </TableRow>
                    ) : (
                      vehicleTypes.map((vehicle) => (
                        <TableRow key={vehicle.id}>
                          <TableCell className="font-medium">{vehicle.name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{vehicle.icon}</Badge>
                          </TableCell>
                          <TableCell>{vehicle.maxWeight} kg</TableCell>
                          <TableCell>{formatCurrency(vehicle.baseFare)}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => {
                                  setSelectedVehicle(vehicle);
                                  setIsEditModalOpen(true);
                                }}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="outline" size="icon">
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Delete Vehicle Type</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to delete this vehicle type? This action cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleDelete(vehicle.id)}
                                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Add Vehicle Type Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Vehicle Type</DialogTitle>
            <DialogDescription>
              Create a new vehicle type with its specifications
            </DialogDescription>
          </DialogHeader>
          <Form {...addForm}>
            <form onSubmit={addForm.handleSubmit(onAddSubmit)} className="space-y-4">
              <FormField
                control={addForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter vehicle name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={addForm.control}
                name="icon"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Icon</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select an icon" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {ICON_OPTIONS.map(option => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={addForm.control}
                name="maxWeight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Maximum Weight (kg)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={addForm.control}
                name="baseFare"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Base Fare</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createVehicleType.isPending}>
                  {createVehicleType.isPending ? 'Creating...' : 'Create'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Vehicle Type Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Vehicle Type</DialogTitle>
            <DialogDescription>
              Modify the vehicle type details
            </DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter vehicle name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="icon"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Icon</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select an icon" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {ICON_OPTIONS.map(option => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="maxWeight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Maximum Weight (kg)</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="baseFare"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Base Fare</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsEditModalOpen(false);
                    setSelectedVehicle(null);
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={updateVehicleType.isPending}>
                  {updateVehicleType.isPending ? 'Saving...' : 'Save Changes'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}