import { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { Order } from '@/types';
import { formatDate, ORDER_STATUS_LABELS } from '@/lib/constants';
import { BottomNavigation } from '@/components/layout/BottomNavigation';
import { ArrowRight, Truck, Bike, Package, Map, MapPin, Clock, List, Loader2, RefreshCw } from 'lucide-react';
import { useCurrency } from '@/lib/currency';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { OrderHistoryMinimap } from '@/components/tracking/OrderHistoryMinimap';
import { LoadingAnimation } from '@/components/ui/loading-animation';
import { useToast } from '@/hooks/use-toast';

export default function OrderHistory() {
  const [_, navigate] = useLocation();
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [refreshInterval, setRefreshInterval] = useState(30000); // 30 seconds by default
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Get user data from the current session instead of using a mock
  const { data: userData } = useQuery({
    queryKey: ['/api/users/current'],
    retry: false
  });
  
  const userId = userData?.id;
  const { formatCurrency } = useCurrency();
  
  // Only fetch orders if we have a userId
  const { 
    data: orders, 
    isLoading, 
    error,
    dataUpdatedAt,
    refetch 
  } = useQuery<Order[]>({
    queryKey: [`/api/users/${userId}/orders`],
    enabled: !!userId,
    refetchInterval: refreshInterval, // Real-time updates with polling
  });
  
  // Increase refresh rate for active orders
  useEffect(() => {
    // Check if there are any orders in progress (not delivered or cancelled)
    const hasActiveOrders = orders?.some(
      order => !['delivered', 'cancelled'].includes(order.status)
    );
    
    // Set refresh rate based on active orders
    if (hasActiveOrders) {
      setRefreshInterval(10000); // 10 seconds for active orders
    } else {
      setRefreshInterval(30000); // 30 seconds for completed orders
    }
  }, [orders]);
  
  // Get icon for vehicle type
  const getVehicleIcon = (vehicleTypeId: number) => {
    switch (vehicleTypeId) {
      case 1: // Bike
      case 2: // Motorbike
        return <Bike className="h-5 w-5" />;
      default:
        return <Truck className="h-5 w-5" />;
    }
  };
  
  // Handle order selection from the map
  const handleOrderSelect = (order: Order) => {
    navigate(`/track/${order.id}`);
  };
  
  const renderOrdersList = () => {
    if (isLoading) {
      return (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white rounded-lg shadow-sm p-4 animate-pulse">
              <div className="flex justify-between items-center mb-2">
                <div className="w-1/2 h-5 bg-gray-200 rounded"></div>
                <div className="w-1/4 h-5 bg-gray-200 rounded"></div>
              </div>
              <div className="w-full h-4 bg-gray-200 rounded mb-2"></div>
              <div className="w-3/4 h-4 bg-gray-200 rounded"></div>
            </div>
          ))}
        </div>
      );
    }
    
    if (error) {
      return <div className="p-4 text-center text-red-500">Failed to load orders</div>;
    }
    
    if (!orders || orders.length === 0) {
      return (
        <div className="p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
            <Package className="h-8 w-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium mb-1">No orders yet</h3>
          <p className="text-gray-500 mb-4">Your order history will appear here</p>
          <Link href="/">
            <button className="text-primary font-medium">Request a Transport</button>
          </Link>
        </div>
      );
    }
    
    return (
      <div className="space-y-4">
        {orders.map((order) => (
          <Link key={order.id} href={`/track/${order.id}`}>
            <div className="bg-white rounded-lg shadow-sm p-4 cursor-pointer border border-gray-100 hover:border-gray-200 transition-colors">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-2 text-primary">
                    {getVehicleIcon(order.vehicleTypeId)}
                  </div>
                  <h3 className="font-medium">Order #{order.id.toString().padStart(5, '0')}</h3>
                </div>
                <Badge variant="outline" className={cn(
                  "font-medium text-xs",
                  order.status === 'delivered' ? "border-green-200 text-green-600 bg-green-50" :
                  order.status === 'on_way_to_delivery' ? "border-amber-200 text-amber-600 bg-amber-50" :
                  "border-blue-200 text-blue-600 bg-blue-50"
                )}>
                  {ORDER_STATUS_LABELS[order.status]}
                </Badge>
              </div>
              
              <div className="flex items-center text-sm text-gray-500 mb-1">
                <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                <span className="truncate">{order.deliveryLocation}</span>
              </div>
              
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center text-xs text-gray-500">
                  <Clock className="h-3 w-3 mr-1" />
                  <span>{formatDate(order.createdAt)}</span>
                </div>
                <div className="flex items-center">
                  <span className="font-medium text-primary mr-1">{formatCurrency(order.fare)}</span>
                  <ArrowRight className="h-4 w-4 text-gray-400" />
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    );
  };
  
  // Function to handle manual refresh
  const handleRefresh = async () => {
    try {
      await refetch();
      toast({
        title: "Refreshed",
        description: "Order data has been updated",
      });
    } catch (error) {
      toast({
        title: "Refresh failed",
        description: "Could not update order data",
        variant: "destructive"
      });
    }
  };

  // Format the last updated time
  const formattedUpdateTime = dataUpdatedAt 
    ? new Date(dataUpdatedAt).toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      })
    : null;

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white relative pb-16">
      {/* Header */}
      <header className="bg-white p-4 shadow-sm flex items-center justify-between sticky top-0 z-10">
        <h1 className="text-xl font-bold">Order History</h1>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-9 w-9 p-0"
            onClick={handleRefresh}
            disabled={isLoading}
            title="Refresh data"
          >
            <RefreshCw className={cn(
              "h-5 w-5",
              isLoading ? "animate-spin text-gray-400" : "text-primary"
            )} />
          </Button>
          <Button 
            variant={viewMode === 'list' ? 'default' : 'outline'} 
            size="sm" 
            className="h-9 w-9 p-0"
            onClick={() => setViewMode('list')}
          >
            <List className="h-5 w-5" />
          </Button>
          <Button 
            variant={viewMode === 'map' ? 'default' : 'outline'} 
            size="sm" 
            className="h-9 w-9 p-0"
            onClick={() => setViewMode('map')}
          >
            <Map className="h-5 w-5" />
          </Button>
        </div>
      </header>
      
      {/* Last updated info */}
      {formattedUpdateTime && (
        <div className="text-xs text-center text-gray-500 bg-gray-50 py-1">
          Last updated: {formattedUpdateTime} 
          {/* Display "Auto refresh: ON" if we have active orders */}
          {refreshInterval === 10000 && (
            <span className="ml-2 text-primary-600">· Auto refresh: ON</span>
          )}
        </div>
      )}
      
      {/* Content */}
      <div className="p-4">
        {viewMode === 'list' ? (
          renderOrdersList()
        ) : (
          <div className="space-y-4">
            {/* Map View */}
            {isLoading ? (
              <div className="h-[300px] flex items-center justify-center bg-gray-50 rounded-lg border">
                <LoadingAnimation size="md" text="Loading orders..." />
              </div>
            ) : orders && orders.length > 0 ? (
              <>
                <OrderHistoryMinimap 
                  orders={orders} 
                  height="h-[300px]"
                  onOrderSelect={handleOrderSelect}
                />
                <div className="text-sm text-center text-gray-500 mt-2">
                  Tap on any marker to view order details
                </div>
                
                {/* Brief order list below the map */}
                <div className="mt-6">
                  <h3 className="text-base font-medium mb-3">Recent Orders</h3>
                  <div className="space-y-2">
                    {orders.slice(0, 3).map((order) => (
                      <Link key={order.id} href={`/track/${order.id}`}>
                        <div className="flex items-center justify-between p-3 border rounded-md hover:bg-gray-50">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                              {getVehicleIcon(order.vehicleTypeId)}
                            </div>
                            <div>
                              <div className="text-sm font-medium">Order #{order.id}</div>
                              <div className="text-xs text-gray-500">{formatDate(order.createdAt)}</div>
                            </div>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {ORDER_STATUS_LABELS[order.status]}
                          </Badge>
                        </div>
                      </Link>
                    ))}
                    
                    {orders.length > 3 && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full mt-2"
                        onClick={() => setViewMode('list')}
                      >
                        View all {orders.length} orders
                      </Button>
                    )}
                  </div>
                </div>
              </>
            ) : error ? (
              <div className="p-4 text-center text-red-500">Failed to load orders</div>
            ) : (
              <div className="p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                  <Package className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium mb-1">No orders yet</h3>
                <p className="text-gray-500 mb-4">Your order history will appear here</p>
                <Link href="/">
                  <button className="text-primary font-medium">Request a Transport</button>
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
      
      <BottomNavigation />
    </div>
  );
}
