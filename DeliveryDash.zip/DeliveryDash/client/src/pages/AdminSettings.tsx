import React, { useState } from 'react';
import { AdminSidebar } from "@/components/admin/AdminSidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { PaymentGateway, CommissionConfiguration } from "@shared/schema";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  CreditCard,
  Percent,
  Plus,
  Edit,
  Trash,
  Check,
  X,
  AlertTriangle,
  Settings,
  RefreshCw,
  Map
} from "lucide-react";
import { MapApiManager } from "@/components/admin/MapApiManager";

// Component to manage payment gateways
function PaymentGatewaysManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingGateway, setEditingGateway] = useState<PaymentGateway | null>(null);

  // Initial form state for new gateways
  const initialGatewayForm = {
    gatewayType: 'paypal',
    displayName: '',
    isActive: true,
    isDefault: false,
    configuration: {},
    supportedCountries: ['US', 'KE'],
    supportedCurrencies: ['USD', 'KES'],
    minimumAmount: 0,
    processingFee: 0,
    processingFeeType: 'percentage',
    adminNotes: '',
    createdBy: 0
  };

  const [gatewayForm, setGatewayForm] = useState(initialGatewayForm);

  // Fetch payment gateways
  const { data: paymentGateways = [], isLoading: isLoadingGateways, refetch: refetchGateways } = useQuery<PaymentGateway[]>({
    queryKey: ['/api/payment-gateways'],
  });

  // Add gateway mutation
  const addGatewayMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/payment-gateways', data);
      
      if (!response.ok) {
        const errorData = await response.json();
        if (errorData.errors && Array.isArray(errorData.errors)) {
          // Format validation errors for better display
          const validationErrors = errorData.errors.map((err: any) => err.message || err.path).join(', ');
          throw new Error(`Validation failed: ${validationErrors}`);
        }
        throw new Error(errorData.message || "Failed to add payment gateway");
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/payment-gateways'] });
      setShowAddDialog(false);
      setGatewayForm(initialGatewayForm);
      toast({
        title: "Gateway Added",
        description: "The payment gateway has been added successfully."
      });
    },
    onError: (error: any) => {
      console.error("Add gateway error:", error);
      toast({
        title: "Failed to Add Gateway",
        description: error.message || "Could not add the payment gateway. Please check the form for errors.",
        variant: "destructive"
      });
    }
  });

  // Update gateway mutation
  const updateGatewayMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('PATCH', `/api/payment-gateways/${data.id}`, data);
      
      if (!response.ok) {
        const errorData = await response.json();
        if (errorData.errors && Array.isArray(errorData.errors)) {
          // Format validation errors for better display
          const validationErrors = errorData.errors.map((err: any) => err.message || err.path).join(', ');
          throw new Error(`Validation failed: ${validationErrors}`);
        }
        throw new Error(errorData.message || "Failed to update payment gateway");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/payment-gateways'] });
      setEditingGateway(null);
      setGatewayForm(initialGatewayForm);
      toast({
        title: "Gateway Updated",
        description: `The payment gateway "${data.displayName}" has been updated successfully.`
      });
    },
    onError: (error: any) => {
      console.error("Update gateway error:", error);
      toast({
        title: "Failed to Update Gateway",
        description: error.message || "Could not update the payment gateway. Please check the form for errors.",
        variant: "destructive"
      });
    }
  });

  // Toggle gateway status mutation
  const toggleGatewayStatusMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number, isActive: boolean }) => {
      const response = await apiRequest('PATCH', `/api/payment-gateways/${id}/toggle-status`, { isActive });
      
      if (!response.ok) {
        const errorData = await response.json();
        if (errorData.code === 'LAST_ACTIVE_GATEWAY') {
          throw new Error("Cannot deactivate the only active payment gateway. At least one gateway must remain active.");
        }
        throw new Error(errorData.message || "Failed to update gateway status");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/payment-gateways'] });
      toast({
        title: "Status Updated",
        description: data.message || `Payment gateway ${data.isActive ? 'activated' : 'deactivated'} successfully.`
      });
    },
    onError: (error: any) => {
      console.error("Gateway status update error:", error);
      toast({
        title: "Gateway Status Update Failed",
        description: error.message || "Failed to update payment gateway status.",
        variant: "destructive"
      });
    }
  });

  // Set default gateway mutation
  const setDefaultGatewayMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('PATCH', `/api/payment-gateways/${id}/set-default`, {});
      
      if (!response.ok) {
        const errorData = await response.json();
        if (errorData.code === 'INACTIVE_GATEWAY') {
          throw new Error("Cannot set an inactive payment gateway as default. Please activate the gateway first.");
        } else if (errorData.code === 'GATEWAY_NOT_FOUND') {
          throw new Error("The payment gateway could not be found. It may have been deleted.");
        }
        throw new Error(errorData.message || "Failed to set default payment gateway");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/payment-gateways'] });
      toast({
        title: "Default Gateway Updated",
        description: data.message || "The payment gateway has been set as the default payment method."
      });
    },
    onError: (error: any) => {
      console.error("Set default gateway error:", error);
      toast({
        title: "Set Default Gateway Failed",
        description: error.message || "Failed to set default payment gateway.",
        variant: "destructive"
      });
    }
  });

  // Handle form input changes
  const handleGatewayInputChange = (field: string, value: any) => {
    setGatewayForm({
      ...gatewayForm,
      [field]: value
    });
  };

  // Handle form submission
  const handleGatewaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = {
      ...gatewayForm,
      // Parse numeric values
      minimumAmount: parseFloat(gatewayForm.minimumAmount.toString()),
      processingFee: parseFloat(gatewayForm.processingFee.toString()),
    };

    if (editingGateway) {
      updateGatewayMutation.mutate({ ...formData, id: editingGateway.id });
    } else {
      addGatewayMutation.mutate(formData);
    }
  };

  // Open edit dialog with gateway data
  const openEditDialog = (gateway: PaymentGateway) => {
    setEditingGateway(gateway);
    setGatewayForm({
      gatewayType: gateway.gatewayType,
      displayName: gateway.displayName,
      isActive: gateway.isActive,
      isDefault: gateway.isDefault,
      configuration: gateway.configuration,
      supportedCountries: gateway.supportedCountries,
      supportedCurrencies: gateway.supportedCurrencies,
      minimumAmount: gateway.minimumAmount,
      processingFee: gateway.processingFee,
      processingFeeType: gateway.processingFeeType,
      adminNotes: gateway.adminNotes || '',
      createdBy: gateway.createdBy
    });
    setShowAddDialog(true);
  };

  // Cancel edit or add
  const cancelGatewayDialog = () => {
    setShowAddDialog(false);
    setEditingGateway(null);
    setGatewayForm(initialGatewayForm);
  };

  // Get payment method display name
  const getPaymentMethodDisplay = (method: string) => {
    const methods: Record<string, string> = {
      'paypal': 'PayPal',
      'google_pay': 'Google Pay',
      'airtel_money': 'Airtel Money',
      'mpesa': 'M-Pesa'
    };
    return methods[method] || method;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Payment Gateways</h3>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Gateway
        </Button>
      </div>

      {isLoadingGateways ? (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      ) : paymentGateways.length === 0 ? (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>No Payment Gateways</AlertTitle>
          <AlertDescription>
            No payment gateways have been configured yet. Add a gateway to accept payments.
          </AlertDescription>
        </Alert>
      ) : (
        <Table>
          <TableCaption>List of configured payment gateways</TableCaption>
          <TableHeader>
            <TableRow>
              <TableHead>Gateway</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Fee</TableHead>
              <TableHead>Default</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paymentGateways.map((gateway) => (
              <TableRow key={gateway.id}>
                <TableCell className="font-medium">
                  <div className="flex flex-col">
                    <span>{gateway.displayName}</span>
                    <span className="text-xs text-muted-foreground">
                      {getPaymentMethodDisplay(gateway.gatewayType)}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <Switch
                    checked={gateway.isActive}
                    onCheckedChange={(checked) => 
                      toggleGatewayStatusMutation.mutate({ id: gateway.id, isActive: checked })
                    }
                  />
                </TableCell>
                <TableCell>
                  {gateway.processingFee}
                  {gateway.processingFeeType === 'percentage' ? '%' : ' USD'}
                </TableCell>
                <TableCell>
                  {gateway.isDefault ? (
                    <Badge variant="default" className="bg-green-500 hover:bg-green-600">Default</Badge>
                  ) : (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setDefaultGatewayMutation.mutate(gateway.id)}
                    >
                      Set Default
                    </Button>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => openEditDialog(gateway)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* Add/Edit Gateway Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              {editingGateway ? 'Edit Payment Gateway' : 'Add Payment Gateway'}
            </DialogTitle>
            <DialogDescription>
              Configure a payment gateway to process payments.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleGatewaySubmit}>
            <div className="space-y-6 py-4">
              {/* Basic Info Section */}
              <div className="space-y-1">
                <h3 className="text-lg font-medium">Basic Information</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Configure the payment gateway's basic settings.
                </p>
              </div>
              
              <div className="grid gap-6">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="gatewayType" className="text-right font-medium">
                    Gateway Type
                  </Label>
                  <Select
                    value={gatewayForm.gatewayType}
                    onValueChange={(value) => handleGatewayInputChange('gatewayType', value)}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select payment gateway type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="paypal">PayPal</SelectItem>
                      <SelectItem value="google_pay">Google Pay</SelectItem>
                      <SelectItem value="airtel_money">Airtel Money</SelectItem>
                      <SelectItem value="mpesa">M-Pesa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="displayName" className="text-right font-medium">
                    Display Name
                  </Label>
                  <Input
                    id="displayName"
                    value={gatewayForm.displayName}
                    onChange={(e) => handleGatewayInputChange('displayName', e.target.value)}
                    placeholder="e.g., PayPal Payment"
                    className="col-span-3"
                  />
                </div>
                
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="processingFee" className="text-right font-medium">
                    Processing Fee
                  </Label>
                  <div className="col-span-3 flex gap-2">
                    <Input
                      id="processingFee"
                      type="number"
                      step="0.01"
                      min="0"
                      value={gatewayForm.processingFee}
                      onChange={(e) => handleGatewayInputChange('processingFee', e.target.value)}
                      className="flex-1"
                    />
                    <Select
                      value={gatewayForm.processingFeeType}
                      onValueChange={(value) => handleGatewayInputChange('processingFeeType', value)}
                    >
                      <SelectTrigger className="w-[110px]">
                        <SelectValue placeholder="Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="percentage">Percentage</SelectItem>
                        <SelectItem value="fixed">Fixed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="minimumAmount" className="text-right font-medium">
                    Minimum Amount
                  </Label>
                  <Input
                    id="minimumAmount"
                    type="number"
                    step="0.01"
                    min="0"
                    value={gatewayForm.minimumAmount}
                    onChange={(e) => handleGatewayInputChange('minimumAmount', e.target.value)}
                    className="col-span-3"
                  />
                </div>
                
                <div className="grid grid-cols-4 items-center gap-4">
                  <div className="text-right">
                    <Label htmlFor="active" className="text-right font-medium">
                      Active
                    </Label>
                  </div>
                  <div className="col-span-3 flex items-center space-x-2">
                    <Switch
                      id="active"
                      checked={gatewayForm.isActive}
                      onCheckedChange={(checked) => handleGatewayInputChange('isActive', checked)}
                    />
                    <span className="text-sm text-muted-foreground">
                      {gatewayForm.isActive ? 'Gateway is active and available for payments' : 'Gateway is disabled'}
                    </span>
                  </div>
                </div>
              </div>
              
              {/* API Key Configuration Section */}
              <Separator className="my-6" />
              
              <div className="space-y-1">
                <h3 className="text-lg font-medium">API Key Configuration</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Enter the API keys for this payment gateway to enable live transactions.
                </p>
              </div>
              
              {/* PayPal API Keys */}
              {gatewayForm.gatewayType === 'paypal' && (
                <div className="grid gap-6 bg-muted/40 p-6 rounded-md">
                  <div className="space-y-1 mb-3">
                    <h4 className="text-base font-semibold flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 mr-2 text-blue-600">
                        <path d="M10.5 3.75a6 6 0 00-5.98 6.496A5.25 5.25 0 006.75 20.25H18a4.5 4.5 0 002.206-8.423 3.75 3.75 0 00-4.133-4.303A6.001 6.001 0 0010.5 3.75z" />
                      </svg>
                      PayPal API Keys
                    </h4>
                    <p className="text-sm text-muted-foreground mb-4">
                      Enter your PayPal developer credentials. Find these in your PayPal Developer Dashboard.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="paypalClientId" className="text-right font-medium">
                      Client ID
                    </Label>
                    <Input
                      id="paypalClientId"
                      value={(gatewayForm.configuration as any)?.clientId || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        clientId: e.target.value
                      })}
                      placeholder="Enter PayPal Client ID from developer dashboard"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="paypalClientSecret" className="text-right font-medium">
                      Client Secret
                    </Label>
                    <Input
                      id="paypalClientSecret"
                      type="password"
                      value={(gatewayForm.configuration as any)?.clientSecret || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        clientSecret: e.target.value
                      })}
                      placeholder="Enter PayPal Client Secret (sensitive)"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="paypalEnvironment" className="text-right font-medium">
                      Environment
                    </Label>
                    <Select
                      value={(gatewayForm.configuration as any)?.environment || 'sandbox'}
                      onValueChange={(value) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        environment: value
                      })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select environment" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sandbox">Sandbox (Testing)</SelectItem>
                        <SelectItem value="production">Production (Live)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
              
              {/* Google Pay API Keys */}
              {gatewayForm.gatewayType === 'google_pay' && (
                <div className="grid gap-6 bg-muted/40 p-6 rounded-md">
                  <div className="space-y-1 mb-3">
                    <h4 className="text-base font-semibold flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 mr-2 text-green-600">
                        <path d="M10.5 3.75a6 6 0 00-5.98 6.496A5.25 5.25 0 006.75 20.25H18a4.5 4.5 0 002.206-8.423 3.75 3.75 0 00-4.133-4.303A6.001 6.001 0 0010.5 3.75z" />
                      </svg>
                      Google Pay API Keys
                    </h4>
                    <p className="text-sm text-muted-foreground mb-4">
                      Enter your Google Pay credentials from the Google Pay Business Console.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="googlePayMerchantId" className="text-right font-medium">
                      Merchant ID
                    </Label>
                    <Input
                      id="googlePayMerchantId"
                      value={(gatewayForm.configuration as any)?.merchantId || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        merchantId: e.target.value
                      })}
                      placeholder="Enter Google Pay Merchant ID"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="googlePayApiKey" className="text-right font-medium">
                      API Key
                    </Label>
                    <Input
                      id="googlePayApiKey"
                      type="password"
                      value={(gatewayForm.configuration as any)?.apiKey || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        apiKey: e.target.value
                      })}
                      placeholder="Enter Google Pay API Key (sensitive)"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="googlePayEnvironment" className="text-right font-medium">
                      Environment
                    </Label>
                    <Select
                      value={(gatewayForm.configuration as any)?.environment || 'TEST'}
                      onValueChange={(value) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        environment: value
                      })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select environment" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="TEST">TEST</SelectItem>
                        <SelectItem value="PRODUCTION">PRODUCTION</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
              
              {/* M-Pesa API Keys */}
              {gatewayForm.gatewayType === 'mpesa' && (
                <div className="grid gap-6 bg-muted/40 p-6 rounded-md">
                  <div className="space-y-1 mb-3">
                    <h4 className="text-base font-semibold flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 mr-2 text-red-600">
                        <path d="M10.5 3.75a6 6 0 00-5.98 6.496A5.25 5.25 0 006.75 20.25H18a4.5 4.5 0 002.206-8.423 3.75 3.75 0 00-4.133-4.303A6.001 6.001 0 0010.5 3.75z" />
                      </svg>
                      M-Pesa API Keys
                    </h4>
                    <p className="text-sm text-muted-foreground mb-4">
                      Enter your M-Pesa Daraja API credentials from the Safaricom Developer Portal.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="mpesaConsumerKey" className="text-right font-medium">
                      Consumer Key
                    </Label>
                    <Input
                      id="mpesaConsumerKey"
                      value={(gatewayForm.configuration as any)?.consumerKey || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        consumerKey: e.target.value
                      })}
                      placeholder="Enter M-Pesa Consumer Key"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="mpesaConsumerSecret" className="text-right font-medium">
                      Consumer Secret
                    </Label>
                    <Input
                      id="mpesaConsumerSecret"
                      type="password"
                      value={(gatewayForm.configuration as any)?.consumerSecret || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        consumerSecret: e.target.value
                      })}
                      placeholder="Enter M-Pesa Consumer Secret (sensitive)"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="mpesaPassKey" className="text-right font-medium">
                      Passkey
                    </Label>
                    <Input
                      id="mpesaPassKey"
                      type="password"
                      value={(gatewayForm.configuration as any)?.passKey || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        passKey: e.target.value
                      })}
                      placeholder="Enter M-Pesa Passkey (sensitive)"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="mpesaShortCode" className="text-right font-medium">
                      Business Shortcode
                    </Label>
                    <Input
                      id="mpesaShortCode"
                      value={(gatewayForm.configuration as any)?.shortCode || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        shortCode: e.target.value
                      })}
                      placeholder="Enter M-Pesa Business Shortcode"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="mpesaEnvironment" className="text-right font-medium">
                      Environment
                    </Label>
                    <Select
                      value={(gatewayForm.configuration as any)?.environment || 'sandbox'}
                      onValueChange={(value) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        environment: value
                      })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select environment" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sandbox">Sandbox</SelectItem>
                        <SelectItem value="production">Production</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
              
              {/* Airtel Money API Keys */}
              {gatewayForm.gatewayType === 'airtel_money' && (
                <div className="grid gap-6 bg-muted/40 p-6 rounded-md">
                  <div className="space-y-1 mb-3">
                    <h4 className="text-base font-semibold flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 mr-2 text-orange-600">
                        <path d="M10.5 3.75a6 6 0 00-5.98 6.496A5.25 5.25 0 006.75 20.25H18a4.5 4.5 0 002.206-8.423 3.75 3.75 0 00-4.133-4.303A6.001 6.001 0 0010.5 3.75z" />
                      </svg>
                      Airtel Money API Keys
                    </h4>
                    <p className="text-sm text-muted-foreground mb-4">
                      Enter your Airtel Money API credentials from the Airtel Developer Portal.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="airtelClientId" className="text-right font-medium">
                      Client ID
                    </Label>
                    <Input
                      id="airtelClientId"
                      value={(gatewayForm.configuration as any)?.clientId || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        clientId: e.target.value
                      })}
                      placeholder="Enter Airtel Money Client ID"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="airtelClientSecret" className="text-right font-medium">
                      Client Secret
                    </Label>
                    <Input
                      id="airtelClientSecret"
                      type="password"
                      value={(gatewayForm.configuration as any)?.clientSecret || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        clientSecret: e.target.value
                      })}
                      placeholder="Enter Airtel Money Client Secret (sensitive)"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="airtelMerchantCode" className="text-right font-medium">
                      Merchant Code
                    </Label>
                    <Input
                      id="airtelMerchantCode"
                      value={(gatewayForm.configuration as any)?.merchantCode || ''}
                      onChange={(e) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        merchantCode: e.target.value
                      })}
                      placeholder="Enter Airtel Money Merchant Code"
                      className="col-span-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="airtelEnvironment" className="text-right font-medium">
                      Environment
                    </Label>
                    <Select
                      value={(gatewayForm.configuration as any)?.environment || 'sandbox'}
                      onValueChange={(value) => handleGatewayInputChange('configuration', {
                        ...gatewayForm.configuration as any,
                        environment: value
                      })}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select environment" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sandbox">Sandbox</SelectItem>
                        <SelectItem value="production">Production</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
                            
              <div className="grid grid-cols-4 items-start gap-4 mt-6">
                <Label htmlFor="adminNotes" className="text-right pt-2">
                  Admin Notes
                </Label>
                <Textarea
                  id="adminNotes"
                  value={gatewayForm.adminNotes}
                  onChange={(e) => handleGatewayInputChange('adminNotes', e.target.value)}
                  placeholder="Optional notes about this payment gateway"
                  className="col-span-3"
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={cancelGatewayDialog}>
                Cancel
              </Button>
              <Button type="submit" disabled={!gatewayForm.displayName}>
                {editingGateway ? 'Update' : 'Add'} Gateway
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Component to manage commission configurations
function CommissionConfigurationsManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingConfig, setEditingConfig] = useState<CommissionConfiguration | null>(null);

  // Initial form state for new commission configurations
  const initialConfigForm = {
    commissionName: '',
    commissionPercentage: 15, // Default to 15%
    description: '',
    appliesTo: 'all',
    vehicleTypeIds: [] as number[],
    partnerIds: [] as number[],
    isDefault: false,
    isActive: true,
    effectiveFrom: new Date().toISOString(),
    effectiveTo: null as null | string,
    createdBy: 0
  };

  const [configForm, setConfigForm] = useState(initialConfigForm);

  // Fetch commission configurations
  const { data: commissionConfigs = [], isLoading: isLoadingConfigs, refetch: refetchConfigs } = useQuery<CommissionConfiguration[]>({
    queryKey: ['/api/commission-configurations'],
  });

  // Add commission configuration mutation
  const addConfigMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/commission-configurations', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/commission-configurations'] });
      setShowAddDialog(false);
      setConfigForm(initialConfigForm);
      toast({
        title: "Commission Configuration Added",
        description: "The commission configuration has been added successfully."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add commission configuration.",
        variant: "destructive"
      });
    }
  });

  // Update commission configuration mutation
  const updateConfigMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('PATCH', `/api/commission-configurations/${data.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/commission-configurations'] });
      setEditingConfig(null);
      setConfigForm(initialConfigForm);
      toast({
        title: "Commission Configuration Updated",
        description: "The commission configuration has been updated successfully."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update commission configuration.",
        variant: "destructive"
      });
    }
  });

  // Toggle commission configuration status mutation
  const toggleConfigStatusMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number, isActive: boolean }) => {
      const response = await apiRequest('PATCH', `/api/commission-configurations/${id}/toggle-status`, { isActive });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/commission-configurations'] });
      toast({
        title: "Status Updated",
        description: "The commission configuration status has been updated."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update configuration status.",
        variant: "destructive"
      });
    }
  });

  // Set default commission configuration mutation
  const setDefaultConfigMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('PATCH', `/api/commission-configurations/${id}/set-default`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/commission-configurations'] });
      toast({
        title: "Default Configuration Updated",
        description: "The default commission configuration has been set."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to set default configuration.",
        variant: "destructive"
      });
    }
  });

  // Handle form input changes
  const handleConfigInputChange = (field: string, value: any) => {
    setConfigForm({
      ...configForm,
      [field]: value
    });
  };

  // Handle form submission
  const handleConfigSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = {
      ...configForm,
      // Parse numeric values
      commissionPercentage: parseFloat(configForm.commissionPercentage.toString()),
    };

    if (editingConfig) {
      updateConfigMutation.mutate({ ...formData, id: editingConfig.id });
    } else {
      addConfigMutation.mutate(formData);
    }
  };

  // Open edit dialog with configuration data
  const openEditDialog = (config: CommissionConfiguration) => {
    setEditingConfig(config);
    setConfigForm({
      commissionName: config.commissionName,
      commissionPercentage: config.commissionPercentage,
      description: config.description || '',
      appliesTo: config.appliesTo,
      vehicleTypeIds: config.vehicleTypeIds || [] as number[],
      partnerIds: config.partnerIds || [] as number[],
      isDefault: config.isDefault,
      isActive: config.isActive,
      effectiveFrom: typeof config.effectiveFrom === 'string' ? config.effectiveFrom : config.effectiveFrom.toISOString(),
      effectiveTo: config.effectiveTo ? (typeof config.effectiveTo === 'string' ? config.effectiveTo : config.effectiveTo.toISOString()) : null,
      createdBy: config.createdBy
    });
    setShowAddDialog(true);
  };

  // Cancel edit or add
  const cancelConfigDialog = () => {
    setShowAddDialog(false);
    setEditingConfig(null);
    setConfigForm(initialConfigForm);
  };

  // Get applies to display text
  const getAppliesToDisplay = (appliesTo: string) => {
    const types: Record<string, string> = {
      'all': 'All Partners',
      'vehicle_type': 'Specific Vehicle Types',
      'specific_partners': 'Specific Partners'
    };
    return types[appliesTo] || appliesTo;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Commission Configurations</h3>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Configuration
        </Button>
      </div>

      {isLoadingConfigs ? (
        <div className="space-y-3">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      ) : commissionConfigs.length === 0 ? (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>No Commission Configurations</AlertTitle>
          <AlertDescription>
            No commission configurations have been set up yet. Add a configuration to define partner commission rates.
          </AlertDescription>
        </Alert>
      ) : (
        <Table>
          <TableCaption>List of commission configurations for delivery partners</TableCaption>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Commission %</TableHead>
              <TableHead>Applies To</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Default</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {commissionConfigs.map((config) => (
              <TableRow key={config.id}>
                <TableCell className="font-medium">
                  <div className="flex flex-col">
                    <span>{config.commissionName}</span>
                    {config.description && (
                      <span className="text-xs text-muted-foreground">
                        {config.description}
                      </span>
                    )}
                  </div>
                </TableCell>
                <TableCell>{config.commissionPercentage}%</TableCell>
                <TableCell>{getAppliesToDisplay(config.appliesTo)}</TableCell>
                <TableCell>
                  <Switch
                    checked={config.isActive}
                    onCheckedChange={(checked) => 
                      toggleConfigStatusMutation.mutate({ id: config.id, isActive: checked })
                    }
                  />
                </TableCell>
                <TableCell>
                  {config.isDefault ? (
                    <Badge variant="default" className="bg-green-500 hover:bg-green-600">Default</Badge>
                  ) : (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setDefaultConfigMutation.mutate(config.id)}
                    >
                      Set Default
                    </Button>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => openEditDialog(config)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* Add/Edit Commission Configuration Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingConfig ? 'Edit Commission Configuration' : 'Add Commission Configuration'}
            </DialogTitle>
            <DialogDescription>
              Configure commission rates for delivery partners.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleConfigSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="commissionName" className="text-right">
                  Name
                </Label>
                <Input
                  id="commissionName"
                  value={configForm.commissionName}
                  onChange={(e) => handleConfigInputChange('commissionName', e.target.value)}
                  placeholder="e.g., Standard Commission"
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="commissionPercentage" className="text-right">
                  Commission %
                </Label>
                <Input
                  id="commissionPercentage"
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  value={configForm.commissionPercentage}
                  onChange={(e) => handleConfigInputChange('commissionPercentage', e.target.value)}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="appliesTo" className="text-right">
                  Applies To
                </Label>
                <Select
                  value={configForm.appliesTo}
                  onValueChange={(value) => handleConfigInputChange('appliesTo', value)}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select who this applies to" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Partners</SelectItem>
                    <SelectItem value="vehicle_type">Specific Vehicle Types</SelectItem>
                    <SelectItem value="specific_partners">Specific Partners</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <div className="text-right">
                  <Label htmlFor="active" className="text-right">
                    Active
                  </Label>
                </div>
                <div className="col-span-3">
                  <Switch
                    id="active"
                    checked={configForm.isActive}
                    onCheckedChange={(checked) => handleConfigInputChange('isActive', checked)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <Label htmlFor="description" className="text-right pt-2">
                  Description
                </Label>
                <Textarea
                  id="description"
                  value={configForm.description}
                  onChange={(e) => handleConfigInputChange('description', e.target.value)}
                  placeholder="Optional description of this commission configuration"
                  className="col-span-3"
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={cancelConfigDialog}>
                Cancel
              </Button>
              <Button type="submit" disabled={!configForm.commissionName}>
                {editingConfig ? 'Update' : 'Add'} Configuration
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Main Settings Component
export default function AdminSettings() {
  const [selectedTab, setSelectedTab] = useState("payment-gateways");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State for automatic payments setting
  const [autoPaymentsEnabled, setAutoPaymentsEnabled] = useState(false);
  const [isUpdatingAutoPayments, setIsUpdatingAutoPayments] = useState(false);
  
  // Fetch automatic payments setting
  const { data: autoPaymentsData, isLoading: isLoadingAutoPayments } = useQuery<{isEnabled: boolean}>({
    queryKey: ['/api/settings/auto-payments']
  });
  
  // Set the auto payments enabled state when data is loaded
  React.useEffect(() => {
    if (autoPaymentsData) {
      setAutoPaymentsEnabled(autoPaymentsData.isEnabled);
    }
  }, [autoPaymentsData]);
  
  // Update automatic payments setting mutation
  const updateAutoPaymentsMutation = useMutation({
    mutationFn: async (isEnabled: boolean) => {
      setIsUpdatingAutoPayments(true);
      const response = await apiRequest('POST', '/api/settings/auto-payments', { isEnabled });
      return response.json();
    },
    onSuccess: (data) => {
      setAutoPaymentsEnabled(data.isEnabled);
      toast({
        title: "Setting Updated",
        description: `Automatic payments ${data.isEnabled ? 'enabled' : 'disabled'}.`
      });
      queryClient.invalidateQueries({ queryKey: ['/api/settings/auto-payments'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update automatic payments setting.",
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsUpdatingAutoPayments(false);
    }
  });
  
  // Handle toggle automatic payments
  const handleToggleAutoPayments = (checked: boolean) => {
    updateAutoPaymentsMutation.mutate(checked);
  };

  return (
    <div className="container mx-auto p-4">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">System Settings</h1>
        <p className="text-muted-foreground">Configure system-wide settings for the platform</p>
      </header>
      
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* Sidebar navigation */}
        <div className="md:col-span-1">
          <AdminSidebar />
        </div>
        
        {/* Main content area */}
        <div className="md:col-span-4">
          
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Automatic Payments</CardTitle>
              <CardDescription>
                Configure whether payments should be automatically processed when orders are completed
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="autoPayments" className="text-base font-medium">
                    Enable Automatic Payments
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    When enabled, payments to delivery partners will be automatically processed upon order completion
                  </p>
                </div>
                <div>
                  {isLoadingAutoPayments ? (
                    <Skeleton className="h-6 w-12" />
                  ) : (
                    <Switch
                      id="autoPayments"
                      checked={autoPaymentsEnabled}
                      onCheckedChange={handleToggleAutoPayments}
                      disabled={isUpdatingAutoPayments}
                    />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Tabs value={selectedTab} onValueChange={setSelectedTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="payment-gateways">
                <CreditCard className="h-4 w-4 mr-2" />
                Payment Gateways
              </TabsTrigger>
              <TabsTrigger value="commission-configurations">
                <Percent className="h-4 w-4 mr-2" />
                Commission Configurations
              </TabsTrigger>
              <TabsTrigger value="map-api-settings">
                <Map className="h-4 w-4 mr-2" />
                Map API Settings
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="payment-gateways" className="space-y-4">
              <PaymentGatewaysManager />
            </TabsContent>
            
            <TabsContent value="commission-configurations" className="space-y-4">
              <CommissionConfigurationsManager />
            </TabsContent>
            
            <TabsContent value="map-api-settings" className="space-y-4">
              <MapApiManager />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}