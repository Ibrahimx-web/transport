import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, CreditCard, CheckCircle2, Loader2, RefreshCw, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useCurrency } from '@/lib/currency';
import { useQuery } from '@tanstack/react-query';
import { Alert, AlertDescription } from '@/components/ui/alert';

// Import payment method icons
import { SiVisa, SiMastercard, SiGooglepay, SiAirbnb, SiPaypal } from 'react-icons/si';

interface PaymentPageProps {
  params: {
    orderId: string;
  };
}

interface OrderDetails {
  id: number;
  totalFare: number;
  distance: number;
  pickupLocation: string;
  deliveryLocation: string;
  status: string;
  userId: number;
  vehicleTypeId: number;
  // Other order details
}

// Payment gateway types
interface PaymentGateway {
  id: number;
  name: string;
  isActive: boolean;
  isDefault: boolean;
  icon: string;
  supportedMethods: string[];
  credentials?: Record<string, any>;
}

// Payment method types
type PaymentMethod = 'card' | 'mobile_money' | 'google_pay' | 'paypal';
type CardType = 'visa' | 'mastercard';
type MobileMoneyProvider = 'airtel' | 'mpesa';

export default function Payment({ params }: PaymentPageProps) {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const { formatCurrency } = useCurrency();
  const orderRefreshIntervalId = useRef<number | null>(null);
  
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [cardType, setCardType] = useState<CardType>('visa');
  const [mobileProvider, setMobileProvider] = useState<MobileMoneyProvider>('mpesa');
  
  const [orderDetails, setOrderDetails] = useState<OrderDetails | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isAutoRefresh, setIsAutoRefresh] = useState<boolean>(true);
  const [showRefreshAnimation, setShowRefreshAnimation] = useState<boolean>(false);

  // Form states
  const [cardNumber, setCardNumber] = useState('');
  const [cardholderName, setCardholderName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  // Fetch payment gateways
  const { data: availablePaymentGateways = [] } = useQuery<PaymentGateway[]>({
    queryKey: ['/api/payment-gateways/public'],
    queryFn: async () => {
      console.log('[PAYMENT] Fetching available payment gateways');
      const res = await apiRequest('GET', '/api/payment-gateways/public');
      if (!res.ok) {
        throw new Error('Failed to fetch payment gateways');
      }
      const data = await res.json();
      console.log(`[PAYMENT] Received ${data.length} payment gateways`);
      return data;
    },
    staleTime: 60000, // 1 minute
  });

  // Filter active payment gateways
  const activeGateways = availablePaymentGateways.filter(gateway => gateway.isActive);

  // Fetch order details with refreshing capability
  const fetchOrderDetails = useCallback(async () => {
    try {
      const fetchStartTime = Date.now();
      console.log(`[PAYMENT] Fetching order details for order ${params.orderId}`);
      
      const response = await apiRequest('GET', `/api/orders/${params.orderId}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch order details');
      }
      
      const data = await response.json();
      setOrderDetails(data);
      setLastUpdated(new Date());
      
      const fetchDuration = Date.now() - fetchStartTime;
      console.log(`[PAYMENT] Received order details in ${fetchDuration}ms`);
      
      // Show refresh animation briefly
      if (showRefreshAnimation) {
        setTimeout(() => setShowRefreshAnimation(false), 700);
      }
    } catch (error) {
      console.error('[PAYMENT] Error fetching order details:', error);
      if (showRefreshAnimation) {
        setShowRefreshAnimation(false);
      }
      
      toast({
        title: 'Error',
        description: 'Failed to load order details. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  }, [params.orderId]);

  // Manual refresh function
  const refreshOrderDetails = () => {
    setShowRefreshAnimation(true);
    fetchOrderDetails();
  };

  // Initial fetch and auto-refresh setup
  useEffect(() => {
    setIsLoading(true);
    fetchOrderDetails();
    
    // Set up auto-refresh if enabled
    if (isAutoRefresh) {
      orderRefreshIntervalId.current = window.setInterval(() => {
        console.log('[PAYMENT] Auto-refreshing order details');
        fetchOrderDetails();
      }, 15000); // Every 15 seconds
    }
    
    return () => {
      if (orderRefreshIntervalId.current) {
        window.clearInterval(orderRefreshIntervalId.current);
      }
    };
  }, [fetchOrderDetails, isAutoRefresh, params.orderId]);

  const handleBack = () => {
    navigate(`/track/${params.orderId}`);
  };

  const formatCardNumber = (value: string) => {
    // Remove non-digit characters
    const numbers = value.replace(/\D/g, '');
    
    // Add space after every 4 digits
    const formatted = numbers.replace(/(\d{4})(?=\d)/g, '$1 ');
    
    // Limit to 19 characters (16 digits + 3 spaces)
    return formatted.slice(0, 19);
  };

  const formatExpiryDate = (value: string) => {
    // Remove non-digit characters
    const numbers = value.replace(/\D/g, '');
    
    // Format as MM/YY
    if (numbers.length > 2) {
      return `${numbers.slice(0, 2)}/${numbers.slice(2, 4)}`;
    }
    
    return numbers;
  };

  const handleSubmitPayment = async () => {
    // Transaction tracking
    const transactionStartTime = Date.now();
    console.log(`[PAYMENT] Starting payment process for order ${params.orderId}`);
    
    // Enhanced validation with detailed error messages
    if (paymentMethod === 'card') {
      const cardErrors = [];
      
      if (cardNumber.replace(/\s/g, '').length !== 16) {
        cardErrors.push('Please enter a valid 16-digit card number');
      }
      
      if (!cardholderName) {
        cardErrors.push('Please enter the cardholder name');
      }
      
      if (expiryDate.length !== 5) {
        cardErrors.push('Please enter a valid expiry date (MM/YY)');
      }
      
      // Check expiry date for valid month and year
      if (expiryDate.length === 5) {
        const [month, year] = expiryDate.split('/');
        const currentYear = new Date().getFullYear() % 100; // Get last 2 digits
        const currentMonth = new Date().getMonth() + 1; // 1-12
        
        if (parseInt(month) < 1 || parseInt(month) > 12) {
          cardErrors.push('Invalid month (must be 01-12)');
        }
        
        if (parseInt(year) < currentYear || 
            (parseInt(year) === currentYear && parseInt(month) < currentMonth)) {
          cardErrors.push('Card has expired');
        }
      }
      
      if (cvv.length !== 3) {
        cardErrors.push('Please enter a valid 3-digit CVV');
      }
      
      if (cardErrors.length > 0) {
        toast({
          title: 'Invalid card information',
          description: cardErrors.join('. '),
          variant: 'destructive'
        });
        return;
      }
    } else if (paymentMethod === 'mobile_money') {
      if (phoneNumber.length < 10) {
        toast({
          title: 'Invalid phone number',
          description: 'Please enter a valid phone number with at least 10 digits',
          variant: 'destructive'
        });
        return;
      }
    }
    
    try {
      setIsProcessing(true);
      
      // Log time for validation
      console.log(`[PAYMENT] Validation completed in ${Date.now() - transactionStartTime}ms`);
      
      // For production, remove any artificial delay - real payment gateways are already slow enough
      // Keeping a small delay only for development/testing
      if (process.env.NODE_ENV !== 'production') {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      
      // Prepare payment data with additional metadata for better tracking
      const paymentData = {
        orderId: parseInt(params.orderId),
        userId: orderDetails?.userId,
        vehicleTypeId: orderDetails?.vehicleTypeId,
        paymentMethod,
        paymentMethodDetails: {
          ...(paymentMethod === 'card' && {
            cardType,
            // In a real app, use a secure payment processor like Stripe
            lastFourDigits: cardNumber.replace(/\s/g, '').slice(-4),
            cardholderName: cardholderName.trim()
          }),
          ...(paymentMethod === 'mobile_money' && {
            provider: mobileProvider,
            phoneNumber: phoneNumber.trim()
          }),
          ...(paymentMethod === 'google_pay' && {
            googlePayToken: 'simulated-token-' + Date.now()
          })
        },
        amount: orderDetails?.totalFare || 0,
        currency: localStorage.getItem('preferredCurrency') || 'USD',
        status: 'processing', // Initially set as processing
        metadata: {
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString(),
        }
      };
      
      console.log(`[PAYMENT] Sending payment request...`);
      const response = await apiRequest('POST', '/api/payments', paymentData);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Payment processing failed');
      }
      
      const paymentResult = await response.json();
      console.log(`[PAYMENT] Payment created with ID: ${paymentResult.id}`);
      
      // Update order status to 'paid'
      console.log(`[PAYMENT] Updating order status to 'paid'...`);
      const orderUpdateResponse = await apiRequest('POST', `/api/orders/${params.orderId}/status`, {
        status: 'paid',
        paymentId: paymentResult.id
      });
      
      if (!orderUpdateResponse.ok) {
        console.error(`[PAYMENT] Order status update failed, but payment was successful`);
        // Continue anyway since payment was processed
      }
      
      // Calculate and log total transaction time
      const totalTime = Date.now() - transactionStartTime;
      console.log(`[PAYMENT] Payment process completed in ${totalTime}ms`);
      
      toast({
        title: 'Payment successful',
        description: `Your payment of ${formatCurrency(orderDetails?.totalFare || 0)} has been processed successfully`,
      });
      
      // Redirect to tracking page after a short delay to allow the user to see the success message
      setTimeout(() => {
        navigate(`/track/${params.orderId}`);
      }, 1500);
    } catch (error) {
      console.error('[PAYMENT] Payment failed:', error);
      
      toast({
        title: 'Payment failed',
        description: error instanceof Error ? error.message : 'There was an error processing your payment. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-gray-500">Loading payment details...</p>
        </div>
      </div>
    );
  }

  if (!orderDetails) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center max-w-md px-4">
          <h2 className="text-xl font-bold mb-2">Order not found</h2>
          <p className="text-gray-500 mb-4">The order you are looking for does not exist or has been removed.</p>
          <Button onClick={() => navigate('/')}>Go to Home</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white relative pb-8">
      {/* Header */}
      <header className="bg-white p-4 shadow-sm flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center">
          <button onClick={handleBack} className="mr-3">
            <ArrowLeft className="text-gray-600" />
          </button>
          <span className="font-bold">Payment</span>
        </div>
        <button 
          onClick={refreshOrderDetails}
          className="p-2 text-gray-500 hover:text-primary transition-colors"
          disabled={showRefreshAnimation}
          aria-label="Refresh order details"
        >
          <RefreshCw 
            className={`h-5 w-5 ${showRefreshAnimation ? 'animate-spin text-primary' : ''}`} 
          />
        </button>
      </header>
      
      {/* Order summary */}
      <div className="px-4 py-6">
        {activeGateways.length === 0 && (
          <Alert className="mb-6 bg-amber-50 border-amber-200">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800">
              Payment gateways are currently being configured by the administrator. Some payment methods may be unavailable.
            </AlertDescription>
          </Alert>
        )}

        <Card className="mb-6">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>Order Summary</CardTitle>
                <CardDescription>Order #{orderDetails.id}</CardDescription>
              </div>
              <div className="text-xs text-gray-500">
                Last updated: {lastUpdated.toLocaleTimeString()}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-1 mb-4">
              <div className="text-sm text-gray-500">From</div>
              <div className="font-medium">{orderDetails.pickupLocation}</div>
            </div>
            <div className="space-y-1 mb-4">
              <div className="text-sm text-gray-500">To</div>
              <div className="font-medium">{orderDetails.deliveryLocation}</div>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-500">Distance</span>
              <span className="font-medium">{orderDetails.distance.toFixed(2)} km</span>
            </div>
          </CardContent>
          <CardFooter className="bg-gray-50 rounded-b-lg border-t">
            <div className="flex justify-between items-center w-full">
              <span className="font-medium">Total Amount</span>
              <span className="text-xl font-bold text-primary">{formatCurrency(orderDetails.totalFare)}</span>
            </div>
          </CardFooter>
        </Card>

        {/* Payment methods */}
        <h2 className="font-bold text-lg mb-3">Payment Method</h2>
        <Tabs 
          defaultValue="card" 
          value={paymentMethod} 
          onValueChange={(value) => setPaymentMethod(value as PaymentMethod)}
          className="mb-6"
        >
          <TabsList className="grid grid-cols-3 w-full mb-4">
            <TabsTrigger value="card" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" /> Card
            </TabsTrigger>
            <TabsTrigger value="mobile_money" className="flex items-center gap-2">
              <SiAirbnb className="h-4 w-4" /> Mobile Money
            </TabsTrigger>
            <TabsTrigger value="google_pay" className="flex items-center gap-2">
              <SiGooglepay className="h-4 w-4" /> Google Pay
            </TabsTrigger>
          </TabsList>
          
          {/* Credit/Debit Card */}
          <TabsContent value="card">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Card Details</CardTitle>
                <CardDescription>Pay securely with your credit or debit card</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <RadioGroup 
                    value={cardType} 
                    onValueChange={(value) => setCardType(value as CardType)}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="visa" id="visa" />
                      <Label htmlFor="visa" className="flex items-center gap-2">
                        <SiVisa className="h-8 w-8 text-blue-700" /> Visa
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="mastercard" id="mastercard" />
                      <Label htmlFor="mastercard" className="flex items-center gap-2">
                        <SiMastercard className="h-8 w-8 text-orange-600" /> Mastercard
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input 
                      id="cardNumber" 
                      placeholder="1234 5678 9012 3456"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                      maxLength={19}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="cardholderName">Cardholder Name</Label>
                    <Input 
                      id="cardholderName" 
                      placeholder="John Doe"
                      value={cardholderName}
                      onChange={(e) => setCardholderName(e.target.value)}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expiryDate">Expiry Date</Label>
                      <Input 
                        id="expiryDate" 
                        placeholder="MM/YY"
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(formatExpiryDate(e.target.value))}
                        maxLength={5}
                      />
                    </div>
                    <div>
                      <Label htmlFor="cvv">CVV</Label>
                      <Input 
                        id="cvv" 
                        placeholder="123"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 3))}
                        maxLength={3}
                        type="password"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Mobile Money */}
          <TabsContent value="mobile_money">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Mobile Money</CardTitle>
                <CardDescription>Pay using your mobile money account</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <RadioGroup 
                    value={mobileProvider} 
                    onValueChange={(value) => setMobileProvider(value as MobileMoneyProvider)}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="airtel" id="airtel" />
                      <Label htmlFor="airtel" className="flex items-center gap-2">
                        <span className="w-8 h-8 flex items-center justify-center bg-red-600 text-white rounded-full text-xs font-bold">
                          Airtel
                        </span> 
                        Airtel Money
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="mpesa" id="mpesa" />
                      <Label htmlFor="mpesa" className="flex items-center gap-2">
                        <span className="w-8 h-8 flex items-center justify-center bg-green-600 text-white rounded-full text-xs font-bold">
                          M-P
                        </span> 
                        M-Pesa
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div>
                  <Label htmlFor="phoneNumber">Phone Number</Label>
                  <Input 
                    id="phoneNumber" 
                    placeholder="Enter your phone number"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    You will receive a prompt on your phone to authorize the payment.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Google Pay */}
          <TabsContent value="google_pay">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Google Pay</CardTitle>
                <CardDescription>Fast, simple and secure payment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-center p-6">
                  <div className="bg-black text-white px-6 py-3 rounded-lg flex items-center gap-2 font-medium">
                    <SiGooglepay className="h-6 w-6" />
                    <span>Pay</span>
                  </div>
                </div>
                <p className="text-center text-sm text-gray-500">
                  Click the Google Pay button to complete your payment
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <Button 
          className="w-full py-6"
          onClick={handleSubmitPayment}
          disabled={isProcessing}
        >
          {isProcessing ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Pay {formatCurrency(orderDetails.totalFare)}
            </>
          )}
        </Button>
        
        <div className="mt-4 text-center text-xs text-gray-500">
          <p>Your payment information is secure and encrypted</p>
        </div>
      </div>
    </div>
  );
}