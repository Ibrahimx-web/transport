import { Link, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { LocationSearch } from '@/components/home/LocationSearch';
import { RecentOrders } from '@/components/home/RecentOrders';
import { BottomNavigation } from '@/components/layout/BottomNavigation';
import { User, Truck, LogIn, UserPlus, Package, ShieldAlert, Sparkles, ArrowRight } from 'lucide-react';
import { User as UserType } from '@/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";

export default function Home() {
  const { data: user } = useQuery<UserType>({
    queryKey: ['/api/users/current'],
  });
  
  const [_, navigate] = useLocation();
  
  const handleRequestTransport = () => {
    // Redirect to login if user is not authenticated
    if (!user) {
      navigate('/login');
      return;
    }
    navigate('/book');
  };
  
  return (
    <div className="app-container">
      {/* Header */}
      <header className="page-header">
        <div className="flex items-center">
          <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/70 text-transparent bg-clip-text">Ask for Transport</span>
        </div>
        {user ? (
          <Link href="/profile">
            <Button variant="ghost" size="icon" className="rounded-full">
              <User className="h-5 w-5" />
            </Button>
          </Link>
        ) : (
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" onClick={() => navigate('/login')}>
              <LogIn className="h-4 w-4 mr-1" />
              Login
            </Button>
            <Button size="sm" onClick={() => navigate('/register')}>
              <UserPlus className="h-4 w-4 mr-1" />
              Register
            </Button>
          </div>
        )}
      </header>
      
      {/* Hero Section */}
      {!user && (
        <div className="px-4 py-6">
          <Card className="overflow-hidden border-none shadow-lg">
            <div className="card-gradient text-white p-6">
              <h1 className="text-2xl font-bold mb-2">Welcome to Ask for Transport</h1>
              <p className="text-white/90">
                The fastest way to transport your goods from A to B
              </p>
            </div>
            <CardContent className="p-6">
              <div className="flex flex-col gap-4">
                <p className="text-sm text-muted-foreground">
                  Create an account or sign in to start using our service!
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <Button className="w-full" onClick={() => navigate('/register')}>
                    Create Account
                  </Button>
                  <Button variant="outline" className="w-full" onClick={() => navigate('/login')}>
                    Sign In
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="mt-8 px-2">
            <h2 className="text-xl font-semibold mb-4">Why choose Ask for Transport?</h2>
            <div className="grid grid-cols-2 gap-4">
              <Card className="border border-muted">
                <CardContent className="p-4 pt-6 text-center">
                  <Truck className="h-8 w-8 mx-auto text-primary mb-2" />
                  <h3 className="font-medium">Multiple Vehicles</h3>
                  <p className="text-xs text-muted-foreground mt-1">From bikes to trucks</p>
                </CardContent>
              </Card>
              <Card className="border border-muted">
                <CardContent className="p-4 pt-6 text-center">
                  <Package className="h-8 w-8 mx-auto text-primary mb-2" />
                  <h3 className="font-medium">Fast Delivery</h3>
                  <p className="text-xs text-muted-foreground mt-1">Get items delivered quickly</p>
                </CardContent>
              </Card>
            </div>
          </div>
          
          {/* Admin Access Link */}
          <div className="mt-8 flex justify-center">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate('/admin/login')}
              className="text-xs text-slate-500 border-slate-300 hover:bg-slate-100"
            >
              <ShieldAlert className="h-3.5 w-3.5 mr-1.5" />
              Administrator Access
            </Button>
          </div>
        </div>
      )}
      
      {/* Location Search - Only visible if user is logged in */}
      {user && <LocationSearch />}
      
      {/* Smart Package Recommendation Promotion - Only for logged in users */}
      {user && user.userType === 'customer' && (
        <div className="px-4 mt-4">
          <Card className="border border-primary/20 bg-gradient-to-r from-primary/5 to-primary/10 overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-start">
                <div className="mr-4 flex-shrink-0 bg-primary/10 p-3 rounded-full">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium text-lg mb-1">Smart Package Recommendations</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Our AI can now recommend the perfect vehicle for your package based on weight, dimensions, and delivery urgency.
                  </p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="group"
                    onClick={() => navigate('/book')}
                  >
                    Try it now 
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      {/* Recent Orders - Only visible if user is logged in */}
      {user && <RecentOrders userId={user.id} />}
      
      {/* Request Transport Button - Only for Customers */}
      {user && user.userType === 'customer' && (
        <div className="px-4 pb-4 mt-4">
          <Button 
            onClick={handleRequestTransport}
            className="w-full py-6 shadow-md bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary"
          >
            <Truck className="mr-2 h-5 w-5" />
            Request Transport
          </Button>
        </div>
      )}
      
      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}
