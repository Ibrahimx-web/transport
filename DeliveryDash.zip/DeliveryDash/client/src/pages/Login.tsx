import { useLocation } from "wouter";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Lock, UserIcon, KeyIcon, LogIn, ShieldAlert } from "lucide-react";
import { UserCredentials } from "@/types";


// Form validation schema
const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Login form
  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (data: UserCredentials) => {
      const response = await apiRequest("POST", "/api/users/login", data);
      const responseData = await response.json();
      console.log("Login response:", responseData);
      return responseData;
    },
    onSuccess: (data) => {
      toast({
        title: "Login successful",
        description: `Welcome back, ${data.fullName || data.username}!`,
      });
      
      console.log("Login success, user type:", data.userType);
      
      // Invalidate the current user query to ensure fresh data
      queryClient.invalidateQueries({ queryKey: ['/api/users/current'] });
      
      // Redirect user based on user type immediately
      if (data.userType === 'delivery') {
        console.log("Redirecting delivery partner to dashboard");
        // Force a hard navigation to ensure proper page reload with authenticated session
        window.location.href = "/delivery/dashboard";
      } else if (data.userType === 'admin') {
        console.log("Redirecting admin to dashboard");
        window.location.href = "/admin/dashboard";
      } else {
        console.log("Redirecting customer to home");
        setLocation("/");
      }
    },
    onError: (error: any) => {
      console.error("Login error:", error);
      toast({
        variant: "destructive",
        title: "Login failed",
        description: error.message || "Invalid username or password",
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: z.infer<typeof loginSchema>) => {
    loginMutation.mutate(data);
  };

  return (
    <div className="app-container">
      {/* Header */}
      <header className="page-header">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setLocation("/")}
            className="mr-2"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="font-semibold">Sign In</h1>
        </div>
      </header>

      <div className="px-4 pt-8 pb-4 flex flex-col items-center">
        <div className="w-20 h-20 rounded-full card-gradient flex items-center justify-center mb-6 shadow-lg">
          <Lock className="h-10 w-10 text-white" />
        </div>
        
        <h1 className="text-2xl font-bold mb-2 text-center">Welcome Back</h1>
        <p className="text-center text-muted-foreground mb-8">
          Sign in to continue to Ask for Transport
        </p>
        
        <Card className="w-full border-none shadow-md">
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-muted-foreground">Username</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <UserIcon className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input 
                            placeholder="Enter your username" 
                            className="pl-10" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-muted-foreground">Password</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <KeyIcon className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input 
                            type="password" 
                            placeholder="Enter your password"
                            className="pl-10"
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full py-6 mt-4" 
                  disabled={loginMutation.isPending}
                >
                  <LogIn className="mr-2 h-5 w-5" />
                  {loginMutation.isPending ? "Signing In..." : "Sign In"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
        
        <div className="mt-8 text-center">
          <p className="text-muted-foreground mb-3">Don't have an account?</p>
          <Button 
            variant="outline" 
            onClick={() => setLocation("/register")}
            className="font-medium mb-4"
          >
            Create Account
          </Button>
          
          <div className="flex justify-center items-center gap-2 mt-2">
            <Button 
              variant="link" 
              onClick={() => setLocation("/admin/login")}
              className="text-sm text-muted-foreground hover:text-primary p-0 h-auto flex items-center gap-1"
            >
              <ShieldAlert className="h-3 w-3" />
              Admin Login
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}