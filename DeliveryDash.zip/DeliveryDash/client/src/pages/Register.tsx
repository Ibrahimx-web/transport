import * as React from "react";
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { UserRegistration, UserType, VehicleType } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Truck, User, ShieldAlert } from "lucide-react";

// Form validation schema
const registrationSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters").max(50),
  password: z.string().min(6, "Password must be at least 6 characters"),
  fullName: z.string().min(3, "Full name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Phone number is required"),
  userType: z.enum(["customer", "delivery", "admin"] as const),
  vehicleTypeId: z.number().optional(),
  licensePlateNumber: z.string().min(3, "License plate number is required").optional(),
  vehicleRegistrationNumber: z.string().min(3, "Vehicle registration number is required").optional(),
  profilePicture: z.instanceof(File).optional(),
  driversLicense: z.instanceof(File).optional(),
  adminCode: z.string().optional(),
});

export default function Register() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [userType, setUserType] = useState<UserType>("customer");
  const [showAdminTab, setShowAdminTab] = useState<boolean>(false);
  const [adminCodeTries, setAdminCodeTries] = useState<number>(0);
  
  // Registration form
  const form = useForm<z.infer<typeof registrationSchema>>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      username: "",
      password: "",
      fullName: "",
      email: "",
      phone: "",
      userType: "customer",
      licensePlateNumber: "",
      vehicleRegistrationNumber: "",
    },
  });
  
  // URL parameter check for admin registration
  useEffect(() => {
    // Check for admin parameter in URL
    const searchParams = new URLSearchParams(window.location.search);
    if (searchParams.get('admin') === 'true') {
      setShowAdminTab(true);
      setUserType('admin');
      form.setValue('userType', 'admin');
    }
  }, [form]);
  
  // Triple click header detection to reveal admin tab
  useEffect(() => {
    const header = document.querySelector("header h1");
    if (header) {
      let clickCount = 0;
      let clickTimer: NodeJS.Timeout;
      
      const handleClick = () => {
        clickCount++;
        clearTimeout(clickTimer);
        
        if (clickCount === 3) {
          // Triple click detected
          setShowAdminTab(true);
          clickCount = 0;
        } else {
          // Reset click count after 500ms
          clickTimer = setTimeout(() => {
            clickCount = 0;
          }, 500);
        }
      };
      
      header.addEventListener("click", handleClick);
      return () => {
        header.removeEventListener("click", handleClick);
        clearTimeout(clickTimer);
      };
    }
  }, []);

  // Fetch vehicle types
  const { data: vehicleTypes = [] } = useQuery<VehicleType[]>({
    queryKey: ["/api/vehicle-types"],
  });

  // Register user mutation
  const registerMutation = useMutation({
    mutationFn: async (data: UserRegistration) => {
      const response = await apiRequest("POST", "/api/users/register", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Registration successful",
        description: "You have been registered. Please login.",
      });
      setLocation("/");
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error.message || "Please try again later",
      });
    },
  });

  // Handle file input
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, fieldName: 'profilePicture' | 'driversLicense') => {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue(fieldName, file);
    }
  };

  // Convert file to base64 string with compression
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      // Create a new image for compression
      const img = new Image();
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (!event.target?.result) {
          reject(new Error('Failed to read file'));
          return;
        }
        
        img.onload = () => {
          // Create a canvas to resize the image
          const canvas = document.createElement('canvas');
          
          // Calculate new dimensions (max 800px wide or tall)
          let width = img.width;
          let height = img.height;
          const maxDimension = 800;
          
          if (width > height && width > maxDimension) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else if (height > maxDimension) {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          // Draw the resized image
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('Could not get canvas context'));
            return;
          }
          
          ctx.drawImage(img, 0, 0, width, height);
          
          // Convert to base64 with reduced quality (0.7 is 70% quality)
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7);
          resolve(compressedBase64);
        };
        
        img.onerror = () => {
          // Fallback to original method if image compression fails
          if (reader.result && typeof reader.result === 'string') {
            resolve(reader.result);
          } else {
            reject(new Error('Failed to load image for compression'));
          }
        };
        
        // Set the image source to the file data
        if (event.target && event.target.result) {
          img.src = event.target.result.toString();
        } else {
          reject(new Error('No file data available'));
        }
      };
      
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Validate admin registration code
  const validateAdminCode = (code: string | undefined): boolean => {
    // Simple admin code validation - in a real app, this would be more secure
    const validCode = "ADMIN1234";
    return code === validCode;
  };

  // Handle form submission
  const onSubmit = async (data: z.infer<typeof registrationSchema>) => {
    // If delivery user selected but no vehicle type, license plate, or vehicle registration, show error
    if (data.userType === "delivery") {
      if (!data.vehicleTypeId) {
        form.setError("vehicleTypeId", {
          type: "manual",
          message: "Please select your vehicle type",
        });
        return;
      }
      
      if (!data.licensePlateNumber) {
        form.setError("licensePlateNumber", {
          type: "manual",
          message: "License plate number is required",
        });
        return;
      }
      
      if (!data.vehicleRegistrationNumber) {
        form.setError("vehicleRegistrationNumber", {
          type: "manual",
          message: "Vehicle registration number is required",
        });
        return;
      }
    }
    
    // For admin registration, validate the admin code
    if (data.userType === "admin") {
      if (!validateAdminCode(data.adminCode)) {
        // Track failed attempts
        setAdminCodeTries(prev => prev + 1);
        
        // Show different messages based on number of attempts
        if (adminCodeTries >= 3) {
          toast({
            variant: "destructive",
            title: "Registration denied",
            description: "Too many incorrect attempts. Please contact system administrator.",
          });
          
          // Redirect away after too many failed attempts
          setTimeout(() => setLocation("/"), 2000);
          return;
        }
        
        form.setError("adminCode", {
          type: "manual",
          message: "Invalid administrator code",
        });
        return;
      }
    }

    try {
      // Convert files to base64 if they exist
      const formData: any = { ...data };
      
      if (data.profilePicture instanceof File) {
        formData.profilePicture = await fileToBase64(data.profilePicture);
      }
      
      if (data.driversLicense instanceof File) {
        formData.driversLicense = await fileToBase64(data.driversLicense);
      }

      // Submit the data with base64 encoded files
      registerMutation.mutate(formData as UserRegistration);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error processing files",
        description: "There was a problem with your uploaded files. Please try again.",
      });
    }
  };

  // Handle user type change
  const handleUserTypeChange = (value: string) => {
    setUserType(value as UserType);
    form.setValue("userType", value as UserType);
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white pb-16">
      {/* Header */}
      <header className="bg-white p-4 flex items-center border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setLocation("/")}
          className="mr-2"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold">Create Account</h1>
      </header>

      <div className="p-4">
        <Tabs defaultValue="customer" onValueChange={handleUserTypeChange}>
          <TabsList className={`grid w-full ${showAdminTab ? 'grid-cols-3' : 'grid-cols-2'} mb-6`}>
            <TabsTrigger value="customer" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Customer
            </TabsTrigger>
            <TabsTrigger value="delivery" className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              Delivery Partner
            </TabsTrigger>
            {showAdminTab && (
              <TabsTrigger value="admin" className="flex items-center gap-2 bg-slate-900 text-white">
                <ShieldAlert className="h-4 w-4" />
                Administrator
              </TabsTrigger>
            )}
          </TabsList>

          <Card>
            <CardHeader>
              <CardTitle>Sign Up</CardTitle>
              <CardDescription>
                {userType === "customer" 
                  ? "Register as a customer to book deliveries" 
                  : userType === "delivery"
                  ? "Sign up as a delivery partner to deliver packages"
                  : "Create a system administrator account"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="fullName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your full name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="your@email.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone</FormLabel>
                          <FormControl>
                            <Input placeholder="Phone number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Choose a username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder="Create a strong password"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="userType"
                    render={({ field }) => (
                      <FormItem className="hidden">
                        <FormControl>
                          <Input type="hidden" {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {/* Admin code field */}
                  {userType === "admin" && (
                    <FormField
                      control={form.control}
                      name="adminCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Administrator Code</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder="Enter administrator authorization code"
                              {...field} 
                              className="bg-slate-50 border-slate-300"
                            />
                          </FormControl>
                          <FormDescription>
                            Enter the secure code provided by system administrator
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  {/* Vehicle type selector for delivery partners */}
                  {userType === "delivery" && (
                    <>
                      <FormField
                        control={form.control}
                        name="vehicleTypeId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Vehicle Type</FormLabel>
                            <Select
                              onValueChange={(value) => field.onChange(parseInt(value))}
                              value={field.value?.toString()}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select your vehicle type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {vehicleTypes.map((vehicle) => (
                                  <SelectItem 
                                    key={vehicle.id} 
                                    value={vehicle.id.toString()}
                                  >
                                    {vehicle.name} (max {vehicle.maxWeight}kg)
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Select the vehicle you will use for deliveries
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="licensePlateNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>License Plate Number</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter vehicle license plate" {...field} />
                            </FormControl>
                            <FormDescription>
                              Enter the license plate number of your delivery vehicle
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="vehicleRegistrationNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Vehicle Registration Number</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter vehicle registration number" {...field} />
                            </FormControl>
                            <FormDescription>
                              Enter the registration/identification number of your vehicle
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Profile Picture Upload */}
                      <FormField
                        control={form.control}
                        name="profilePicture"
                        render={() => (
                          <FormItem>
                            <FormLabel>Profile Picture</FormLabel>
                            <FormControl>
                              <Input 
                                type="file" 
                                accept="image/*"
                                onChange={(e) => handleFileChange(e, 'profilePicture')}
                              />
                            </FormControl>
                            <FormDescription>
                              Upload a clear photo of yourself
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Driver's License Upload */}
                      <FormField
                        control={form.control}
                        name="driversLicense"
                        render={() => (
                          <FormItem>
                            <FormLabel>Driver's License</FormLabel>
                            <FormControl>
                              <Input 
                                type="file" 
                                accept="image/*"
                                onChange={(e) => handleFileChange(e, 'driversLicense')}
                              />
                            </FormControl>
                            <FormDescription>
                              Upload a photo of your valid driver's license
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </>
                  )}

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                  </Button>
                </form>
              </Form>
            </CardContent>
            <CardFooter className="flex justify-center border-t pt-4">
              <Button variant="link" onClick={() => setLocation("/")}>
                Already have an account? Sign In
              </Button>
            </CardFooter>
          </Card>
        </Tabs>
      </div>
    </div>
  );
}