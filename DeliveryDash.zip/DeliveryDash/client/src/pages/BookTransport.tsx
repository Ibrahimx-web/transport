import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, Sparkles, List, MapPin, LocateFixed } from 'lucide-react';
import { MapView } from '@/components/booking/MapView';
import { RouteInfo } from '@/components/booking/RouteInfo';
import { TransportOptions } from '@/components/booking/TransportOptions';
import { PackageDetailsForm } from '@/components/booking/PackageDetails';
import { PackageRecommendation } from '@/components/booking/PackageRecommendation';
import { useDelivery } from '@/hooks/use-delivery';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Toast } from '@/components/ui/toast';
import { useToast } from '@/hooks/use-toast';
import { useCurrency, formatCurrency } from '@/lib/currency';
import { useQuery } from '@tanstack/react-query';

export default function BookTransport() {
  const { 
    pickup, 
    delivery, 
    vehicleTypeId, 
    setVehicleTypeId, 
    priceEstimation, 
    detectCurrentLocation,
    isDetectingLocation
  } = useDelivery();
  const [_, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<string>("manual"); // Default to manual selection tab
  const { toast } = useToast();
  
  // Get the current user data to use their ID
  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ['/api/users/current'],
    retry: false
  });
  
  // Use the authenticated user ID from the current session
  const userId = userData?.id;
  
  // Automatically detect current location when the page loads
  useEffect(() => {
    // Only run if the pickup location is not already set
    if (pickup.lat === 0 && pickup.lng === 0) {
      detectCurrentLocation()
        .catch(error => {
          // Show error toast if location detection fails
          toast({
            title: "Location detection failed",
            description: "Please enable location access or enter your pickup location manually.",
            variant: "destructive"
          });
          console.error("Failed to automatically detect location:", error);
        });
    }
  }, []);
  
  // Show price and distance information when available
  useEffect(() => {
    if (priceEstimation && priceEstimation.distance > 0) {
      toast({
        title: "Route calculated",
        description: `Distance: ${priceEstimation.distance.toFixed(2)} km | Estimated price: ${formatCurrency(priceEstimation.totalFare)}`,
      });
    }
  }, [priceEstimation?.distance]);
  
  const handleBack = () => {
    navigate('/');
  };
  
  const handleVehicleSelect = (vehicleId: number) => {
    setVehicleTypeId(vehicleId);
  };
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white relative">
      {/* Header */}
      <header className="bg-white p-4 shadow-sm flex items-center">
        <button onClick={handleBack} className="mr-3">
          <ArrowLeft className="text-gray-600" />
        </button>
        <span className="font-bold">Book Transport</span>
        
        {/* Current location button in header for quick access */}
        <Button 
          variant="outline" 
          size="sm" 
          className="ml-auto flex items-center gap-1"
          onClick={() => detectCurrentLocation()}
          disabled={isDetectingLocation}
        >
          <LocateFixed className="h-4 w-4" />
          {isDetectingLocation ? 'Detecting...' : 'Current Location'}
        </Button>
      </header>
      
      {/* Map View */}
      <MapView 
        pickupLocation={pickup.address ? pickup : undefined}
        deliveryLocation={delivery.address ? delivery : undefined}
      />
      
      {/* Route Info with location detection */}
      <RouteInfo 
        pickup={pickup.address ? pickup : undefined}
        delivery={delivery.address ? delivery : undefined}
      />
      
      {/* Price Summary (when available) */}
      {priceEstimation && pickup.lat !== 0 && delivery.lat !== 0 && (
        <div className="bg-primary-50 p-4 border-t border-b border-primary-100">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-primary-700">Distance</p>
              <p className="text-lg font-bold text-primary-900">{priceEstimation.distance.toFixed(2)} km</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-primary-700">Estimated Price</p>
              <p className="text-lg font-bold text-primary-900">{formatCurrency(priceEstimation.totalFare)}</p>
            </div>
          </div>
          {/* Price breakdown */}
          <div className="mt-2 pt-2 border-t border-primary-100 grid grid-cols-3 gap-2 text-xs text-primary-700">
            <div>
              <p>Base fare</p>
              <p className="font-medium">{formatCurrency(priceEstimation.baseFare)}</p>
            </div>
            <div>
              <p>Distance fare</p>
              <p className="font-medium">{formatCurrency(priceEstimation.distanceFare)}</p>
            </div>
            <div>
              <p>Service fee</p>
              <p className="font-medium">{formatCurrency(priceEstimation.serviceFee)}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Selection Mode Tabs */}
      {pickup.address && delivery.address && priceEstimation && (
        <div className="px-4 mt-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 w-full">
              <TabsTrigger value="manual" className="flex items-center gap-2">
                <List className="h-4 w-4" /> Manual Selection
              </TabsTrigger>
              <TabsTrigger value="ai" className="flex items-center gap-2">
                <Sparkles className="h-4 w-4" /> AI Recommendation
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="manual">
              {/* Transport Options */}
              <TransportOptions />
            </TabsContent>
            
            <TabsContent value="ai">
              {/* AI Package Recommendation */}
              <PackageRecommendation 
                packageDetails={{
                  weight: 15, // Default weight if not specified
                  fragile: false, // Default not fragile
                  distance: priceEstimation.distance,
                  description: "Package from location to destination",
                  // Adding dimensions to fix the AI recommendation error
                  width: 30,
                  height: 30,
                  length: 30,
                  // Also include dimensions object for backward compatibility
                  dimensions: {
                    width: 30,
                    height: 30,
                    length: 30
                  }
                }}
                onRecommendationReceived={(recommendation) => {
                  // Find matching vehicle type by name and select it
                  if (recommendation.recommendedVehicleId) {
                    handleVehicleSelect(recommendation.recommendedVehicleId);
                  }
                }}
              />
            </TabsContent>
          </Tabs>
        </div>
      )}
      
      {(!pickup.address || !delivery.address || !priceEstimation) && (
        <TransportOptions />
      )}
      
      {/* Package Details Form */}
      <PackageDetailsForm userId={userId} />
    </div>
  );
}
