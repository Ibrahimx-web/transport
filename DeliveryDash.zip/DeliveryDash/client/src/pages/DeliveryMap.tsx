import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { User, Order } from '@/types';
// Components
import { SafeRouteVisualizationDemo } from '@/components/test/SafeRouteVisualizationDemo';
import { DeliveryPartnerMap } from '@/components/delivery/DeliveryPartnerMap';
import { Button } from '@/components/ui/button';
import { MapPin, User as UserIcon, Loader2, AlertCircle, Map, ArrowLeft } from 'lucide-react';
import { BottomNavigation } from '@/components/layout/BottomNavigation';
import ErrorBoundary from '@/components/error-boundary';
// Hooks and utilities
import { useCurrentLocation } from '@/lib/map';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { DEFAULT_COORDINATES } from '@/lib/constants';
import { useLocationWebSocket } from '@/hooks/use-location-websocket';
import { useLocation } from 'wouter';
import { PageTransition } from '@/components/ui/page-transition';

export default function DeliveryMap() {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  // Get current user data
  const { data: user } = useQuery<User>({
    queryKey: ['/api/users/current'],
  });
  
  // Fetch pending orders
  const { data: pendingOrders = [], isLoading: isLoadingOrders } = useQuery<Order[]>({
    queryKey: ['/api/orders/pending'],
  });
  
  // Real geolocation using browser's API
  const { location, error: locationError, isLoading: isLoadingLocation, refreshLocation } = useCurrentLocation();
  
  // Current location state
  const [currentLocation, setCurrentLocation] = useState({
    lat: DEFAULT_COORDINATES.lat,
    lng: DEFAULT_COORDINATES.lng
  });
  
  // WebSocket connection for real-time location updates
  const { 
    isConnected, 
    connectionError, 
    circuitBreakerStatus,
    sendLocationUpdate, 
    reconnect 
  } = useLocationWebSocket({
    userId: user?.id,
    userType: 'delivery',
    onConnect: () => {
      console.log('WebSocket connected for driver location updates');
      toast({
        title: 'Connected to real-time system',
        description: 'Live tracking enabled',
        duration: 3000,
      });
    },
    onDisconnect: () => {
      console.log('WebSocket disconnected');
    },
    onMessage: (data) => {
      console.log('WebSocket message received:', data);
    }
  });
  
  // Update current location when geolocation is available
  useEffect(() => {
    if (location) {
      setCurrentLocation({
        lat: location.lat,
        lng: location.lng
      });
      
      // Send location update via WebSocket if available
      if (isConnected && user?.id) {
        sendLocationUpdate(location.lat, location.lng);
      }
    }
  }, [location, isConnected, user?.id, sendLocationUpdate]);
  
  // Refresh location periodically
  useEffect(() => {
    if (!locationError) {
      const intervalId = setInterval(() => {
        refreshLocation();
      }, 30000); // every 30 seconds
      
      return () => clearInterval(intervalId);
    }
  }, [locationError, refreshLocation]);
  
  // Handle order selection from map
  const handleOrderSelect = (order: Order) => {
    setSelectedOrder(order);
    // You could navigate to order details or show a modal here
    toast({
      title: `Order #${order.id} selected`,
      description: `From ${order.pickupLocation} to ${order.deliveryLocation}`,
    });
  };

  return (
    <PageTransition>
      <div className="min-h-screen max-w-md mx-auto bg-white pb-16">
        {/* Header */}
        <header className="bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setLocation('/delivery/dashboard')}
                className="h-9 w-9"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h1 className="font-bold text-lg">Live Map</h1>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
                {user?.profilePicture ? (
                  <img src={user.profilePicture} alt="" className="w-full h-full rounded-full object-cover" />
                ) : (
                  <UserIcon className="h-5 w-5 text-primary" />
                )}
              </div>
              <div className="flex items-center gap-1 text-sm text-gray-500">
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                <span>{isConnected ? 'Online' : 'Connecting...'}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <MapPin className="h-4 w-4" />
            {isLoadingLocation ? (
              <div className="flex items-center gap-1">
                <Loader2 className="h-3 w-3 animate-spin" />
                <span>Detecting location...</span>
              </div>
            ) : locationError ? (
              <span>Unable to get location</span>
            ) : (
              <span>Current Location Detected</span>
            )}
          </div>
        </header>

        {locationError && (
          <div className="px-4 pt-2">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Location Error</AlertTitle>
              <AlertDescription>
                Please enable location services to use the map.
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-2 w-full"
                  onClick={() => refreshLocation()}
                >
                  Try Again
                </Button>
              </AlertDescription>
            </Alert>
          </div>
        )}
        
        {connectionError && (
          <div className="px-4 pt-2">
            <Alert className="bg-amber-50 border-amber-200">
              <AlertCircle className="h-4 w-4 text-amber-500" />
              <AlertTitle className="text-amber-700">Connection Issue</AlertTitle>
              <AlertDescription className="text-amber-700">
                Having trouble connecting to the live tracking system.
                
                {circuitBreakerStatus.active ? (
                  <div className="mt-2">
                    <div className="text-sm mb-1">
                      Connection attempts paused due to repeated failures.
                    </div>
                    <div className="w-full bg-amber-200 rounded-full h-2 mb-2">
                      <div 
                        className="bg-amber-500 h-2 rounded-full transition-all duration-500 ease-in-out" 
                        style={{ 
                          width: `${100 - (circuitBreakerStatus.remainingTime / 60000 * 100)}%` 
                        }}
                      />
                    </div>
                    <div className="text-xs text-right">
                      Auto-reconnect in {Math.ceil(circuitBreakerStatus.remainingTime / 1000)}s
                    </div>
                  </div>
                ) : (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-2 w-full border-amber-300 hover:bg-amber-100"
                    onClick={() => reconnect()}
                  >
                    Reconnect
                  </Button>
                )}
              </AlertDescription>
            </Alert>
          </div>
        )}

        <div className="px-4 py-4">
          <div className="mb-4">
            <h2 className="font-semibold">Nearby Delivery Requests</h2>
            <p className="text-sm text-gray-500">
              {isLoadingOrders ? (
                <span className="flex items-center gap-1">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  Loading available orders...
                </span>
              ) : pendingOrders.length > 0 ? (
                `${pendingOrders.length} orders available in your area`
              ) : (
                'No pending orders in your area'
              )}
            </p>
          </div>
          
          {/* Live map with error handling for the delivery partner */}
          <ErrorBoundary 
            fallback={
              <div className="h-auto">
                <SafeRouteVisualizationDemo />
              </div>
            }
          >
            {isLoadingOrders ? (
              <div className="h-[500px] flex items-center justify-center border rounded-lg">
                <div className="flex flex-col items-center">
                  <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
                  <p className="text-gray-500">Loading map data...</p>
                </div>
              </div>
            ) : pendingOrders && pendingOrders.length > 0 ? (
              <div className="h-[500px]">
                <DeliveryPartnerMap
                  orders={pendingOrders}
                  currentLat={currentLocation.lat}
                  currentLng={currentLocation.lng}
                  userId={user?.id}
                  onOrderSelect={handleOrderSelect}
                />
              </div>
            ) : (
              <div className="p-6 border rounded-lg bg-white text-center h-[400px] flex flex-col items-center justify-center">
                <div className="mb-4 bg-gray-100 p-6 rounded-full inline-flex">
                  <Map className="h-10 w-10 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium mb-2">No pending orders</h3>
                <p className="text-gray-500 text-sm mb-4">
                  There are currently no delivery requests in your area. New requests will appear here when available.
                </p>
                <Button 
                  variant="outline" 
                  onClick={() => setLocation('/delivery/dashboard')}
                  className="mt-2"
                >
                  Return to Dashboard
                </Button>
              </div>
            )}
          </ErrorBoundary>
          
          {selectedOrder && (
            <div className="mt-4 p-4 border rounded-lg shadow-sm bg-white">
              <h3 className="font-medium">Selected Order #{selectedOrder.id}</h3>
              <div className="mt-2 text-sm space-y-1">
                <p>
                  <span className="text-gray-500">Pickup:</span> {selectedOrder.pickupLocation}
                </p>
                <p>
                  <span className="text-gray-500">Delivery:</span> {selectedOrder.deliveryLocation}
                </p>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={() => setSelectedOrder(null)}>Cancel</Button>
                <Button>Accept Request</Button>
              </div>
            </div>
          )}
        </div>

        <BottomNavigation />
      </div>
    </PageTransition>
  );
}