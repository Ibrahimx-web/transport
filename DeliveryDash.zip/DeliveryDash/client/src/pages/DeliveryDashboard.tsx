
import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { User, Order } from '@/types';
import { DeliveryRequests } from '@/components/delivery/DeliveryRequests';
import { DeliveryPartnerMap } from '@/components/delivery/DeliveryPartnerMap';
import { PartnerEarnings } from '@/components/delivery/PartnerEarnings';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { MapPin, User as UserIcon, Loader2, AlertCircle, Map, Wallet } from 'lucide-react';
import { BottomNavigation } from '@/components/layout/BottomNavigation';
import { useCurrentLocation } from '@/lib/map';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { DEFAULT_COORDINATES } from '@/lib/constants';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLocationWebSocket } from '@/hooks/use-location-websocket';

export default function DeliveryDashboard() {
  const [isAvailable, setIsAvailable] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const { toast } = useToast();
  
  // Get current user data
  const { data: user } = useQuery<User>({
    queryKey: ['/api/users/current'],
  });
  
  // Fetch pending orders
  const { data: pendingOrders = [] } = useQuery<Order[]>({
    queryKey: ['/api/orders/pending'],
    enabled: isAvailable
  });
  
  // Real geolocation using browser's API
  const { location, error: locationError, isLoading: isLoadingLocation, refreshLocation } = useCurrentLocation();
  
  // Current location state
  const [currentLocation, setCurrentLocation] = useState({
    lat: DEFAULT_COORDINATES.lat,
    lng: DEFAULT_COORDINATES.lng
  });
  
  // WebSocket connection for real-time location updates
  const { 
    isConnected, 
    connectionError, 
    circuitBreakerStatus,
    sendLocationUpdate, 
    reconnect 
  } = useLocationWebSocket({
    userId: user?.id,
    userType: 'delivery',
    onConnect: () => {
      console.log('WebSocket connected for driver location updates');
      toast({
        title: 'Connected to real-time system',
        description: 'You will receive live delivery requests',
        duration: 3000,
      });
    },
    onDisconnect: () => {
      console.log('WebSocket disconnected');
    },
    onMessage: (data) => {
      console.log('WebSocket message received:', data);
    }
  });
  
  // Update current location when geolocation is available
  useEffect(() => {
    if (location) {
      setCurrentLocation({
        lat: location.lat,
        lng: location.lng
      });
      
      // Send location update via WebSocket if available
      if (isConnected && user?.id && isAvailable) {
        sendLocationUpdate(location.lat, location.lng);
      }
    }
  }, [location, isConnected, user?.id, isAvailable, sendLocationUpdate]);
  
  // Refresh location periodically when available
  useEffect(() => {
    if (isAvailable && !locationError) {
      const intervalId = setInterval(() => {
        refreshLocation();
      }, 30000); // every 30 seconds
      
      return () => clearInterval(intervalId);
    }
  }, [isAvailable, locationError, refreshLocation]);
  
  // Update availability status mutation
  const updateAvailabilityMutation = useMutation({
    mutationFn: async (isAvailable: boolean) => {
      const response = await apiRequest('POST', '/api/users/availability', { 
        isAvailable,
        currentLat: currentLocation.lat,
        currentLng: currentLocation.lng
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/current'] });
      toast({
        title: isAvailable ? 'You are now available' : 'You are now offline',
        description: isAvailable 
          ? 'You will now receive delivery requests' 
          : 'You will not receive any new delivery requests',
      });
    },
    onError: (error: any) => {
      toast({
        variant: 'destructive',
        title: 'Failed to update availability',
        description: error.message || 'Please try again',
      });
      // Revert the switch if there was an error
      setIsAvailable(!isAvailable);
    }
  });
  
  // Handle availability toggle
  const handleAvailabilityChange = (checked: boolean) => {
    setIsAvailable(checked);
    // Skip update if location is not available
    if (!locationError) {
      updateAvailabilityMutation.mutate(checked);
    }
  };
  
  // Handle order selection from map
  const handleOrderSelect = (order: Order) => {
    setSelectedOrder(order);
    // You could navigate to order details or show a modal here
    toast({
      title: `Order #${order.id} selected`,
      description: `From ${order.pickupLocation} to ${order.deliveryLocation}`,
    });
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white pb-16">
      {/* Header */}
      <header className="bg-white p-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              {user?.profilePicture ? (
                <img src={user.profilePicture} alt="" className="w-full h-full rounded-full object-cover" />
              ) : (
                <UserIcon className="h-6 w-6 text-primary" />
              )}
            </div>
            <div>
              <h1 className="font-bold">{user?.fullName}</h1>
              <p className="text-sm text-gray-500">Delivery Partner</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm">{isAvailable ? 'Available' : 'Offline'}</span>
            <Switch 
              checked={isAvailable}
              onCheckedChange={handleAvailabilityChange}
              disabled={isLoadingLocation || locationError !== null || updateAvailabilityMutation.isPending}
            />
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <MapPin className="h-4 w-4" />
          {isLoadingLocation ? (
            <div className="flex items-center gap-1">
              <Loader2 className="h-3 w-3 animate-spin" />
              <span>Detecting location...</span>
            </div>
          ) : locationError ? (
            <span>Unable to get location</span>
          ) : (
            <span>Current Location</span>
          )}
        </div>
      </header>

      {locationError && (
        <div className="px-4 pt-2">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Location Error</AlertTitle>
            <AlertDescription>
              Please enable location services to receive nearby delivery requests.
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-2 w-full"
                onClick={() => refreshLocation()}
              >
                Try Again
              </Button>
            </AlertDescription>
          </Alert>
        </div>
      )}
      
      {connectionError && (
        <div className="px-4 pt-2">
          <Alert className="bg-amber-50 border-amber-200">
            <AlertCircle className="h-4 w-4 text-amber-500" />
            <AlertTitle className="text-amber-700">Connection Issue</AlertTitle>
            <AlertDescription className="text-amber-700">
              Having trouble connecting to the live tracking system. Your status is still available but real-time updates may be delayed.
              
              {circuitBreakerStatus.active ? (
                <div className="mt-2">
                  <div className="text-sm mb-1">
                    Connection attempts paused due to repeated failures.
                  </div>
                  <div className="w-full bg-amber-200 rounded-full h-2 mb-2">
                    <div 
                      className="bg-amber-500 h-2 rounded-full transition-all duration-500 ease-in-out" 
                      style={{ 
                        width: `${100 - (circuitBreakerStatus.remainingTime / 60000 * 100)}%` 
                      }}
                    />
                  </div>
                  <div className="text-xs text-right">
                    Auto-reconnect in {Math.ceil(circuitBreakerStatus.remainingTime / 1000)}s
                  </div>
                </div>
              ) : (
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-2 w-full border-amber-300 hover:bg-amber-100"
                  onClick={() => reconnect()}
                >
                  Reconnect
                </Button>
              )}
            </AlertDescription>
          </Alert>
        </div>
      )}

      {isAvailable ? (
        <Tabs defaultValue="map" className="w-full">
          <div className="px-4 py-2">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="map" className="flex items-center gap-1.5">
                <Map className="h-4 w-4" />
                <span>Map View</span>
              </TabsTrigger>
              <TabsTrigger value="list" className="flex items-center gap-1.5">
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                </svg>
                <span>List View</span>
              </TabsTrigger>
              <TabsTrigger value="earnings" className="flex items-center gap-1.5">
                <Wallet className="h-4 w-4" />
                <span>Earnings</span>
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="map" className="p-0 mt-0">
            <div className="px-4 pb-4">
              {pendingOrders && pendingOrders.length > 0 ? (
                <>
                  <DeliveryPartnerMap
                    orders={pendingOrders}
                    currentLat={currentLocation.lat}
                    currentLng={currentLocation.lng}
                    userId={user?.id}
                    onOrderSelect={handleOrderSelect}
                  />
                  <div className="mt-2 text-center">
                    <Button 
                      variant="outline" 
                      onClick={() => window.location.href = '/delivery/map'}
                      className="text-sm"
                    >
                      <Map className="h-4 w-4 mr-2" />
                      Open Full Map View
                    </Button>
                  </div>
                </>
              ) : (
                <div className="p-6 border rounded-lg bg-white text-center">
                  <div className="mb-4 bg-gray-100 p-6 rounded-full inline-flex">
                    <Map className="h-10 w-10 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No pending orders</h3>
                  <p className="text-gray-500 text-sm mb-4">
                    There are currently no delivery requests in your area. New requests will appear here when available.
                  </p>
                  <Button 
                    variant="outline" 
                    onClick={() => window.location.href = '/delivery/map'}
                    className="text-sm"
                  >
                    <Map className="h-4 w-4 mr-2" />
                    Open Map View
                  </Button>
                </div>
              )}
              
              {selectedOrder && (
                <div className="mt-4 p-4 border rounded-lg shadow-sm">
                  <h3 className="font-medium">Selected Order #{selectedOrder.id}</h3>
                  <div className="mt-2 text-sm space-y-1">
                    <p>
                      <span className="text-gray-500">Pickup:</span> {selectedOrder.pickupLocation}
                    </p>
                    <p>
                      <span className="text-gray-500">Delivery:</span> {selectedOrder.deliveryLocation}
                    </p>
                  </div>
                  <div className="mt-3">
                    <Button className="w-full">Accept Request</Button>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="list" className="mt-0">
            <div className="p-4">
              {pendingOrders && pendingOrders.length > 0 ? (
                <DeliveryRequests 
                  currentLat={currentLocation.lat}
                  currentLng={currentLocation.lng}
                />
              ) : (
                <div className="p-6 border rounded-lg bg-white text-center">
                  <div className="mb-4 bg-gray-100 p-6 rounded-full inline-flex">
                    <Map className="h-10 w-10 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No pending orders</h3>
                  <p className="text-gray-500 text-sm mb-4">
                    There are currently no delivery requests in your area. Check back soon for new delivery opportunities.
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="earnings" className="mt-0">
            <div className="p-4">
              <PartnerEarnings />
            </div>
          </TabsContent>
        </Tabs>
      ) : (
        <div className="text-center p-4 py-8 text-gray-500">
          <p>You're currently offline</p>
          <p className="text-sm">Switch to available to see delivery requests</p>
        </div>
      )}

      <BottomNavigation />
    </div>
  );
}
