import { useState, useEffect } from 'react';

// Interface for geocoding response
interface GeocodingResult {
  lat: number;
  lng: number;
  address: string;
  error?: string;
}

// Import the map configuration and provider utilities
import { useMapConfig, getFallbackApiKey, MapProvider } from './mapService';

// Geocoding function that adapts to the selected map provider
export async function geocodeAddress(address: string): Promise<GeocodingResult> {
  try {
    if (!address || address.trim() === '') {
      throw new Error('Address cannot be empty');
    }
    
    // Handle 'Current Location' as a special case
    if (address.toLowerCase() === 'current location') {
      // Try to get user's current location
      const position = await getCurrentPosition();
      return {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        address: 'Current Location'
      };
    }
    
    // Get the map configuration from local storage first for faster access
    // We'll use this before the async API call completes
    let configStr = localStorage.getItem('mapConfig');
    let activeProvider: MapProvider = 'google_maps'; // Default to Google Maps
    let apiKey: string | null = null;
    
    if (configStr) {
      try {
        const savedConfig = JSON.parse(configStr);
        if (savedConfig && savedConfig.provider) {
          activeProvider = savedConfig.provider as MapProvider;
          apiKey = savedConfig.apiKey;
        }
      } catch (e) {
        console.warn('Failed to parse saved map configuration, using defaults');
      }
    }
    
    // If no API key in local storage, try environment variables
    if (!apiKey) {
      apiKey = getFallbackApiKey(activeProvider);
    }
    
    // Geocode based on the selected provider
    switch (activeProvider) {
      case 'google_maps':
        return await geocodeAddressWithGoogleMaps(address, apiKey);
      case 'mapbox':
        return await geocodeAddressWithMapbox(address, apiKey);
      case 'osm':
        return await geocodeAddressWithOSM(address);
      default:
        return await geocodeAddressWithGoogleMaps(address, apiKey);
    }
  } catch (error) {
    console.error('Error in geocoding:', error);
    return {
      lat: 0,
      lng: 0,
      address,
      error: error instanceof Error ? error.message : 'Geocoding failed'
    };
  }
}

// Google Maps Geocoding implementation
async function geocodeAddressWithGoogleMaps(address: string, apiKey: string | null): Promise<GeocodingResult> {
  if (!apiKey) {
    console.warn('No Google Maps API key available. Using fallback geocoding.');
    return getFallbackGeocoding(address);
  }
  
  try {
    // URL-encode the address for the API request
    const encodedAddress = encodeURIComponent(address);
    
    // Make request to Google Maps Geocoding API
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?address=${encodedAddress}&key=${apiKey}`
    );
    
    if (!response.ok) {
      throw new Error('Google Maps Geocoding API request failed');
    }
    
    const data = await response.json();
    
    if (data.status === 'OK' && data.results && data.results.length > 0) {
      // Extract coordinates from the first result
      const location = data.results[0].geometry.location;
      const formattedAddress = data.results[0].formatted_address;
      
      return {
        lat: location.lat,
        lng: location.lng,
        address: formattedAddress || address // Use formatted address if available
      };
    }
    
    // If no results or error status, throw an error
    throw new Error(`Google Maps Geocoding failed: ${data.status}`);
  } catch (error) {
    console.error('Google Maps geocoding error:', error);
    return getFallbackGeocoding(address);
  }
}

// Mapbox Geocoding implementation
async function geocodeAddressWithMapbox(address: string, apiKey: string | null): Promise<GeocodingResult> {
  if (!apiKey) {
    console.warn('No Mapbox access token available. Using fallback geocoding.');
    return getFallbackGeocoding(address);
  }
  
  try {
    // URL-encode the address for the API request
    const encodedAddress = encodeURIComponent(address);
    
    // Make request to Mapbox Geocoding API
    const response = await fetch(
      `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodedAddress}.json?access_token=${apiKey}`
    );
    
    if (!response.ok) {
      throw new Error('Mapbox Geocoding API request failed');
    }
    
    const data = await response.json();
    
    if (data.features && data.features.length > 0) {
      // Extract coordinates from the first result (Mapbox returns [lng, lat])
      const coordinates = data.features[0].center;
      const formattedAddress = data.features[0].place_name;
      
      return {
        lat: coordinates[1], // Mapbox returns [lng, lat]
        lng: coordinates[0],
        address: formattedAddress || address
      };
    }
    
    // If no results, throw an error
    throw new Error('Mapbox Geocoding returned no results');
  } catch (error) {
    console.error('Mapbox geocoding error:', error);
    return getFallbackGeocoding(address);
  }
}

// OSM/Nominatim Geocoding implementation (free, no API key required)
async function geocodeAddressWithOSM(address: string): Promise<GeocodingResult> {
  try {
    // URL-encode the address for the API request
    const encodedAddress = encodeURIComponent(address);
    
    // Make request to OSM/Nominatim API (add application name in headers as good practice)
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encodedAddress}&format=json`,
      {
        headers: {
          'User-Agent': 'AskForTransport/1.0'
        }
      }
    );
    
    if (!response.ok) {
      throw new Error('OSM Geocoding API request failed');
    }
    
    const data = await response.json();
    
    if (data && data.length > 0) {
      // Extract coordinates from the first result
      const result = data[0];
      
      return {
        lat: parseFloat(result.lat),
        lng: parseFloat(result.lon),
        address: result.display_name || address
      };
    }
    
    // If no results, throw an error
    throw new Error('OSM Geocoding returned no results');
  } catch (error) {
    console.error('OSM geocoding error:', error);
    return getFallbackGeocoding(address);
  }
}

// Fallback geocoding when all providers fail
function getFallbackGeocoding(address: string): GeocodingResult {
  const hash = hashString(address);
  
  // Use Kenya as the base location for the fallback (instead of NYC)
  const lat = -1.2921 + (hash % 1000) / 10000; // Around Nairobi with some variation
  const lng = 36.8219 + (hash % 500) / 10000;
  
  return {
    lat,
    lng,
    address
  };
}

// Reverse geocode coordinates to address using the active map provider
export async function reverseGeocode(lat: number, lng: number): Promise<string> {
  try {
    // Get the map configuration from local storage first for faster access
    let configStr = localStorage.getItem('mapConfig');
    let activeProvider: MapProvider = 'google_maps'; // Default to Google Maps
    let apiKey: string | null = null;
    
    if (configStr) {
      try {
        const savedConfig = JSON.parse(configStr);
        if (savedConfig && savedConfig.provider) {
          activeProvider = savedConfig.provider as MapProvider;
          apiKey = savedConfig.apiKey;
        }
      } catch (e) {
        console.warn('Failed to parse saved map configuration, using defaults');
      }
    }
    
    // If no API key in local storage, try environment variables
    if (!apiKey) {
      apiKey = getFallbackApiKey(activeProvider);
    }
    
    // Reverse geocode based on the selected provider
    switch (activeProvider) {
      case 'google_maps':
        return await reverseGeocodeWithGoogleMaps(lat, lng, apiKey);
      case 'mapbox':
        return await reverseGeocodeWithMapbox(lat, lng, apiKey);
      case 'osm':
        return await reverseGeocodeWithOSM(lat, lng);
      default:
        return await reverseGeocodeWithGoogleMaps(lat, lng, apiKey);
    }
  } catch (error) {
    console.error('Error in reverse geocoding:', error);
    // Return a formatted coordinate string as fallback
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }
}

// Google Maps reverse geocoding implementation
async function reverseGeocodeWithGoogleMaps(lat: number, lng: number, apiKey: string | null): Promise<string> {
  if (!apiKey) {
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }
  
  try {
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`
    );
    
    if (!response.ok) {
      throw new Error('Google Maps Reverse Geocoding API request failed');
    }
    
    const data = await response.json();
    
    if (data.status === 'OK' && data.results && data.results.length > 0) {
      // Return the formatted address from the first result
      return data.results[0].formatted_address;
    }
    
    throw new Error(`Google Maps Reverse Geocoding failed: ${data.status}`);
  } catch (error) {
    console.error('Google Maps reverse geocoding error:', error);
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }
}

// Mapbox reverse geocoding implementation
async function reverseGeocodeWithMapbox(lat: number, lng: number, apiKey: string | null): Promise<string> {
  if (!apiKey) {
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }
  
  try {
    const response = await fetch(
      `https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${apiKey}`
    );
    
    if (!response.ok) {
      throw new Error('Mapbox Reverse Geocoding API request failed');
    }
    
    const data = await response.json();
    
    if (data.features && data.features.length > 0) {
      return data.features[0].place_name;
    }
    
    throw new Error('Mapbox Reverse Geocoding returned no results');
  } catch (error) {
    console.error('Mapbox reverse geocoding error:', error);
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }
}

// OSM/Nominatim reverse geocoding implementation
async function reverseGeocodeWithOSM(lat: number, lng: number): Promise<string> {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`,
      {
        headers: {
          'User-Agent': 'AskForTransport/1.0'
        }
      }
    );
    
    if (!response.ok) {
      throw new Error('OSM Reverse Geocoding API request failed');
    }
    
    const data = await response.json();
    
    if (data && data.display_name) {
      return data.display_name;
    }
    
    throw new Error('OSM Reverse Geocoding returned no results');
  } catch (error) {
    console.error('OSM reverse geocoding error:', error);
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }
}

// Helper function to get a number hash from a string
function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash);
}

// Get current position from browser geolocation API
function getCurrentPosition(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser'));
    } else {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
      });
    }
  });
}

// Importing calculateDistance from utils.ts
import { calculateDistance } from './utils';
// Re-export the calculateDistance function
export { calculateDistance };

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

// Generate route waypoints between two points
export function generateRouteWaypoints(
  start: { lat: number; lng: number }, 
  end: { lat: number; lng: number }, 
  numPoints = 8
): { lat: number; lng: number }[] {
  const waypoints = [];
  
  // Always include start point
  waypoints.push({ ...start });
  
  // Generate intermediate waypoints with some realistic path variation
  for (let i = 1; i < numPoints - 1; i++) {
    // Linear interpolation with random deviation
    const ratio = i / numPoints;
    const lat = start.lat + (end.lat - start.lat) * ratio;
    const lng = start.lng + (end.lng - start.lng) * ratio;
    
    // Add some randomness to simulate realistic road paths
    // The deviation gets larger in the middle of the route
    const deviation = 0.005 * Math.sin(Math.PI * ratio); // Max ~500m deviation
    
    const randomLat = lat + (Math.random() * 2 - 1) * deviation;
    const randomLng = lng + (Math.random() * 2 - 1) * deviation;
    
    waypoints.push({ 
      lat: randomLat, 
      lng: randomLng 
    });
  }
  
  // Always include end point
  waypoints.push({ ...end });
  
  return waypoints;
}

// Calculate ETA based on distance and average speed
export function calculateETA(
  distance: number, // in km
  averageSpeed = 30, // km/h
  departureTime = new Date()
): Date {
  // Calculate travel time in hours
  const travelTimeHours = distance / averageSpeed;
  
  // Convert to milliseconds and add to departure time
  const travelTimeMs = travelTimeHours * 60 * 60 * 1000;
  const eta = new Date(departureTime.getTime() + travelTimeMs);
  
  return eta;
}

// Calculate distance between a point and a line segment (for determining if a driver is on route)
export function pointToLineDistance(
  point: { lat: number; lng: number },
  lineStart: { lat: number; lng: number },
  lineEnd: { lat: number; lng: number }
): number {
  const x = point.lng;
  const y = point.lat;
  const x1 = lineStart.lng;
  const y1 = lineStart.lat;
  const x2 = lineEnd.lng;
  const y2 = lineEnd.lat;

  const A = x - x1;
  const B = y - y1;
  const C = x2 - x1;
  const D = y2 - y1;

  const dot = A * C + B * D;
  const lenSq = C * C + D * D;
  let param = -1;

  if (lenSq !== 0) {
    param = dot / lenSq;
  }

  let xx, yy;

  if (param < 0) {
    xx = x1;
    yy = y1;
  } else if (param > 1) {
    xx = x2;
    yy = y2;
  } else {
    xx = x1 + param * C;
    yy = y1 + param * D;
  }

  const dx = x - xx;
  const dy = y - yy;

  // Return distance in km
  return calculateDistance(point.lat, point.lng, yy, xx);
}

// Custom hook to get user's current location
export function useCurrentLocation() {
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Attempt to get location on hook initialization
  useEffect(() => {
    const fetchLocation = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        const position = await getCurrentPosition();
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to get location');
      } finally {
        setIsLoading(false);
      }
    };

    fetchLocation();
  }, []);

  // Manual refresh function
  const refreshLocation = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const position = await getCurrentPosition();
      setLocation({
        lat: position.coords.latitude,
        lng: position.coords.longitude
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to get location');
    } finally {
      setIsLoading(false);
    }
  };

  return { location, isLoading, error, refreshLocation };
}
