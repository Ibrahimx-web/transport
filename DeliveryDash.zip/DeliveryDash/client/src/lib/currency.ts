import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { useToast } from '@/hooks/use-toast';

// Define supported currencies
export type CurrencyCode = 'USD' | 'KES' | 'EUR' | 'GBP' | 'NGN' | 'ZAR' | 'UGX' | 'TZS' | 'INR';

type CurrencyInfo = {
  symbol: string;
  name: string;
  decimalPlaces: number;
};

type ExchangeRates = {
  [key in CurrencyCode]: number;
};

// Define regions for location-based currency detection
type Region = {
  name: string;
  currency: CurrencyCode;
  bounds: {
    north: number;
    south: number;
    west: number;
    east: number;
  }
};

export interface CurrencyState {
  currency: CurrencyCode;
  exchangeRates: ExchangeRates;
  isLoading: boolean;
  error: string | null;
  detectedLocation: {
    country?: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  detectCountry: () => Promise<void>;
  fetchExchangeRates: () => Promise<void>;
  setCurrency: (currency: CurrencyCode) => void;
  convertAmount: (amount: number, fromCurrency?: CurrencyCode, toCurrency?: CurrencyCode) => number;
  formatCurrency: (amount: number, currency?: CurrencyCode) => string;
}

export const SUPPORTED_CURRENCIES: Record<CurrencyCode, CurrencyInfo> = {
  USD: { symbol: '$', name: 'US Dollar', decimalPlaces: 2 },
  KES: { symbol: 'Ksh', name: 'Kenyan Shilling', decimalPlaces: 0 },
  EUR: { symbol: '€', name: 'Euro', decimalPlaces: 2 },
  GBP: { symbol: '£', name: 'British Pound', decimalPlaces: 2 },
  NGN: { symbol: '₦', name: 'Nigerian Naira', decimalPlaces: 0 },
  ZAR: { symbol: 'R', name: 'South African Rand', decimalPlaces: 2 },
  UGX: { symbol: 'USh', name: 'Ugandan Shilling', decimalPlaces: 0 },
  TZS: { symbol: 'TSh', name: 'Tanzanian Shilling', decimalPlaces: 0 },
  INR: { symbol: '₹', name: 'Indian Rupee', decimalPlaces: 2 },
};

// Define regions for location-based currency detection
export const REGIONS: Region[] = [
  {
    name: 'Kenya',
    currency: 'KES',
    bounds: {
      north: 5.0,
      south: -4.8,
      west: 33.8,
      east: 41.9
    }
  },
  {
    name: 'Nigeria',
    currency: 'NGN',
    bounds: {
      north: 13.9,
      south: 4.3,
      west: 2.7,
      east: 14.7
    }
  },
  {
    name: 'South Africa',
    currency: 'ZAR',
    bounds: {
      north: -22.1,
      south: -34.8,
      west: 16.5,
      east: 32.9
    }
  },
  {
    name: 'Uganda',
    currency: 'UGX',
    bounds: {
      north: 4.2,
      south: -1.5,
      west: 29.6,
      east: 35.0
    }
  },
  {
    name: 'Tanzania',
    currency: 'TZS',
    bounds: {
      north: -1.0,
      south: -11.7,
      west: 29.3,
      east: 40.5
    }
  },
  {
    name: 'United Kingdom',
    currency: 'GBP',
    bounds: {
      north: 58.7,
      south: 50.0,
      west: -8.2,
      east: 1.8
    }
  },
  {
    name: 'Eurozone',
    currency: 'EUR',
    bounds: {
      north: 60.0,
      south: 35.0,
      west: -10.0,
      east: 30.0
    }
  },
  {
    name: 'India',
    currency: 'INR',
    bounds: {
      north: 35.5,
      south: 6.8,
      west: 68.2,
      east: 97.4
    }
  }
];

// Default exchange rates (1 USD to other currencies)
export const DEFAULT_EXCHANGE_RATES: ExchangeRates = {
  USD: 1,
  KES: 129.5, // 1 USD = 129.5 KES
  EUR: 0.92,  // 1 USD = 0.92 EUR
  GBP: 0.79,  // 1 USD = 0.79 GBP
  NGN: 1490,  // 1 USD = 1490 NGN
  ZAR: 18.5,  // 1 USD = 18.5 ZAR
  UGX: 3800,  // 1 USD = 3800 UGX
  TZS: 2550,  // 1 USD = 2550 TZS
  INR: 83.2,  // 1 USD = 83.2 INR
};

// Function to check if coordinates are within a specific region
export function isLocationInRegion(lat: number, lng: number, region: Region): boolean {
  return (
    lat >= region.bounds.south && 
    lat <= region.bounds.north && 
    lng >= region.bounds.west && 
    lng <= region.bounds.east
  );
}

// Detect which region a location belongs to
export function detectRegionFromCoordinates(lat: number, lng: number): Region | null {
  for (const region of REGIONS) {
    if (isLocationInRegion(lat, lng, region)) {
      return region;
    }
  }
  return null; // No matching region found
}

export const useCurrencyStore = create<CurrencyState>()(
  persist(
    (set, get) => ({
      currency: 'USD', // Default currency
      exchangeRates: DEFAULT_EXCHANGE_RATES,
      isLoading: false,
      error: null,
      detectedLocation: {},

      detectCountry: async () => {
        try {
          set({ isLoading: true, error: null });
          
          // First check if a currency preference is already set in localStorage
          const savedCurrency = localStorage.getItem('selected_currency') as CurrencyCode | null;
          if (savedCurrency && Object.keys(SUPPORTED_CURRENCIES).includes(savedCurrency)) {
            console.log(`Using saved currency preference: ${savedCurrency}`);
            set({ currency: savedCurrency, isLoading: false });
            return;
          }
          
          // If no saved preference, try to detect location
          if (navigator.geolocation) {
            try {
              // Get the current position with a reasonable timeout
              const position = await new Promise<GeolocationPosition>((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject, {
                  timeout: 10000,
                  maximumAge: 0,
                  enableHighAccuracy: false
                });
              });
              
              const lat = position.coords.latitude;
              const lng = position.coords.longitude;
              
              // Determine which region the coordinates belong to
              const detectedRegion = detectRegionFromCoordinates(lat, lng);
              
              // Set currency based on detected region, or default to USD
              const detectedCurrency: CurrencyCode = detectedRegion?.currency || 'USD';
              const detectedCountry = detectedRegion?.name || 'Unknown';
              
              // Update state with detected information
              set({ 
                currency: detectedCurrency,
                detectedLocation: {
                  country: detectedCountry,
                  coordinates: { lat, lng }
                }
              });
              
              // Save the location data in localStorage for faster access next time
              localStorage.setItem('user_location', JSON.stringify({
                lat,
                lng,
                country: detectedCountry,
                currency: detectedCurrency,
                timestamp: Date.now()
              }));
              
              console.log(`Location detected in ${detectedCountry}, using ${detectedCurrency}`);
            } catch (geoError) {
              console.warn('Geolocation failed:', geoError);
              
              // Try to use cached location data if available
              const cachedLocation = localStorage.getItem('user_location');
              if (cachedLocation) {
                try {
                  const locationData = JSON.parse(cachedLocation);
                  // Use cached data if it's less than 24 hours old
                  if (Date.now() - locationData.timestamp < 24 * 60 * 60 * 1000) {
                    console.log('Using cached location data');
                    set({ 
                      currency: locationData.currency,
                      detectedLocation: {
                        country: locationData.country,
                        coordinates: locationData.lat && locationData.lng ? 
                          { lat: locationData.lat, lng: locationData.lng } : undefined
                      }
                    });
                    return;
                  }
                } catch (e) {
                  // Ignore parse errors in cached data
                }
              }
              
              // Default to USD if geolocation fails and no valid cache
              set({ currency: 'USD' });
            }
          } else {
            // Browser doesn't support geolocation
            console.warn('Geolocation not supported by browser');
            set({ currency: 'USD' });
          }
          
          // Use default exchange rates
          set({ exchangeRates: DEFAULT_EXCHANGE_RATES, isLoading: false });
        } catch (error) {
          console.error('Error in currency detection:', error);
          // Default to USD in case of any errors
          set({ 
            currency: 'USD', 
            exchangeRates: DEFAULT_EXCHANGE_RATES, 
            isLoading: false, 
            error: String(error) 
          });
        }
      },
      
      fetchExchangeRates: async () => {
        try {
          set({ isLoading: true, error: null });
          
          // Use hardcoded exchange rates to avoid API dependencies
          // In a production environment, this would connect to a live exchange rate API
          console.info('Using default exchange rates');
          set({ exchangeRates: DEFAULT_EXCHANGE_RATES });
          
          set({ isLoading: false });
        } catch (error) {
          console.error('Error in exchange rates:', error);
          // Ensure we always have default rates
          set({ exchangeRates: DEFAULT_EXCHANGE_RATES, isLoading: false });
        }
      },
      
      setCurrency: (currency: CurrencyCode) => {
        // Update currency in state
        set({ currency });
        // Also update in localStorage for components that might not have access to the store
        localStorage.setItem('selected_currency', currency);
      },
      
      convertAmount: (amount: number, fromCurrency?: CurrencyCode, toCurrency?: CurrencyCode) => {
        const { currency, exchangeRates } = get();
        const from = fromCurrency || currency;
        const to = toCurrency || currency;
        
        // If same currency, return original amount
        if (from === to) {
          return amount;
        }
        
        // Convert to USD first (as base currency), then to target currency
        const amountInUSD = from === 'USD' ? amount : amount / exchangeRates[from];
        return to === 'USD' ? amountInUSD : amountInUSD * exchangeRates[to];
      },
      
      formatCurrency: (amount: number, currencyCode?: CurrencyCode) => {
        const { currency } = get();
        const code = currencyCode || currency;
        const currencyInfo = SUPPORTED_CURRENCIES[code];
        
        // Convert amount if necessary
        const convertedAmount = get().convertAmount(amount, 'USD', code);
        
        // Format with appropriate decimal places (varies by currency)
        // Using a more sophisticated formatting approach with decimal places based on currency
        const formattedAmount = convertedAmount.toLocaleString(undefined, {
          minimumFractionDigits: currencyInfo.decimalPlaces,
          maximumFractionDigits: currencyInfo.decimalPlaces
        });
        
        return `${currencyInfo.symbol}${formattedAmount}`;
      }
    }),
    {
      name: 'currency-storage',
      partialize: (state) => ({ 
        currency: state.currency,
        exchangeRates: state.exchangeRates,
        detectedLocation: state.detectedLocation
      }),
    }
  )
);

// Helper function for direct formatting in components
export const formatCurrency = (amount: number, currencyCode?: CurrencyCode) => {
  // If a specific currency wasn't provided, check localStorage first for user preference
  if (!currencyCode) {
    const savedCurrency = localStorage.getItem('selected_currency') as CurrencyCode | null;
    if (savedCurrency && Object.keys(SUPPORTED_CURRENCIES).includes(savedCurrency)) {
      currencyCode = savedCurrency;
    }
  }
  
  return useCurrencyStore.getState().formatCurrency(amount, currencyCode);
};

export function useCurrency() {
  const { toast } = useToast();
  const currency = useCurrencyStore(state => state.currency);
  const setCurrency = useCurrencyStore(state => state.setCurrency);
  const detectCountry = useCurrencyStore(state => state.detectCountry);
  const formatCurrency = useCurrencyStore(state => state.formatCurrency);
  const isLoading = useCurrencyStore(state => state.isLoading);
  const error = useCurrencyStore(state => state.error);
  const detectedLocation = useCurrencyStore(state => state.detectedLocation);
  
  const toggleCurrency = () => {
    // Toggle between current currency and USD
    const newCurrency = currency === 'USD' ? 
      (detectedLocation.country ? 
        detectRegionFromCoordinates(
          detectedLocation.coordinates?.lat || 0, 
          detectedLocation.coordinates?.lng || 0
        )?.currency || 'KES' 
        : 'KES') 
      : 'USD';
    
    setCurrency(newCurrency);
    toast({
      title: `Currency changed to ${SUPPORTED_CURRENCIES[newCurrency].name}`,
      description: 'All prices will be displayed in this currency',
    });
  };
  
  return {
    currency,
    setCurrency,
    detectCountry,
    formatCurrency,
    toggleCurrency,
    isLoading,
    error,
    supportedCurrencies: SUPPORTED_CURRENCIES,
    detectedLocation,
  };
}