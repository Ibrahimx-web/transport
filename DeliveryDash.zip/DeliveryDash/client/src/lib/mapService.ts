import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";

// Map provider types
export type MapProvider = 'google_maps' | 'mapbox' | 'osm';

// Map API configuration interface
export interface MapApiConfig {
  id: number;
  provider: MapProvider;
  apiKey: string;
  isActive: boolean;
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
}

// Hook to get the active map configuration
export function useMapConfig() {
  const queryClient = useQueryClient();
  
  const {
    data: configs,
    isLoading,
    isError,
    error,
  } = useQuery<MapApiConfig[]>({
    queryKey: ['/api/map-api-configs'],
    retry: 1,
    staleTime: 60000, // 1 minute
  });

  // Select the active map configuration
  // First look for default + active, then just active, then just first in the list
  let activeConfig: MapApiConfig | undefined;
  
  if (configs && configs.length > 0) {
    // First try to find the default active config
    activeConfig = configs.find(config => config.isDefault && config.isActive);
    
    // If no default active config, try to find any active config
    if (!activeConfig) {
      activeConfig = configs.find(config => config.isActive);
    }
    
    // If no active config, just use the first one
    if (!activeConfig) {
      activeConfig = configs[0];
    }
  }
  
  // When active config changes, update localStorage for quick access
  useEffect(() => {
    if (activeConfig) {
      updateLocalMapConfig(activeConfig);
    }
  }, [activeConfig?.id, activeConfig?.provider, activeConfig?.apiKey, activeConfig?.isActive]);

  // Manual function to refetch configurations
  const refreshMapConfigs = () => {
    return queryClient.invalidateQueries({queryKey: ['/api/map-api-configs']});
  };

  return {
    config: activeConfig,
    isLoading,
    isError,
    error,
    allConfigs: configs || [],
    refreshMapConfigs,
  };
}

// Update the local storage with map configuration for faster access
export function updateLocalMapConfig(config: MapApiConfig): void {
  try {
    // Only store essential info in localStorage (not everything)
    const essentialConfig = {
      id: config.id,
      provider: config.provider,
      apiKey: config.apiKey,
      isActive: config.isActive,
      isDefault: config.isDefault,
    };
    
    localStorage.setItem('mapConfig', JSON.stringify(essentialConfig));
    console.log(`Map configuration updated to ${getProviderDisplayName(config.provider)}`);
  } catch (error) {
    console.error('Failed to update map configuration in localStorage:', error);
  }
}

// Get the currently active map provider from localStorage for fast access
// or fall back to default (Google Maps)
export function getActiveMapProvider(): MapProvider {
  try {
    const configStr = localStorage.getItem('mapConfig');
    if (configStr) {
      const config = JSON.parse(configStr);
      if (config && config.provider && config.isActive) {
        return config.provider as MapProvider;
      }
    }
  } catch (error) {
    console.warn('Failed to read map configuration from localStorage:', error);
  }
  
  return 'google_maps'; // Default to Google Maps if nothing is found
}

// Get the fallback API key if no configuration exists
export function getFallbackApiKey(provider: MapProvider): string | null {
  switch (provider) {
    case 'google_maps':
      return import.meta.env.VITE_GOOGLE_MAPS_API_KEY || null;
    case 'mapbox':
      return import.meta.env.VITE_MAPBOX_ACCESS_TOKEN || null;
    case 'osm':
      // OSM doesn't require an API key
      return null; 
    default:
      return null;
  }
}

// Helper function to get a display name for providers
export function getProviderDisplayName(provider?: MapProvider): string {
  if (!provider) return 'Unknown Provider';
  
  const providers: Record<MapProvider, string> = {
    'google_maps': 'Google Maps',
    'mapbox': 'Mapbox',
    'osm': 'OpenStreetMap'
  };
  
  return providers[provider] || provider;
}