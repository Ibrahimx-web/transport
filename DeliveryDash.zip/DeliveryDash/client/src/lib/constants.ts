import { VehicleType } from "@/types";
import { useCurrencyStore } from "./currency";

// Default coordinates (used for map center when no locations are selected)
export const DEFAULT_COORDINATES = {
  lat: 40.7128, // New York City
  lng: -74.0060,
};

// Kenya coordinates for potential use
export const KENYA_COORDINATES = {
  lat: -1.2921, // Nairobi
  lng: 36.8219,
};

// Status labels for UI display
export const ORDER_STATUS_LABELS: Record<string, string> = {
  pending: "Pending",
  driver_assigned: "Driver assigned",
  on_way_to_pickup: "On the way to pickup",
  arrived_at_pickup: "Arrived at pickup",
  package_picked_up: "Package picked up",
  on_way_to_delivery: "On the way to delivery",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

// Calculate price estimations
export function calculatePricing(
  distance: number,
  baseFare: number
): { 
  baseFare: number; 
  distanceFare: number; 
  serviceFee: number; 
  totalFare: number;
} {
  // Rate per km is $1.00 USD (base currency)
  const distanceFare = parseFloat((distance * 1.0).toFixed(2));
  
  // Service fee is 10% of (base fare + distance fare)
  const serviceFee = parseFloat(((baseFare + distanceFare) * 0.1).toFixed(2));
  
  // Total fare is base fare + distance fare + service fee
  const totalFare = parseFloat((baseFare + distanceFare + serviceFee).toFixed(2));
  
  return {
    baseFare,
    distanceFare,
    serviceFee,
    totalFare,
  };
}

// Format currency (legacy function - use useCurrency hook instead)
export function formatCurrency(amount: number): string {
  // This is now a wrapper for the currency store's format function
  const formatWithStore = useCurrencyStore.getState().formatCurrency;
  return formatWithStore(amount);
}

// Format date
export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { 
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });
}

// Default vehicle types (fallback if API call fails)
export const DEFAULT_VEHICLE_TYPES: VehicleType[] = [
  { id: 1, name: "Bike", icon: "bicycle", maxWeight: 5, baseFare: 5.99 },
  { id: 2, name: "Motorbike", icon: "motorcycle", maxWeight: 20, baseFare: 8.99 },
  { id: 3, name: "Pickup", icon: "truck-pickup", maxWeight: 100, baseFare: 14.99 },
  { id: 4, name: "Van", icon: "shuttle-van", maxWeight: 500, baseFare: 24.99 },
  { id: 5, name: "Lorry", icon: "truck", maxWeight: 2000, baseFare: 44.99 },
  { id: 6, name: "Motor Breakdown", icon: "wrench", maxWeight: 0, baseFare: 29.99 }
];

// Map API keys handling - IMPORTANT NOTE:
// We no longer use hardcoded API keys from constants.ts
// All mapping-related API keys are now managed through the mapService
// which retrieves configuration from the backend database
// If you need to access a map API key, please use:
//   1. The useMapConfig() hook in React components, or
//   2. The getFallbackApiKey() function for non-React code
// See mapService.ts for details
