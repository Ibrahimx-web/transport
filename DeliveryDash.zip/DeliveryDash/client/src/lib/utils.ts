import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { OrderStatus } from '@/types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  // Haversine formula to calculate distance between two points on earth
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in km
  return parseFloat(distance.toFixed(2));
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

// Get human-readable order status
export function getOrderStatusName(status: OrderStatus): string {
  switch (status) {
    case 'pending':
      return 'Pending';
    case 'driver_assigned':
      return 'Driver Assigned';
    case 'on_way_to_pickup':
      return 'On Way to Pickup';
    case 'arrived_at_pickup':
      return 'At Pickup Location';
    case 'package_picked_up':
      return 'Package Picked Up';
    case 'on_way_to_delivery':
      return 'On Way to Delivery';
    case 'delivered':
      return 'Delivered';
    default:
      return 'Unknown Status';
  }
}

// Convert file to base64 string with compression
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    // Create a new image for compression
    const img = new Image();
    const reader = new FileReader();
    
    reader.onload = (event) => {
      if (!event.target?.result) {
        reject(new Error('Failed to read file'));
        return;
      }
      
      img.onload = () => {
        // Create a canvas to resize the image
        const canvas = document.createElement('canvas');
        
        // Calculate new dimensions (max 800px wide or tall)
        let width = img.width;
        let height = img.height;
        const maxDimension = 800;
        
        if (width > height && width > maxDimension) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else if (height > maxDimension) {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
        
        canvas.width = width;
        canvas.height = height;
        
        // Draw the resized image
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Could not get canvas context'));
          return;
        }
        
        ctx.drawImage(img, 0, 0, width, height);
        
        // Convert to base64 with reduced quality (0.7 is 70% quality)
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7);
        resolve(compressedBase64);
      };
      
      img.onerror = () => {
        // Fallback to original method if image compression fails
        if (reader.result && typeof reader.result === 'string') {
          resolve(reader.result);
        } else {
          reject(new Error('Failed to load image for compression'));
        }
      };
      
      // Set the image source to the file data
      if (event.target && event.target.result) {
        img.src = event.target.result.toString();
      } else {
        reject(new Error('No file data available'));
      }
    };
    
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};
