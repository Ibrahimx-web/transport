// User Types
export type UserType = "customer" | "delivery" | "admin";

export interface User {
  id: number;
  username: string;
  fullName: string;
  email: string;
  phone: string;
  userType: UserType;
  vehicleTypeId: number | null;
  licensePlateNumber: string | null;
  vehicleRegistrationNumber: string | null;
  profilePicture: string | null;
  driversLicense: string | null;
  currentLat: number | null;
  currentLng: number | null;
  isAvailable: boolean;
  createdAt: string;
}

export interface UserRegistration {
  username: string;
  password: string;
  fullName: string;
  email: string;
  phone: string;
  userType: UserType;
  vehicleTypeId?: number | null;
  licensePlateNumber?: string | null;
  vehicleRegistrationNumber?: string | null;
  profilePicture?: string | null;
  driversLicense?: string | null;
  adminCode?: string;
}

// Vehicle Types
export interface VehicleType {
  id: number;
  name: string;
  icon: string | null;
  basePrice: number;
  pricePerKm: number;
  maxWeight: number;
  baseFare: number; // Added for compatibility with existing code
  createdAt: string;
}

// Order Types
export interface Location {
  lat: number;
  lng: number;
  address: string;
}

// Renamed to avoid confusion with Location
export interface OrderLocation {
  lat: number;
  lng: number;
  address: string;
}

// Delivery form state for the booking process
export interface DeliveryFormState {
  pickup: OrderLocation;
  delivery: OrderLocation;
  vehicleTypeId: number;
  packageDetails: {
    description: string;
    weight?: number;
    dimensions: string;
    specialInstructions: string;
  };
}

export interface PackageDetails {
  weight: number;
  height?: number;
  width?: number;
  length?: number;
  description: string;
  isFragile?: boolean;
  fragile?: boolean; // For backward compatibility
  dimensions?: string; // For size in format "L x W x H"
  specialInstructions?: string;
  distance?: number; // For AI recommendation 
  urgency?: "normal" | "urgent" | "same-day";
}

export type OrderStatus = 
  | 'pending'
  | 'driver_assigned'
  | 'on_way_to_pickup'
  | 'arrived_at_pickup'
  | 'package_picked_up'
  | 'on_way_to_delivery'
  | 'delivered';

export interface Order {
  id: number;
  userId: number;
  partnerId: number | null;
  deliveryPersonId: number | null;
  vehicleTypeId: number;
  pickupLat: number;
  pickupLng: number;
  pickupAddress: string;
  pickupLocation: string;
  deliveryLat: number;
  deliveryLng: number;
  deliveryAddress: string;
  deliveryLocation: string;
  packageDetails: PackageDetails;
  distance: number;
  fare: number;
  status: OrderStatus;
  createdAt: string;
}

export interface OrderStatusUpdate {
  id: number;
  orderId: number;
  status: OrderStatus;
  createdAt: string;
  timestamp: string;
  latitude: number | null;
  longitude: number | null;
  notes: string | null;
}

export interface RouteSegment {
  path: {
    lat: number;
    lng: number;
  }[];
  distance: number;
  estimatedTime: number;
}

export interface RouteInfo {
  distance: number;
  estimatedTime: number;
  segments: RouteSegment[];
}

// Payment Types
export interface Payment {
  id: number;
  userId: number;
  paymentType: string;
  amount: number;
  status: string;
  gatewayReference: string | null;
  createdAt: string;
  details: any;
}

// Document Types
export interface PartnerDocument {
  id: number;
  userId: number;
  documentType: string;
  documentUrl: string;
  status: "pending" | "verified" | "rejected";
  createdAt: string;
  verifiedAt: string | null;
  verifiedBy: number | null;
  rejectionReason: string | null;
}

// Map API Configuration Types
export interface MapApiConfig {
  id: number;
  provider: string;
  apiKey: string;
  isActive: boolean;
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
}

// Payment Gateway Types
export interface PaymentGateway {
  id: number;
  displayName: string;
  gatewayType: string;
  configuration: any;
  isActive: boolean;
  isDefault: boolean;
  supportedCountries: string[];
  supportedCurrencies: string[];
  processingFee: number;
  minimumAmount: number;
  iconUrl: string | null;
  createdAt: string;
  createdBy: number;
  updatedAt: string;
  adminNotes: string | null;
}

// Commission Configuration Types
export interface CommissionConfiguration {
  id: number;
  commissionName: string;
  commissionPercentage: number;
  appliesTo: string;
  vehicleTypeIds: number[];
  isActive: boolean;
  isDefault: boolean;
  effectiveFrom: string;
  effectiveTo: string | null;
  description: string | null;
  createdAt: string;
  createdBy: number;
  updatedAt: string;
}

// WebSocket Message Types
export interface WSMessage {
  type: string;
  data: any;
}

export interface LocationUpdateMessage extends WSMessage {
  type: 'locationUpdate';
  data: {
    userId: number;
    latitude: number;
    longitude: number;
    timestamp: number;
  };
}

export interface OrderUpdateMessage extends WSMessage {
  type: 'orderUpdate';
  data: Order;
}

export interface OrderStatusUpdateMessage extends WSMessage {
  type: 'orderStatusUpdate';
  data: OrderStatus;
}

// Admin Dashboard Types
export interface DailyStats {
  date: string;
  orders: number;
  revenue: number;
}

export interface AdminDashboardSummary {
  totalUsers: number;
  activeDrivers: number;
  pendingOrders: number;
  completedOrders: number;
  totalRevenue: number;
  dailyStats: DailyStats[];
}

export interface PendingOrderItem {
  id: string;
  customer: string;
  pickup: string;
  delivery: string;
  status: string;
}

export interface DeliveryPartnerStats {
  id: number;
  name: string;
  deliveries: number;
  rating: number;
  earnings: number;
  isActive: boolean;
}

export interface DocumentVerificationItem {
  id: number;
  partnerId: number;
  partnerName: string;
  documentType: string;
  submittedDate: string;
  status: string;
}

export interface AdminDashboardData {
  summary: AdminDashboardSummary;
  pendingOrders: PendingOrderItem[];
  partners: DeliveryPartnerStats[];
  documents: DocumentVerificationItem[];
}