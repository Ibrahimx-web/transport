// Custom declarations for map libraries loaded dynamically in SimpleMapTest.tsx

declare global {
  interface Window {
    // Mapbox GL declarations
    mapboxgl?: {
      Map: new (options: any) => {
        on: (event: string, callback: Function) => void;
        remove: () => void;
      };
      Marker: new () => {
        setLngLat: (coords: [number, number]) => any;
        addTo: (map: any) => any;
      };
      accessToken: string;
    };
    
    // Leaflet declarations
    L?: {
      map: (container: HTMLElement) => {
        setView: (center: [number, number], zoom: number) => any;
        on: (event: string, callback: Function) => void;
        remove: () => void;
        invalidateSize: () => void;
      };
      tileLayer: (url: string, options: any) => {
        addTo: (map: any) => any;
      };
      marker: (coords: [number, number]) => {
        addTo: (map: any) => any;
        bindPopup: (content: string) => any;
      };
    };
  }
}

export {};