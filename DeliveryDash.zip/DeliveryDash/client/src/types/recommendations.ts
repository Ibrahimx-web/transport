export interface PackageDetails {
  width?: number;      // in cm
  height?: number;     // in cm
  length?: number;     // in cm
  weight: number;      // in kg
  fragile: boolean;    // if the item is fragile
  description?: string; // brief description of the item
  urgency?: "normal" | "urgent" | "same-day"; // delivery urgency
  distance: number;    // delivery distance in km
  
  // For backward compatibility with existing code
  dimensions?: {
    width: number;
    height: number;
    length: number;
  };
}

export interface VehicleRecommendation {
  recommendedVehicleType: string;
  recommendedVehicleId?: number | null;
  confidence: number;
  reasoning: string;
  alternativeVehicleType?: string;
  provider: "openai" | "anthropic" | "fallback" | "local"; // Which provider was used
}