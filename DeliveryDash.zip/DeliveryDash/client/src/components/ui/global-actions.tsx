import React from "react";
import { CurrencyToggle } from "./currency-toggle";

/**
 * Global actions that appear at the bottom right of the screen
 * across the entire application
 */
export function GlobalActions() {
  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
      <CurrencyToggle />
    </div>
  );
}