import React, { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import { AnimatePresence, motion } from 'framer-motion';

interface PageTransitionProps {
  children: React.ReactNode;
  className?: string;
  transitionKey: string | number;
  direction?: 'up' | 'down' | 'left' | 'right' | 'fade';
}

const variants = {
  up: {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 }
  },
  down: {
    initial: { opacity: 0, y: -20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: 20 }
  },
  left: {
    initial: { opacity: 0, x: 20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -20 }
  },
  right: {
    initial: { opacity: 0, x: -20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: 20 }
  },
  fade: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 }
  }
};

export function PageTransition({
  children,
  className,
  transitionKey,
  direction = 'up'
}: PageTransitionProps) {
  // Using a mounted state ensures the animation doesn't play on initial load
  const [isMounted, setIsMounted] = useState(false);
  
  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) {
    return <div className={className}>{children}</div>;
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={transitionKey}
        initial={variants[direction].initial}
        animate={variants[direction].animate}
        exit={variants[direction].exit}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className={cn(className)}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}

/**
 * Staggered items component for creating staggered animation effects
 */
interface StaggeredItemsProps {
  children: React.ReactNode;
  className?: string;
  staggerAmount?: number;
  direction?: 'up' | 'down' | 'left' | 'right' | 'fade';
  delay?: number;
}

export function StaggeredItems({
  children,
  className,
  staggerAmount = 0.1,
  direction = 'up',
  delay = 0
}: StaggeredItemsProps) {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: staggerAmount,
        delayChildren: delay
      }
    }
  };
  
  const getItemVariant = () => {
    switch (direction) {
      case 'up':
        return {
          hidden: { opacity: 0, y: 20 },
          show: { opacity: 1, y: 0 }
        };
      case 'down':
        return {
          hidden: { opacity: 0, y: -20 },
          show: { opacity: 1, y: 0 }
        };
      case 'left':
        return {
          hidden: { opacity: 0, x: 20 },
          show: { opacity: 1, x: 0 }
        };
      case 'right':
        return {
          hidden: { opacity: 0, x: -20 },
          show: { opacity: 1, x: 0 }
        };
      case 'fade':
      default:
        return {
          hidden: { opacity: 0 },
          show: { opacity: 1 }
        };
    }
  };

  return (
    <motion.div
      className={cn(className)}
      variants={container}
      initial="hidden"
      animate="show"
    >
      {React.Children.map(children, (child, index) => (
        <motion.div key={index} variants={getItemVariant()}>
          {child}
        </motion.div>
      ))}
    </motion.div>
  );
}