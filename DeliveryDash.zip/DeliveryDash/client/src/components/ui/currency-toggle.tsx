import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useCurrency } from "@/lib/currency";
import { Loader2, DollarSign, CreditCard } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function CurrencyToggle() {
  const { 
    currency, 
    toggleCurrency, 
    supportedCurrencies, 
    isLoading,
    setCurrency
  } = useCurrency();
  const [isSwitching, setIsSwitching] = useState(false);

  const handleToggle = async () => {
    setIsSwitching(true);
    toggleCurrency();
    setTimeout(() => setIsSwitching(false), 500);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="flex items-center gap-1"
          disabled={isLoading || isSwitching}
        >
          {isLoading || isSwitching ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : currency === 'USD' ? (
            <DollarSign className="h-3 w-3" />
          ) : (
            <CreditCard className="h-3 w-3" />
          )}
          {currency}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {Object.entries(supportedCurrencies).map(([code, info]) => (
          <DropdownMenuItem 
            key={code}
            onClick={() => setCurrency(code as any)}
            className={currency === code ? "bg-muted" : ""}
          >
            <span className="mr-2">{info.symbol}</span>
            {info.name} ({code})
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}