import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

export interface LoadingAnimationProps {
  size?: 'sm' | 'md' | 'lg';
  text?: string;
  className?: string;
  spinnerOnly?: boolean;
  textColor?: string;
}

/**
 * A versatile loading animation component
 * 
 * @param size - Size of the spinner (sm, md, lg)
 * @param text - Optional text to display alongside the spinner
 * @param className - Additional CSS classes
 * @param spinnerOnly - If true, only shows the spinner without text
 * @param textColor - Optional text color override
 */
export function LoadingAnimation({
  size = 'md',
  text = 'Loading...',
  className,
  spinnerOnly = false,
  textColor
}: LoadingAnimationProps) {
  // Map sizes to Tailwind classes
  const sizeClasses = {
    sm: 'h-4 w-4',
    md: 'h-6 w-6',
    lg: 'h-8 w-8'
  };

  // Map sizes to text sizes
  const textSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base'
  };
  
  // If spinner only, just return the spinner
  if (spinnerOnly) {
    return (
      <div className={cn("flex items-center justify-center", className)}>
        <Loader2 className={cn("animate-spin text-primary", sizeClasses[size])} />
      </div>
    );
  }
  
  // Return spinner with text
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <Loader2 className={cn("animate-spin text-primary", sizeClasses[size])} />
      {text && (
        <span 
          className={cn(
            "font-medium animate-pulse", 
            textSizeClasses[size],
            textColor || "text-muted-foreground"
          )}
        >
          {text}
        </span>
      )}
    </div>
  );
}