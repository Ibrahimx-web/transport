import * as React from "react";
import { cn } from "@/lib/utils";

interface LoadingSpinnerProps extends React.HTMLAttributes<HTMLDivElement> {
  size?: "sm" | "md" | "lg" | "xl";
  variant?: "default" | "primary" | "secondary" | "ghost";
}

export function LoadingSpinner({
  size = "md",
  variant = "default",
  className,
  ...props
}: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: "h-4 w-4 border-2",
    md: "h-8 w-8 border-3",
    lg: "h-12 w-12 border-4",
    xl: "h-16 w-16 border-4",
  };

  const variantClasses = {
    default: "border-muted-foreground/20 border-t-muted-foreground/60",
    primary: "border-blue-200 border-t-blue-600",
    secondary: "border-gray-200 border-t-gray-600",
    ghost: "border-gray-100 border-t-gray-400",
  };

  return (
    <div
      className={cn("flex items-center justify-center", className)}
      {...props}
    >
      <div
        className={cn(
          "animate-spin rounded-full",
          sizeClasses[size],
          variantClasses[variant]
        )}
      />
    </div>
  );
}

interface LoadingAnimationProps extends React.HTMLAttributes<HTMLDivElement> {
  text?: string;
  size?: "sm" | "md" | "lg" | "xl";
  variant?: "default" | "primary" | "secondary" | "ghost";
  fullPage?: boolean;
}

export function LoadingAnimation({
  text = "Loading...",
  size = "md",
  variant = "primary",
  fullPage = false,
  className,
  ...props
}: LoadingAnimationProps) {
  const fullPageClasses = fullPage
    ? "fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
    : "";

  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center space-y-4",
        fullPageClasses,
        className
      )}
      {...props}
    >
      <LoadingSpinner size={size} variant={variant} />
      {text && (
        <p
          className={cn(
            "text-center font-medium animate-pulse",
            size === "sm" ? "text-sm" : size === "lg" ? "text-lg" : "text-base"
          )}
        >
          {text}
        </p>
      )}
    </div>
  );
}

interface LoadingDotsProps extends React.HTMLAttributes<HTMLDivElement> {
  size?: "sm" | "md" | "lg";
  color?: "default" | "primary" | "secondary";
}

export function LoadingDots({
  size = "md",
  color = "default",
  className,
  ...props
}: LoadingDotsProps) {
  const sizeClasses = {
    sm: "h-1 w-1 mx-0.5",
    md: "h-2 w-2 mx-1",
    lg: "h-3 w-3 mx-1.5",
  };

  const colorClasses = {
    default: "bg-muted-foreground",
    primary: "bg-primary",
    secondary: "bg-secondary",
  };

  return (
    <div
      className={cn("flex items-center justify-center", className)}
      {...props}
    >
      <div className="flex space-x-1">
        <div
          className={cn(
            "rounded-full animate-bounce [animation-delay:-0.3s]",
            sizeClasses[size],
            colorClasses[color]
          )}
        />
        <div
          className={cn(
            "rounded-full animate-bounce [animation-delay:-0.15s]",
            sizeClasses[size],
            colorClasses[color]
          )}
        />
        <div
          className={cn(
            "rounded-full animate-bounce",
            sizeClasses[size],
            colorClasses[color]
          )}
        />
      </div>
    </div>
  );
}