import React, { useEffect, useState } from "react";
import { usePackageRecommendation } from "@/hooks/use-package-recommendation";
import { PackageDetails, VehicleRecommendation } from "@/types/recommendations";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Zap } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface PackageRecommendationProps {
  packageDetails: PackageDetails;
  onRecommendationReceived?: (recommendation: VehicleRecommendation) => void;
  className?: string;
}

const PackageRecommendation: React.FC<PackageRecommendationProps> = ({
  packageDetails,
  onRecommendationReceived,
  className
}) => {
  const {
    getRecommendation,
    recommendation,
    isLoading,
    isError,
    error
  } = usePackageRecommendation();
  
  // Track when we started the analysis for a nicer UX
  const [analysisStart, setAnalysisStart] = useState<number>(0);

  // Get recommendation when package details change
  useEffect(() => {
    if (
      packageDetails && 
      packageDetails.weight &&
      packageDetails.distance !== undefined &&
      packageDetails.fragile !== undefined
    ) {
      setAnalysisStart(Date.now());
      getRecommendation(packageDetails);
    }
  }, [packageDetails, getRecommendation]);

  // Notify parent component when recommendation is received
  useEffect(() => {
    if (recommendation && onRecommendationReceived) {
      onRecommendationReceived(recommendation);
    }
  }, [recommendation, onRecommendationReceived]);

  // Calculate how long it took to generate the recommendation (in ms)
  const analysisDuration = recommendation ? (Date.now() - analysisStart) : 0;
  
  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="text-xl font-semibold">Analyzing Your Package</CardTitle>
          <CardDescription>Finding the best vehicle for your delivery</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center space-y-4 p-6">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-muted-foreground text-sm">Optimizing for your package...</p>
        </CardContent>
      </Card>
    );
  }

  if (isError) {
    return (
      <Card className={`border-red-200 ${className}`}>
        <CardHeader className="bg-red-50 rounded-t-lg">
          <CardTitle className="text-xl font-semibold text-red-700">Recommendation Failed</CardTitle>
          <CardDescription className="text-red-600">{String(error)}</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <p className="text-sm text-muted-foreground">
            Please try again or select a vehicle manually.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!recommendation) {
    return null;
  }

  // Calculate confidence percentage for display
  const confidencePercentage = Math.round(recommendation.confidence * 100);

  return (
    <Card className={`border-primary/20 ${className}`}>
      <CardHeader className={`rounded-t-lg ${
        recommendation.provider === "local" 
          ? "bg-blue-50 dark:bg-blue-950/20" 
          : recommendation.provider === "fallback"
            ? "bg-amber-50 dark:bg-amber-950/20"
            : "bg-primary/5"
      }`}>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl font-semibold">Recommended Vehicle</CardTitle>
          <Badge 
            variant={
              recommendation.provider === "openai" 
                ? "default" 
                : recommendation.provider === "anthropic" 
                  ? "secondary"
                  : recommendation.provider === "local"
                    ? "outline"
                    : "destructive"
            }
          >
            {recommendation.provider === "openai" 
              ? "OpenAI" 
              : recommendation.provider === "anthropic" 
                ? "Anthropic"
                : recommendation.provider === "local"
                  ? <span className="flex items-center"><Zap className="h-3 w-3 mr-1" /> Quick</span>
                  : "Automatic"}
          </Badge>
        </div>
        <CardDescription>
          {recommendation.provider === "local" && (
            <span className="text-blue-600 dark:text-blue-400 flex items-center gap-1">
              <Zap className="h-3 w-3" />
              Instant recommendation in {analysisDuration}ms
            </span>
          )}
          {recommendation.provider === "fallback" && (
            "Based on package specifications (AI service unavailable)"
          )}
          {(recommendation.provider === "openai" || recommendation.provider === "anthropic") && (
            "Based on your package specifications and AI analysis"
          )}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex flex-col space-y-1">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Recommendation Confidence</span>
              <span className="text-sm font-medium">{confidencePercentage}%</span>
            </div>
            <Progress value={confidencePercentage} className="h-2" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <h4 className="text-sm font-semibold">Best Choice</h4>
              <p className="text-2xl font-bold text-primary">{recommendation.recommendedVehicleType}</p>
            </div>
            
            {recommendation.alternativeVehicleType && (
              <div className="space-y-1">
                <h4 className="text-sm font-semibold">Alternative</h4>
                <p className="text-lg font-medium text-muted-foreground">
                  {recommendation.alternativeVehicleType}
                </p>
              </div>
            )}
          </div>
          
          <div className="pt-4 border-t border-border">
            <h4 className="text-sm font-semibold mb-2">Reasoning</h4>
            <p className="text-sm text-muted-foreground">{recommendation.reasoning}</p>
          </div>
          
          <div className="pt-4 border-t border-border">
            <h4 className="text-sm font-semibold mb-2">Package Details</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-muted-foreground">Weight:</span>{" "}
                <span className="font-medium">{packageDetails.weight} kg</span>
              </div>
              
              {(packageDetails.width || (packageDetails.dimensions?.width)) && (
                <div>
                  <span className="text-muted-foreground">Width:</span>{" "}
                  <span className="font-medium">
                    {packageDetails.width || packageDetails.dimensions?.width} cm
                  </span>
                </div>
              )}
              
              {(packageDetails.height || (packageDetails.dimensions?.height)) && (
                <div>
                  <span className="text-muted-foreground">Height:</span>{" "}
                  <span className="font-medium">
                    {packageDetails.height || packageDetails.dimensions?.height} cm
                  </span>
                </div>
              )}
              
              {(packageDetails.length || (packageDetails.dimensions?.length)) && (
                <div>
                  <span className="text-muted-foreground">Length:</span>{" "}
                  <span className="font-medium">
                    {packageDetails.length || packageDetails.dimensions?.length} cm
                  </span>
                </div>
              )}
              
              <div>
                <span className="text-muted-foreground">Fragile:</span>{" "}
                <span className="font-medium">{packageDetails.fragile ? "Yes" : "No"}</span>
              </div>
              
              <div>
                <span className="text-muted-foreground">Distance:</span>{" "}
                <span className="font-medium">{packageDetails.distance} km</span>
              </div>
              
              {packageDetails.urgency && (
                <div>
                  <span className="text-muted-foreground">Urgency:</span>{" "}
                  <span className="font-medium capitalize">{packageDetails.urgency}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export { PackageRecommendation };