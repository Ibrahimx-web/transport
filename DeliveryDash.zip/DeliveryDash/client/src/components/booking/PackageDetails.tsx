import { useForm } from 'react-hook-form';
import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useDelivery } from '@/hooks/use-delivery';
import { useToast } from '@/hooks/use-toast';
import { PackageDetails as IPackageDetails } from '@/types';
import { apiRequest } from '@/lib/queryClient';
import { useLocation } from 'wouter';
import { useCurrency } from '@/lib/currency';

interface PackageDetailsFormProps {
  userId?: number;
}

export function PackageDetailsForm({ userId }: PackageDetailsFormProps) {
  const { packageDetails, pickup, delivery, vehicleTypeId, priceEstimation, setPackageDetails } = useDelivery();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const [_, navigate] = useLocation();
  const { formatCurrency, currency } = useCurrency();
  
  const { register, handleSubmit, formState: { errors } } = useForm<IPackageDetails>({
    defaultValues: packageDetails
  });
  
  const onSubmit = async (data: IPackageDetails) => {
    if (!userId) {
      toast({
        title: 'Authentication required',
        description: 'Please log in to book a transport',
        variant: 'destructive'
      });
      return;
    }
    
    if (!pickup || !delivery || !priceEstimation) {
      toast({
        title: 'Missing information',
        description: 'Please complete all required fields',
        variant: 'destructive'
      });
      return;
    }
    
    setPackageDetails(data);
    
    try {
      setIsSubmitting(true);
      
      // Create order
      const orderData = {
        userId,
        vehicleTypeId,
        status: 'pending',
        pickupLocation: pickup.address,
        pickupLat: pickup.lat,
        pickupLng: pickup.lng,
        deliveryLocation: delivery.address,
        deliveryLat: delivery.lat,
        deliveryLng: delivery.lng,
        distance: priceEstimation.distance,
        packageDescription: data.description || '',
        packageWeight: data.weight || 0,
        packageDimensions: data.dimensions || '',
        specialInstructions: data.specialInstructions || '',
        baseFare: priceEstimation.baseFare,
        distanceFare: priceEstimation.distanceFare,
        serviceFee: priceEstimation.serviceFee,
        totalFare: priceEstimation.totalFare
      };
      
      const response = await apiRequest('POST', '/api/orders', orderData);
      const orderResult = await response.json();
      
      toast({
        title: 'Order confirmed!',
        description: 'Proceeding to payment',
      });
      
      // Navigate to payment page
      navigate(`/payment/${orderResult.id}`);
    } catch (error) {
      toast({
        title: 'Failed to create order',
        description: error instanceof Error ? error.message : 'Please try again later',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="px-4 pb-4">
      <h2 className="font-bold text-lg mb-3">Package Details</h2>
      
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card className="mb-4">
          <CardContent className="pt-4">
            <div className="mb-3">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Package Description
              </label>
              <Input
                placeholder="e.g., Office furniture"
                {...register('description')}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Weight (kg)
                </label>
                <Input
                  type="number"
                  placeholder="0"
                  {...register('weight', { valueAsNumber: true })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Size (cm)
                </label>
                <Input
                  placeholder="L x W x H"
                  {...register('dimensions')}
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Special Instructions
              </label>
              <Textarea
                placeholder="Any special handling instructions"
                rows={2}
                className="resize-none"
                {...register('specialInstructions')}
              />
            </div>
          </CardContent>
        </Card>
        
        {/* Payment Summary */}
        {priceEstimation && (
          <Card className="mb-6">
            <CardContent className="pt-4">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Base Fare</span>
                <span className="font-medium">{formatCurrency(priceEstimation.baseFare)}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Distance ({priceEstimation.distance} km)</span>
                <span className="font-medium">{formatCurrency(priceEstimation.distanceFare)}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Service Fee</span>
                <span className="font-medium">{formatCurrency(priceEstimation.serviceFee)}</span>
              </div>
              <div className="border-t border-gray-200 my-2"></div>
              <div className="flex justify-between font-bold">
                <span>Total</span>
                <span className="text-primary">{formatCurrency(priceEstimation.totalFare)}</span>
              </div>
            </CardContent>
          </Card>
        )}
        
        <Button
          type="submit"
          className="w-full py-6"
          disabled={isSubmitting || !priceEstimation}
        >
          {isSubmitting ? 'Processing...' : 'Confirm & Book'}
        </Button>
      </form>
    </div>
  );
}
