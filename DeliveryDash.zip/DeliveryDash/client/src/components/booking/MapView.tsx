import { useState, useEffect, useMemo, useCallback } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow, Polyline } from '@react-google-maps/api';
import { DEFAULT_COORDINATES } from '@/lib/constants';
import { OrderLocation, OrderStatus, RouteInfo } from '@/types';
import { useRouteTracking } from '@/hooks/use-route-tracking';
import { formatDistanceToNow } from 'date-fns';
import { MapPin, Navigation, Clock, Truck, AlertTriangle, RefreshCw } from 'lucide-react';
import { useMapConfig, getFallbackApiKey } from '@/lib/mapService';

interface MapViewProps {
  pickupLocation?: OrderLocation;
  deliveryLocation?: OrderLocation;
  showDriverLocation?: boolean;
  driverLocation?: { lat: number; lng: number };
  orderStatus?: OrderStatus;
  distance?: number;
  showDetailedRoute?: boolean;
  height?: string;
}

export function MapView({
  pickupLocation,
  deliveryLocation,
  showDriverLocation = false,
  driverLocation,
  orderStatus = 'pending',
  distance = 0,
  showDetailedRoute = false,
  height = "h-48"
}: MapViewProps) {
  const [mapKey, setMapKey] = useState(0);
  const [selectedWaypoint, setSelectedWaypoint] = useState<number | null>(null);
  const [mapRef, setMapRef] = useState<google.maps.Map | null>(null);
  
  // Get map configuration from our centralized service
  const { config, isLoading: isConfigLoading, isError: isConfigError } = useMapConfig();
  
  // Get the API key based on the map configuration
  const apiKey = config?.isActive && config?.provider === 'google_maps' 
    ? config.apiKey 
    : getFallbackApiKey('google_maps');
  
  // Load Google Maps JavaScript API
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: apiKey || ''
  });
  
  // Use route tracking hook if detailed route is requested
  const { routeInfo, activeSegment } = showDetailedRoute && pickupLocation && deliveryLocation && driverLocation
    ? useRouteTracking({
        pickupLocation,
        deliveryLocation,
        driverLocation,
        orderStatus,
        distance
      })
    : { routeInfo: null, activeSegment: 0 };
  
  // Convert route data for Google Maps
  const simpleRoute = useMemo(() => {
    if (pickupLocation && deliveryLocation) {
      return [
        { lat: pickupLocation.lat, lng: pickupLocation.lng },
        { lat: deliveryLocation.lat, lng: deliveryLocation.lng }
      ];
    }
    return null;
  }, [pickupLocation, deliveryLocation]);

  // Process route data for Google Maps
  const routePaths = useMemo(() => {
    if (!showDetailedRoute || !routeInfo) {
      return null;
    }
    
    // Convert waypoints to Google Maps format
    const allPoints = routeInfo.waypoints.map(wp => ({ lat: wp.lat, lng: wp.lng }));
    
    // Split the route into completed and upcoming segments
    const completed = allPoints.slice(0, activeSegment + 1);
    const upcoming = allPoints.slice(activeSegment);
    
    return { completed, upcoming };
  }, [showDetailedRoute, routeInfo, activeSegment]);
  
  // Calculate map center and zoom
  const center = useMemo(() => {
    if (pickupLocation && deliveryLocation) {
      return {
        lat: (pickupLocation.lat + deliveryLocation.lat) / 2,
        lng: (pickupLocation.lng + deliveryLocation.lng) / 2,
      };
    }
    return { lat: DEFAULT_COORDINATES.lat, lng: DEFAULT_COORDINATES.lng };
  }, [pickupLocation, deliveryLocation]);
  
  // Force re-render when locations change significantly
  useEffect(() => {
    setMapKey(prev => prev + 1);
  }, [pickupLocation?.lat, pickupLocation?.lng, deliveryLocation?.lat, deliveryLocation?.lng]);
  
  // Save map reference
  const onMapLoad = useCallback((map: google.maps.Map) => {
    setMapRef(map);
  }, []);
  
  // Fit map bounds to show all relevant points
  useEffect(() => {
    if (!mapRef || !pickupLocation || !deliveryLocation) return;
    
    const bounds = new google.maps.LatLngBounds();
    
    // Add pickup and delivery locations
    bounds.extend({ lat: pickupLocation.lat, lng: pickupLocation.lng });
    bounds.extend({ lat: deliveryLocation.lat, lng: deliveryLocation.lng });
    
    // Add driver location if available
    if (showDriverLocation && driverLocation) {
      bounds.extend({ lat: driverLocation.lat, lng: driverLocation.lng });
    }
    
    // Fit bounds with padding
    mapRef.fitBounds(bounds, {
      top: 30,
      right: 30,
      bottom: 30,
      left: 30
    });
  }, [mapRef, pickupLocation, deliveryLocation, driverLocation, showDriverLocation]);
  
  // If API configuration is still loading
  if (isConfigLoading) {
    return (
      <div className={`relative ${height} w-full flex items-center justify-center bg-gray-50`}>
        <div className="flex flex-col items-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-2"></div>
          <p className="text-sm text-muted-foreground">Loading map configuration...</p>
        </div>
      </div>
    );
  }
  
  // If no API key is available
  if (!apiKey) {
    return (
      <div className={`relative ${height} w-full flex items-center justify-center bg-gray-50`}>
        <div className="text-center max-w-md px-4">
          <AlertTriangle className="h-6 w-6 text-amber-500 mx-auto mb-2" />
          <p className="text-red-500 font-medium mb-1">No map API key configured</p>
          <p className="text-sm text-muted-foreground">
            Please configure a Google Maps API key in admin settings.
          </p>
        </div>
      </div>
    );
  }
  
  // If map is still loading
  if (!isLoaded) {
    return (
      <div className={`relative ${height} w-full flex items-center justify-center bg-gray-50`}>
        <div className="flex flex-col items-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-2"></div>
          <p className="text-sm text-muted-foreground">Loading map...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className={`relative ${height} w-full overflow-hidden rounded-md`} key={mapKey}>
      <GoogleMap
        mapContainerStyle={{ width: '100%', height: '100%' }}
        center={center}
        zoom={12}
        options={{
          fullscreenControl: false,
          streetViewControl: false,
          mapTypeControl: false,
          zoomControl: true
        }}
        onLoad={onMapLoad}
      >
        {/* Pickup location marker */}
        {pickupLocation && pickupLocation.lat !== 0 && (
          <Marker
            position={{ lat: pickupLocation.lat, lng: pickupLocation.lng }}
            icon={{
              url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="10" fill="#3b82f6" stroke="white" stroke-width="2" />
                  <path d="M12 17v-10M7 12h10" stroke="white" stroke-width="2" stroke-linecap="round" />
                </svg>`
              ),
              scaledSize: new google.maps.Size(30, 30)
            }}
            onClick={() => setSelectedWaypoint(-1)}
          />
        )}
        
        {/* Delivery location marker */}
        {deliveryLocation && deliveryLocation.lat !== 0 && (
          <Marker
            position={{ lat: deliveryLocation.lat, lng: deliveryLocation.lng }}
            icon={{
              url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="10" fill="#10b981" stroke="white" stroke-width="2" />
                  <path d="M8 12l3 3l5-5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                </svg>`
              ),
              scaledSize: new google.maps.Size(30, 30)
            }}
            onClick={() => setSelectedWaypoint(-2)}
          />
        )}
        
        {/* Driver location marker */}
        {showDriverLocation && driverLocation && (
          <Marker
            position={{ lat: driverLocation.lat, lng: driverLocation.lng }}
            icon={{
              url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="10" fill="#ef4444" stroke="white" stroke-width="2" />
                  <path d="M7 12h10M12 17v-10" stroke="white" stroke-width="2" stroke-linecap="round" />
                </svg>`
              ),
              scaledSize: new google.maps.Size(40, 40)
            }}
            onClick={() => setSelectedWaypoint(-3)}
          />
        )}
        
        {/* Waypoint markers if detailed route is enabled */}
        {showDetailedRoute && routeInfo?.waypoints && routeInfo.waypoints.map((waypoint, index) => {
          // Skip first and last waypoints (pickup/delivery)
          if (index === 0 || index === routeInfo.waypoints.length - 1) return null;
          
          return (
            <Marker
              key={`waypoint-${index}`}
              position={{ lat: waypoint.lat, lng: waypoint.lng }}
              icon={{
                url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="6" fill="${waypoint.isVisited ? '#10b981' : '#e5e7eb'}" 
                            stroke="${waypoint.isVisited ? '#ffffff' : '#d1d5db'}" stroke-width="2" />
                  </svg>`
                ),
                scaledSize: new google.maps.Size(16, 16)
              }}
              onClick={() => setSelectedWaypoint(index)}
            />
          );
        })}
        
        {/* Route lines */}
        {showDetailedRoute && routePaths ? (
          <>
            {/* Completed segment - solid green line */}
            {routePaths.completed.length > 1 && (
              <Polyline
                path={routePaths.completed}
                options={{
                  strokeColor: '#10B981', // Green for completed route
                  strokeOpacity: 0.8,
                  strokeWeight: 4
                }}
              />
            )}
            
            {/* Upcoming segment - dashed blue line */}
            {routePaths.upcoming.length > 1 && (
              <Polyline
                path={routePaths.upcoming}
                options={{
                  strokeColor: '#6366F1', // Indigo for upcoming route
                  strokeOpacity: 0.8,
                  strokeWeight: 3,
                  icons: [{
                    icon: {
                      path: 'M 0,-1 0,1',
                      strokeOpacity: 1,
                      scale: 3
                    },
                    offset: '0',
                    repeat: '10px'
                  }]
                }}
              />
            )}
          </>
        ) : (
          // Simple route visualization if detailed not available
          simpleRoute && simpleRoute.length > 1 && (
            <Polyline
              path={simpleRoute}
              options={{
                strokeColor: '#6366F1', // Indigo for simple route
                strokeOpacity: 0.7,
                strokeWeight: 3,
                icons: [{
                  icon: {
                    path: 'M 0,-1 0,1',
                    strokeOpacity: 1,
                    scale: 3
                  },
                  offset: '0',
                  repeat: '10px'
                }]
              }}
            />
          )
        )}
        
        {/* Info windows for waypoints */}
        {selectedWaypoint !== null && (
          <>
            {/* Pickup location info */}
            {selectedWaypoint === -1 && pickupLocation && (
              <InfoWindow
                position={{ lat: pickupLocation.lat, lng: pickupLocation.lng }}
                onCloseClick={() => setSelectedWaypoint(null)}
              >
                <div className="p-2 text-xs max-w-[200px]">
                  <p className="font-semibold">Pickup Location</p>
                  <p className="text-gray-500 mt-1">{pickupLocation.address}</p>
                </div>
              </InfoWindow>
            )}
            
            {/* Delivery location info */}
            {selectedWaypoint === -2 && deliveryLocation && (
              <InfoWindow
                position={{ lat: deliveryLocation.lat, lng: deliveryLocation.lng }}
                onCloseClick={() => setSelectedWaypoint(null)}
              >
                <div className="p-2 text-xs max-w-[200px]">
                  <p className="font-semibold">Delivery Location</p>
                  <p className="text-gray-500 mt-1">{deliveryLocation.address}</p>
                </div>
              </InfoWindow>
            )}
            
            {/* Driver location info */}
            {selectedWaypoint === -3 && driverLocation && routeInfo?.eta && (
              <InfoWindow
                position={{ lat: driverLocation.lat, lng: driverLocation.lng }}
                onCloseClick={() => setSelectedWaypoint(null)}
              >
                <div className="p-2 text-xs max-w-[200px]">
                  <p className="font-semibold flex items-center gap-1">
                    <Truck className="w-3 h-3" /> Driver Location
                  </p>
                  <p className="text-gray-500 flex items-center gap-1 mt-1">
                    <Clock className="w-3 h-3" /> ETA: {formatDistanceToNow(routeInfo.eta)}
                  </p>
                </div>
              </InfoWindow>
            )}
            
            {/* Waypoint info */}
            {selectedWaypoint >= 0 && routeInfo?.waypoints && (
              <InfoWindow
                position={{ 
                  lat: routeInfo.waypoints[selectedWaypoint].lat, 
                  lng: routeInfo.waypoints[selectedWaypoint].lng 
                }}
                onCloseClick={() => setSelectedWaypoint(null)}
              >
                <div className="p-2 text-xs max-w-[200px]">
                  <p className="font-semibold">Waypoint {selectedWaypoint}</p>
                  <p className="text-gray-500 mt-1">
                    {routeInfo.waypoints[selectedWaypoint].isVisited 
                      ? 'Visited' 
                      : 'Not yet visited'}
                  </p>
                </div>
              </InfoWindow>
            )}
          </>
        )}
      </GoogleMap>
      
      {/* Route progress overlay */}
      {showDetailedRoute && routeInfo && (
        <div className="absolute bottom-2 left-2 right-2 bg-white/80 backdrop-blur-sm rounded-md p-2 text-xs">
          <div className="flex justify-between mb-1">
            <span className="font-medium">Delivery Progress</span>
            <span className="font-medium">{routeInfo.progress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-1.5">
            <div 
              className="bg-primary h-1.5 rounded-full" 
              style={{ width: `${routeInfo.progress}%` }}
            />
          </div>
          {routeInfo.eta && (
            <div className="flex items-center gap-1 mt-1 text-gray-700">
              <Clock className="h-3 w-3" /> 
              <span>ETA: {formatDistanceToNow(routeInfo.eta)}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}