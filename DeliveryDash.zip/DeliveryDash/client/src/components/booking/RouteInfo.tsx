import { OrderLocation } from '@/types';
import { useDelivery } from '@/hooks/use-delivery';
import { MapPin, LocateFixed, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

interface RouteInfoProps {
  pickup?: OrderLocation;
  delivery?: OrderLocation;
}

export function RouteInfo({ pickup, delivery }: RouteInfoProps) {
  const { detectCurrentLocation, isDetectingLocation } = useDelivery();
  const [showingLocationOptions, setShowingLocationOptions] = useState(false);
  
  const handleDetectLocation = async () => {
    await detectCurrentLocation();
    setShowingLocationOptions(false);
  };
  
  return (
    <div className="p-4 bg-white shadow-sm relative">
      <div className="flex justify-between items-center">
        <div className="flex-1 relative">
          <div className="flex items-center gap-1">
            <p className="text-sm text-gray-500">Pickup</p>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-5 w-5 rounded-full"
              onClick={() => setShowingLocationOptions(!showingLocationOptions)}
            >
              <MapPin className="h-3 w-3" />
            </Button>
          </div>
          <p className="font-medium truncate">
            {pickup?.address || 'Select pickup location'}
          </p>
          
          {/* Location detection popup */}
          {showingLocationOptions && (
            <div className="absolute top-full left-0 mt-1 bg-white shadow-md rounded-md p-2 z-10 w-64">
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-full justify-start p-2 h-auto text-sm"
                onClick={handleDetectLocation}
                disabled={isDetectingLocation}
              >
                {isDetectingLocation ? (
                  <Loader2 className="h-3 w-3 mr-2 animate-spin" />
                ) : (
                  <LocateFixed className="h-3 w-3 mr-2" />
                )}
                {isDetectingLocation ? 'Detecting location...' : 'Use my current location'}
              </Button>
            </div>
          )}
        </div>
        <div className="px-3">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right text-gray-400">
            <path d="M5 12h14"/>
            <path d="m12 5 7 7-7 7"/>
          </svg>
        </div>
        <div className="flex-1">
          <p className="text-sm text-gray-500">Delivery</p>
          <p className="font-medium truncate">
            {delivery?.address || 'Select delivery location'}
          </p>
        </div>
      </div>
      
      {/* Distance and estimated time if both locations are set */}
      {pickup && delivery && pickup.lat !== 0 && delivery.lat !== 0 && (
        <div className="mt-3 pt-3 border-t border-gray-100 text-xs text-gray-500 flex justify-between">
          <span>Distance will be calculated in kilometers</span>
          <span>Price based on distance</span>
        </div>
      )}
    </div>
  );
}
