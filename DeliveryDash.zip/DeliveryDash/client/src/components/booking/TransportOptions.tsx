import { useQuery } from '@tanstack/react-query';
import { useDelivery } from '@/hooks/use-delivery';
import { VehicleType } from '@/types';
import { DEFAULT_VEHICLE_TYPES } from '@/lib/constants';
import { cn } from '@/lib/utils';
import { useCurrency } from '@/lib/currency';

export function TransportOptions() {
  const { vehicleTypeId, setVehicleTypeId, calculatePriceEstimation } = useDelivery();
  const { formatCurrency, currency } = useCurrency();
  
  const { data: vehicleTypes = DEFAULT_VEHICLE_TYPES } = useQuery<VehicleType[]>({
    queryKey: ['/api/vehicle-types'],
    initialData: DEFAULT_VEHICLE_TYPES,
  });
  
  const handleVehicleChange = async (id: number) => {
    setVehicleTypeId(id);
    await calculatePriceEstimation(vehicleTypes);
  };
  
  const getIconForVehicle = (iconName: string) => {
    switch (iconName) {
      case 'bicycle':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary text-lg">
            <circle cx="18.5" cy="17.5" r="3.5"/><circle cx="5.5" cy="17.5" r="3.5"/><circle cx="15" cy="5" r="1"/><path d="M12 17.5V14l-3-3 4-3 2 3h2"/></svg>
        );
      case 'motorcycle':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary text-lg">
            <circle cx="18.5" cy="17.5" r="3.5"/><circle cx="5.5" cy="17.5" r="3.5"/><path d="M10.5 17.5 H14"/><path d="M5.5 14 L9 9 H13.5 L10.5 17.5"/><path d="M18.5 14 L15 9"/></svg>
        );
      case 'truck-pickup':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary text-lg">
            <path d="M4 12V6a2 2 0 0 1 2-2h8l4 4v4"/><path d="M2 12h1"/><rect width="10" height="8" x="9" y="12" rx="2"/><circle cx="14" cy="20" r="2"/><path d="M5 12v-2"/></svg>
        );
      case 'shuttle-van':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary text-lg">
            <path d="M3 8h13l2 4h3a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-1a3 3 0 0 1-3 3 3 3 0 0 1-3-3h-4a3 3 0 0 1-3 3 3 3 0 0 1-3-3H3a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/></svg>
        );
      case 'truck':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary text-lg">
            <path d="M10 17h4V5H2v12h3"/><path d="M20 17h2v-3.34a4 4 0 0 0-1.17-2.83L19 9h-5"/><path d="M14 17h1"/><circle cx="7.5" cy="17.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/></svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary text-lg">
            <circle cx="18.5" cy="17.5" r="3.5"/><circle cx="5.5" cy="17.5" r="3.5"/><path d="M15 7h2c2 0 3 1 3 3v7"/><path d="M9 17H4V7h5V4"/><path d="M4 11h9"/></svg>
        );
    }
  };
  
  return (
    <div className="p-4">
      <h2 className="font-bold text-lg mb-3">Select Transport Type</h2>
      
      <div className="grid grid-cols-2 gap-3 mb-4">
        {vehicleTypes.map((vehicle) => (
          <label key={vehicle.id} className="relative">
            <input
              type="radio"
              name="vehicle-type"
              className="sr-only"
              checked={vehicle.id === vehicleTypeId}
              onChange={() => handleVehicleChange(vehicle.id)}
            />
            <div
              className={cn(
                'p-4 rounded-lg border-2 flex flex-col items-center transition-all cursor-pointer',
                vehicle.id === vehicleTypeId
                  ? 'border-primary bg-primary/5'
                  : 'border-gray-200'
              )}
            >
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                {getIconForVehicle(vehicle.icon)}
              </div>
              <p className="font-medium">{vehicle.name}</p>
              <p className="text-xs text-gray-500">Up to {vehicle.maxWeight}kg</p>
              <p className="font-bold mt-1">{formatCurrency(vehicle.baseFare)}</p>
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}
