import * as React from "react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { UserType, VehicleType } from "@/types";
import UserForm, { UserFormData } from "./UserForm";
import { fileToBase64 } from "@/lib/utils";

interface UserFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  isSubmitting: boolean;
  title: string;
  description?: string;
  defaultValues?: Partial<UserFormData>;
  vehicleTypes: VehicleType[];
  isEdit?: boolean;
}

export default function UserFormModal({
  isOpen,
  onClose,
  onSubmit,
  isSubmitting,
  title,
  description,
  defaultValues,
  vehicleTypes,
  isEdit = false,
}: UserFormModalProps) {
  const handleSubmit = async (data: UserFormData) => {
    try {
      // Convert files to base64 if they exist
      const formData: any = { ...data };
      
      if (data.profilePicture instanceof File) {
        formData.profilePicture = await fileToBase64(data.profilePicture);
      }
      
      if (data.driversLicense instanceof File) {
        formData.driversLicense = await fileToBase64(data.driversLicense);
      }

      // Submit the data with base64 encoded files
      onSubmit(formData);
    } catch (error) {
      console.error("Error processing files:", error);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        
        <UserForm
          defaultValues={defaultValues}
          vehicleTypes={vehicleTypes}
          onSubmit={handleSubmit}
          isSubmitting={isSubmitting}
          showAdminOption={true}
          isEdit={isEdit}
          submitButtonText={isEdit ? "Update User" : "Create User"}
        />
        
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}