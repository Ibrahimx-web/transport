import * as React from "react";
import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserType, UserRegistration, VehicleType } from "@/types";
import { Truck, User, ShieldAlert } from "lucide-react";

// Define the schema for user form validation
export const userFormSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters").max(50),
  password: z.string().min(6, "Password must be at least 6 characters"),
  fullName: z.string().min(3, "Full name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Phone number is required"),
  userType: z.enum(["customer", "delivery", "admin"] as const),
  vehicleTypeId: z.number().optional(),
  licensePlateNumber: z.string().min(3, "License plate number is required").optional(),
  vehicleRegistrationNumber: z.string().min(3, "Vehicle registration number is required").optional(),
  profilePicture: z.instanceof(File).optional(),
  driversLicense: z.instanceof(File).optional(),
  adminCode: z.string().optional(),
});

export type UserFormData = z.infer<typeof userFormSchema>;

interface UserFormProps {
  defaultValues?: Partial<UserFormData>;
  vehicleTypes: VehicleType[];
  onSubmit: (data: UserFormData) => void;
  isSubmitting: boolean;
  showAdminOption?: boolean;
  isEdit?: boolean;
  submitButtonText?: string;
}

export default function UserForm({
  defaultValues,
  vehicleTypes,
  onSubmit,
  isSubmitting,
  showAdminOption = false,
  isEdit = false,
  submitButtonText = "Create User"
}: UserFormProps) {
  const [userType, setUserType] = useState<UserType>(defaultValues?.userType || "customer");

  // Setup the form with default values
  const form = useForm<UserFormData>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      username: "",
      password: "",
      fullName: "",
      email: "",
      phone: "",
      userType: "customer",
      licensePlateNumber: "",
      vehicleRegistrationNumber: "",
      ...defaultValues
    },
  });

  // Handle file input
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, fieldName: 'profilePicture' | 'driversLicense') => {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue(fieldName, file);
    }
  };

  // Handle user type change
  const handleUserTypeChange = (value: string) => {
    setUserType(value as UserType);
    form.setValue("userType", value as UserType);
  };

  // Handle form submission
  const handleFormSubmit = (data: UserFormData) => {
    // If delivery user selected but no vehicle type, license plate, or vehicle registration, show error
    if (data.userType === "delivery") {
      if (!data.vehicleTypeId) {
        form.setError("vehicleTypeId", {
          type: "manual",
          message: "Please select your vehicle type",
        });
        return;
      }
      
      if (!data.licensePlateNumber) {
        form.setError("licensePlateNumber", {
          type: "manual",
          message: "License plate number is required",
        });
        return;
      }
      
      if (!data.vehicleRegistrationNumber) {
        form.setError("vehicleRegistrationNumber", {
          type: "manual",
          message: "Vehicle registration number is required",
        });
        return;
      }
    }
    
    onSubmit(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
        <Tabs defaultValue={userType} onValueChange={handleUserTypeChange}>
          <TabsList className={`grid w-full ${showAdminOption ? 'grid-cols-3' : 'grid-cols-2'} mb-6`}>
            <TabsTrigger value="customer" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Customer
            </TabsTrigger>
            <TabsTrigger value="delivery" className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              Delivery Partner
            </TabsTrigger>
            {showAdminOption && (
              <TabsTrigger value="admin" className="flex items-center gap-2 bg-slate-900 text-white">
                <ShieldAlert className="h-4 w-4" />
                Administrator
              </TabsTrigger>
            )}
          </TabsList>

          <FormField
            control={form.control}
            name="fullName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Full Name</FormLabel>
                <FormControl>
                  <Input placeholder="Enter full name" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="your@email.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone</FormLabel>
                  <FormControl>
                    <Input placeholder="Phone number" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Username</FormLabel>
                <FormControl>
                  <Input placeholder="Choose a username" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {!isEdit && (
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input 
                      type="password" 
                      placeholder="Create a strong password"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          <FormField
            control={form.control}
            name="userType"
            render={({ field }) => (
              <FormItem className="hidden">
                <FormControl>
                  <Input type="hidden" {...field} />
                </FormControl>
              </FormItem>
            )}
          />

          {/* Admin code field - Only for admins, and hidden for admin creating other users */}
          {userType === "admin" && !isEdit && !showAdminOption && (
            <FormField
              control={form.control}
              name="adminCode"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Administrator Code</FormLabel>
                  <FormControl>
                    <Input 
                      type="password" 
                      placeholder="Enter administrator authorization code"
                      {...field} 
                      className="bg-slate-50 border-slate-300"
                    />
                  </FormControl>
                  <FormDescription>
                    Enter the secure code provided by system administrator
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          {/* Vehicle type selector for delivery partners */}
          {userType === "delivery" && (
            <>
              <FormField
                control={form.control}
                name="vehicleTypeId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vehicle Type</FormLabel>
                    <Select
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      value={field.value?.toString()}
                      defaultValue={defaultValues?.vehicleTypeId?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select vehicle type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {vehicleTypes.map((vehicle) => (
                          <SelectItem 
                            key={vehicle.id} 
                            value={vehicle.id.toString()}
                          >
                            {vehicle.name} (max {vehicle.maxWeight}kg)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Select the vehicle used for deliveries
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="licensePlateNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>License Plate Number</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter vehicle license plate" {...field} />
                    </FormControl>
                    <FormDescription>
                      Enter the license plate number of the delivery vehicle
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="vehicleRegistrationNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vehicle Registration Number</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter vehicle registration number" {...field} />
                    </FormControl>
                    <FormDescription>
                      Enter the registration/identification number of the vehicle
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {!isEdit && (
                <>
                  {/* Profile Picture Upload */}
                  <FormField
                    control={form.control}
                    name="profilePicture"
                    render={() => (
                      <FormItem>
                        <FormLabel>Profile Picture</FormLabel>
                        <FormControl>
                          <Input 
                            type="file" 
                            accept="image/*"
                            onChange={(e) => handleFileChange(e, 'profilePicture')}
                          />
                        </FormControl>
                        <FormDescription>
                          Upload a clear photo of the delivery partner
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Driver's License Upload */}
                  <FormField
                    control={form.control}
                    name="driversLicense"
                    render={() => (
                      <FormItem>
                        <FormLabel>Driver's License</FormLabel>
                        <FormControl>
                          <Input 
                            type="file" 
                            accept="image/*"
                            onChange={(e) => handleFileChange(e, 'driversLicense')}
                          />
                        </FormControl>
                        <FormDescription>
                          Upload a photo of the valid driver's license
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </>
              )}
            </>
          )}

          <Button 
            type="submit" 
            className="w-full" 
            disabled={isSubmitting}
          >
            {isSubmitting ? "Processing..." : submitButtonText}
          </Button>
        </Tabs>
      </form>
    </Form>
  );
}