import { useState } from 'react';
import { Share, Copy, Check, ExternalLink } from 'lucide-react';
import { 
  Button,
  ButtonProps
} from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from '@/components/ui/tooltip';
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface ShareDeliveryLinkProps extends ButtonProps {
  orderId: number;
  className?: string;
  variant?: "default" | "ghost" | "outline" | "secondary" | "destructive" | "link";
  size?: "default" | "sm" | "lg" | "icon";
  showLabel?: boolean;
}

export function ShareDeliveryLink({
  orderId,
  className,
  variant = "secondary",
  size = "default",
  showLabel = true,
  ...props
}: ShareDeliveryLinkProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [popoverOpen, setPopoverOpen] = useState(false);

  // Generate the shareable URL
  const shareableUrl = `${window.location.origin}/track/${orderId}`;

  // Handle copy to clipboard
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareableUrl);
      setCopied(true);
      toast({
        title: "Link copied!",
        description: "Tracking link has been copied to clipboard"
      });

      // Reset the copied state after 2 seconds
      setTimeout(() => {
        setCopied(false);
      }, 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please copy the link manually",
        variant: "destructive"
      });
    }
  };

  // Handle native sharing when available
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Track Delivery #${orderId}`,
          text: `Track your delivery in real-time. Delivery #${orderId}`,
          url: shareableUrl
        });
        toast({
          title: "Shared!",
          description: "Link has been shared"
        });
      } catch (err) {
        // User cancelled or sharing failed
        if (err instanceof Error && err.name !== 'AbortError') {
          toast({
            title: "Sharing failed",
            description: "Please use the copy link option instead",
            variant: "destructive"
          });
        }
      }
    } else {
      // If native sharing is not available, open the popover
      setPopoverOpen(true);
    }
  };

  // Button to open in a new tab
  const openInNewTab = () => {
    window.open(shareableUrl, '_blank');
  };

  return (
    <div className={cn("inline-flex", className)}>
      {navigator.share ? (
        // Use native sharing if available (most mobile devices)
        <Button
          variant={variant}
          size={size}
          onClick={handleShare}
          className={cn("gap-1", className)}
          {...props}
        >
          <Share className="h-4 w-4" />
          {showLabel && <span>Share</span>}
        </Button>
      ) : (
        // Use popover for platforms without native sharing
        <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
          <PopoverTrigger asChild>
            <Button
              variant={variant}
              size={size}
              className={cn("gap-1", className)}
              {...props}
            >
              <Share className="h-4 w-4" />
              {showLabel && <span>Share</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-72 p-4" side="top">
            <div className="space-y-4">
              <h3 className="font-medium text-sm">Share tracking link</h3>
              <div className="flex gap-2">
                <Input 
                  value={shareableUrl} 
                  readOnly 
                  className="text-sm h-9"
                />
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-9 w-9"
                        onClick={handleCopy}
                      >
                        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">
                      <p>Copy to clipboard</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <div className="flex justify-between pt-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-xs"
                  onClick={openInNewTab}
                >
                  <ExternalLink className="h-3 w-3 mr-1" />
                  Open in new tab
                </Button>
                <Button 
                  variant="secondary" 
                  size="sm" 
                  className="text-xs"
                  onClick={() => setPopoverOpen(false)}
                >
                  Done
                </Button>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      )}
    </div>
  );
}