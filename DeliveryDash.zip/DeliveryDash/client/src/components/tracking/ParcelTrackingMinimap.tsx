import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow, Polyline } from '@react-google-maps/api';
import { useMapConfig, getFallbackApiKey } from '@/lib/mapService';
import { Order, RouteInfo } from '@/types';
import { getOrderStatusName } from '@/lib/utils';
import { Truck, Package, Navigation, CircleDotDashed } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { LoadingAnimation } from '@/components/ui/loading-animation';
import { cn } from '@/lib/utils';

interface ParcelTrackingMinimapProps {
  order: Order;
  driverLocation?: { lat: number; lng: number };
  routeInfo?: RouteInfo | null; 
  className?: string;
  height?: string;
  activeSegment?: number;
  progress?: number;
  onMapLoad?: (map: google.maps.Map) => void;
  showControls?: boolean;
}

const mapContainerStyle = {
  width: '100%',
  height: '100%',
  borderRadius: 'inherit'
};

export function ParcelTrackingMinimap({
  order,
  driverLocation,
  routeInfo,
  className,
  height = "h-[200px]",
  activeSegment = 0,
  progress = 0,
  onMapLoad,
  showControls = false
}: ParcelTrackingMinimapProps) {
  const [mapRef, setMapRef] = useState<google.maps.Map | null>(null);
  const [showPickupInfo, setShowPickupInfo] = useState(false);
  const [showDeliveryInfo, setShowDeliveryInfo] = useState(false);
  const [showDriverInfo, setShowDriverInfo] = useState(false);
  
  // Get map configuration
  const { config } = useMapConfig();
  
  // Get the API key based on the map configuration
  const apiKey = config?.isActive && config?.provider === 'google_maps' 
    ? config.apiKey 
    : getFallbackApiKey('google_maps');
  
  // Load Google Maps JavaScript API
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: apiKey || ''
  });
  
  // Handle map load
  const handleMapLoad = useCallback((map: google.maps.Map) => {
    setMapRef(map);
    if (onMapLoad) onMapLoad(map);
  }, [onMapLoad]);
  
  // Fit map to show all relevant locations
  useEffect(() => {
    if (mapRef) {
      const bounds = new google.maps.LatLngBounds();
      
      // Add pickup and delivery locations
      bounds.extend(new google.maps.LatLng(order.pickupLat, order.pickupLng));
      bounds.extend(new google.maps.LatLng(order.deliveryLat, order.deliveryLng));
      
      // Add driver location if available
      if (driverLocation) {
        bounds.extend(new google.maps.LatLng(driverLocation.lat, driverLocation.lng));
      }
      
      // Fit the map to these bounds with some padding
      mapRef.fitBounds(bounds, { top: 30, right: 30, bottom: 30, left: 30 });
      
      // Set a minimum zoom level to avoid excessive zoom on nearby points
      if (mapRef) {
        const listener = mapRef.addListener('idle', () => {
          const zoom = mapRef.getZoom();
      if (zoom !== undefined && zoom > 15) {
            mapRef.setZoom(15);
          }
          if (mapRef) {
            google.maps.event.removeListener(listener);
          }
        });
      }
    }
  }, [mapRef, order, driverLocation]);
  
  // Process route data for display
  const processedRouteData = useMemo(() => {
    if (!routeInfo) return null;
    
    // Prepare colors for route segments
    const routeSegments = routeInfo.segments.map((segment, index) => {
      // Determine segment color
      const isActive = index === activeSegment;
      const isCompleted = index < activeSegment;
      
      let color = '#6b7280'; // Default color (gray-500)
      if (isActive) {
        color = '#3b82f6'; // Active segment (blue-500)
      } else if (isCompleted) {
        color = '#16a34a'; // Completed segment (green-600)
      }
      
      // If this is the active segment, we need to split it based on progress
      if (isActive && progress > 0 && progress < 1) {
        // Find the point where we need to split the path
        const totalPoints = segment.path.length;
        const splitIndex = Math.floor(totalPoints * progress);
        
        // Create the completed part of the active segment
        const completedPart = {
          path: segment.path.slice(0, splitIndex + 1),
          color: '#3b82f6', // Blue for active segment
          weight: 4,
          opacity: 1.0
        };
        
        // Create the incomplete part of the active segment
        const incompletePart = {
          path: segment.path.slice(splitIndex),
          color: '#6b7280', // Gray for incomplete part
          weight: 4,
          opacity: 0.7
        };
        
        return [completedPart, incompletePart];
      }
      
      // Regular segment (not split)
      return [{
        path: segment.path,
        color,
        weight: 4,
        opacity: isActive || isCompleted ? 1.0 : 0.7
      }];
    });
    
    // Flatten the array of segments
    return routeSegments.flat();
  }, [routeInfo, activeSegment, progress]);
  
  // Loading state
  if (!isLoaded) {
    return (
      <div className={cn("w-full overflow-hidden rounded-lg border bg-gray-100 flex items-center justify-center", height, className)}>
        <LoadingAnimation size="sm" text="Loading map..." />
      </div>
    );
  }
  
  // Map content
  return (
    <div className={cn("w-full overflow-hidden rounded-lg border relative", height, className)}>
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        zoom={12}
        options={{
          disableDefaultUI: !showControls,
          zoomControl: showControls,
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: false,
          clickableIcons: false,
          styles: [
            {
              featureType: "poi",
              elementType: "labels",
              stylers: [{ visibility: "off" }]
            }
          ]
        }}
        onLoad={handleMapLoad}
      >
        {/* Draw route if available */}
        {processedRouteData && processedRouteData.map((segment, index) => (
          <Polyline
            key={`segment-${index}`}
            path={segment.path}
            options={{
              strokeColor: segment.color,
              strokeWeight: segment.weight,
              strokeOpacity: segment.opacity,
            }}
          />
        ))}
        
        {/* Pickup location marker */}
        <Marker
          position={{ lat: order.pickupLat, lng: order.pickupLng }}
          icon={{
            path: google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: '#3b82f6', // blue-500
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
          }}
          onClick={() => setShowPickupInfo(true)}
        />
        
        {/* Show pickup info window */}
        {showPickupInfo && (
          <InfoWindow
            position={{ lat: order.pickupLat, lng: order.pickupLng }}
            onCloseClick={() => setShowPickupInfo(false)}
          >
            <div className="p-1 max-w-[200px]">
              <div className="font-medium text-sm mb-1">Pickup Point</div>
              <div className="text-xs text-gray-500">{order.pickupLocation}</div>
            </div>
          </InfoWindow>
        )}
        
        {/* Delivery location marker */}
        <Marker
          position={{ lat: order.deliveryLat, lng: order.deliveryLng }}
          icon={{
            path: google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: '#16a34a', // green-600
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
          }}
          onClick={() => setShowDeliveryInfo(true)}
        />
        
        {/* Show delivery info window */}
        {showDeliveryInfo && (
          <InfoWindow
            position={{ lat: order.deliveryLat, lng: order.deliveryLng }}
            onCloseClick={() => setShowDeliveryInfo(false)}
          >
            <div className="p-1 max-w-[200px]">
              <div className="font-medium text-sm mb-1">Delivery Point</div>
              <div className="text-xs text-gray-500">{order.deliveryLocation}</div>
            </div>
          </InfoWindow>
        )}
        
        {/* Driver location marker */}
        {driverLocation && (
          <Marker
            position={{ lat: driverLocation.lat, lng: driverLocation.lng }}
            icon={{
              url: '/truck-icon.svg', // You can use a custom truck icon here
              scaledSize: new google.maps.Size(32, 32)
            }}
            onClick={() => setShowDriverInfo(true)}
          />
        )}
        
        {/* Show driver info window */}
        {showDriverInfo && driverLocation && (
          <InfoWindow
            position={{ lat: driverLocation.lat, lng: driverLocation.lng }}
            onCloseClick={() => setShowDriverInfo(false)}
          >
            <div className="p-1 max-w-[200px]">
              <div className="font-medium text-sm mb-1">Driver Location</div>
              <Badge variant="outline" className="text-[10px] py-0 h-4">
                {getOrderStatusName(order.status)}
              </Badge>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
      
      {/* Map overlay with order status */}
      <div className="absolute top-2 left-2 right-2 flex justify-between">
        <Badge 
          variant="outline" 
          className="bg-white/90 backdrop-blur-sm text-xs shadow-sm"
        >
          Order #{order.id}
        </Badge>
        <Badge 
          variant="outline" 
          className={cn(
            "bg-white/90 backdrop-blur-sm text-xs shadow-sm",
            order.status === 'delivered' ? "border-green-200 text-green-600" :
            order.status === 'on_way_to_delivery' ? "border-amber-200 text-amber-600" :
            "border-blue-200 text-blue-600"
          )}
        >
          {getOrderStatusName(order.status)}
        </Badge>
      </div>
    </div>
  );
}