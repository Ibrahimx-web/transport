import React, { useState, useCallback, useEffect } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow } from '@react-google-maps/api';
import { useMapConfig, getFallbackApiKey } from '@/lib/mapService';
import { Order } from '@/types';
import { Badge } from '@/components/ui/badge';
import { Truck, Package, CalendarDays, Navigation, Info } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { getOrderStatusName } from '@/lib/utils';
import { cn } from '@/lib/utils';

interface OrderHistoryMinimapProps {
  orders: Order[];
  className?: string;
  height?: string;
  interactive?: boolean;
  onOrderSelect?: (order: Order) => void;
}

const mapContainerStyle = {
  width: '100%',
  height: '100%',
  borderRadius: 'inherit'
};

export function OrderHistoryMinimap({ 
  orders, 
  className, 
  height = "h-[200px]",
  interactive = true,
  onOrderSelect 
}: OrderHistoryMinimapProps) {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [mapRef, setMapRef] = useState<google.maps.Map | null>(null);
  
  // Get map configuration
  const { config } = useMapConfig();
  
  // Get the API key based on the map configuration
  const apiKey = config?.isActive && config?.provider === 'google_maps' 
    ? config.apiKey 
    : getFallbackApiKey('google_maps');
  
  // Load Google Maps JavaScript API
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: apiKey || ''
  });
  
  // Handle map load
  const onMapLoad = useCallback((map: google.maps.Map) => {
    setMapRef(map);
  }, []);
  
  // Fit map to show all delivery locations
  useEffect(() => {
    if (mapRef && orders.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      
      orders.forEach(order => {
        // Add delivery location to bounds
        bounds.extend(new google.maps.LatLng(order.deliveryLat, order.deliveryLng));
      });
      
      // Fit the map to these bounds with some padding
      mapRef.fitBounds(bounds, { top: 20, right: 20, bottom: 20, left: 20 });
      
      // Set a minimum zoom level to avoid excessive zoom on single points
      if (mapRef) {
        const listener = mapRef.addListener('idle', () => {
          const zoom = mapRef.getZoom();
          if (zoom !== undefined && zoom > 15) {
            mapRef.setZoom(15);
          }
          if (mapRef) {
            google.maps.event.removeListener(listener);
          }
        });
      }
    }
  }, [mapRef, orders]);
  
  // Handle marker click
  const handleMarkerClick = (order: Order) => {
    setSelectedOrder(order);
    if (interactive && onOrderSelect) {
      onOrderSelect(order);
    }
  };
  
  // Get marker icon color based on order status
  const getMarkerColor = (status: string): string => {
    switch (status) {
      case 'delivered':
        return '#16a34a'; // green-600
      case 'on_way_to_delivery':
      case 'package_picked_up':
        return '#f59e0b'; // amber-500
      case 'arrived_at_pickup':
      case 'on_way_to_pickup':
      case 'driver_assigned':
        return '#3b82f6'; // blue-500
      default:
        return '#6b7280'; // gray-500
    }
  };
  
  if (!isLoaded) {
    return (
      <div className={cn("w-full overflow-hidden rounded-lg border bg-gray-100 flex items-center justify-center", height, className)}>
        <div className="text-sm text-muted-foreground">Loading map...</div>
      </div>
    );
  }
  
  if (orders.length === 0) {
    return (
      <div className={cn("w-full overflow-hidden rounded-lg border bg-gray-50 flex items-center justify-center", height, className)}>
        <div className="flex flex-col items-center text-center p-4">
          <Package className="h-8 w-8 text-muted-foreground/50 mb-2" />
          <div className="text-sm text-muted-foreground">No order history to display</div>
        </div>
      </div>
    );
  }
  
  return (
    <div className={cn("w-full overflow-hidden rounded-lg border relative", height, className)}>
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        zoom={12}
        options={{
          disableDefaultUI: !interactive,
          zoomControl: interactive,
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: false,
          clickableIcons: false,
          styles: [
            {
              featureType: "poi",
              elementType: "labels",
              stylers: [{ visibility: "off" }]
            }
          ]
        }}
        onLoad={onMapLoad}
      >
        {orders.map((order) => (
          <Marker
            key={order.id}
            position={{ lat: order.deliveryLat, lng: order.deliveryLng }}
            icon={{
              path: google.maps.SymbolPath.CIRCLE,
              scale: 8,
              fillColor: getMarkerColor(order.status),
              fillOpacity: 1,
              strokeColor: '#ffffff',
              strokeWeight: 2,
            }}
            onClick={() => handleMarkerClick(order)}
          />
        ))}
        
        {selectedOrder && (
          <InfoWindow
            position={{ lat: selectedOrder.deliveryLat, lng: selectedOrder.deliveryLng }}
            onCloseClick={() => setSelectedOrder(null)}
          >
            <div className="p-2 max-w-[200px]">
              <div className="font-medium text-sm flex items-center justify-between gap-2 mb-1">
                <div className="flex items-center gap-1">
                  <Truck className="h-3 w-3 text-primary" />
                  <span>Order #{selectedOrder.id}</span>
                </div>
                <Badge variant="outline" className="text-[10px] h-4 px-1">
                  {getOrderStatusName(selectedOrder.status)}
                </Badge>
              </div>
              <div className="text-xs text-gray-500 mb-1 truncate">
                {selectedOrder.deliveryLocation}
              </div>
              <div className="text-xs text-gray-500 flex items-center gap-1">
                <CalendarDays className="h-3 w-3" />
                <span>{formatDistanceToNow(new Date(selectedOrder.createdAt), { addSuffix: true })}</span>
              </div>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
      
      {/* Subtle info text at bottom */}
      {interactive && (
        <div className="absolute bottom-1 left-0 right-0 flex justify-center">
          <div className="bg-white/80 backdrop-blur-sm text-xs text-gray-500 px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
            <Info className="h-3 w-3" />
            <span>Click markers for details</span>
          </div>
        </div>
      )}
    </div>
  );
}