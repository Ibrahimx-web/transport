import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bike, Truck, TruckIcon, Car, MapPin } from 'lucide-react';
import { Order, RouteInfo } from '@/types';
import { ORDER_STATUS_LABELS } from '@/lib/constants';

interface AnimatedVehicleTrackerProps {
  order: Order;
  routeInfo?: RouteInfo | null;
  driverLocation?: { lat: number; lng: number };
  className?: string;
}

export function AnimatedVehicleTracker({ 
  order, 
  routeInfo, 
  driverLocation,
  className 
}: AnimatedVehicleTrackerProps) {
  const [animationProgress, setAnimationProgress] = useState(0);
  
  // Get the vehicle icon based on vehicle type
  const getVehicleIcon = () => {
    switch (order.vehicleTypeId) {
      case 1: // Bike
        return <Bike className="text-white" />;
      case 2: // Motorbike
        return <Bike className="text-white" />;
      case 3: // Pickup
        return <Truck className="text-white" />;
      case 4: // Van
        return <Car className="text-white" />;
      case 5: // Lorry
        return <TruckIcon className="text-white" />;
      default:
        return <Car className="text-white" />;
    }
  };
  
  // Update animation progress based on route progress
  useEffect(() => {
    if (routeInfo) {
      setAnimationProgress(routeInfo.progress);
    }
  }, [routeInfo]);
  
  // Format ETA
  const formatETA = (eta?: Date) => {
    if (!eta) return 'Calculating...';
    
    return eta.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };
  
  // Calculate estimated remaining time in minutes
  const getRemainingTime = () => {
    if (!routeInfo || !routeInfo.eta) return '';
    
    const now = new Date();
    const eta = new Date(routeInfo.eta);
    const diffMs = eta.getTime() - now.getTime();
    const diffMinutes = Math.round(diffMs / 60000);
    
    if (diffMinutes <= 0) return 'Arriving now';
    if (diffMinutes === 1) return '1 minute';
    return `${diffMinutes} minutes`;
  };
  
  return (
    <div className={`bg-white rounded-lg shadow-sm overflow-hidden ${className}`}>
      {/* Progress path visualization */}
      <div className="p-4 pb-0">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-semibold">Live Tracking</h3>
          {routeInfo && routeInfo.eta && (
            <div className="text-sm text-gray-500">
              ETA: <span className="font-medium">{formatETA(routeInfo.eta)}</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Animated map path */}
      <div className="relative h-24 bg-gray-50 overflow-hidden">
        {/* Path line */}
        <div className="absolute top-1/2 left-0 right-0 h-1 bg-gray-200 transform -translate-y-1/2" />
        
        {/* Colored progress line */}
        <motion.div 
          className="absolute top-1/2 left-0 h-1 bg-primary transform -translate-y-1/2"
          initial={{ width: '0%' }}
          animate={{ width: `${animationProgress}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
        
        {/* Pickup point */}
        <div className="absolute top-1/2 left-5 transform -translate-y-1/2 z-10">
          <div className="w-3 h-3 rounded-full bg-primary border-2 border-white shadow-sm" />
          <div className="absolute bottom-5 left-1/2 transform -translate-x-1/2 bg-primary text-white text-xs px-2 py-1 rounded whitespace-nowrap">
            Pickup
          </div>
        </div>
        
        {/* Delivery point */}
        <div className="absolute top-1/2 right-5 transform -translate-y-1/2 z-10">
          <div className="w-3 h-3 rounded-full bg-green-500 border-2 border-white shadow-sm" />
          <div className="absolute bottom-5 left-1/2 transform -translate-x-1/2 bg-green-500 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
            Delivery
          </div>
        </div>
        
        {/* Vehicle position */}
        <motion.div 
          className="absolute top-1/2 transform -translate-y-1/2 z-20"
          initial={{ left: '5%' }}
          animate={{ left: `${5 + (animationProgress * 0.9)}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.div 
            className="w-10 h-10 rounded-full bg-primary flex items-center justify-center shadow-lg"
            animate={{ 
              y: [0, -3, 0],
              rotate: [0, 2, 0, -2, 0]
            }}
            transition={{ 
              repeat: Infinity, 
              duration: 2
            }}
          >
            {getVehicleIcon()}
          </motion.div>
          
          {/* Animated shadow */}
          <div className="absolute bottom-0 left-1/2 transform translate-y-1 -translate-x-1/2 w-6 h-1 bg-black/20 rounded-full blur-sm"></div>
        </motion.div>
      </div>
      
      {/* Status and remaining time */}
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="mr-2 p-1.5 bg-primary/10 rounded-full">
              <MapPin className="w-4 h-4 text-primary" />
            </div>
            <div className="text-sm text-gray-700">
              {order.status === 'on_way_to_pickup' 
                ? 'Heading to pickup'
                : order.status === 'on_way_to_delivery'
                  ? 'Heading to delivery'
                  : ORDER_STATUS_LABELS[order.status] || 'Tracking delivery'}
            </div>
          </div>
          
          {routeInfo && routeInfo.eta && order.status !== 'delivered' && (
            <motion.div 
              className="text-sm font-medium text-gray-900"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              {getRemainingTime()}
            </motion.div>
          )}
          
          {order.status === 'delivered' && (
            <motion.div 
              className="flex items-center text-green-600 text-sm font-medium"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              <span className="mr-1">●</span>
              <span>Delivered</span>
            </motion.div>
          )}
        </div>
        
        {/* Distance information */}
        {routeInfo && (
          <div className="mt-2 text-xs text-gray-500 flex justify-between">
            <span>
              Total Distance: <span className="font-medium">{order.distance.toFixed(1)} km</span>
            </span>
            <span>
              {animationProgress < 100 
                ? `${animationProgress}% completed` 
                : 'Delivery completed'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}