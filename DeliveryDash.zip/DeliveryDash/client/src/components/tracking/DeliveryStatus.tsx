import { useState, useEffect } from 'react';
import { User, Phone, MessageCircle, MapPin } from 'lucide-react';
import { Order, OrderStatusUpdate } from '@/types';
import { formatDate, ORDER_STATUS_LABELS } from '@/lib/constants';
import { useCurrency } from '@/lib/currency';
import { ShareDeliveryLink } from './ShareDeliveryLink';

interface DeliveryStatusProps {
  order: Order;
  statusUpdates?: OrderStatusUpdate[];
}

const DRIVER_INFO = {
  name: 'David Wilson',
  vehicle: {
    type: 'Pickup Truck',
    license: 'ABC 123'
  }
};

export function DeliveryStatus({ order, statusUpdates = [] }: DeliveryStatusProps) {
  const { formatCurrency } = useCurrency();
  
  // Status timeline data
  const allStatuses = [
    'driver_assigned',
    'on_way_to_pickup',
    'arrived_at_pickup',
    'package_picked_up',
    'on_way_to_delivery',
    'delivered'
  ];
  
  // Get the icon for the vehicle type
  const getVehicleIcon = () => {
    switch (order.vehicleTypeId) {
      case 1: // Bike
        return <i className="fas fa-bicycle text-primary text-xl"></i>;
      case 2: // Motorbike
        return <i className="fas fa-motorcycle text-primary text-xl"></i>;
      case 3: // Pickup
        return <i className="fas fa-truck-pickup text-primary text-xl"></i>;
      case 4: // Van
        return <i className="fas fa-shuttle-van text-primary text-xl"></i>;
      case 5: // Lorry
        return <i className="fas fa-truck text-primary text-xl"></i>;
      default:
        return <i className="fas fa-truck text-primary text-xl"></i>;
    }
  };
  
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };
  
  return (
    <div className="p-4 bg-white shadow-sm">
      <div className="flex items-start mb-4">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mr-3">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
            <path d="M4 12V6a2 2 0 0 1 2-2h8l4 4v4"/>
            <path d="M2 12h1"/>
            <rect width="10" height="8" x="9" y="12" rx="2"/>
            <circle cx="14" cy="20" r="2"/>
            <path d="M5 12v-2"/>
          </svg>
        </div>
        <div>
          <h3 className="font-bold">{DRIVER_INFO.vehicle.type}</h3>
          <p className="text-sm text-gray-500">License: {DRIVER_INFO.vehicle.license}</p>
          <div className="flex items-center mt-1">
            <div className="w-2 h-2 rounded-full bg-success animate-pulse mr-1.5"></div>
            <span className="text-sm font-medium text-success">
              {ORDER_STATUS_LABELS[order.status]}
            </span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center mb-4">
        <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mr-3">
          <User className="h-5 w-5 text-gray-500" />
        </div>
        <div>
          <h3 className="font-medium">{DRIVER_INFO.name}</h3>
          <p className="text-sm text-gray-500">Driver</p>
        </div>
        <div className="ml-auto flex space-x-2">
          <button className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
            <Phone className="h-4 w-4 text-primary" />
          </button>
          <button className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
            <MessageCircle className="h-4 w-4 text-primary" />
          </button>
        </div>
      </div>
      
      {/* Route Information */}
      <div className="mb-4 bg-gray-50 p-3 rounded-lg">
        <div className="flex items-start space-x-2 mb-2">
          <div className="mt-1">
            <div className="w-3 h-3 rounded-full bg-primary"></div>
          </div>
          <div>
            <p className="text-xs text-gray-500">Pickup Location</p>
            <p className="text-sm font-medium">{order.pickupLocation}</p>
          </div>
        </div>
        
        <div className="border-l-2 border-dashed border-gray-300 h-4 ml-1.5"></div>
        
        <div className="flex items-start space-x-2">
          <div className="mt-1">
            <div className="w-3 h-3 rounded-full bg-success"></div>
          </div>
          <div>
            <p className="text-xs text-gray-500">Delivery Location</p>
            <p className="text-sm font-medium">{order.deliveryLocation}</p>
          </div>
        </div>
        
        <div className="mt-2 flex justify-between items-center text-sm">
          <div className="flex items-center">
            <MapPin className="h-3 w-3 text-gray-500 mr-1" />
            <span>{order.distance.toFixed(1)} km</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-medium">{formatCurrency(order.fare)}</span>
            <ShareDeliveryLink 
              orderId={order.id} 
              variant="outline" 
              size="sm" 
              className="h-7"
            />
          </div>
        </div>
      </div>
      
      {/* Status Timeline */}
      <div className="border-l-2 border-primary/20 pl-4 ml-2 space-y-6 py-2">
        {allStatuses.map((status, index) => {
          const statusUpdate = statusUpdates?.find(update => update.status === status);
          const isCompleted = statusUpdate !== undefined;
          
          return (
            <div className="relative" key={status}>
              <div className={`absolute -left-6 top-0 w-4 h-4 rounded-full ${isCompleted ? 'bg-primary' : 'bg-gray-300'}`}></div>
              <h4 className={`font-medium ${isCompleted ? '' : 'text-gray-400'}`}>
                {ORDER_STATUS_LABELS[status]}
              </h4>
              <p className={`text-sm ${isCompleted ? 'text-gray-500' : 'text-gray-400'}`}>
                {isCompleted ? formatTime(statusUpdate.timestamp) : '-'}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
