import { Card, CardContent } from '@/components/ui/card';
import { Order } from '@/types';
import { useCurrency } from '@/lib/currency';

interface PackageInfoProps {
  order: Order;
}

export function PackageInfo({ order }: PackageInfoProps) {
  const { formatCurrency } = useCurrency();
  return (
    <div className="p-4">
      <Card>
        <CardContent className="pt-4">
          <h3 className="font-bold mb-2">Package Details</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <p className="text-gray-500">Description</p>
              <p className="font-medium">{order.packageDescription || 'Not specified'}</p>
            </div>
            <div>
              <p className="text-gray-500">Weight</p>
              <p className="font-medium">{order.packageWeight ? `${order.packageWeight} kg` : 'Not specified'}</p>
            </div>
            <div>
              <p className="text-gray-500">Dimensions</p>
              <p className="font-medium">{order.packageDimensions || 'Not specified'}</p>
            </div>
            <div>
              <p className="text-gray-500">Order ID</p>
              <p className="font-medium">#{order.id.toString().padStart(5, '0')}</p>
            </div>
          </div>
          
          <h3 className="font-bold mb-2 mt-4">Pricing Details</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <p className="text-gray-500">Base Fare</p>
              <p className="font-medium">{formatCurrency(order.baseFare)}</p>
            </div>
            <div>
              <p className="text-gray-500">Distance Fare</p>
              <p className="font-medium">{formatCurrency(order.distanceFare)}</p>
            </div>
            <div>
              <p className="text-gray-500">Service Fee</p>
              <p className="font-medium">{formatCurrency(order.serviceFee)}</p>
            </div>
            <div>
              <p className="text-gray-500">Total Fare</p>
              <p className="font-medium font-bold text-primary">{formatCurrency(order.totalFare)}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
