import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bike, Package, Truck, CheckCircle, Truck as TruckDelivery, MapPin, Navigation } from 'lucide-react';
import { Order, OrderStatusUpdate } from '@/types';
import { ORDER_STATUS_LABELS } from '@/lib/constants';

interface AnimatedDeliveryProgressProps {
  order: Order;
  statusUpdates: OrderStatusUpdate[];
  className?: string;
}

export function AnimatedDeliveryProgress({ order, statusUpdates, className }: AnimatedDeliveryProgressProps) {
  const [activeStatusIndex, setActiveStatusIndex] = useState(0);
  
  // All possible statuses in sequence
  const allStatuses = [
    'driver_assigned',
    'on_way_to_pickup',
    'arrived_at_pickup',
    'package_picked_up',
    'on_way_to_delivery',
    'delivered'
  ];
  
  // Find current active status index
  useEffect(() => {
    const currentStatusIndex = allStatuses.findIndex(status => status === order.status);
    if (currentStatusIndex >= 0) {
      setActiveStatusIndex(currentStatusIndex);
    }
  }, [order.status]);
  
  // Map status to icon
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'driver_assigned':
        return <Bike className="h-6 w-6" />;
      case 'on_way_to_pickup':
        return <Navigation className="h-6 w-6" />;
      case 'arrived_at_pickup':
        return <MapPin className="h-6 w-6" />;
      case 'package_picked_up':
        return <Package className="h-6 w-6" />;
      case 'on_way_to_delivery':
        return <TruckDelivery className="h-6 w-6" />;
      case 'delivered':
        return <CheckCircle className="h-6 w-6" />;
      default:
        return <Truck className="h-6 w-6" />;
    }
  };
  
  // Format time for display
  const formatTime = (dateString?: string) => {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };
  
  // Find timestamp for a status
  const getStatusTimestamp = (status: string) => {
    const update = statusUpdates.find(u => u.status === status);
    return update ? formatTime(update.timestamp) : '';
  };
  
  // Return progress percentage based on current status
  const getProgressPercentage = () => {
    if (activeStatusIndex < 0) return 0;
    return Math.min(100, Math.round((activeStatusIndex / (allStatuses.length - 1)) * 100));
  };
  
  return (
    <div className={`bg-white rounded-lg shadow-sm p-5 ${className}`}>
      <h3 className="text-lg font-semibold mb-4">Delivery Progress</h3>
      
      {/* Progress bar */}
      <div className="relative h-2 bg-gray-100 rounded-full mb-6 overflow-hidden">
        <motion.div 
          className="absolute top-0 left-0 h-full bg-primary rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${getProgressPercentage()}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>
      
      {/* Status steps */}
      <div className="space-y-8 relative">
        {/* Vertical line connecting steps */}
        <div className="absolute left-3.5 top-3 bottom-3 w-0.5 bg-gray-200 z-0" />
        
        {allStatuses.map((status, index) => {
          const isActive = index <= activeStatusIndex;
          const isCurrent = index === activeStatusIndex;
          const timestamp = getStatusTimestamp(status);
          
          return (
            <div className="relative z-10 flex items-start" key={status}>
              <motion.div 
                className={`flex items-center justify-center rounded-full p-1.5 ${
                  isActive ? 'bg-primary text-white' : 'bg-gray-200 text-gray-400'
                } ${isCurrent ? 'ring-4 ring-primary/20' : ''}`}
                initial={{ scale: 0.8, opacity: 0.5 }}
                animate={{ 
                  scale: isActive ? 1 : 0.8, 
                  opacity: isActive ? 1 : 0.5,
                }}
                transition={{ duration: 0.3 }}
              >
                {getStatusIcon(status)}
              </motion.div>
              
              <div className="ml-4 flex-1">
                <div className="flex items-center justify-between">
                  <motion.h4 
                    className={`font-medium text-base ${isActive ? 'text-gray-900' : 'text-gray-400'}`}
                    initial={{ opacity: 0.5 }}
                    animate={{ opacity: isActive ? 1 : 0.5 }}
                  >
                    {ORDER_STATUS_LABELS[status]}
                  </motion.h4>
                  
                  <motion.span 
                    className={`text-sm ${isActive ? 'text-gray-500' : 'text-gray-400'}`}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: isActive ? 1 : 0 }}
                  >
                    {timestamp || '-'}
                  </motion.span>
                </div>
                
                {isCurrent && (
                  <AnimatePresence>
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="mt-1 text-sm text-gray-500 overflow-hidden"
                    >
                      {status === 'on_way_to_pickup' && (
                        <p>Driver is en route to pickup your package</p>
                      )}
                      {status === 'arrived_at_pickup' && (
                        <p>Driver has arrived at the pickup location</p>
                      )}
                      {status === 'on_way_to_delivery' && (
                        <p>Package is on its way to the delivery address</p>
                      )}
                      {status === 'delivered' && (
                        <p>Your package has been delivered successfully</p>
                      )}
                    </motion.div>
                  </AnimatePresence>
                )}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Current status highlight */}
      {activeStatusIndex >= 0 && activeStatusIndex < allStatuses.length && (
        <motion.div 
          className="mt-6 p-4 rounded-lg bg-primary/5 border border-primary/10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center">
            <div className="mr-3 bg-primary rounded-full p-2 text-white">
              {getStatusIcon(allStatuses[activeStatusIndex])}
            </div>
            <div>
              <h4 className="font-semibold text-gray-900">
                {ORDER_STATUS_LABELS[allStatuses[activeStatusIndex]]}
              </h4>
              <p className="text-sm text-gray-500">
                {activeStatusIndex === allStatuses.length - 1 
                  ? 'Delivery completed!' 
                  : `${getProgressPercentage()}% complete`}
              </p>
            </div>
            
            {/* Animated pulse indicator if delivery is in progress */}
            {activeStatusIndex > 0 && activeStatusIndex < allStatuses.length - 1 && (
              <div className="ml-auto">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
                </span>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </div>
  );
}