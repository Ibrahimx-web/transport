import React, { useState } from 'react';
import { Order, RouteInfo, OrderStatusUpdate } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ParcelTrackingMinimap } from './ParcelTrackingMinimap';
import { formatDate, ORDER_STATUS_LABELS } from '@/lib/constants';
import { useCurrency } from '@/lib/currency';
import { 
  MapPin, 
  Clock, 
  TruckIcon, 
  PackageIcon, 
  ChevronDown, 
  ChevronUp,
  PhoneIcon,
  MessageSquare,
  Navigation
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface InteractiveTrackingCardProps {
  order: Order;
  statusUpdates?: OrderStatusUpdate[];
  driverLocation?: { lat: number; lng: number };
  routeInfo?: RouteInfo | null;
  activeSegment?: number;
  progress?: number;
  estimatedTimeRemaining?: number;
  className?: string;
  onContactDriver?: () => void;
  onSendMessage?: () => void;
  onViewFullMap?: () => void;
}

export function InteractiveTrackingCard({
  order,
  driverLocation,
  routeInfo,
  activeSegment = 0,
  progress = 0,
  estimatedTimeRemaining = 0,
  className,
  onContactDriver,
  onSendMessage,
  onViewFullMap
}: InteractiveTrackingCardProps) {
  const [expanded, setExpanded] = useState(true);
  const { formatCurrency } = useCurrency();
  
  // Format estimated time remaining
  const formatEstimatedTime = (minutes: number): string => {
    if (minutes <= 0) return 'Arriving now';
    if (minutes < 60) return `${Math.floor(minutes)} min`;
    
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = Math.floor(minutes % 60);
    
    if (remainingMinutes === 0) {
      return `${hours} hr`;
    }
    
    return `${hours} hr ${remainingMinutes} min`;
  };
  
  // Calculate overall delivery progress (0 to 100)
  const calculateOverallProgress = (): number => {
    if (order.status === 'delivered') return 100;
    if (!routeInfo) return 0;
    
    const totalSegments = routeInfo.segments.length;
    if (totalSegments === 0) return 0;
    
    // Calculate progress as a combination of completed segments and progress in current segment
    return Math.min(100, Math.round(((activeSegment + progress) / totalSegments) * 100));
  };
  
  // Get status badge styling
  const getStatusBadgeStyles = (status: string): string => {
    switch (status) {
      case 'delivered':
        return 'bg-green-50 text-green-600 border-green-200';
      case 'on_way_to_delivery':
      case 'package_picked_up':
        return 'bg-amber-50 text-amber-600 border-amber-200';
      case 'driver_assigned':
      case 'on_way_to_pickup':
      case 'arrived_at_pickup':
        return 'bg-blue-50 text-blue-600 border-blue-200';
      default:
        return 'bg-gray-50 text-gray-600 border-gray-200';
    }
  };
  
  return (
    <Card className={cn("w-full overflow-hidden", className)}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <PackageIcon className="h-5 w-5 text-primary" />
            <span>Order #{order.id.toString().padStart(4, '0')}</span>
          </CardTitle>
          <Badge 
            variant="outline" 
            className={cn("font-medium", getStatusBadgeStyles(order.status))}
          >
            {ORDER_STATUS_LABELS[order.status]}
          </Badge>
        </div>
      </CardHeader>
      
      {/* Expandable toggle control */}
      <div 
        className="px-4 py-1 flex items-center justify-between cursor-pointer border-t border-b border-gray-100"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center text-sm text-gray-500">
          <Clock className="h-4 w-4 mr-1" />
          <span>{formatDate(order.createdAt)}</span>
        </div>
        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </Button>
      </div>
      
      {expanded && (
        <>
          {/* Mini Map */}
          <ParcelTrackingMinimap 
            order={order}
            driverLocation={driverLocation}
            routeInfo={routeInfo}
            height="h-[180px]"
            activeSegment={activeSegment}
            progress={progress}
          />
          
          {/* Progress indicator */}
          <div className="p-4 pb-2">
            <div className="flex items-center justify-between mb-1 text-sm">
              <span className="font-medium">Delivery Progress</span>
              {order.status !== 'delivered' && estimatedTimeRemaining > 0 && (
                <div className="flex items-center text-xs text-gray-500">
                  <Clock className="h-3 w-3 mr-1" />
                  <span>ETA: {formatEstimatedTime(estimatedTimeRemaining)}</span>
                </div>
              )}
            </div>
            <Progress
              value={calculateOverallProgress()}
              className="h-2"
            />
          </div>
          
          <CardContent className="pt-2">
            {/* Locations */}
            <div className="space-y-3 mb-4">
              <div className="flex items-start gap-2">
                <div className="w-6 flex justify-center mt-0.5">
                  <div className="w-3 h-3 rounded-full bg-primary flex-shrink-0"></div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-0.5">Pickup</div>
                  <div className="text-sm">{order.pickupLocation}</div>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <div className="w-6 flex justify-center mt-0.5">
                  <div className="w-3 h-3 rounded-full bg-green-500 flex-shrink-0"></div>
                </div>
                <div>
                  <div className="text-xs text-gray-500 mb-0.5">Destination</div>
                  <div className="text-sm">{order.deliveryLocation}</div>
                </div>
              </div>
            </div>
            
            {/* Order details */}
            <div className="grid grid-cols-2 gap-2 mb-4">
              <div className="bg-gray-50 p-2 rounded-md">
                <div className="text-xs text-gray-500 mb-0.5">Distance</div>
                <div className="text-sm font-medium">{order.distance.toFixed(1)} km</div>
              </div>
              <div className="bg-gray-50 p-2 rounded-md">
                <div className="text-xs text-gray-500 mb-0.5">Total Fare</div>
                <div className="text-sm font-medium">{formatCurrency(order.fare)}</div>
              </div>
            </div>
            
            {/* Action buttons */}
            {order.status !== 'delivered' && (
              <div className="grid grid-cols-3 gap-2">
                {onContactDriver && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex items-center gap-1" 
                    onClick={onContactDriver}
                  >
                    <PhoneIcon className="h-3 w-3" />
                    <span>Call</span>
                  </Button>
                )}
                
                {onSendMessage && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex items-center gap-1" 
                    onClick={onSendMessage}
                  >
                    <MessageSquare className="h-3 w-3" />
                    <span>Message</span>
                  </Button>
                )}
                
                {onViewFullMap && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex items-center gap-1" 
                    onClick={onViewFullMap}
                  >
                    <Navigation className="h-3 w-3" />
                    <span>Full Map</span>
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </>
      )}
    </Card>
  );
}