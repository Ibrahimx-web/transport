import React, { useState, useEffect } from 'react';
import { useLoadScript, Libraries } from '@react-google-maps/api';
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  AlertTriangle, 
  CheckCircle, 
  Info,
  MapPin, 
  RefreshCw 
} from 'lucide-react';
import { 
  useMapConfig, 
  getProviderDisplayName, 
  getFallbackApiKey, 
  MapProvider, 
  getActiveMapProvider 
} from '@/lib/mapService';

const libraries: Libraries = ['places'];

const DEFAULT_MAP_CENTER = { lat: -1.286389, lng: 36.817223 }; // Nairobi, Kenya
const DEFAULT_ZOOM = 13;

export function SimpleMapTest() {
  const { toast } = useToast();
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);

  // Use our new map config hook
  const { config, isLoading, isError, error } = useMapConfig();
  
  // Get active provider, either from config or fallback
  const activeProvider: MapProvider = config?.isActive 
    ? config.provider 
    : getActiveMapProvider();
  
  // Get the appropriate API key based on the provider
  const apiKey = config?.isActive 
    ? config.apiKey 
    : getFallbackApiKey(activeProvider);

  // Load the appropriate map component based on provider
  const renderMapComponent = () => {
    // Common props for all map components
    const mapProps = {
      onLoad: handleMapLoad,
      onError: handleMapLoadError
    };
    
    switch (activeProvider) {
      case 'google_maps':
        return <GoogleMapsComponent apiKey={apiKey || ''} {...mapProps} />;
      case 'mapbox':
        return <MapboxComponent apiKey={apiKey || ''} {...mapProps} />;
      case 'osm':
        return <OSMComponent {...mapProps} />;
      default:
        return <GoogleMapsComponent apiKey={apiKey || ''} {...mapProps} />;
    }
  };

  // Handle map load success
  const handleMapLoad = () => {
    setMapLoaded(true);
    setMapError(null);
    toast({
      title: "Map Loaded",
      description: `${getProviderDisplayName(activeProvider)} loaded successfully.`,
    });
  };

  // Handle map load error
  const handleMapLoadError = (error: Error) => {
    console.error(`Error loading ${getProviderDisplayName(activeProvider)}:`, error);
    setMapError(error.message);
    toast({
      title: "Map Load Error",
      description: error.message || `Failed to load ${getProviderDisplayName(activeProvider)}.`,
      variant: "destructive",
    });
  };

  // Display map configuration information
  const renderMapConfigInfo = () => {
    if (isLoading) return null;
    
    if (config) {
      return (
        <div className="text-sm text-muted-foreground mb-4">
          <p>
            <span className="font-medium">Active provider:</span> {getProviderDisplayName(config.provider)}
          </p>
          {config.isDefault && (
            <p>
              <span className="font-medium">Status:</span> Default configuration
            </p>
          )}
        </div>
      );
    }
    
    return (
      <div className="text-sm text-amber-600 mb-4">
        <span className="font-medium">Using fallback API configuration</span>
      </div>
    );
  };

  // If the API config is loading
  if (isLoading) {
    return (
      <div className="w-full h-[300px] bg-gray-100 rounded-md flex items-center justify-center">
        <div className="text-center">
          <Skeleton className="h-8 w-36 mx-auto mb-2" />
          <Skeleton className="h-4 w-48 mx-auto" />
        </div>
      </div>
    );
  }

  // If the provider needs an API key and we don't have one
  if ((activeProvider === 'google_maps' || activeProvider === 'mapbox') && !apiKey) {
    return (
      <Alert className="mb-4">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>No API Key Found</AlertTitle>
        <AlertDescription>
          No {getProviderDisplayName(activeProvider)} API key has been configured. 
          Please add an API key in the form below to use {getProviderDisplayName(activeProvider)}.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-4">
      {renderMapConfigInfo()}
      
      {mapError ? (
        <Alert variant="destructive" className="mb-4">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Map API Error</AlertTitle>
          <AlertDescription>
            There was an error loading the {getProviderDisplayName(activeProvider)}. This may be due to an invalid API key or network issues.
            <div className="mt-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => window.location.reload()}
                className="mr-2"
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Retry
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      ) : (
        <Alert variant="default" className={mapLoaded ? 'bg-green-50 border-green-200' : 'bg-blue-50 border-blue-200'}>
          {mapLoaded ? (
            <CheckCircle className="h-4 w-4 text-green-500" />
          ) : (
            <Info className="h-4 w-4 text-blue-500" />
          )}
          <AlertTitle>
            {mapLoaded 
              ? `${getProviderDisplayName(activeProvider)} Successfully Loaded!` 
              : 'Initializing Map...'}
          </AlertTitle>
          <AlertDescription>
            {mapLoaded 
              ? `The map was loaded successfully. Your ${activeProvider !== 'osm' ? 'API key is' : 'configuration is'} working properly.` 
              : 'The map is in the process of initializing. This usually takes a few seconds.'}
          </AlertDescription>
        </Alert>
      )}

      <div 
        className="w-full h-[300px] rounded-md overflow-hidden border border-gray-200"
        id="map-container"
      >
        {renderMapComponent()}
      </div>
    </div>
  );
}

// Google Maps component
function GoogleMapsComponent({ 
  apiKey, 
  onLoad, 
  onError 
}: { 
  apiKey: string, 
  onLoad: () => void, 
  onError: (error: Error) => void 
}) {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: apiKey,
    libraries,
  });

  // If there was an error loading the script
  if (loadError) {
    useEffect(() => {
      onError(new Error(loadError.message));
    }, [loadError]);
    
    return (
      <div className="w-full h-full flex items-center justify-center bg-red-50 p-4 text-center">
        <p className="text-red-600">Failed to load Google Maps</p>
      </div>
    );
  }

  // If the script is still loading
  if (!isLoaded) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-50">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return <GoogleMap onMapLoad={onLoad} onMapError={onError} />;
}

function GoogleMap({ 
  onMapLoad, 
  onMapError 
}: { 
  onMapLoad: () => void, 
  onMapError: (error: Error) => void 
}) {
  const mapRef = React.useRef<HTMLDivElement>(null);
  
  React.useEffect(() => {
    if (!mapRef.current) return;

    try {
      // Create the map instance
      const map = new google.maps.Map(mapRef.current, {
        center: DEFAULT_MAP_CENTER,
        zoom: DEFAULT_ZOOM,
        mapTypeControl: true,
        streetViewControl: false,
        fullscreenControl: true,
      });

      // Add a marker at the center
      new google.maps.Marker({
        position: DEFAULT_MAP_CENTER,
        map,
        title: "Nairobi, Kenya",
        animation: google.maps.Animation.DROP,
      });

      // Call onLoad callback
      map.addListener('tilesloaded', () => {
        onMapLoad();
      });
    } catch (error) {
      onMapError(error as Error);
    }
  }, [onMapLoad, onMapError]);

  return <div ref={mapRef} style={{ width: '100%', height: '100%' }} />;
}

// Mapbox component
function MapboxComponent({ 
  apiKey, 
  onLoad, 
  onError 
}: { 
  apiKey: string, 
  onLoad: () => void, 
  onError: (error: Error) => void 
}) {
  const mapRef = React.useRef<HTMLDivElement>(null);
  const [mapScriptLoaded, setMapScriptLoaded] = useState(false);

  // Load Mapbox GL script dynamically
  useEffect(() => {
    if (window.mapboxgl) {
      setMapScriptLoaded(true);
      return;
    }

    const mapboxScript = document.createElement('script');
    mapboxScript.src = 'https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js';
    mapboxScript.async = true;
    mapboxScript.onload = () => setMapScriptLoaded(true);
    mapboxScript.onerror = () => onError(new Error('Failed to load Mapbox GL script'));
    
    // Also load the CSS
    const mapboxCss = document.createElement('link');
    mapboxCss.rel = 'stylesheet';
    mapboxCss.href = 'https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.css';
    
    document.head.appendChild(mapboxScript);
    document.head.appendChild(mapboxCss);
    
    return () => {
      // Clean up
      if (document.head.contains(mapboxScript)) {
        document.head.removeChild(mapboxScript);
      }
      if (document.head.contains(mapboxCss)) {
        document.head.removeChild(mapboxCss);
      }
    };
  }, []);

  // Initialize map once script is loaded
  useEffect(() => {
    if (!mapScriptLoaded || !mapRef.current || !window.mapboxgl) return;
    
    try {
      window.mapboxgl.accessToken = apiKey;
      
      const map = new window.mapboxgl.Map({
        container: mapRef.current,
        style: 'mapbox://styles/mapbox/streets-v12',
        center: [DEFAULT_MAP_CENTER.lng, DEFAULT_MAP_CENTER.lat],
        zoom: DEFAULT_ZOOM
      });
      
      // Add a marker
      new window.mapboxgl.Marker()
        .setLngLat([DEFAULT_MAP_CENTER.lng, DEFAULT_MAP_CENTER.lat])
        .addTo(map);
      
      map.on('load', () => {
        onLoad();
      });
      
      map.on('error', (e: any) => {
        onError(new Error(e.error?.message || 'Mapbox error'));
      });
      
      return () => {
        map.remove();
      };
    } catch (error) {
      onError(error as Error);
    }
  }, [mapScriptLoaded, apiKey]);

  if (!mapScriptLoaded) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-50">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return <div ref={mapRef} style={{ width: '100%', height: '100%' }} />;
}

// OpenStreetMap component using Leaflet
function OSMComponent({ 
  onLoad, 
  onError 
}: { 
  onLoad: () => void, 
  onError: (error: Error) => void 
}) {
  const mapRef = React.useRef<HTMLDivElement>(null);
  const [leafletLoaded, setLeafletLoaded] = useState(false);

  // Load Leaflet script dynamically
  useEffect(() => {
    if (window.L) {
      setLeafletLoaded(true);
      return;
    }

    const leafletScript = document.createElement('script');
    leafletScript.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    leafletScript.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
    leafletScript.crossOrigin = '';
    leafletScript.async = true;
    
    const leafletCss = document.createElement('link');
    leafletCss.rel = 'stylesheet';
    leafletCss.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    leafletCss.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
    leafletCss.crossOrigin = '';
    
    leafletScript.onload = () => setLeafletLoaded(true);
    leafletScript.onerror = () => onError(new Error('Failed to load Leaflet script'));
    
    document.head.appendChild(leafletCss);
    document.head.appendChild(leafletScript);
    
    return () => {
      // Clean up
      if (document.head.contains(leafletScript)) {
        document.head.removeChild(leafletScript);
      }
      if (document.head.contains(leafletCss)) {
        document.head.removeChild(leafletCss);
      }
    };
  }, []);

  // Initialize map once Leaflet is loaded
  useEffect(() => {
    if (!leafletLoaded || !mapRef.current || !window.L) return;
    
    try {
      const map = window.L.map(mapRef.current).setView(
        [DEFAULT_MAP_CENTER.lat, DEFAULT_MAP_CENTER.lng], 
        DEFAULT_ZOOM
      );
      
      // Add OpenStreetMap tile layer
      window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);
      
      // Add a marker
      window.L.marker([DEFAULT_MAP_CENTER.lat, DEFAULT_MAP_CENTER.lng])
        .addTo(map)
        .bindPopup('Nairobi, Kenya');
      
      // Fire the onLoad callback once the tiles are loaded
      map.on('load', () => {
        onLoad();
      });
      
      map.on('error', (e: any) => {
        onError(new Error(e.error || 'Leaflet error'));
      });
      
      // Make sure the map is properly sized
      setTimeout(() => {
        map.invalidateSize();
      }, 100);
      
      return () => {
        map.remove();
      };
    } catch (error) {
      onError(error as Error);
    }
  }, [leafletLoaded]);

  if (!leafletLoaded) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-50">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return <div ref={mapRef} style={{ width: '100%', height: '100%' }} />;
}