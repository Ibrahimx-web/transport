import { useState } from 'react';
import { AnimatedRouteProgress } from '@/components/delivery/AnimatedRouteProgress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Play, Pause, RotateCcw, Check } from 'lucide-react';

export function RouteVisualizationDemo() {
  const [progress, setProgress] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showDirections, setShowDirections] = useState(true);
  const [hasArrived, setHasArrived] = useState(false);
  
  // Nairobi example locations
  const pickupLocation = {
    lat: -1.286389, 
    lng: 36.817223,
    address: "CBD, Nairobi, Kenya"
  };
  
  const deliveryLocation = {
    lat: -1.269090, 
    lng: 36.843546,
    address: "Eastlands, Nairobi, Kenya"
  };
  
  // Simulate animation
  const startAnimation = () => {
    if (progress >= 100) {
      // Reset if we're already at 100%
      setProgress(0);
      setHasArrived(false);
    }
    
    setIsAnimating(true);
    
    // Use an interval to increment progress
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsAnimating(false);
          return 100;
        }
        return prev + 2; // Increment by 2% at a time
      });
    }, 200); // Update every 200ms
    
    // Cleanup interval on component unmount
    return () => clearInterval(interval);
  };
  
  const pauseAnimation = () => {
    setIsAnimating(false);
  };
  
  const resetAnimation = () => {
    setIsAnimating(false);
    setProgress(0);
    setHasArrived(false);
  };
  
  const handleArrived = () => {
    setHasArrived(true);
    setIsAnimating(false);
  };
  
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Route Visualization</CardTitle>
        </CardHeader>
        <CardContent>
          <AnimatedRouteProgress
            pickupLocation={pickupLocation}
            deliveryLocation={deliveryLocation}
            progress={progress}
            onArrived={handleArrived}
            showDirections={showDirections}
          />
          
          <div className="mt-4 space-y-4">
            {/* Progress control */}
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label>Progress: {progress.toFixed(0)}%</Label>
                {hasArrived && (
                  <span className="text-green-600 flex items-center gap-1 text-sm">
                    <Check className="h-4 w-4" />
                    Arrived
                  </span>
                )}
              </div>
              <Slider 
                value={[progress]} 
                max={100} 
                step={1}
                onValueChange={([value]) => {
                  setProgress(value);
                  if (value >= 100) {
                    setHasArrived(true);
                  } else {
                    setHasArrived(false);
                  }
                }}
              />
            </div>
            
            {/* Animation controls */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Switch 
                  id="show-directions" 
                  checked={showDirections}
                  onCheckedChange={setShowDirections}
                />
                <Label htmlFor="show-directions">Show directions</Label>
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={resetAnimation}
                >
                  <RotateCcw className="h-4 w-4 mr-1" />
                  Reset
                </Button>
                
                {isAnimating ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={pauseAnimation}
                  >
                    <Pause className="h-4 w-4 mr-1" />
                    Pause
                  </Button>
                ) : (
                  <Button
                    variant="default"
                    size="sm"
                    onClick={startAnimation}
                  >
                    <Play className="h-4 w-4 mr-1" />
                    {progress >= 100 ? "Restart" : "Start"} Animation
                  </Button>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}