import { RouteVisualizationDemo } from './RouteVisualizationDemo';
import ErrorBoundary from '@/components/error-boundary';
import { Map, Truck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { useState, useEffect } from 'react';

const FallbackComponent = () => {
  const [, setLocation] = useLocation();
  
  return (
    <div className="p-6 border rounded-lg bg-white text-center h-[400px] flex flex-col items-center justify-center">
      <div className="mb-4 bg-red-50 p-6 rounded-full inline-flex">
        <Map className="h-10 w-10 text-red-400" />
      </div>
      <h3 className="text-lg font-medium mb-2">Map visualization error</h3>
      <p className="text-gray-500 text-sm mb-4">
        There was a problem loading the map visualization. This could be due to a temporary issue.
      </p>
      <div className="flex gap-3">
        <Button 
          variant="outline" 
          onClick={() => setLocation('/delivery/dashboard')}
        >
          Return to Dashboard
        </Button>
        <Button 
          variant="default" 
          onClick={() => window.location.reload()}
        >
          Refresh Page
        </Button>
      </div>
    </div>
  );
};

export function SafeRouteVisualizationDemo() {
  const [hasError, setHasError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  
  useEffect(() => {
    // Reset error state when retrying
    if (retryCount > 0) {
      setHasError(false);
    }
  }, [retryCount]);
  
  // Render a simple fallback if we already tried multiple times
  if (hasError) {
    return (
      <div className="p-6 border rounded-lg bg-white h-[400px] flex flex-col items-center justify-center">
        <div className="mb-4 bg-amber-50 p-6 rounded-full inline-flex">
          <Truck className="h-10 w-10 text-amber-500" />
        </div>
        <h3 className="text-lg font-medium mb-2">Simplified Route View</h3>
        <p className="text-gray-500 text-sm mb-4 text-center max-w-xs">
          We're showing a simplified view due to map loading issues. Your delivery route is from downtown Nairobi to residential areas.
        </p>
        <div className="w-full max-w-xs my-4 relative">
          <div className="h-2 bg-gray-200 rounded-full w-full">
            <div className="h-2 bg-primary rounded-full" style={{ width: '65%' }}></div>
          </div>
          <div className="flex justify-between text-xs mt-1 text-gray-500">
            <span>Pickup</span>
            <span>65% Complete</span>
            <span>Delivery</span>
          </div>
        </div>
        <Button 
          variant="outline" 
          onClick={() => setRetryCount(c => c + 1)}
          className="mt-4"
        >
          Try Advanced Map Again
        </Button>
      </div>
    );
  }

  return (
    <ErrorBoundary 
      fallback={<FallbackComponent />}
      onError={() => setHasError(true)}
    >
      <RouteVisualizationDemo />
    </ErrorBoundary>
  );
}