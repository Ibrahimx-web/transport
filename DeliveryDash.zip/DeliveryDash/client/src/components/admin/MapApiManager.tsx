import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Map, 
  AlertTriangle, 
  RefreshCw, 
  Check, 
  ExternalLink, 
  Info 
} from "lucide-react";
import { SimpleMapTest } from '../test/SimpleMapTest';
import { MapProvider, updateLocalMapConfig, getProviderDisplayName } from '@/lib/mapService';

// Interface for Map API configuration
interface MapApiConfig {
  id: number;
  provider: MapProvider;
  isActive: boolean;
  isDefault: boolean;
  apiKey: string;
  createdAt: string;
  updatedAt: string;
}

// Ensure type safety for the array operations
type MapApiConfigArray = MapApiConfig[];

// Initial form state
const initialMapConfig = {
  provider: 'google_maps' as MapProvider,
  apiKey: '',
  isActive: true,
  isDefault: true
};

export function MapApiManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showMapTest, setShowMapTest] = useState(false);
  const [mapConfig, setMapConfig] = useState(initialMapConfig);
  
  // Fetch map API configurations
  const { 
    data: mapApiConfigs, 
    isLoading, 
    isError, 
    error,
    refetch 
  } = useQuery<MapApiConfigArray>({
    queryKey: ['/api/map-api-configs'],
    // Using onSuccess and catching errors in main query
    staleTime: 60000, // 1 minute
    retry: 1, // Only retry once for 404s
  });
  
  // Ensure mapApiConfigs is always an array for type safety
  const configs = Array.isArray(mapApiConfigs) ? mapApiConfigs : [];

  // Update state when configs are loaded
  useEffect(() => {
    // If we have a config and there's no form data yet, use the first active one or the first one
    if (configs.length > 0 && !mapConfig.apiKey) {
      // Find the default active config or just the first active one
      const defaultConfig = configs.find((c: MapApiConfig) => c.isDefault && c.isActive) || 
                            configs.find((c: MapApiConfig) => c.isActive) ||
                            configs[0];
                            
      setMapConfig({
        provider: defaultConfig.provider,
        apiKey: defaultConfig.apiKey,
        isActive: defaultConfig.isActive,
        isDefault: defaultConfig.isDefault
      });
      
      // Update localStorage with the active config for immediate use
      updateLocalMapConfig(defaultConfig);
    }
  }, [configs]);

  // Add/Update map API config mutation
  const saveMapConfigMutation = useMutation({
    mutationFn: async (data: typeof mapConfig) => {
      // Find the config to update if it exists
      let configToUpdate: MapApiConfig | undefined;
      
      if (configs.length > 0) {
        // Try to find an exact match to update
        configToUpdate = configs.find(c => c.provider === data.provider);
        
        // If we can't find a match for the provider, just update the first one
        if (!configToUpdate) {
          configToUpdate = configs[0];
        }
      }
      
      // If we have a config to update, update it, otherwise create a new one
      const method = configToUpdate ? 'PATCH' : 'POST';
      const endpoint = configToUpdate 
        ? `/api/map-api-configs/${configToUpdate.id}` 
        : '/api/map-api-configs';
      
      const response = await apiRequest(method, endpoint, data);
      return response.json();
    },
    onSuccess: (data) => {
      // Invalidate the map API config query to refetch the updated data
      queryClient.invalidateQueries({ queryKey: ['/api/map-api-configs'] });
      
      // Update localStorage with the new config for immediate use
      updateLocalMapConfig(data);
      
      // Show success toast
      toast({
        title: "Map API Configuration Saved",
        description: `The map provider has been set to ${getProviderDisplayName(data.provider)} and will be used throughout the application.`
      });
      
      // Force reload SimpleMapTest if it's showing
      if (showMapTest) {
        // Briefly hide and show the test map to force a reload
        setShowMapTest(false);
        setTimeout(() => setShowMapTest(true), 100);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save map API configuration.",
        variant: "destructive"
      });
    }
  });

  // Handle form input changes
  const handleInputChange = (field: string, value: any) => {
    setMapConfig({
      ...mapConfig,
      [field]: value
    });
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // If setting this as active and default, make sure to make other configs inactive/not default
    if (mapConfig.isActive && mapConfig.isDefault) {
      saveMapConfigMutation.mutate(mapConfig);
    } else {
      // Make sure we don't deactivate ALL map providers
      const otherActiveConfigs = configs.filter(c => 
        c.isActive && c.provider !== mapConfig.provider
      );
      
      if (!mapConfig.isActive && otherActiveConfigs.length === 0) {
        toast({
          title: "Configuration Error",
          description: "At least one map provider must be active. You cannot deactivate all providers.",
          variant: "destructive"
        });
        return;
      }
      
      // Otherwise proceed with the update
      saveMapConfigMutation.mutate(mapConfig);
    }
  };

  // Get provider instructions
  const getProviderInstructions = (provider: string) => {
    switch (provider) {
      case 'google_maps':
        return (
          <>
            <p className="mb-2">
              To get a Google Maps API key, follow these steps:
            </p>
            <ol className="list-decimal ml-5 space-y-1 text-sm">
              <li>Go to the <a href="https://console.cloud.google.com/google/maps-apis/overview" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline flex items-center">
                Google Cloud Console 
                <ExternalLink className="h-3 w-3 ml-1" />
              </a></li>
              <li>Create a new project or select an existing one</li>
              <li>Enable the Maps JavaScript API, Directions API, and Geocoding API</li>
              <li>Create an API key from the Credentials page</li>
              <li>Set up API restrictions if needed for security</li>
            </ol>
          </>
        );
      case 'mapbox':
        return (
          <>
            <p className="mb-2">
              To get a Mapbox access token:
            </p>
            <ol className="list-decimal ml-5 space-y-1 text-sm">
              <li>Sign up or log in to <a href="https://account.mapbox.com/auth/signup/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline flex items-center">
                Mapbox
                <ExternalLink className="h-3 w-3 ml-1" />
              </a></li>
              <li>Navigate to your account's Access Tokens page</li>
              <li>Create a new token with the appropriate scopes</li>
            </ol>
          </>
        );
      case 'osm':
        return (
          <p>
            OpenStreetMap doesn't require an API key for basic usage, but you may want to specify a custom tile server.
          </p>
        );
      default:
        return (
          <p>Select a map provider to see specific instructions.</p>
        );
    }
  };

  // If there's an error loading the configs
  if (isError && configs.length === 0) {
    return (
      <Alert variant="destructive" className="mb-6">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Failed to load map configurations</AlertTitle>
        <AlertDescription>
          There was an error loading the map API configurations. This might be because the backend API is not yet implemented.
          <div className="mt-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => refetch()}
              className="mr-2"
            >
              <RefreshCw className="h-4 w-4 mr-1" />
              Retry
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Map API Settings</h3>
        <Button
          variant="outline"
          onClick={() => setShowMapTest(!showMapTest)}
        >
          {showMapTest ? 'Hide Test Map' : 'Test Map Integration'}
        </Button>
      </div>

      {showMapTest && (
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <CardTitle>Map API Test</CardTitle>
            <CardDescription>
              Test the current map configuration to ensure it's working properly.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <SimpleMapTest />
          </CardContent>
        </Card>
      )}

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Map Provider Configuration</CardTitle>
            <CardDescription>
              Configure the map provider and API key used throughout the application.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {isLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : (
              <>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="mapProvider" className="text-right font-medium">
                    Map Provider
                  </Label>
                  <Select
                    value={mapConfig.provider}
                    onValueChange={(value) => handleInputChange('provider', value)}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select map provider" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="google_maps">Google Maps</SelectItem>
                      <SelectItem value="mapbox">Mapbox</SelectItem>
                      <SelectItem value="osm">OpenStreetMap</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="apiKey" className="text-right font-medium">
                    API Key
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="apiKey"
                      type="text"
                      value={mapConfig.apiKey}
                      onChange={(e) => handleInputChange('apiKey', e.target.value)}
                      placeholder={`Enter your ${getProviderDisplayName(mapConfig.provider)} API key`}
                      className="w-full"
                    />
                    {mapConfig.provider === 'osm' && (
                      <p className="text-sm text-muted-foreground mt-1">
                        For basic usage, an API key is optional with OpenStreetMap.
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-4 items-center gap-4">
                  <div className="text-right">
                    <Label htmlFor="active" className="font-medium">
                      Active
                    </Label>
                  </div>
                  <div className="col-span-3 flex items-center space-x-2">
                    <Switch
                      id="active"
                      checked={mapConfig.isActive}
                      onCheckedChange={(checked) => handleInputChange('isActive', checked)}
                    />
                    <span className="text-sm text-muted-foreground">
                      {mapConfig.isActive ? 'Map integration is enabled' : 'Map integration is disabled'}
                    </span>
                  </div>
                </div>

                <div className="mt-6 border border-gray-100 rounded-md p-4 bg-gray-50">
                  <div className="flex gap-2 mb-3">
                    <Info className="h-5 w-5 text-blue-500" />
                    <h4 className="font-medium">How to get a {getProviderDisplayName(mapConfig.provider)} API key</h4>
                  </div>
                  <div className="text-sm text-gray-600">
                    {getProviderInstructions(mapConfig.provider)}
                  </div>
                </div>
              </>
            )}
          </CardContent>
          <CardFooter className="flex justify-between border-t px-6 py-4">
            <div className="text-sm text-muted-foreground">
              {configs.length > 0 ? (
                <div className="flex items-center text-green-600">
                  <Check className="h-4 w-4 mr-1" />
                  Map configuration is set up
                </div>
              ) : (
                <div className="flex items-center text-amber-600">
                  <AlertTriangle className="h-4 w-4 mr-1" />
                  No map configuration found
                </div>
              )}
            </div>
            <Button type="submit" disabled={isLoading || saveMapConfigMutation.isPending}>
              {saveMapConfigMutation.isPending ? 'Saving...' : 'Save Configuration'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  );
}