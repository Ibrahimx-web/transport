import React from 'react';
import { Link } from 'wouter';
import { 
  LayoutDashboard, 
  Users, 
  Map, 
  Truck, 
  CreditCard, 
  Settings,
  FileText,
  LogOut
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface AdminHeaderProps {
  title: string;
}

export function AdminHeader({ title }: AdminHeaderProps) {
  const { toast } = useToast();
  
  // Handle logout
  const handleLogout = async () => {
    try {
      await apiRequest("POST", '/api/users/logout');
      
      // Invalidate user query
      queryClient.invalidateQueries({ queryKey: ['/api/users/current'] });
      
      // Redirect to login page
      window.location.href = '/admin/login';
      
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of your admin account."
      });
    } catch (error) {
      console.error('Logout failed:', error);
      toast({
        title: "Logout failed",
        description: "There was a problem logging you out. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  return (
    <header className="bg-primary/5 border-b">
      <div className="container py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-6">
            <div>
              <h1 className="text-xl font-bold">Ask for Transport Admin</h1>
              <p className="text-sm text-muted-foreground">{title}</p>
            </div>
            
            <nav className="hidden md:flex items-center gap-1">
              <Link href="/admin/dashboard">
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Dashboard</span>
                </Button>
              </Link>
              
              <Link href="/admin/users">
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  <span>Users</span>
                </Button>
              </Link>
              
              <Link href="/admin/live-map">
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  <Map className="h-4 w-4" />
                  <span>Live Map</span>
                </Button>
              </Link>
              
              <Link href="/admin/vehicles">
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  <Truck className="h-4 w-4" />
                  <span>Vehicles</span>
                </Button>
              </Link>
              
              <Link href="/admin/payments">
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  <CreditCard className="h-4 w-4" />
                  <span>Payments</span>
                </Button>
              </Link>
              
              <Link href="/admin/documents">
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  <FileText className="h-4 w-4" />
                  <span>Documents</span>
                </Button>
              </Link>
              
              <Link href="/admin/settings">
                <Button variant="ghost" size="sm" className="flex items-center gap-1">
                  <Settings className="h-4 w-4" />
                  <span>Settings</span>
                </Button>
              </Link>
            </nav>
          </div>
          
          <Button variant="outline" size="sm" onClick={handleLogout} className="flex items-center gap-1">
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
          </Button>
        </div>
      </div>
    </header>
  );
}