import React, { useEffect, useState } from 'react';
import Map, { Marker } from 'react-map-gl';
import { LocateFixed } from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle, 
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { KENYA_COORDINATES } from '@/lib/constants';
import { useMapConfig, getFallbackApiKey } from '@/lib/mapService';

interface User {
  id: number;
  fullName: string;
  username: string;
  userType: string;
  isAvailable?: boolean;
  currentLat?: number | null;
  currentLng?: number | null;
}

interface UserLocationMapProps {
  user: User;
  isOpen: boolean;
  onClose: () => void;
}

export default function UserLocationMap({ user, isOpen, onClose }: UserLocationMapProps) {
  // Get map configuration from our centralized service
  const { config, isLoading: isConfigLoading } = useMapConfig();
  
  // Get API key from config or fallback (specifically for Mapbox)
  const mapboxToken = config?.isActive && config?.provider === 'mapbox' 
    ? config.apiKey 
    : getFallbackApiKey('mapbox');
    
  const [viewState, setViewState] = useState({
    latitude: user.currentLat || KENYA_COORDINATES.lat,
    longitude: user.currentLng || KENYA_COORDINATES.lng,
    zoom: 14
  });

  // Keep map centered on user's location if it's available
  useEffect(() => {
    if (user.currentLat && user.currentLng) {
      setViewState(prev => ({
        ...prev,
        latitude: user.currentLat!,
        longitude: user.currentLng!
      }));
    }
  }, [user.currentLat, user.currentLng]);

  return (
    <Dialog open={isOpen} onOpenChange={open => !open && onClose()}>
      <DialogContent className="sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="text-xl">Location: {user.fullName}</DialogTitle>
          <DialogDescription>
            {user.currentLat && user.currentLng 
              ? `Current coordinates: ${user.currentLat.toFixed(6)}, ${user.currentLng.toFixed(6)}`
              : "Location not available for this user"}
          </DialogDescription>
        </DialogHeader>
        
        <div className="rounded-md overflow-hidden border h-[400px] mt-4">
          {isConfigLoading ? (
            <div className="flex items-center justify-center h-full bg-slate-100">
              <div className="text-center">
                <div className="animate-spin h-6 w-6 border-4 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
                <p className="text-muted-foreground">Loading map configuration...</p>
              </div>
            </div>
          ) : !mapboxToken ? (
            <div className="flex items-center justify-center h-full bg-slate-100">
              <div className="text-center">
                <p className="text-amber-600 font-medium mb-2">Map API key not configured</p>
                <p className="text-sm text-muted-foreground">Please configure a Mapbox API key in the Admin Settings.</p>
              </div>
            </div>
          ) : user.currentLat && user.currentLng ? (
            <Map
              {...viewState}
              onMove={evt => setViewState(evt.viewState)}
              mapStyle="mapbox://styles/mapbox/streets-v11"
              mapboxAccessToken={mapboxToken || ''}
            >
              <Marker 
                latitude={user.currentLat}
                longitude={user.currentLng}
                anchor="bottom"
                offset={[0, -5]}
              >
                <div className={`p-2 rounded-full ${user.userType === 'delivery' ? 'bg-blue-500' : 'bg-green-500'}`}>
                  <LocateFixed className="h-4 w-4 text-white" />
                </div>
              </Marker>
            </Map>
          ) : (
            <div className="flex items-center justify-center h-full bg-slate-100">
              <div className="text-center">
                <LocateFixed className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
                <p className="text-muted-foreground">Location data not available</p>
              </div>
            </div>
          )}
        </div>
        
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={onClose}>Close</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}