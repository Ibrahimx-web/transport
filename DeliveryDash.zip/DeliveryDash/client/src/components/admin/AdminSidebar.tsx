import * as React from "react";
import { useLocation } from "wouter";
import { Home, Users, Truck, CreditCard, Map, Settings, FileText, LogOut, CircleUser } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";

export function AdminSidebar() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  // Get current admin user
  const { data: user } = useQuery<User>({
    queryKey: ['/api/users/current'],
    refetchOnWindowFocus: false
  });

  const menuItems = [
    { path: "/admin/dashboard", icon: Home, label: "Dashboard" },
    { path: "/admin/users", icon: Users, label: "Users" },
    { path: "/admin/vehicles", icon: Truck, label: "Vehicles" },
    { path: "/admin/payments", icon: CreditCard, label: "Payments" },
    { path: "/admin/livemap", icon: Map, label: "Live Map" },
    { path: "/admin/documents", icon: FileText, label: "Documents" },
    { path: "/admin/settings", icon: Settings, label: "Settings" }
  ];

  // Handle logout
  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await apiRequest("POST", "/api/users/logout");
      toast({
        title: "Logged out",
        description: "You have been logged out successfully"
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error logging out",
        variant: "destructive"
      });
    } finally {
      setIsLoggingOut(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground mb-2 uppercase font-semibold">Main Menu</p>
        {menuItems.map((item) => (
          <Button 
            key={item.path}
            variant={location === item.path ? "default" : "ghost"} 
            className="w-full justify-start"
            onClick={() => setLocation(item.path)}
          >
            <item.icon className="mr-2 h-4 w-4" />
            {item.label}
          </Button>
        ))}
      </div>
      
      <div className="pt-4 border-t border-border">
        <p className="text-xs text-muted-foreground mb-2 uppercase font-semibold">Your Account</p>
        <Button 
          variant="ghost" 
          className="w-full justify-start"
          onClick={() => setLocation("/profile")}
        >
          <CircleUser className="mr-2 h-4 w-4" />
          Profile
        </Button>
        <Button 
          variant="ghost" 
          className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
          onClick={handleLogout}
          disabled={isLoggingOut}
        >
          <LogOut className="mr-2 h-4 w-4" />
          {isLoggingOut ? "Logging out..." : "Logout"}
        </Button>
      </div>
      
      {/* Display welcome message for the admin */}
      {user && (
        <div className="mt-4 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-700">Logged in as:</p>
          <p className="font-medium">{user.fullName || user.username}</p>
          <p className="text-xs text-blue-600 mt-1">Administrator</p>
        </div>
      )}
    </div>
  );
}