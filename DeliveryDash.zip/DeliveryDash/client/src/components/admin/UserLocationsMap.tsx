import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow } from '@react-google-maps/api';
import { 
  LocateFixed, 
  Truck, 
  User as UserIcon,
  Clock,
  RefreshCw,
  Search,
  Filter,
  MapPin,
  Phone,
  Mail,
  CheckCircle2,
  XCircle,
  ChevronDown,
  CarFront,
  Bike
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useWebSocket, MessageType } from '@/hooks/use-websocket';
import { apiRequest } from '@/lib/queryClient';
import { KENYA_COORDINATES } from '@/lib/constants';
import { useMapConfig, getFallbackApiKey } from '@/lib/mapService';
import { formatDistanceToNow } from 'date-fns';
import { Input } from '@/components/ui/input';
import { useCurrentLocation } from '@/lib/map'; // Import the custom hook
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface Location {
  lat: number;
  lng: number;
}

interface ConnectedUser {
  userId: number;
  username: string;
  fullName: string;
  userType: string;
  lastSeen: number;
  phoneNumber?: string;
  email?: string;
  isAvailable?: boolean;
  vehicleType?: string;
  currentLocation?: Location;
}

interface PopupInfo {
  user: ConnectedUser;
  currentLocation: Location;
}

export default function UserLocationsMap() {
  // Use the custom hook to get user's current location
  const { location: userLocation, isLoading: locationLoading, error: locationError } = useCurrentLocation();
  
  // Default center is Kenya, but we'll use the user's location if available
  const [center, setCenter] = useState({
    lat: KENYA_COORDINATES.lat,
    lng: KENYA_COORDINATES.lng
  });
  const [zoom, setZoom] = useState(14); // Closer zoom for better visibility
  const [mapRef, setMapRef] = useState<google.maps.Map | null>(null);
  
  const [connectedUsers, setConnectedUsers] = useState<ConnectedUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [popupInfo, setPopupInfo] = useState<PopupInfo | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  
  // Search and filter state
  const [searchTerm, setSearchTerm] = useState("");
  const [userTypeFilter, setUserTypeFilter] = useState<string>("all");
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<string>("map");
  
  // Get map configuration from the server
  const { config, isLoading: isConfigLoading } = useMapConfig();
  
  // Load Google Maps JavaScript API
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: config?.provider === 'google_maps' ? config.apiKey : getFallbackApiKey('google_maps') || ''
  });
  
  // Initialize WebSocket connection for real-time updates
  const { addMessageHandler, isConnected } = useWebSocket({
    debug: true
  });
  
  // Fetch connected users from the API
  const fetchConnectedUsers = useCallback(async () => {
    try {
      setIsLoading(true);
      const response = await apiRequest("GET", '/api/admin/connected-users');
      const data = await response.json();
      
      setConnectedUsers(data as ConnectedUser[]);
      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      console.error('Failed to fetch connected users:', err);
      setError('Failed to load connected users. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  // Handle WebSocket messages for real-time location updates
  useEffect(() => {
    // Handle location updates
    const unsubscribeLocationUpdate = addMessageHandler(
      MessageType.LOCATION_UPDATE,
      (message) => {
        if (message.userId && message.data) {
          const { lat, lng } = message.data;
          
          setConnectedUsers(prev => 
            prev.map(user => 
              user.userId === message.userId
                ? { 
                    ...user, 
                    currentLocation: { lat, lng },
                    lastSeen: message.timestamp || Date.now()
                  }
                : user
            )
          );
        }
      }
    );
    
    // Handle user connections
    const unsubscribeUserConnect = addMessageHandler(
      MessageType.USER_CONNECT, 
      async (message) => {
        // Refresh the user list when a new user connects
        await fetchConnectedUsers();
      }
    );
    
    // Handle user disconnections
    const unsubscribeUserDisconnect = addMessageHandler(
      MessageType.USER_DISCONNECT,
      (message) => {
        if (message.userId) {
          setConnectedUsers(prev => 
            prev.filter(user => user.userId !== message.userId)
          );
        }
      }
    );
    
    return () => {
      unsubscribeLocationUpdate();
      unsubscribeUserConnect();
      unsubscribeUserDisconnect();
    };
  }, [addMessageHandler, fetchConnectedUsers]);
  
  // Update map center when user location is available
  useEffect(() => {
    if (userLocation) {
      setCenter({
        lat: userLocation.lat,
        lng: userLocation.lng
      });
      
      // If we have a map reference, pan to the user's location
      if (mapRef) {
        mapRef.panTo({
          lat: userLocation.lat,
          lng: userLocation.lng
        });
      }
    }
  }, [userLocation, mapRef]);
  
  // Initial data fetch
  useEffect(() => {
    fetchConnectedUsers();
    
    // Poll for updates every 30 seconds
    const interval = setInterval(() => {
      fetchConnectedUsers();
    }, 30000);
    
    return () => clearInterval(interval);
  }, [fetchConnectedUsers]);
  
  // Format the time since last update
  const formatLastUpdated = () => {
    return formatDistanceToNow(lastUpdated, { addSuffix: true });
  };
  
  // Filter users based on search term and filter
  const filteredUsers = useMemo(() => {
    return connectedUsers.filter(user => {
      // Apply user type filter
      if (userTypeFilter !== "all" && user.userType !== userTypeFilter) {
        return false;
      }
      
      // Apply search term filter
      const searchLower = searchTerm.toLowerCase();
      if (searchTerm && 
          !user.username.toLowerCase().includes(searchLower) && 
          !user.fullName.toLowerCase().includes(searchLower)) {
        return false;
      }
      
      return true;
    });
  }, [connectedUsers, searchTerm, userTypeFilter]);
  
  // Find selected user
  const selectedUser = useMemo(() => {
    if (!selectedUserId) return null;
    return connectedUsers.find(user => user.userId === selectedUserId) || null;
  }, [connectedUsers, selectedUserId]);
  
  // Focus on selected user
  useEffect(() => {
    if (selectedUser && selectedUser.currentLocation && mapRef) {
      const newCenter = {
        lat: selectedUser.currentLocation.lat,
        lng: selectedUser.currentLocation.lng
      };
      
      mapRef.panTo(newCenter);
      mapRef.setZoom(14);
      
      // Open popup for the selected user
      setPopupInfo({
        user: selectedUser,
        currentLocation: selectedUser.currentLocation
      });
    }
  }, [selectedUserId, mapRef, selectedUser]);
  
  // Save map reference on load
  const onMapLoad = useCallback((map: google.maps.Map) => {
    setMapRef(map);
  }, []);
  
  // Get user icon based on type
  const getUserIcon = (userType: string) => {
    switch (userType) {
      case 'delivery':
        return <Truck className="h-4 w-4" />;
      case 'admin':
        return <CheckCircle2 className="h-4 w-4" />;
      default:
        return <UserIcon className="h-4 w-4" />;
    }
  };
  
  // Generate SVG icon URL based on user type
  const getUserIconUrl = (userType: string, isSelected: boolean = false) => {
    const scale = isSelected ? 1.2 : 1;
    let color = '';
    let icon = '';
    
    switch (userType) {
      case 'delivery':
        color = '#3b82f6'; // blue
        icon = 'M7 16.67l-5-5 1.5-1.5L7 13.67l8-8 1.5 1.5-9.5 9.5z';
        break;
      case 'admin':
        color = '#8b5cf6'; // purple
        icon = 'M9 16.17l-4.17-4.17 1.42-1.41 2.75 2.75 6.58-6.59 1.42 1.42-8 8z';
        break;
      default:
        color = '#10b981'; // green
        icon = 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z';
    }
    
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="10" fill="${color}" stroke="white" stroke-width="${isSelected ? 3 : 2}" />
        <path d="${icon}" fill="white" />
      </svg>
    `;
    
    return {
      url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(svg),
      scaledSize: new google.maps.Size(isSelected ? 36 : 30, isSelected ? 36 : 30)
    };
  };
  
  // Show loading state when config or Maps API is loading
  if (isConfigLoading || !isLoaded) {
    return (
      <div className="w-full h-[480px] relative rounded-lg overflow-hidden border border-border flex items-center justify-center">
        <div className="flex flex-col items-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-3"></div>
          <p className="text-muted-foreground text-sm">{isConfigLoading ? "Loading map configuration..." : "Loading map..."}</p>
        </div>
      </div>
    );
  }
  
  // Show warning if Google Maps API key is not configured
  if (!config?.apiKey && config?.provider === 'google_maps') {
    return (
      <div className="w-full h-[480px] relative rounded-lg overflow-hidden border border-border flex items-center justify-center bg-amber-50">
        <div className="flex flex-col items-center text-center max-w-md p-6">
          <div className="text-amber-600 mb-3 font-medium text-lg">Google Maps API key not configured</div>
          <p className="text-muted-foreground text-sm mb-4">
            Please configure a Google Maps API key in the Admin Settings to use this feature.
            Without a valid API key, the map functionality will be limited.
          </p>
          <Button variant="outline" asChild>
            <a href="/admin/settings">Go to Settings</a>
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>User Locations</CardTitle>
            <CardDescription>
              Real-time tracking of all connected users
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={isConnected ? "success" : "destructive"}>
              {isConnected ? "Connected" : "Disconnected"}
            </Badge>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={fetchConnectedUsers}
              disabled={isLoading}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {error ? (
          <div className="text-center py-6 text-destructive">
            <p>{error}</p>
          </div>
        ) : (
          <>
            {/* Search and filter controls */}
            <div className="mb-4">
              <div className="flex gap-3 mb-3">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search users by name or username..."
                    className="pl-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select
                  value={userTypeFilter}
                  onValueChange={(value) => setUserTypeFilter(value)}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All users</SelectItem>
                    <SelectItem value="customer">Customers</SelectItem>
                    <SelectItem value="delivery">Drivers</SelectItem>
                    <SelectItem value="admin">Admins</SelectItem>
                  </SelectContent>
                </Select>
                <Button 
                  variant="outline" 
                  className="gap-1.5" 
                  onClick={() => {
                    if (userLocation && mapRef) {
                      mapRef.panTo({
                        lat: userLocation.lat,
                        lng: userLocation.lng
                      });
                      mapRef.setZoom(15);
                    }
                  }}
                  disabled={!userLocation}
                  title={userLocation ? "Center map on your location" : "Location access not available"}
                >
                  <LocateFixed className="h-4 w-4" />
                  <span className="hidden sm:inline">Center on Me</span>
                </Button>
              </div>
              
              {/* Results count and location status */}
              <div className="flex justify-between items-center text-sm text-muted-foreground mb-2">
                <div>
                  Found {filteredUsers.length} users
                  {userTypeFilter !== "all" && ` of type ${userTypeFilter}`}
                  {searchTerm && ` matching "${searchTerm}"`}
                </div>
                
                {locationLoading ? (
                  <div className="flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 bg-amber-500 rounded-full animate-pulse"></span>
                    <span className="text-xs">Locating...</span>
                  </div>
                ) : locationError ? (
                  <div className="flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 bg-red-500 rounded-full"></span>
                    <span className="text-xs">Location unavailable</span>
                  </div>
                ) : userLocation ? (
                  <div className="flex items-center gap-1.5">
                    <span className="inline-block w-2 h-2 bg-green-500 rounded-full"></span>
                    <span className="text-xs">Location available</span>
                  </div>
                ) : null}
              </div>
            </div>
            
            {/* Tabs for Map or List view */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-2 mb-4">
                <TabsTrigger value="map" className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2" />
                  Map View
                </TabsTrigger>
                <TabsTrigger value="list" className="flex items-center">
                  <UserIcon className="h-4 w-4 mr-2" />
                  List View
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="map" className="mt-0">
                <div className="rounded-md overflow-hidden border h-[480px]">
                  <GoogleMap
                    mapContainerStyle={{ width: '100%', height: '100%' }}
                    center={center}
                    zoom={zoom}
                    options={{
                      fullscreenControl: true,
                      streetViewControl: false,
                      mapTypeControl: true,
                      zoomControl: true
                    }}
                    onLoad={onMapLoad}
                  >
                    {/* Current user's location marker */}
                    {userLocation && (
                      <Marker
                        position={{ lat: userLocation.lat, lng: userLocation.lng }}
                        icon={{
                          path: google.maps.SymbolPath.CIRCLE,
                          fillColor: '#EF4444', // red-500
                          fillOpacity: 1,
                          strokeColor: '#FFFFFF',
                          strokeWeight: 2,
                          scale: 8,
                        }}
                        zIndex={1000} // Make sure it's on top of other markers
                        title="Your Location"
                      />
                    )}
                    
                    {/* Map markers for filtered users */}
                    {filteredUsers.map(user => {
                      // Skip users without location data
                      if (!user.currentLocation) return null;
                      
                      const { lat, lng } = user.currentLocation;
                      const isSelected = selectedUserId === user.userId;
                      
                      return (
                        <Marker
                          key={user.userId}
                          position={{ lat, lng }}
                          icon={getUserIconUrl(user.userType, isSelected)}
                          onClick={() => {
                            setSelectedUserId(user.userId);
                            setPopupInfo({
                              user,
                              currentLocation: { lat, lng }
                            });
                          }}
                          animation={isSelected ? google.maps.Animation.BOUNCE : undefined}
                        />
                      );
                    })}
                    
                    {/* Info window for selected user */}
                    {popupInfo && (
                      <InfoWindow
                        position={{
                          lat: popupInfo.currentLocation.lat,
                          lng: popupInfo.currentLocation.lng
                        }}
                        onCloseClick={() => {
                          setPopupInfo(null);
                          setSelectedUserId(null);
                        }}
                      >
                        <div className="p-2 max-w-xs">
                          <h3 className="font-semibold text-sm">{popupInfo.user.fullName}</h3>
                          <p className="text-xs text-muted-foreground">@{popupInfo.user.username}</p>
                          
                          <div className="flex items-center mt-1 text-xs">
                            <span className={`inline-block px-2 py-0.5 rounded-full text-white mr-2 ${
                              popupInfo.user.userType === 'delivery' 
                                ? 'bg-blue-500' 
                                : popupInfo.user.userType === 'admin'
                                  ? 'bg-purple-500'
                                  : 'bg-green-500'
                            }`}>
                              {popupInfo.user.userType === 'delivery' 
                                ? 'Driver' 
                                : popupInfo.user.userType === 'admin'
                                  ? 'Admin'
                                  : 'Customer'
                              }
                            </span>
                            
                            {popupInfo.user.isAvailable !== undefined && (
                              <span className={`inline-block px-2 py-0.5 rounded-full text-white mr-2 ${
                                popupInfo.user.isAvailable ? 'bg-green-500' : 'bg-gray-400'
                              }`}>
                                {popupInfo.user.isAvailable ? 'Available' : 'Unavailable'}
                              </span>
                            )}
                          </div>
                          
                          {popupInfo.user.vehicleType && (
                            <div className="flex items-center mt-1 text-xs">
                              <CarFront className="h-3 w-3 mr-1 text-muted-foreground" />
                              <span className="text-muted-foreground">{popupInfo.user.vehicleType}</span>
                            </div>
                          )}
                          
                          {popupInfo.user.phoneNumber && (
                            <div className="flex items-center mt-1 text-xs">
                              <Phone className="h-3 w-3 mr-1 text-muted-foreground" />
                              <span className="text-muted-foreground">{popupInfo.user.phoneNumber}</span>
                            </div>
                          )}
                          
                          {popupInfo.user.email && (
                            <div className="flex items-center mt-1 text-xs truncate">
                              <Mail className="h-3 w-3 mr-1 text-muted-foreground" />
                              <span className="text-muted-foreground">{popupInfo.user.email}</span>
                            </div>
                          )}
                          
                          <div className="flex items-center mt-2 text-xs">
                            <Clock className="h-3 w-3 mr-1 text-muted-foreground" />
                            <span className="text-muted-foreground">
                              Last seen: {formatDistanceToNow(popupInfo.user.lastSeen, { addSuffix: true })}
                            </span>
                          </div>
                          
                          <div className="mt-2 pt-2 border-t flex justify-end gap-2">
                            <Button size="sm" variant="secondary" className="h-7 text-xs" onClick={() => {
                              if (mapRef) {
                                mapRef.setZoom(16);
                              }
                            }}>
                              <LocateFixed className="h-3 w-3 mr-1" />
                              Zoom In
                            </Button>
                            <Button size="sm" className="h-7 text-xs">
                              Contact
                            </Button>
                          </div>
                        </div>
                      </InfoWindow>
                    )}
                  </GoogleMap>
                </div>
                
                <div className="mt-2 text-xs text-muted-foreground">
                  Last updated: {formatLastUpdated()}
                </div>
                
                {/* Map legend */}
                <div className="mt-3 bg-muted/20 p-2 rounded text-xs">
                  <span className="font-medium">Map Legend:</span>
                  <div className="flex flex-wrap items-center gap-4 mt-1">
                    <div className="flex items-center">
                      <span className="bg-green-500 rounded-full w-3 h-3 inline-block mr-1" />
                      Customers
                    </div>
                    <div className="flex items-center">
                      <span className="bg-blue-500 rounded-full w-3 h-3 inline-block mr-1" />
                      Drivers
                    </div>
                    <div className="flex items-center">
                      <span className="bg-purple-500 rounded-full w-3 h-3 inline-block mr-1" />
                      Admins
                    </div>
                    <div className="flex items-center">
                      <span className="bg-red-500 rounded-full w-3 h-3 inline-block mr-1" />
                      Your Location
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="list" className="mt-0">
                <div className="rounded-md border h-[480px] overflow-hidden">
                  <ScrollArea className="h-full">
                    <Table>
                      <TableHeader className="bg-muted/20 sticky top-0">
                        <TableRow>
                          <TableHead className="w-[180px]">Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Last Seen</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredUsers.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="h-96 text-center">
                              {isLoading ? (
                                <div className="flex justify-center items-center py-8">
                                  <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
                                </div>
                              ) : (
                                "No users found matching the criteria"
                              )}
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredUsers.map(user => (
                            <TableRow 
                              key={user.userId} 
                              className={`${selectedUserId === user.userId ? 'bg-muted/50' : ''}`}
                              onClick={() => {
                                setSelectedUserId(user.userId);
                                setActiveTab("map");
                              }}
                            >
                              <TableCell className="font-medium">
                                <div className="flex items-center gap-2">
                                  <div className={`p-1 rounded-full ${
                                    user.userType === 'delivery' 
                                      ? 'bg-blue-500' 
                                      : user.userType === 'admin' 
                                        ? 'bg-purple-500'
                                        : 'bg-green-500'
                                  } text-white`}>
                                    {getUserIcon(user.userType)}
                                  </div>
                                  <div>
                                    <div className="font-medium text-sm">{user.fullName}</div>
                                    <div className="text-xs text-muted-foreground">@{user.username}</div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge variant={
                                  user.userType === 'delivery' 
                                    ? 'default' 
                                    : user.userType === 'admin' 
                                      ? 'destructive' 
                                      : 'success'
                                }>
                                  {user.userType === 'delivery' 
                                    ? 'Driver' 
                                    : user.userType === 'admin' 
                                      ? 'Admin' 
                                      : 'Customer'
                                  }
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {user.currentLocation ? (
                                  <Badge variant="outline" className="bg-green-500/10 text-green-600 hover:bg-green-500/20">
                                    Online
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="bg-gray-500/10 text-gray-500 hover:bg-gray-500/20">
                                    Offline
                                  </Badge>
                                )}
                              </TableCell>
                              <TableCell>
                                {formatDistanceToNow(user.lastSeen, { addSuffix: true })}
                              </TableCell>
                              <TableCell className="text-right">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedUserId(user.userId);
                                    setActiveTab("map");
                                  }}
                                >
                                  <MapPin className="h-4 w-4 mr-2" />
                                  Locate
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </div>
                
                <div className="mt-2 text-xs text-muted-foreground">
                  Last updated: {formatLastUpdated()}
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </CardContent>
    </Card>
  );
}