import { Link, useLocation } from 'wouter';
import { Home, Clock, Bell, User, Truck, Map, Package, History } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useQuery } from '@tanstack/react-query';
import { User as UserType } from '@/types';

export function BottomNavigation() {
  const [location] = useLocation();
  
  const { data: user } = useQuery<UserType>({
    queryKey: ['/api/users/current'],
  });
  
  // Default navigation items (for non-authenticated users or as a fallback)
  const defaultNavItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: User, label: 'Profile', path: '/profile' }
  ];
  
  // Navigation items for delivery partners
  const deliveryNavItems = [
    { icon: Package, label: 'Requests', path: '/' },
    { icon: Map, label: 'Map', path: '/delivery/map' },
    { icon: History, label: 'History', path: '/history' },
    { icon: User, label: 'Profile', path: '/profile' }
  ];
  
  // Navigation items for customers
  const customerNavItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Truck, label: 'Book', path: '/book' },
    { icon: Bell, label: 'Track', path: '/track' },
    { icon: User, label: 'Profile', path: '/profile' }
  ];
  
  // Determine which nav items to show based on user type
  let navItems = defaultNavItems;
  if (user) {
    if (user.userType === 'delivery') {
      navItems = deliveryNavItems;
    } else if (user.userType === 'customer') {
      navItems = customerNavItems;
    }
  }
  
  return (
    <nav className="bottom-nav">
      {navItems.map((item) => {
        const isActive = location === item.path;
        return (
          <Link 
            key={item.path} 
            href={item.path}
            className="nav-item"
          >
            <div className={cn(
              isActive ? "nav-item-active" : "nav-item-inactive"
            )}>
              <item.icon className="h-5 w-5 mb-1" />
              <span>{item.label}</span>
            </div>
          </Link>
        );
      })}
    </nav>
  );
}
