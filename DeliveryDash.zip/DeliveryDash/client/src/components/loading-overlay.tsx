import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useLoading } from "@/hooks/use-loading";
import { LoadingSpinner, LoadingDots } from "@/components/ui/loading-spinner";
import { cn } from "@/lib/utils";

export function LoadingOverlay() {
  const { isLoading, loadingText } = useLoading();

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="bg-card shadow-lg rounded-lg p-6 max-w-sm w-full flex flex-col items-center"
          >
            <LoadingSpinner size="lg" variant="primary" className="mb-4" />
            
            <div className="text-center space-y-2">
              <motion.p 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-lg font-medium"
              >
                {loadingText}
              </motion.p>
              <LoadingDots color="primary" size="md" />
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface ContentLoadingProps {
  isLoading: boolean;
  children: React.ReactNode;
  loadingComponent?: React.ReactNode;
  className?: string;
  minHeight?: string;
}

export function ContentLoading({
  isLoading,
  children,
  loadingComponent,
  className,
  minHeight = "min-h-[200px]",
}: ContentLoadingProps) {
  return (
    <div className={cn("relative", minHeight, className)}>
      <AnimatePresence mode="wait">
        {isLoading ? (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            {loadingComponent || (
              <div className="flex flex-col items-center justify-center">
                <LoadingSpinner variant="primary" size="md" />
                <span className="mt-2 text-sm text-muted-foreground">Loading...</span>
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            {children}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function SkeletonCard({ className }: { className?: string }) {
  return (
    <div className={cn("rounded-lg border p-4 space-y-3", className)}>
      <div className="w-2/3 h-5 bg-muted rounded animate-pulse" />
      <div className="space-y-2">
        <div className="w-full h-4 bg-muted rounded animate-pulse" />
        <div className="w-4/5 h-4 bg-muted rounded animate-pulse" />
        <div className="w-3/5 h-4 bg-muted rounded animate-pulse" />
      </div>
    </div>
  );
}

export function SkeletonTable({ rows = 5, columns = 4, className }: { rows?: number; columns?: number, className?: string }) {
  return (
    <div className={cn("rounded-lg border overflow-hidden", className)}>
      {/* Header */}
      <div className="bg-muted/30 p-4 grid gap-4" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
        {Array(columns).fill(0).map((_, i) => (
          <div key={`header-${i}`} className="h-5 bg-muted animate-pulse rounded" />
        ))}
      </div>
      
      {/* Rows */}
      {Array(rows).fill(0).map((_, rowIndex) => (
        <div 
          key={`row-${rowIndex}`} 
          className="border-t p-4 grid gap-4"
          style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}
        >
          {Array(columns).fill(0).map((_, colIndex) => (
            <div 
              key={`cell-${rowIndex}-${colIndex}`} 
              className="h-4 bg-muted/60 animate-pulse rounded"
              style={{ 
                width: `${Math.max(50, Math.min(95, 70 + Math.random() * 30))}%`,
                animationDelay: `${(rowIndex * columns + colIndex) * 0.05}s`
              }} 
            />
          ))}
        </div>
      ))}
    </div>
  );
}