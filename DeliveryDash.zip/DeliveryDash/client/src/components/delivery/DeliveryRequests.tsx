
import { useQuery } from '@tanstack/react-query';
import { Order } from '@/types';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { PhoneCall, MessageSquare, MapPin } from 'lucide-react';
import { calculateDistance } from '@/lib/utils';
import { Link } from 'wouter';

interface DeliveryRequestsProps {
  currentLat: number;
  currentLng: number;
}

export function DeliveryRequests({ currentLat, currentLng }: DeliveryRequestsProps) {
  const { data: pendingOrders = [] } = useQuery<Order[]>({
    queryKey: ['/api/orders/pending'],
  });

  // Sort orders by distance from current location
  const sortedOrders = [...pendingOrders].sort((a, b) => {
    const distA = calculateDistance(currentLat, currentLng, a.pickupLat, a.pickupLng);
    const distB = calculateDistance(currentLat, currentLng, b.pickupLat, b.pickupLng);
    return distA - distB;
  });

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Nearby Delivery Requests</h2>
      {sortedOrders.length === 0 ? (
        <p className="text-gray-500 text-center py-4">No delivery requests available</p>
      ) : (
        sortedOrders.map((order) => {
          const distance = calculateDistance(currentLat, currentLng, order.pickupLat, order.pickupLng);
          
          return (
            <Card key={order.id} className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-medium">Request #{order.id}</h3>
                  <p className="text-sm text-gray-500">{distance.toFixed(1)} km away</p>
                </div>
                <div className="flex gap-2">
                  <Button size="icon" variant="outline">
                    <PhoneCall className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="outline">
                    <MessageSquare className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  <p className="text-sm">{order.pickupLocation}</p>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  <p className="text-sm">{order.deliveryLocation}</p>
                </div>
              </div>
              
              <Link href={`/delivery/accept/${order.id}`}>
                <Button className="w-full">Accept Request</Button>
              </Link>
            </Card>
          );
        })
      )}
    </div>
  );
}
