import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Loader2, TrendingUp, Wallet, Clock, CheckCircle, CreditCard, 
  Settings, Phone, Mail, AlertTriangle, Info
} from 'lucide-react';
import { formatCurrency } from '@/lib/currency';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

interface PartnerEarningsSummary {
  totalEarnings: number;
  paidEarnings: number;
  pendingEarnings: number;
  totalTrips: number;
  paidTrips: number;
  pendingTrips: number;
}

interface PartnerPayment {
  id: number;
  partnerId: number;
  orderId: number;
  amount: number;
  commissionPercentage: number;
  commissionAmount: number;
  finalPayment: number;
  status: 'pending' | 'paid' | 'disputed';
  paymentDate?: string;
  createdAt: string;
  processedBy?: number;
}

interface PartnerEarningsResponse {
  summary: PartnerEarningsSummary;
  recentPayments: PartnerPayment[];
}

interface PaymentGateway {
  id: number;
  gatewayType: string;
  displayName: string;
  isDefault: boolean;
  supportedCountries: string[];
  supportedCurrencies: string[];
  minimumAmount: number;
  processingFee: number;
  processingFeeType: string;
}

// Define payment details schema with validation
const paymentDetailsSchema = z.object({
  paypal: z.object({
    email: z.string().email({ message: "Please enter a valid PayPal email address" }),
  }),
  google_pay: z.object({
    email: z.string().email({ message: "Please enter a valid Google email address" }),
  }),
  mpesa: z.object({
    phoneNumber: z.string().min(10, { message: "Please enter a valid Safaricom M-Pesa phone number" }),
  }),
  airtel_money: z.object({
    phoneNumber: z.string().min(10, { message: "Please enter a valid Airtel Money phone number" }),
  }),
});

type PaymentDetailsFormValues = {
  paypal: { email: string };
  google_pay: { email: string };
  mpesa: { phoneNumber: string };
  airtel_money: { phoneNumber: string };
};

export function PartnerEarnings() {
  const [activeTab, setActiveTab] = useState<string>('summary');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // For payment details form based on selected method
  const [showDetailsForm, setShowDetailsForm] = useState(false);
  
  // Fetch partner earnings data
  const { data: earningsData, isLoading: isLoadingEarnings } = useQuery<PartnerEarningsResponse>({
    queryKey: ['/api/partner/earnings'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });
  
  // Fetch payment gateways
  const { data: paymentGateways, isLoading: isLoadingGateways } = useQuery<PaymentGateway[]>({
    queryKey: ['/api/payment-gateways/public'],
  });
  
  // Fetch user data to get preferred payment method
  const { data: userData, isLoading: isLoadingUserData } = useQuery<any>({
    queryKey: ['/api/users/current'],
  });
  
  // Initialize the form with default values or user's saved values
  const form = useForm<PaymentDetailsFormValues>({
    resolver: zodResolver(paymentDetailsSchema),
    defaultValues: {
      paypal: { email: '' },
      google_pay: { email: '' },
      mpesa: { phoneNumber: '' },
      airtel_money: { phoneNumber: '' },
    }
  });
  
  // Set initial selected payment method and payment details once data is loaded
  React.useEffect(() => {
    if (userData) {
      if (userData.preferredPaymentMethod) {
        setSelectedPaymentMethod(userData.preferredPaymentMethod);
      }
      
      // If user has saved payment details, set them in the form
      if (userData.paymentDetails) {
        const details = userData.paymentDetails;
        const formValues: Partial<PaymentDetailsFormValues> = {};
        
        if (details.paypal?.email) {
          formValues.paypal = { email: details.paypal.email };
        }
        
        if (details.google_pay?.email) {
          formValues.google_pay = { email: details.google_pay.email };
        }
        
        if (details.mpesa?.phoneNumber) {
          formValues.mpesa = { phoneNumber: details.mpesa.phoneNumber };
        }
        
        if (details.airtel_money?.phoneNumber) {
          formValues.airtel_money = { phoneNumber: details.airtel_money.phoneNumber };
        }
        
        form.reset(formValues as PaymentDetailsFormValues);
      }
    }
  }, [userData, form]);
  
  // Mutation to update payment preference
  const updatePaymentPreferenceMutation = useMutation({
    mutationFn: async (preferredPaymentMethod: string) => {
      const response = await apiRequest('PATCH', '/api/users/payment-preference', { preferredPaymentMethod });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Payment Preference Updated',
        description: 'Your payment method preference has been updated successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users/current'] });
      
      // Show the payment details form after method selection
      setShowDetailsForm(true);
    },
    onError: (error: any) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update payment preference.',
        variant: 'destructive',
      });
    }
  });
  
  // Mutation to update payment details
  const updatePaymentDetailsMutation = useMutation({
    mutationFn: async (data: PaymentDetailsFormValues) => {
      // Extract only the relevant part based on selected payment method
      const paymentDetails = {
        [selectedPaymentMethod]: data[selectedPaymentMethod as keyof PaymentDetailsFormValues]
      };
      
      const response = await apiRequest('PATCH', '/api/users/profile', { paymentDetails });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Payment Details Updated',
        description: 'Your payment details have been saved successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users/current'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update payment details.',
        variant: 'destructive',
      });
    }
  });
  
  const handlePaymentPreferenceUpdate = () => {
    if (selectedPaymentMethod) {
      updatePaymentPreferenceMutation.mutate(selectedPaymentMethod);
    } else {
      toast({
        title: 'Selection Required',
        description: 'Please select a payment method.',
        variant: 'destructive',
      });
    }
  };
  
  const isLoading = isLoadingEarnings || isLoadingGateways || isLoadingUserData;
  
  // Helper function to get user's preferred payment method display name
  const getSelectedPaymentMethodName = () => {
    if (!paymentGateways || !selectedPaymentMethod) return 'Not set';
    const gateway = paymentGateways.find(g => g.gatewayType === selectedPaymentMethod);
    return gateway ? gateway.displayName : 'Not set';
  };
  
  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader className="pb-2">
          <CardTitle>Earnings</CardTitle>
          <CardDescription>Your delivery earnings and payments</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center items-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }
  
  // Error state handling - if any of the queries failed
  if (!earningsData && !isLoadingEarnings) {
    return (
      <Card className="w-full">
        <CardHeader className="pb-2">
          <CardTitle>Earnings</CardTitle>
          <CardDescription>Your delivery earnings and payments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6 text-muted-foreground">
            <p>Unable to load earnings data.</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!earningsData) {
    return (
      <Card className="w-full">
        <CardHeader className="pb-2">
          <CardTitle>Earnings</CardTitle>
          <CardDescription>Your delivery earnings and payments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6 text-muted-foreground">
            <p>No earnings data available yet.</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  const { summary, recentPayments } = earningsData;
  
  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle>Earnings</CardTitle>
        <CardDescription>Your delivery earnings and payments</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="summary" className="flex items-center gap-1.5">
              <TrendingUp className="h-4 w-4" />
              <span>Summary</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-1.5">
              <Clock className="h-4 w-4" />
              <span>History</span>
            </TabsTrigger>
            <TabsTrigger value="payment-preferences" className="flex items-center gap-1.5">
              <CreditCard className="h-4 w-4" />
              <span>Payment</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="summary" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg border bg-card p-4">
                <div className="flex flex-col space-y-1.5">
                  <span className="text-sm text-muted-foreground">Total Earnings</span>
                  <span className="text-2xl font-bold">{formatCurrency(summary.totalEarnings)}</span>
                </div>
              </div>
              <div className="rounded-lg border bg-card p-4">
                <div className="flex flex-col space-y-1.5">
                  <span className="text-sm text-muted-foreground">Completed Trips</span>
                  <span className="text-2xl font-bold">{summary.totalTrips}</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <div>
                    <h4 className="font-medium">Paid Earnings</h4>
                    <p className="text-sm text-muted-foreground">{summary.paidTrips} trips</p>
                  </div>
                </div>
                <span className="text-lg font-bold">{formatCurrency(summary.paidEarnings)}</span>
              </div>
              
              <div className="flex justify-between items-center p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-amber-500" />
                  <div>
                    <h4 className="font-medium">Pending Earnings</h4>
                    <p className="text-sm text-muted-foreground">{summary.pendingTrips} trips</p>
                  </div>
                </div>
                <span className="text-lg font-bold">{formatCurrency(summary.pendingEarnings)}</span>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="history">
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-muted-foreground">Recent Payments</h3>
              
              {recentPayments.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground border rounded-lg">
                  <p>No payment history available yet.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentPayments.map(payment => (
                    <div key={payment.id} className="flex justify-between items-center p-3 border rounded-lg">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">Order #{payment.orderId}</h4>
                          <Badge variant={payment.status === 'paid' ? 'default' : 'outline'}>
                            {payment.status === 'paid' ? 'Paid' : 'Pending'}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {new Date(payment.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{formatCurrency(payment.finalPayment)}</p>
                        <p className="text-xs text-muted-foreground">
                          {payment.commissionPercentage}% commission
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="payment-preferences">
            <div className="space-y-6">
              <div className="space-y-1.5">
                <h3 className="text-lg font-medium">Payment Method Preferences</h3>
                <p className="text-sm text-muted-foreground">
                  Choose how you want to receive your earnings
                </p>
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 border rounded-lg bg-muted/30">
                  <div className="flex items-center gap-3">
                    <CreditCard className="h-5 w-5 text-primary" />
                    <div>
                      <h4 className="font-medium">Current Payment Method</h4>
                      <p className="text-sm text-muted-foreground">
                        {getSelectedPaymentMethodName()}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <label htmlFor="payment-method" className="text-sm font-medium">
                    Select Payment Method
                  </label>
                  
                  {!paymentGateways || paymentGateways.length === 0 ? (
                    <div className="text-center py-6 text-muted-foreground border rounded-lg">
                      <p>No payment methods available at this time.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <Select
                        value={selectedPaymentMethod}
                        onValueChange={setSelectedPaymentMethod}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select a payment method" />
                        </SelectTrigger>
                        <SelectContent>
                          {paymentGateways.map((gateway) => (
                            <SelectItem key={gateway.id} value={gateway.gatewayType}>
                              {gateway.displayName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      
                      <Button 
                        className="w-full" 
                        onClick={handlePaymentPreferenceUpdate}
                        disabled={updatePaymentPreferenceMutation.isPending}
                      >
                        {updatePaymentPreferenceMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Updating...
                          </>
                        ) : (
                          'Save Payment Preference'
                        )}
                      </Button>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Payment Details Form */}
              {selectedPaymentMethod && (showDetailsForm || userData?.paymentDetails) && (
                <div className="space-y-4 mt-6">
                  <div className="space-y-1.5">
                    <h3 className="text-md font-medium">Payment Account Details</h3>
                    <p className="text-sm text-muted-foreground">
                      Enter your account details for {getSelectedPaymentMethodName()}
                    </p>
                  </div>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit((data) => updatePaymentDetailsMutation.mutate(data))} className="space-y-6">
                      {/* PayPal Email Form */}
                      {selectedPaymentMethod === 'paypal' && (
                        <FormField
                          control={form.control}
                          name="paypal.email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>PayPal Email Address</FormLabel>
                              <FormControl>
                                <div className="flex items-center space-x-2">
                                  <Mail className="h-4 w-4 text-muted-foreground" />
                                  <Input placeholder="your.email@example.com" {...field} />
                                </div>
                              </FormControl>
                              <FormDescription>
                                We'll send payments to this PayPal account
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                      
                      {/* Google Pay Email Form */}
                      {selectedPaymentMethod === 'google_pay' && (
                        <FormField
                          control={form.control}
                          name="google_pay.email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Google Pay Email Address</FormLabel>
                              <FormControl>
                                <div className="flex items-center space-x-2">
                                  <Mail className="h-4 w-4 text-muted-foreground" />
                                  <Input placeholder="your.google.email@gmail.com" {...field} />
                                </div>
                              </FormControl>
                              <FormDescription>
                                We'll send payments to this Google account
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                      
                      {/* M-Pesa Phone Form */}
                      {selectedPaymentMethod === 'mpesa' && (
                        <FormField
                          control={form.control}
                          name="mpesa.phoneNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>M-Pesa Phone Number</FormLabel>
                              <FormControl>
                                <div className="flex items-center space-x-2">
                                  <Phone className="h-4 w-4 text-muted-foreground" />
                                  <Input placeholder="e.g. 07XXXXXXXX" {...field} />
                                </div>
                              </FormControl>
                              <FormDescription>
                                Payments will be sent to this Safaricom M-Pesa number
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                      
                      {/* Airtel Money Phone Form */}
                      {selectedPaymentMethod === 'airtel_money' && (
                        <FormField
                          control={form.control}
                          name="airtel_money.phoneNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Airtel Money Phone Number</FormLabel>
                              <FormControl>
                                <div className="flex items-center space-x-2">
                                  <Phone className="h-4 w-4 text-muted-foreground" />
                                  <Input placeholder="e.g. 01XXXXXXXX" {...field} />
                                </div>
                              </FormControl>
                              <FormDescription>
                                Payments will be sent to this Airtel Money account
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                      
                      {/* Auto Payout Switch */}
                      {/* Note about automatic payments now being managed by admin */}
                      <div className="rounded-lg border p-4 bg-muted/30">
                        <div className="flex items-center gap-2">
                          <Info className="h-5 w-5 text-blue-500" />
                          <h4 className="font-medium">Automatic Payments</h4>
                        </div>
                        <p className="mt-1 text-sm text-muted-foreground">
                          Payments are now managed by the system administrator. Your earnings will be automatically 
                          processed based on your preferred payment method.
                        </p>
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={updatePaymentDetailsMutation.isPending}
                      >
                        {updatePaymentDetailsMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Updating...
                          </>
                        ) : (
                          'Save Payment Details'
                        )}
                      </Button>
                    </form>
                  </Form>
                </div>
              )}
              
              {/* How it works info section */}
              <div className="mt-6 p-4 border rounded-lg bg-muted/30">
                <h4 className="text-sm font-medium flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  How it works
                </h4>
                <ul className="mt-2 space-y-2 text-sm text-muted-foreground">
                  <li>• Your earnings will be sent via your preferred payment method.</li>
                  <li>• Payments are processed within 1-3 business days after being marked as paid.</li>
                  <li>• For M-Pesa and Airtel Money, ensure you enter the correct phone number.</li>
                  <li>• For PayPal and Google Pay, ensure your email address is correct and active.</li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}