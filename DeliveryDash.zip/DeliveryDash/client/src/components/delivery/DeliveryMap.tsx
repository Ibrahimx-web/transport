import { useState, useEffect, useCallback } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow, Polyline } from '@react-google-maps/api';
import { 
  Navigation,
  MapPin, 
  Package,
  ArrowUpRight
} from 'lucide-react';
import { Order } from '@/types';
import { DEFAULT_COORDINATES } from '@/lib/constants';
import { useMapConfig, getFallbackApiKey } from '@/lib/mapService';
import { calculateDistance } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';

// Define types for props
interface DeliveryMapProps {
  pendingOrders: Order[];
  currentLat: number;
  currentLng: number;
  onSelectOrder?: (order: Order) => void;
}

// Format distance helper - we'll use this to display distances in km
const formatDistance = (distance: number): string => {
  return distance.toFixed(1);
};

export function DeliveryMap({ pendingOrders, currentLat, currentLng, onSelectOrder }: DeliveryMapProps) {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [routePath, setRoutePath] = useState<google.maps.LatLngLiteral[]>([]);
  const [mapRef, setMapRef] = useState<google.maps.Map | null>(null);
  
  // Use our map configuration service
  const { config, isLoading: isConfigLoading } = useMapConfig();
  
  // Get API key from config or fallback
  const apiKey = config?.isActive && config?.provider === 'google_maps' 
    ? config.apiKey 
    : getFallbackApiKey('google_maps');
  
  // Load the Google Maps JavaScript API
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: apiKey || ''
  });
  
  // Update route path when an order is selected
  useEffect(() => {
    if (selectedOrder && currentLat && currentLng) {
      // Create a route path between current location and pickup location
      const path = [
        { lat: currentLat, lng: currentLng },
        { lat: selectedOrder.pickupLat, lng: selectedOrder.pickupLng }
      ];
      
      setRoutePath(path);
      
      // Center map to fit both points if map reference exists
      if (mapRef) {
        const bounds = new google.maps.LatLngBounds();
        path.forEach(point => bounds.extend(point));
        mapRef.fitBounds(bounds);
      }
    } else {
      setRoutePath([]);
    }
  }, [selectedOrder, currentLat, currentLng, mapRef]);
  
  // Handle selecting an order
  const handleSelectOrder = useCallback((order: Order) => {
    setSelectedOrder(order);
    if (onSelectOrder) {
      onSelectOrder(order);
    }
  }, [onSelectOrder]);
  
  // Save map reference on load
  const onMapLoad = useCallback((map: google.maps.Map) => {
    setMapRef(map);
  }, []);
  
  // Show loading state if either map config or Google Maps API is loading
  if (isConfigLoading || !isLoaded) {
    return (
      <div className="rounded-lg overflow-hidden border border-gray-200 shadow-sm">
        <div className="h-[400px] flex items-center justify-center bg-gray-100">
          <div className="flex flex-col items-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-2"></div>
            <p className="text-sm text-muted-foreground">
              {isConfigLoading ? 'Loading map configuration...' : 'Loading map...'}
            </p>
          </div>
        </div>
      </div>
    );
  }
  
  // Show error state if no API key is available
  if (!apiKey) {
    return (
      <div className="rounded-lg overflow-hidden border border-gray-200 shadow-sm">
        <div className="h-[400px] flex items-center justify-center bg-gray-100">
          <div className="text-center max-w-md px-4">
            <p className="text-red-500 font-medium mb-2">No map API key configured</p>
            <p className="text-sm text-muted-foreground">
              Please configure a Google Maps API key in the admin settings.
            </p>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="rounded-lg overflow-hidden border border-gray-200 shadow-sm">
      <div className="h-[400px] relative">
        <GoogleMap
          mapContainerStyle={{ width: '100%', height: '100%' }}
          center={{ lat: currentLat || DEFAULT_COORDINATES.lat, lng: currentLng || DEFAULT_COORDINATES.lng }}
          zoom={13}
          options={{
            fullscreenControl: false,
            streetViewControl: false,
            mapTypeControl: false,
            zoomControl: true
          }}
          onLoad={onMapLoad}
        >
          {/* Current location marker with pulsing effect */}
          {currentLat && currentLng && (
            <Marker
              position={{ lat: currentLat, lng: currentLng }}
              icon={{
                url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2">
                    <circle cx="12" cy="12" r="10" fill="#b91c1c" />
                    <path d="M12 8l4 4m0-4l-4 4" stroke="#fff" stroke-linecap="round" />
                  </svg>`
                ),
                scaledSize: new google.maps.Size(30, 30)
              }}
            />
          )}
          
          {/* Pending order markers */}
          {pendingOrders.map(order => (
            <Marker
              key={order.id}
              position={{ lat: order.pickupLat, lng: order.pickupLng }}
              onClick={() => handleSelectOrder(order)}
              icon={{
                url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2">
                    <circle cx="12" cy="12" r="10" fill="#16a34a" />
                    <path d="M8 11h8M12 7v8" stroke="#fff" stroke-linecap="round" />
                  </svg>`
                ),
                scaledSize: new google.maps.Size(30, 30)
              }}
            />
          ))}
          
          {/* Route line between current location and selected order */}
          {routePath.length > 0 && (
            <Polyline
              path={routePath}
              options={{
                strokeColor: '#3B82F6',
                strokeOpacity: 0.8,
                strokeWeight: 3
              }}
            />
          )}
          
          {/* Info window for selected order */}
          {selectedOrder && (
            <InfoWindow
              position={{ lat: selectedOrder.pickupLat, lng: selectedOrder.pickupLng }}
              onCloseClick={() => setSelectedOrder(null)}
              options={{
                pixelOffset: new google.maps.Size(0, -5)
              }}
            >
              <div className="p-1 max-w-[220px]">
                <div className="font-medium flex items-center justify-between">
                  <div>Order #{selectedOrder.id}</div>
                  <Badge variant="outline" className="text-xs">
                    {formatDistance(selectedOrder.distance)} km
                  </Badge>
                </div>
                <div className="text-xs text-gray-600 mt-1">
                  <div className="flex items-start gap-1 mb-1">
                    <MapPin className="h-3 w-3 mt-0.5 text-green-600 flex-shrink-0" />
                    <span className="line-clamp-1">{selectedOrder.pickupLocation}</span>
                  </div>
                  <div className="flex items-start gap-1">
                    <MapPin className="h-3 w-3 mt-0.5 text-red-600 flex-shrink-0" />
                    <span className="line-clamp-1">{selectedOrder.deliveryLocation}</span>
                  </div>
                </div>
                <Link href={`/delivery/accept/${selectedOrder.id}`}>
                  <Button size="sm" className="w-full mt-2 text-xs py-1 h-7">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    Accept Request
                  </Button>
                </Link>
              </div>
            </InfoWindow>
          )}
        </GoogleMap>
      </div>
    </div>
  );
}