import { useState, useEffect, useRef } from 'react';
import { GoogleMap, useJsApiLoader, Marker, Polyline, InfoWindow } from '@react-google-maps/api';
import { Button } from '@/components/ui/button';
import { MapPin, Navigation, Clock, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useMapConfig, getFallbackApiKey } from '@/lib/mapService';

// Loading fallback component
const MapLoadingFallback = () => (
  <div className="w-full h-[400px] flex items-center justify-center border border-gray-200 rounded-lg bg-gray-50">
    <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
  </div>
);

interface RoutePoint {
  lat: number;
  lng: number;
}

interface AnimatedRouteProgressProps {
  pickupLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  deliveryLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  currentLocation?: {
    lat: number;
    lng: number;
  };
  progress?: number; // 0 to 100
  onArrived?: () => void;
  showDirections?: boolean;
}

export function AnimatedRouteProgress({
  pickupLocation,
  deliveryLocation,
  currentLocation,
  progress = 0,
  onArrived,
  showDirections = true
}: AnimatedRouteProgressProps) {
  // Use our map configuration service
  const { config, isLoading: isConfigLoading } = useMapConfig();
  
  // Get API key from config or fallback
  const apiKey = config?.isActive && config?.provider === 'google_maps' 
    ? config.apiKey 
    : getFallbackApiKey('google_maps');
  
  // Load the Google Maps JavaScript API
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: apiKey || ''
  });

  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [routePoints, setRoutePoints] = useState<RoutePoint[]>([]);
  const [currentPosition, setCurrentPosition] = useState<RoutePoint | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<'pickup' | 'delivery' | 'current' | null>(null);
  const [showVehicleInfo, setShowVehicleInfo] = useState(false);
  
  // Animation frame management
  const animationFrameRef = useRef<number | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [animationSpeed, setAnimationSpeed] = useState(1); // Speed multiplier
  
  // Calculate route points between pickup and delivery locations
  useEffect(() => {
    if (!pickupLocation || !deliveryLocation) return;
    
    // Generate a series of points between pickup and delivery for a smooth route
    const generateRoutePoints = (start: RoutePoint, end: RoutePoint, numPoints: number): RoutePoint[] => {
      const points: RoutePoint[] = [];
      
      for (let i = 0; i <= numPoints; i++) {
        const fraction = i / numPoints;
        
        // Add some randomness for a more natural path
        const jitter = (i > 0 && i < numPoints) ? {
          lat: (Math.random() - 0.5) * 0.005,
          lng: (Math.random() - 0.5) * 0.005
        } : { lat: 0, lng: 0 };
        
        points.push({
          lat: start.lat + (end.lat - start.lat) * fraction + jitter.lat,
          lng: start.lng + (end.lng - start.lng) * fraction + jitter.lng
        });
      }
      
      return points;
    };
    
    const points = generateRoutePoints(
      { lat: pickupLocation.lat, lng: pickupLocation.lng },
      { lat: deliveryLocation.lat, lng: deliveryLocation.lng },
      20
    );
    
    setRoutePoints(points);
    
    // Initialize current position to the start (pickup location)
    setCurrentPosition(points[0]);
  }, [pickupLocation, deliveryLocation]);
  
  // Update position based on progress
  useEffect(() => {
    if (!routePoints.length) return;
    
    // If progress is provided, set the current position based on the progress percentage
    if (currentLocation) {
      // Use actual current location if provided
      setCurrentPosition(currentLocation);
    } else if (progress !== undefined) {
      // Otherwise use the progress percentage to determine position along the route
      const pointIndex = Math.min(
        Math.floor(progress / 100 * (routePoints.length - 1)),
        routePoints.length - 1
      );
      setCurrentPosition(routePoints[pointIndex]);
      
      // Trigger arrived callback when we reach the end
      if (progress >= 100 && onArrived) {
        onArrived();
      }
    }
  }, [progress, routePoints, currentLocation, onArrived]);
  
  // Animate the route when animation is playing
  useEffect(() => {
    if (!isAnimating || !routePoints.length) return;
    
    let stepIndex = 0;
    const totalSteps = routePoints.length;
    let rafId: number | null = null;
    
    const animate = () => {
      if (stepIndex < totalSteps) {
        setCurrentPosition(routePoints[stepIndex]);
        stepIndex += animationSpeed;
        rafId = requestAnimationFrame(animate);
        animationFrameRef.current = rafId;
      } else {
        // Reached the end
        setIsAnimating(false);
        if (onArrived) onArrived();
      }
    };
    
    rafId = requestAnimationFrame(animate);
    animationFrameRef.current = rafId;
    
    // Cleanup animation
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
    };
  }, [isAnimating, routePoints, animationSpeed, onArrived]);
  
  // Toggle animation playback
  const toggleAnimation = () => {
    setIsAnimating(prev => !prev);
  };
  
  // Reset animation to the beginning
  const resetAnimation = () => {
    setIsAnimating(false);
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    setCurrentPosition(routePoints[0]);
  };
  
  // Handle map load
  const onMapLoad = (mapInstance: google.maps.Map) => {
    setMap(mapInstance);
    
    // Set map bounds to fit all route points
    if (routePoints.length) {
      const bounds = new google.maps.LatLngBounds();
      routePoints.forEach(point => bounds.extend(point));
      mapInstance.fitBounds(bounds);
    }
  };
  
  // Calculate the traveled path points
  const getTraveledPath = (): RoutePoint[] => {
    if (!currentPosition || !routePoints.length) return [];
    
    const currentIndex = routePoints.findIndex(
      point => point.lat === currentPosition.lat && point.lng === currentPosition.lng
    );
    
    return routePoints.slice(0, currentIndex + 1);
  };
  
  // Calculate the remaining path points
  const getRemainingPath = (): RoutePoint[] => {
    if (!currentPosition || !routePoints.length) return routePoints;
    
    const currentIndex = routePoints.findIndex(
      point => point.lat === currentPosition.lat && point.lng === currentPosition.lng
    );
    
    if (currentIndex === -1) return routePoints;
    return routePoints.slice(currentIndex);
  };
  
  // Calculate the estimated time of arrival
  const getETA = (): string => {
    if (!currentPosition || !routePoints.length) return 'Calculating...';
    
    const currentIndex = routePoints.findIndex(
      point => point.lat === currentPosition.lat && point.lng === currentPosition.lng
    );
    
    if (currentIndex === -1) return 'Calculating...';
    
    // Assume average speed of 30 km/h and calculate remaining time
    const remainingPoints = routePoints.length - currentIndex - 1;
    const totalPoints = routePoints.length - 1;
    const progress = currentIndex / totalPoints;
    
    if (progress >= 1) return 'Arrived';
    
    const estimatedTotalMinutes = 30; // Assume 30 minutes for total journey
    const remainingMinutes = Math.ceil((1 - progress) * estimatedTotalMinutes);
    
    if (remainingMinutes <= 1) return 'Arriving now';
    return `${remainingMinutes} minutes`;
  };
  
  // Show loading state if either map config or Google Maps API is loading
  if (isConfigLoading || !isLoaded) {
    return (
      <div className="w-full h-[400px] flex items-center justify-center border border-gray-200 rounded-lg bg-gray-50">
        <div className="flex flex-col items-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-2"></div>
          <p className="text-sm text-muted-foreground">
            {isConfigLoading ? 'Loading map configuration...' : 'Loading map...'}
          </p>
        </div>
      </div>
    );
  }
  
  // Show error state if no API key is available
  if (!apiKey) {
    return (
      <div className="w-full h-[400px] flex items-center justify-center border border-gray-200 rounded-lg bg-gray-50">
        <div className="text-center max-w-md px-4">
          <AlertCircle className="h-6 w-6 text-amber-500 mx-auto mb-2" />
          <p className="text-red-500 font-medium mb-1">No map API key configured</p>
          <p className="text-sm text-muted-foreground">
            Please configure a Google Maps API key in admin settings.
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="relative w-full h-[400px] border border-gray-200 rounded-lg overflow-hidden">
      <GoogleMap
        mapContainerStyle={{ width: '100%', height: '100%' }}
        center={currentPosition || { lat: pickupLocation.lat, lng: pickupLocation.lng }}
        zoom={14}
        options={{
          fullscreenControl: false,
          mapTypeControl: false,
          streetViewControl: false,
          zoomControl: true
        }}
        onLoad={onMapLoad}
      >
        {/* Pickup marker */}
        <Marker
          position={{ lat: pickupLocation.lat, lng: pickupLocation.lng }}
          icon={{
            url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
              `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" fill="#3b82f6" stroke="white" stroke-width="2" />
                <path d="M12 7v10M7 12h10" stroke="white" stroke-width="2" stroke-linecap="round" />
              </svg>`
            ),
            scaledSize: new google.maps.Size(32, 32)
          }}
          onClick={() => setSelectedLocation('pickup')}
        />
        
        {/* Delivery marker */}
        <Marker
          position={{ lat: deliveryLocation.lat, lng: deliveryLocation.lng }}
          icon={{
            url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
              `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" fill="#10b981" stroke="white" stroke-width="2" />
                <path d="M8 12l3 3l5-5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
              </svg>`
            ),
            scaledSize: new google.maps.Size(32, 32)
          }}
          onClick={() => setSelectedLocation('delivery')}
        />
        
        {/* Vehicle marker */}
        {currentPosition && (
          <Marker
            position={currentPosition}
            icon={{
              url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="10" fill="#ef4444" stroke="white" stroke-width="2" />
                  <path d="M12 7v5l3 3" stroke="white" stroke-width="2" stroke-linecap="round" />
                </svg>`
              ),
              scaledSize: new google.maps.Size(36, 36)
            }}
            onClick={() => setShowVehicleInfo(!showVehicleInfo)}
            animation={google.maps.Animation.BOUNCE}
          />
        )}
        
        {/* Route (traveled) line */}
        <Polyline
          path={getTraveledPath()}
          options={{
            strokeColor: '#10b981',
            strokeOpacity: 0.8,
            strokeWeight: 5,
          }}
        />
        
        {/* Route (remaining) line */}
        <Polyline
          path={getRemainingPath()}
          options={{
            strokeColor: '#3b82f6',
            strokeOpacity: 0.6,
            strokeWeight: 5,
            // Using custom dashing through stroke pattern instead of strokeDasharray
            icons: [{
              icon: {
                path: 'M 0,-1 0,1',
                strokeOpacity: 0.6,
                scale: 3
              },
              offset: '0',
              repeat: '10px'
            }],
          }}
        />
        
        {/* Direction indicators along the route */}
        {showDirections && routePoints.length > 5 && (
          <>
            {[0.25, 0.5, 0.75].map((fraction, index) => {
              const pointIndex = Math.floor(routePoints.length * fraction);
              if (pointIndex >= routePoints.length || pointIndex < 0) return null;
              
              return (
                <Marker
                  key={`direction-${index}`}
                  position={routePoints[pointIndex]}
                  icon={{
                    url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="8" fill="white" />
                        <path d="M10 8l4 4l-4 4" stroke="#3b82f6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                      </svg>`
                    ),
                    scaledSize: new google.maps.Size(20, 20),
                  }}
                />
              );
            })}
          </>
        )}
        
        {/* Info windows */}
        {selectedLocation === 'pickup' && (
          <InfoWindow
            position={{ lat: pickupLocation.lat, lng: pickupLocation.lng }}
            onCloseClick={() => setSelectedLocation(null)}
          >
            <div className="p-2 max-w-[200px]">
              <div className="flex items-center gap-1 text-blue-600 mb-1">
                <MapPin className="h-4 w-4" />
                <h3 className="font-semibold text-sm">Pickup Point</h3>
              </div>
              <p className="text-xs text-gray-600 mb-1.5">{pickupLocation.address}</p>
              <div className="flex justify-end">
                <Button size="sm" className="h-7 px-2 text-xs" variant="outline">
                  Navigate
                </Button>
              </div>
            </div>
          </InfoWindow>
        )}
        
        {selectedLocation === 'delivery' && (
          <InfoWindow
            position={{ lat: deliveryLocation.lat, lng: deliveryLocation.lng }}
            onCloseClick={() => setSelectedLocation(null)}
          >
            <div className="p-2 max-w-[200px]">
              <div className="flex items-center gap-1 text-green-600 mb-1">
                <CheckCircle2 className="h-4 w-4" />
                <h3 className="font-semibold text-sm">Delivery Destination</h3>
              </div>
              <p className="text-xs text-gray-600 mb-1.5">{deliveryLocation.address}</p>
              <div className="flex justify-end">
                <Button size="sm" className="h-7 px-2 text-xs" variant="outline">
                  Navigate
                </Button>
              </div>
            </div>
          </InfoWindow>
        )}
        
        {showVehicleInfo && currentPosition && (
          <InfoWindow
            position={currentPosition}
            onCloseClick={() => setShowVehicleInfo(false)}
          >
            <div className="p-2 max-w-[200px]">
              <div className="flex items-center gap-1 text-red-600 mb-1">
                <AlertCircle className="h-4 w-4" />
                <h3 className="font-semibold text-sm">Current Position</h3>
              </div>
              <div className="space-y-1 mb-2">
                <div className="flex items-center gap-1.5 text-xs text-gray-600">
                  <Clock className="h-3.5 w-3.5" />
                  <span>ETA: {getETA()}</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-gray-600">
                  <Navigation className="h-3.5 w-3.5" />
                  <span>Speed: 30 km/h</span>
                </div>
              </div>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
      
      {/* Map controls overlay */}
      <div className="absolute bottom-4 right-4 flex gap-2">
        <Button
          size="sm"
          variant="secondary"
          className="shadow-md"
          onClick={resetAnimation}
        >
          Reset
        </Button>
        <Button
          size="sm"
          variant="default"
          className="shadow-md"
          onClick={toggleAnimation}
        >
          {isAnimating ? 'Pause' : 'Play Animation'}
        </Button>
      </div>
      
      {/* Speed control */}
      <div className="absolute bottom-4 left-4 bg-white/80 p-2 rounded-md shadow-md flex flex-col">
        <div className="text-xs font-medium mb-1">Animation Speed</div>
        <div className="flex items-center gap-2">
          <button 
            className={`px-2 py-1 rounded text-xs ${animationSpeed === 0.5 ? 'bg-blue-100 text-blue-700' : 'bg-gray-100'}`}
            onClick={() => setAnimationSpeed(0.5)}
          >
            0.5x
          </button>
          <button 
            className={`px-2 py-1 rounded text-xs ${animationSpeed === 1 ? 'bg-blue-100 text-blue-700' : 'bg-gray-100'}`}
            onClick={() => setAnimationSpeed(1)}
          >
            1x
          </button>
          <button 
            className={`px-2 py-1 rounded text-xs ${animationSpeed === 2 ? 'bg-blue-100 text-blue-700' : 'bg-gray-100'}`}
            onClick={() => setAnimationSpeed(2)}
          >
            2x
          </button>
        </div>
      </div>
    </div>
  );
}