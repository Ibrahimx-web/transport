import { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow, Polyline, Circle } from '@react-google-maps/api';
import { MapPin, Navigation, Truck, Clock, Info, AlertTriangle, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import { Order } from '@/types';
import { calculateDistance, generateRouteWaypoints, calculateETA } from '@/lib/map';
import { formatDistanceToNow } from 'date-fns';
import { DEFAULT_COORDINATES } from '@/lib/constants';
import { Button } from '@/components/ui/button';
import { useLocationWebSocket } from '@/hooks/use-location-websocket';
import { useMapConfig, getFallbackApiKey } from '@/lib/mapService';

interface DeliveryPartnerMapProps {
  orders: Order[];
  currentLat: number;
  currentLng: number;
  userId?: number;
  onOrderSelect?: (order: Order) => void;
}

export function DeliveryPartnerMap({ 
  orders, 
  currentLat, 
  currentLng,
  userId,
  onOrderSelect 
}: DeliveryPartnerMapProps) {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<'pickup' | 'delivery' | 'partner' | null>(null);
  const [routes, setRoutes] = useState<{
    partnerToPickup: any;
    pickupToDelivery: any;
  } | null>(null);
  const [showDirections, setShowDirections] = useState(false);
  const [mapRef, setMapRef] = useState<google.maps.Map | null>(null);
  
  // Connect to WebSocket for location updates if userId is provided
  const { isConnected, sendLocationUpdate } = useLocationWebSocket({
    userId,
    userType: 'delivery',
    onConnect: () => {
      console.log('WebSocket connected, driver can now receive real-time updates');
    }
  });
  
  // Reference to store the interval ID for sending location updates
  const locationIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // Track position history for the vehicle path
  const [positionHistory, setPositionHistory] = useState<google.maps.LatLngLiteral[]>([]);
  const [movementStatus, setMovementStatus] = useState<'stationary' | 'moving'>('stationary');
  const [locationAccuracy, setLocationAccuracy] = useState<number | null>(null);
  const lastPositionRef = useRef<{lat: number, lng: number} | null>(null);
  const movementTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Get map configuration from our centralized service
  const { config, isLoading: isConfigLoading, isError: isConfigError } = useMapConfig();
  
  // Get the API key based on the map configuration
  const apiKey = config?.isActive && config?.provider === 'google_maps' 
    ? config.apiKey 
    : getFallbackApiKey('google_maps');
  
  // Load Google Maps JavaScript API
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: apiKey || '',
    // Load additional libraries
    libraries: ['geometry']
  });
  
  // Track position history and movement detection
  useEffect(() => {
    if (currentLat && currentLng) {
      const currentPosition = { lat: currentLat, lng: currentLng };
      
      // Update position history (keep the last 50 points)
      setPositionHistory(prev => {
        const newHistory = [...prev, currentPosition];
        return newHistory.slice(-50); // Keep only the last 50 positions to avoid memory issues
      });
      
      // Detect if we're moving or stationary
      const lastPosition = lastPositionRef.current;
      if (lastPosition) {
        // Calculate distance from last position in meters
        const distance = google.maps.geometry?.spherical?.computeDistanceBetween(
          new google.maps.LatLng(lastPosition.lat, lastPosition.lng),
          new google.maps.LatLng(currentLat, currentLng)
        ) || 0;
        
        // If we've moved more than 10 meters, consider it "moving"
        if (distance > 10) {
          setMovementStatus('moving');
          
          // Reset the stationary timer
          if (movementTimerRef.current) {
            clearTimeout(movementTimerRef.current);
          }
          
          // Set a timer to mark as stationary if no movement after 30 seconds
          movementTimerRef.current = setTimeout(() => {
            setMovementStatus('stationary');
          }, 30000);
        }
        
        // Simulate location accuracy (in a real app, we'd get this from the Geolocation API)
        // Here we're just setting a random value between 5-20 meters for demonstration
        setLocationAccuracy(Math.floor(Math.random() * 15) + 5);
      }
      
      // Update last position
      lastPositionRef.current = currentPosition;
    }
    
    return () => {
      if (movementTimerRef.current) {
        clearTimeout(movementTimerRef.current);
        movementTimerRef.current = null;
      }
    };
  }, [currentLat, currentLng]);

  // Send location updates periodically if connected to WebSocket
  useEffect(() => {
    if (isConnected && userId && currentLat && currentLng) {
      // Clear any existing interval
      if (locationIntervalRef.current) {
        clearInterval(locationIntervalRef.current);
      }
      
      // Send initial location update
      sendLocationUpdate(currentLat, currentLng);
      
      // Set up interval to send updates every 10 seconds
      locationIntervalRef.current = setInterval(() => {
        sendLocationUpdate(currentLat, currentLng);
      }, 10000); // Every 10 seconds
    }
    
    // Cleanup interval on unmount or when connection changes
    return () => {
      if (locationIntervalRef.current) {
        clearInterval(locationIntervalRef.current);
        locationIntervalRef.current = null;
      }
    };
  }, [isConnected, userId, currentLat, currentLng, sendLocationUpdate]);
  
  // Generate routes when an order is selected
  useEffect(() => {
    if (!selectedOrder || !currentLat || !currentLng) {
      setRoutes(null);
      return;
    }
    
    // Generate driver to pickup route
    const partnerToPickupPoints = generateRouteWaypoints(
      { lat: currentLat, lng: currentLng },
      { lat: selectedOrder.pickupLat, lng: selectedOrder.pickupLng },
      8
    );
    
    // Generate pickup to delivery route
    const pickupToDeliveryPoints = generateRouteWaypoints(
      { lat: selectedOrder.pickupLat, lng: selectedOrder.pickupLng },
      { lat: selectedOrder.deliveryLat, lng: selectedOrder.deliveryLng },
      8
    );
    
    // Create GeoJSON data for routes
    const partnerToPickupRoute = {
      type: 'Feature',
      properties: {},
      geometry: {
        type: 'LineString',
        coordinates: partnerToPickupPoints.map(point => [point.lng, point.lat]),
      },
    };
    
    const pickupToDeliveryRoute = {
      type: 'Feature',
      properties: {},
      geometry: {
        type: 'LineString',
        coordinates: pickupToDeliveryPoints.map(point => [point.lng, point.lat]),
      },
    };
    
    setRoutes({
      partnerToPickup: partnerToPickupRoute,
      pickupToDelivery: pickupToDeliveryRoute,
    });
    
    // If we have map reference and route, fit bounds to show the full route
    if (mapRef && selectedOrder) {
      const bounds = new google.maps.LatLngBounds();
      bounds.extend({ lat: currentLat, lng: currentLng });
      bounds.extend({ lat: selectedOrder.pickupLat, lng: selectedOrder.pickupLng });
      bounds.extend({ lat: selectedOrder.deliveryLat, lng: selectedOrder.deliveryLng });
      mapRef.fitBounds(bounds);
    }
  }, [selectedOrder, currentLat, currentLng, mapRef]);
  
  // Format distance for display
  const formatDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
    const distance = calculateDistance(lat1, lng1, lat2, lng2);
    return distance < 1 ? `${(distance * 1000).toFixed(0)}m` : `${distance.toFixed(1)}km`;
  };
  
  // Calculate ETA for pickup and delivery
  const calculateETAInfo = (order: Order) => {
    // Distance from current location to pickup point
    const distanceToPickup = calculateDistance(
      currentLat, 
      currentLng, 
      order.pickupLat, 
      order.pickupLng
    );
    
    // Distance from pickup to delivery
    const distanceToDelivery = calculateDistance(
      order.pickupLat, 
      order.pickupLng, 
      order.deliveryLat, 
      order.deliveryLng
    );
    
    // Calculate ETAs using different speeds based on distance
    // Shorter distances typically have lower average speeds due to city traffic
    const pickupETA = calculateETA(distanceToPickup, distanceToPickup < 5 ? 20 : 30);
    const deliveryETA = calculateETA(distanceToDelivery, distanceToDelivery < 5 ? 20 : 30, pickupETA);
    
    return {
      pickupDistance: distanceToPickup,
      pickupETA,
      deliveryDistance: distanceToDelivery,
      deliveryETA,
      totalDistance: distanceToPickup + distanceToDelivery
    };
  };
  
  // Handle marker click
  const handleMarkerClick = (order: Order, locationType: 'pickup' | 'delivery') => {
    setSelectedOrder(order);
    setSelectedLocation(locationType);
    
    // Call onOrderSelect callback if provided
    if (onOrderSelect) {
      onOrderSelect(order);
    }
  };
  
  // Convert GeoJSON route to Google Maps path coordinates
  const [mapRoutes, setMapRoutes] = useState<{
    partnerToPickup: google.maps.LatLngLiteral[];
    pickupToDelivery: google.maps.LatLngLiteral[];
  } | null>(null);
  
  // Convert routes to Google Maps format
  useEffect(() => {
    if (!routes) {
      setMapRoutes(null);
      return;
    }
    
    // Convert the coordinates from the GeoJSON format to Google Maps format
    const partnerToPickupCoords = routes.partnerToPickup.geometry.coordinates.map(
      (coord: [number, number]) => ({ lat: coord[1], lng: coord[0] })
    );
    
    const pickupToDeliveryCoords = routes.pickupToDelivery.geometry.coordinates.map(
      (coord: [number, number]) => ({ lat: coord[1], lng: coord[0] })
    );
    
    setMapRoutes({
      partnerToPickup: partnerToPickupCoords,
      pickupToDelivery: pickupToDeliveryCoords
    });
  }, [routes]);
  
  // Handle map load
  const onMapLoad = useCallback((map: google.maps.Map) => {
    setMapRef(map);
  }, []);
  
  // If API configuration is still loading
  if (isConfigLoading) {
    return (
      <div className="w-full h-[400px] relative rounded-lg overflow-hidden border border-border shadow-sm flex items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-2"></div>
          <p className="text-sm text-muted-foreground">Loading map configuration...</p>
        </div>
      </div>
    );
  }
  
  // If no API key is available
  if (!apiKey) {
    return (
      <div className="w-full h-[400px] relative rounded-lg overflow-hidden border border-border shadow-sm flex items-center justify-center bg-gray-50">
        <div className="text-center max-w-md px-4">
          <AlertTriangle className="h-6 w-6 text-amber-500 mx-auto mb-2" />
          <p className="text-red-500 font-medium mb-1">No map API key configured</p>
          <p className="text-sm text-muted-foreground">
            Please configure a Google Maps API key in admin settings.
          </p>
        </div>
      </div>
    );
  }
  
  // If map is still loading
  if (!isLoaded) {
    return (
      <div className="w-full h-[400px] relative rounded-lg overflow-hidden border border-border shadow-sm flex items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-2"></div>
          <p className="text-sm text-muted-foreground">Loading map...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="w-full h-[400px] relative rounded-lg overflow-hidden border border-border shadow-sm">
      <GoogleMap
        mapContainerStyle={{ width: '100%', height: '100%' }}
        center={{ lat: currentLat || DEFAULT_COORDINATES.lat, lng: currentLng || DEFAULT_COORDINATES.lng }}
        zoom={13}
        options={{
          fullscreenControl: false,
          streetViewControl: false,
          mapTypeControl: false,
          zoomControl: true
        }}
        onLoad={onMapLoad}
      >
        {/* Position history trail (path the vehicle has taken) */}
        {positionHistory.length > 1 && (
          <Polyline
            path={positionHistory}
            options={{
              strokeColor: '#ef4444',
              strokeOpacity: 0.5,
              strokeWeight: 3,
              zIndex: 1
            }}
          />
        )}

        {/* Location accuracy circle */}
        {locationAccuracy && (
          <Circle
            center={{ lat: currentLat, lng: currentLng }}
            radius={locationAccuracy}
            options={{
              strokeColor: '#ef4444',
              strokeOpacity: 0.4,
              strokeWeight: 1,
              fillColor: '#ef4444',
              fillOpacity: 0.1,
              zIndex: 1
            }}
          />
        )}
        
        {/* Partner's current location marker with animation based on movement status */}
        <Marker
          position={{ lat: currentLat, lng: currentLng }}
          icon={{
            url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
              `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" fill="#ef4444" stroke="white" stroke-width="2" />
                <path d="M7 12h10M12 17v-10" stroke="white" stroke-width="2" stroke-linecap="round" />
              </svg>`
            ),
            scaledSize: new google.maps.Size(40, 40)
          }}
          animation={movementStatus === 'moving' ? google.maps.Animation.BOUNCE : undefined}
          onClick={() => setSelectedLocation('partner')}
        />
        
        {/* Order markers */}
        {orders.map(order => (
          <div key={order.id}>
            {/* Pickup location marker */}
            <Marker
              position={{ lat: order.pickupLat, lng: order.pickupLng }}
              icon={{
                url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="#3b82f6" stroke="white" stroke-width="2" />
                    <path d="M12 17v-10M7 12h10" stroke="white" stroke-width="2" stroke-linecap="round" />
                  </svg>`
                ),
                scaledSize: new google.maps.Size(30, 30)
              }}
              onClick={() => handleMarkerClick(order, 'pickup')}
            />
            
            {/* Delivery location marker */}
            <Marker
              position={{ lat: order.deliveryLat, lng: order.deliveryLng }}
              icon={{
                url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="#10b981" stroke="white" stroke-width="2" />
                    <path d="M8 12l3 3l5-5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                  </svg>`
                ),
                scaledSize: new google.maps.Size(30, 30)
              }}
              onClick={() => handleMarkerClick(order, 'delivery')}
            />
          </div>
        ))}
        
        {/* Route lines */}
        {mapRoutes && (
          <>
            {/* Partner to pickup route - red dashed line */}
            <Polyline
              path={mapRoutes.partnerToPickup}
              options={{
                strokeColor: '#EF4444',
                strokeOpacity: 0.8,
                strokeWeight: 4,
                icons: [{
                  icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 3,
                    fillColor: '#FFFFFF',
                    fillOpacity: 1,
                    strokeWeight: 0
                  },
                  offset: '0',
                  repeat: '15px'
                }]
              }}
            />
            
            {/* Pickup to delivery route - green solid line */}
            <Polyline
              path={mapRoutes.pickupToDelivery}
              options={{
                strokeColor: '#10B981',
                strokeOpacity: 0.8,
                strokeWeight: 4
              }}
            />
          </>
        )}
        
        {/* Route direction indicators */}
        {selectedOrder && mapRoutes && showDirections && (
          <>
            {/* Mid-point direction indicators */}
            {[0.25, 0.5, 0.75].map((fraction, index) => {
              const pickupRoutePos = Math.floor(mapRoutes.partnerToPickup.length * fraction);
              const deliveryRoutePos = Math.floor(mapRoutes.pickupToDelivery.length * fraction);
              
              return (
                <div key={`direction-${index}`}>
                  {pickupRoutePos > 0 && pickupRoutePos < mapRoutes.partnerToPickup.length && (
                    <Marker
                      position={mapRoutes.partnerToPickup[pickupRoutePos]}
                      icon={{
                        url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                          `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                            <circle cx="12" cy="12" r="10" fill="white" stroke="#EF4444" stroke-width="2" />
                            <path d="M10 8l4 4l-4 4" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                          </svg>`
                        ),
                        scaledSize: new google.maps.Size(20, 20)
                      }}
                    />
                  )}
                  
                  {deliveryRoutePos > 0 && deliveryRoutePos < mapRoutes.pickupToDelivery.length && (
                    <Marker
                      position={mapRoutes.pickupToDelivery[deliveryRoutePos]}
                      icon={{
                        url: "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
                          `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                            <circle cx="12" cy="12" r="10" fill="white" stroke="#10B981" stroke-width="2" />
                            <path d="M10 8l4 4l-4 4" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                          </svg>`
                        ),
                        scaledSize: new google.maps.Size(20, 20)
                      }}
                    />
                  )}
                </div>
              );
            })}
          </>
        )}
        
        {/* Info windows for selected locations */}
        {selectedOrder && selectedLocation === 'pickup' && (
          <InfoWindow
            position={{ lat: selectedOrder.pickupLat, lng: selectedOrder.pickupLng }}
            onCloseClick={() => setSelectedLocation(null)}
          >
            <div className="p-2 w-64">
              <h3 className="font-medium text-sm">Pickup Point</h3>
              <p className="text-xs text-gray-500 mt-1">{selectedOrder.pickupLocation}</p>
              
              {currentLat && currentLng && (
                <div className="mt-2 border-t pt-2 text-xs">
                  <div className="flex items-center gap-1 text-gray-600">
                    <Info className="w-3 h-3" />
                    <span>Distance: {formatDistance(currentLat, currentLng, selectedOrder.pickupLat, selectedOrder.pickupLng)}</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-600 mt-1">
                    <Clock className="w-3 h-3" />
                    <span>ETA: {formatDistanceToNow(calculateETAInfo(selectedOrder).pickupETA)}</span>
                  </div>
                </div>
              )}
              
              <div className="mt-2 pt-2 flex justify-end">
                <Button size="sm" className="text-xs h-8 px-3" onClick={() => onOrderSelect?.(selectedOrder)}>
                  Accept Request
                </Button>
              </div>
            </div>
          </InfoWindow>
        )}
        
        {selectedOrder && selectedLocation === 'delivery' && (
          <InfoWindow
            position={{ lat: selectedOrder.deliveryLat, lng: selectedOrder.deliveryLng }}
            onCloseClick={() => setSelectedLocation(null)}
          >
            <div className="p-2 w-64">
              <h3 className="font-medium text-sm">Delivery Point</h3>
              <p className="text-xs text-gray-500 mt-1">{selectedOrder.deliveryLocation}</p>
              
              {selectedOrder.pickupLat && selectedOrder.pickupLng && (
                <div className="mt-2 border-t pt-2 text-xs">
                  <div className="flex items-center gap-1 text-gray-600">
                    <Info className="w-3 h-3" />
                    <span>Distance from pickup: {formatDistance(
                      selectedOrder.pickupLat, 
                      selectedOrder.pickupLng, 
                      selectedOrder.deliveryLat, 
                      selectedOrder.deliveryLng
                    )}</span>
                  </div>
                </div>
              )}
            </div>
          </InfoWindow>
        )}
        
        {selectedLocation === 'partner' && (
          <InfoWindow
            position={{ lat: currentLat, lng: currentLng }}
            onCloseClick={() => setSelectedLocation(null)}
          >
            <div className="p-2 w-64">
              <h3 className="font-medium text-sm">Your Location</h3>
              
              <div className="flex items-center justify-between mt-2">
                <span className={`text-xs ${isConnected ? 'text-green-600' : 'text-amber-600'} flex items-center gap-1`}>
                  <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-600' : 'bg-amber-500'}`}></div>
                  {isConnected ? "Broadcasting live" : "Offline"}
                </span>
                <span className={`text-xs ${movementStatus === 'moving' ? 'text-blue-600' : 'text-gray-500'} flex items-center gap-1`}>
                  <div className={`w-2 h-2 rounded-full ${movementStatus === 'moving' ? 'bg-blue-500' : 'bg-gray-400'}`}></div>
                  {movementStatus === 'moving' ? "Moving" : "Stationary"}
                </span>
              </div>
              
              <div className="mt-2 text-xs text-gray-600 border-t border-gray-200 pt-2">
                {locationAccuracy && (
                  <div className="flex items-center justify-between">
                    <span>GPS Accuracy:</span>
                    <span className={
                      locationAccuracy < 10 
                        ? "text-green-600" 
                        : locationAccuracy < 20 
                          ? "text-amber-500" 
                          : "text-red-500"
                    }>
                      ±{locationAccuracy.toFixed(0)} meters
                    </span>
                  </div>
                )}
                
                <div className="flex items-center justify-between mt-1">
                  <span>Position history:</span>
                  <span>{positionHistory.length} points</span>
                </div>
              </div>
              
              {!isConnected && userId && (
                <div className="mt-3 pt-1">
                  <Button size="sm" className="text-xs h-8 w-full" onClick={() => {
                    // Attempt to reconnect and send location update
                    if (currentLat && currentLng) {
                      sendLocationUpdate(currentLat, currentLng);
                    }
                  }}>
                    Start Sharing Location
                  </Button>
                </div>
              )}
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
      
      {/* Map overlay controls */}
      <div className="absolute bottom-4 right-4 z-10 flex flex-col gap-2">
        {selectedOrder && (
          <button
            className={`${showDirections ? 'bg-green-500 text-white' : 'bg-white text-gray-700'} p-2 rounded-full shadow-md hover:bg-green-600 hover:text-white transition-colors`}
            onClick={() => setShowDirections(!showDirections)}
            title={showDirections ? "Hide Directions" : "Show Directions"}
          >
            <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L16 5m0 12V5m0 0L9 7" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        )}
        <button
          className="bg-white p-2 rounded-full shadow-md text-gray-700 hover:bg-gray-100 transition-colors"
          onClick={() => {
            if (mapRef && currentLat && currentLng) {
              mapRef.panTo({ lat: currentLat, lng: currentLng });
              mapRef.setZoom(15);
            }
          }}
          title="Center on your location"
        >
          <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="3" />
            <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
          </svg>
        </button>
      </div>
      
      {/* Selected order info panel */}
      {selectedOrder && (
        <div className="absolute left-4 bottom-4 z-10 bg-white p-3 rounded-lg shadow-lg max-w-xs">
          <div className="flex items-center justify-between">
            <h3 className="font-medium">Order #{selectedOrder.id}</h3>
            <button 
              className="text-gray-400 hover:text-gray-600"
              onClick={() => setSelectedOrder(null)}
            >
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          {/* Route information */}
          <div className="mt-2 text-xs text-gray-600">
            <div className="flex items-start gap-2 mb-1">
              <div className="h-5 w-5 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0 mt-0.5">
                <MapPin className="h-3 w-3 text-white" />
              </div>
              <div>
                <div className="font-medium text-gray-700">From:</div>
                <div className="line-clamp-2">{selectedOrder.pickupLocation}</div>
              </div>
            </div>
            
            <div className="flex items-start gap-2">
              <div className="h-5 w-5 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Navigation className="h-3 w-3 text-white" />
              </div>
              <div>
                <div className="font-medium text-gray-700">To:</div>
                <div className="line-clamp-2">{selectedOrder.deliveryLocation}</div>
              </div>
            </div>
          </div>
          
          {/* Distance and ETA info */}
          {currentLat && currentLng && (
            <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
              <div className="bg-gray-50 p-1.5 rounded">
                <div className="text-gray-500">Total Distance</div>
                <div className="font-medium">
                  {(calculateETAInfo(selectedOrder).totalDistance).toFixed(1)} km
                </div>
              </div>
              <div className="bg-gray-50 p-1.5 rounded">
                <div className="text-gray-500">Est. Travel Time</div>
                <div className="font-medium">
                  {formatDistanceToNow(calculateETAInfo(selectedOrder).deliveryETA)}
                </div>
              </div>
            </div>
          )}
          
          {/* Accept button */}
          <Button 
            className="w-full mt-3" 
            size="sm"
            onClick={() => onOrderSelect?.(selectedOrder)}
          >
            Accept Delivery
          </Button>
        </div>
      )}
    </div>
  );
}