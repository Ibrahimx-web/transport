import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ShieldAlert } from "lucide-react";

export default function AdminAccessButton() {
  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Link href="/admin-access">
        <Button
          variant="outline"
          size="sm"
          className="bg-black text-white border-white hover:bg-white hover:text-black hover:border-black transition-colors"
        >
          <ShieldAlert className="h-4 w-4 mr-2" />
          <span>Admin Access</span>
        </Button>
      </Link>
    </div>
  );
}