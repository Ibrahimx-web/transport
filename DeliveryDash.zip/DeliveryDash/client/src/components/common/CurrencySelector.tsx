import { useCurrency } from "@/lib/currency";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Check, Globe } from "lucide-react";

export function CurrencySelector() {
  const { 
    currency, 
    setCurrency, 
    supportedCurrencies 
  } = useCurrency();
  
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="px-3 h-8">
          <Globe className="h-4 w-4 mr-2" />
          {currency}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[200px] p-0">
        <div className="p-2">
          <p className="text-sm font-medium mb-2">Select Currency</p>
          <div className="space-y-1">
            {Object.entries(supportedCurrencies).map(([code, details]) => (
              <Button
                key={code}
                variant="ghost"
                className="w-full justify-start"
                onClick={() => setCurrency(code as any)}
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center">
                    <span className="mr-2">{details.symbol}</span>
                    <span>{details.name}</span>
                  </div>
                  {currency === code && <Check className="h-4 w-4" />}
                </div>
              </Button>
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}