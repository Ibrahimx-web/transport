import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { geocodeAddress } from '@/lib/map';
import { useDelivery } from '@/hooks/use-delivery';
import { DEFAULT_VEHICLE_TYPES } from '@/lib/constants';
import { OrderLocation } from '@/types';

export function LocationSearch() {
  const { pickup, delivery, setPickup, setDelivery, calculatePriceEstimation } = useDelivery();
  const [pickupInput, setPickupInput] = useState(pickup.address);
  const [deliveryInput, setDeliveryInput] = useState(delivery.address);
  
  const handlePickupChange = async (address: string) => {
    setPickupInput(address);
    try {
      if (address.trim() === '') return;
      const result = await geocodeAddress(address);
      if (!result.error) {
        const newPickup: OrderLocation = {
          address: result.address,
          lat: result.lat,
          lng: result.lng
        };
        setPickup(newPickup);
        
        // If we also have delivery location, calculate price
        if (delivery.address) {
          calculatePriceEstimation(DEFAULT_VEHICLE_TYPES);
        }
      }
    } catch (error) {
      console.error('Error geocoding pickup address:', error);
    }
  };
  
  const handleDeliveryChange = async (address: string) => {
    setDeliveryInput(address);
    try {
      if (address.trim() === '') return;
      const result = await geocodeAddress(address);
      if (!result.error) {
        const newDelivery: OrderLocation = {
          address: result.address,
          lat: result.lat,
          lng: result.lng
        };
        setDelivery(newDelivery);
        
        // If we also have pickup location, calculate price
        if (pickup.address) {
          calculatePriceEstimation(DEFAULT_VEHICLE_TYPES);
        }
      }
    } catch (error) {
      console.error('Error geocoding delivery address:', error);
    }
  };
  
  return (
    <div className="p-4">
      <Card>
        <CardContent className="pt-6">
          <h2 className="text-lg font-bold mb-4">Where are you moving goods?</h2>
          
          {/* Pickup Location Field */}
          <div className="mb-3 relative">
            <div className="absolute left-3 top-3">
              <div className="w-4 h-4 rounded-full bg-primary flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-white"></div>
              </div>
            </div>
            <Input
              type="text"
              placeholder="Pickup location"
              className="pl-10 pr-4 py-6"
              value={pickupInput}
              onChange={(e) => handlePickupChange(e.target.value)}
            />
          </div>
          
          {/* Delivery Location Field */}
          <div className="relative">
            <div className="absolute left-3 top-3">
              <div className="w-4 h-4 rounded-full bg-secondary flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-white"></div>
              </div>
            </div>
            <Input
              type="text"
              placeholder="Delivery location"
              className="pl-10 pr-4 py-6"
              value={deliveryInput}
              onChange={(e) => handleDeliveryChange(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
