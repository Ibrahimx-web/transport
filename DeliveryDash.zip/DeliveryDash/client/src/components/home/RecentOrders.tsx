import { useQuery, UseQueryResult } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Order } from '@/types';
import { formatDate, ORDER_STATUS_LABELS } from '@/lib/constants';
import { Bike, Truck, ChevronRight, Package } from 'lucide-react';

interface RecentOrdersProps {
  userId?: number;
}

export function RecentOrders({ userId }: RecentOrdersProps) {
  const { data: orders = [], isLoading, error } = useQuery<Order[]>({
    queryKey: [`/api/users/${userId}/orders`],
    enabled: !!userId,
  });
  
  if (!userId) {
    return null;
  }
  
  const getVehicleIcon = (vehicleTypeId: number) => {
    switch (vehicleTypeId) {
      case 1: // Bike
      case 2: // Motorbike
        return <Bike className="text-primary" />;
      default:
        return <Truck className="text-primary" />;
    }
  };
  
  return (
    <div className="px-4 mb-4">
      <h2 className="text-lg font-bold mb-2">Recent Deliveries</h2>
      <div className="space-y-3">
        {isLoading ? (
          <div className="bg-white rounded-lg shadow-sm p-3 animate-pulse">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gray-200"></div>
                <div className="ml-3">
                  <div className="h-4 bg-gray-200 rounded w-24"></div>
                  <div className="h-3 bg-gray-200 rounded w-32 mt-2"></div>
                </div>
              </div>
              <div className="w-6 h-6 bg-gray-200 rounded-full"></div>
            </div>
          </div>
        ) : error ? (
          <div className="bg-white rounded-lg shadow-sm p-3 text-center text-red-500">
            Failed to load orders
          </div>
        ) : orders && orders.length > 0 ? (
          orders.map((order) => (
            <Link key={order.id} href={`/track/${order.id}`}>
              <div className="bg-white rounded-lg shadow-sm p-3 flex items-center justify-between cursor-pointer">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mr-3">
                    {getVehicleIcon(order.vehicleTypeId)}
                  </div>
                  <div>
                    <p className="font-medium">{order.deliveryLocation.split(',')[0]}</p>
                    <p className="text-sm text-gray-500">
                      {formatDate(order.createdAt)} • {ORDER_STATUS_LABELS[order.status]}
                    </p>
                  </div>
                </div>
                <ChevronRight className="text-primary h-5 w-5" />
              </div>
            </Link>
          ))
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-5 text-center">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-3">
              <Truck className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-gray-800 font-medium mb-1">No delivery history yet</h3>
            <p className="text-gray-500 text-sm mb-3">
              Your recent deliveries will appear here when you place an order
            </p>
            <Link href="/book">
              <div className="inline-flex items-center justify-center text-primary text-sm font-medium hover:underline">
                Book a transport
                <ChevronRight className="h-4 w-4 ml-1" />
              </div>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
