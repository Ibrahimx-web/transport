import * as React from "react";
import { Switch, Route, useLocation, Redirect } from "wouter";
import { queryClient, getQueryFn, apiRequest } from "./lib/queryClient";
import { QueryClientProvider, useQuery, useMutation } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import BookTransport from "@/pages/BookTransport";
import TrackDelivery from "@/pages/TrackDelivery";
import OrderHistory from "@/pages/OrderHistory";
import Profile from "@/pages/Profile";
import EditProfile from "@/pages/EditProfile";
import Login from "@/pages/Login";
import AdminLogin from "@/pages/AdminLogin";
import Register from "@/pages/Register";
import Payment from "@/pages/Payment";
import DeliveryDashboard from '@/pages/DeliveryDashboard';
import DeliveryMap from './pages/DeliveryMap';
import AdminDashboard from '@/pages/AdminDashboard';
import AdminUsers from '@/pages/AdminUsers';
import AdminLiveMap from '@/pages/AdminLiveMap';
import AdminVehicles from '@/pages/AdminVehicles';
import AdminPayments from '@/pages/AdminPayments';
import AdminDocuments from '@/pages/AdminDocuments';
import AdminSettings from '@/pages/AdminSettings';
import MapTest from '@/pages/MapTest';
import { useEffect, useState, useRef } from "react";
import { useCurrencyStore } from "./lib/currency";
import { useToast } from "@/hooks/use-toast";
import { User } from "@/types";
import AdminAccessButton from "@/components/AdminAccessButton";
import { GlobalActions } from "@/components/ui/global-actions";
import { LoadingProvider } from "@/hooks/use-loading";
import { LoadingOverlay } from "@/components/loading-overlay";
import { PageTransition, StaggeredItems } from "@/components/ui/page-transition";
import { LoadingAnimation } from "@/components/ui/loading-animation";

// Protected route component for role-based access control
interface ProtectedRouteProps {
  component: React.ComponentType;
  userType: 'customer' | 'delivery' | 'admin' | 'any';
  // Property to restrict specific user types from accessing this route
  restrictedFor?: 'customer' | 'delivery' | 'admin' | null;
}

function ProtectedRoute({ 
  component: Component, 
  userType, 
  restrictedFor = null 
}: ProtectedRouteProps) {
  const [, setLocation] = useLocation();
  
  const { data: user, isLoading, isError } = useQuery<User>({
    queryKey: ['/api/users/current'],
    queryFn: getQueryFn({ 
      on401: "returnNull",
    }),
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingAnimation size="lg" text="Loading your profile..." />
      </div>
    );
  }

  // If not authenticated, redirect to login
  if (isError || !user) {
    window.location.href = "/login";
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingAnimation size="lg" text="Redirecting to login..." />
      </div>
    );
  }

  // If this route is restricted for the current user type, redirect them
  if (restrictedFor && user.userType === restrictedFor) {
    if (user.userType === 'delivery') {
      window.location.href = "/delivery/dashboard";
      return (
        <div className="flex items-center justify-center min-h-screen">
          <LoadingAnimation size="lg" text="Redirecting to delivery dashboard..." />
        </div>
      );
    } else if (user.userType === 'admin') {
      window.location.href = "/admin/dashboard";
      return (
        <div className="flex items-center justify-center min-h-screen">
          <LoadingAnimation size="lg" text="Redirecting to admin dashboard..." />
        </div>
      );
    } else {
      window.location.href = "/";
      return (
        <div className="flex items-center justify-center min-h-screen">
          <LoadingAnimation size="lg" text="Redirecting to home..." />
        </div>
      );
    }
  }

  // Check if user has the correct role (if specific role is required)
  if (userType !== 'any' && user.userType !== userType) {
    // Redirect based on user type
    switch (user.userType) {
      case 'customer':
        window.location.href = "/";
        break;
      case 'delivery':
        window.location.href = "/delivery/dashboard";
        break;
      case 'admin':
        window.location.href = "/admin/dashboard";
        break;
      default:
        window.location.href = "/";
    }
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingAnimation size="lg" text="Redirecting to appropriate dashboard..." />
      </div>
    );
  }

  return (
    <PageTransition transitionKey={`route-${userType}`} direction="fade">
      <Component />
    </PageTransition>
  );
}

// Component that provides direct access to the admin dashboard
function AdminDirectAccess() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  const loginMutation = useMutation({
    mutationFn: async () => {
      setIsLoading(true);
      const response = await apiRequest("POST", "/api/users/login", {
        username: "admin",
        password: "admin123"
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data && data.userType === 'admin') {
        toast({
          title: "Admin access granted",
          description: "Welcome to the admin dashboard",
        });
        console.log("Admin direct access: redirecting to dashboard");
        window.location.href = "/admin/dashboard";
      } else {
        toast({
          title: "Access failed",
          description: "Could not log in as admin",
          variant: "destructive"
        });
        setIsLoading(false);
      }
    },
    onError: (error: any) => {
      console.error("Admin access error:", error);
      toast({
        title: "Access failed",
        description: "Could not log in as admin. Please check server logs.",
        variant: "destructive"
      });
      setIsLoading(false);
    }
  });

  useEffect(() => {
    // Auto-login on component mount
    loginMutation.mutate();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <h1 className="text-2xl font-bold text-center mb-6">Admin Access</h1>
        {isLoading ? (
          <div className="text-center">
            <p className="mb-4">Logging you in to the admin panel...</p>
            <LoadingAnimation size="sm" spinnerOnly className="mx-auto mt-2" />
          </div>
        ) : (
          <div className="text-center">
            <p className="mb-4">If you're not redirected automatically, click the button below:</p>
            <button 
              onClick={() => loginMutation.mutate()}
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
            >
              Access Admin Dashboard
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/login">
        <Login />
      </Route>
      <Route path="/admin/login">
        <AdminLogin />
      </Route>
      <Route path="/register">
        <Register />
      </Route>
      
      {/* Special route for direct admin access */}
      <Route path="/admin-access">
        <AdminDirectAccess />
      </Route>
      
      {/* Track delivery - accessible to all */}
      <Route path="/track/:id">
        {(params) => <TrackDelivery params={params} />}
      </Route>
      
      {/* Payment page */}
      <Route path="/payment/:orderId">
        {(params) => <Payment params={params} />}
      </Route>
      
      {/* Customer routes */}
      <Route path="/book">
        <ProtectedRoute component={BookTransport} userType="customer" restrictedFor="delivery" />
      </Route>
      
      {/* Common routes for authenticated users */}
      <Route path="/history">
        <ProtectedRoute component={OrderHistory} userType="any" />
      </Route>
      <Route path="/profile">
        <ProtectedRoute component={Profile} userType="any" />
      </Route>
      <Route path="/profile/edit">
        <ProtectedRoute component={EditProfile} userType="any" />
      </Route>
      
      {/* Delivery partner routes */}
      <Route path="/delivery/dashboard">
        <ProtectedRoute component={DeliveryDashboard} userType="delivery" restrictedFor="admin" />
      </Route>
      <Route path="/delivery/map">
        <ProtectedRoute component={DeliveryMap} userType="delivery" restrictedFor="admin" />
      </Route>
      
      {/* Admin routes */}
      <Route path="/admin/dashboard">
        <ProtectedRoute component={AdminDashboard} userType="admin" restrictedFor="customer" />
      </Route>
      <Route path="/admin/users">
        <ProtectedRoute component={AdminUsers} userType="admin" restrictedFor="customer" />
      </Route>
      <Route path="/admin/vehicles">
        <ProtectedRoute component={AdminVehicles} userType="admin" restrictedFor="customer" />
      </Route>
      <Route path="/admin/payments">
        <ProtectedRoute component={AdminPayments} userType="admin" restrictedFor="customer" />
      </Route>
      <Route path="/admin/settings">
        <ProtectedRoute component={AdminSettings} userType="admin" restrictedFor="customer" />
      </Route>
      <Route path="/admin/documents">
        <ProtectedRoute component={AdminDocuments} userType="admin" restrictedFor="customer" />
      </Route>
      <Route path="/admin/livemap">
        <ProtectedRoute component={AdminLiveMap} userType="admin" restrictedFor="customer" />
      </Route>
      
      {/* Public map test route - accessible without authentication */}
      <Route path="/map-test">
        <PageTransition transitionKey="map-test" direction="fade">
          <MapTest />
        </PageTransition>
      </Route>
      
      {/* Home route must be last, as it's the most generic path */}
      <Route path="/">
        <ProtectedRouteWithRoleCheck />
      </Route>
      
      {/* 404 route must be at the very end */}
      <Route>
        <NotFound />
      </Route>
    </Switch>
  );
}

// Special component for home page to route based on user type
function ProtectedRouteWithRoleCheck() {
  const { data: user, isLoading, isError } = useQuery<User>({
    queryKey: ['/api/users/current'],
    queryFn: getQueryFn({ 
      on401: "returnNull",
    }),
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingAnimation size="lg" text="Loading your dashboard..." />
      </div>
    );
  }

  // Not authenticated or error, show standard home page
  if (isError || !user) {
    return (
      <PageTransition transitionKey="home-public" direction="fade">
        <Home />
      </PageTransition>
    );
  }

  // Redirect based on user type
  switch (user.userType) {
    case 'delivery':
      window.location.href = "/delivery/dashboard";
      return (
        <div className="flex items-center justify-center min-h-screen">
          <LoadingAnimation size="lg" text="Loading delivery dashboard..." />
        </div>
      );
    case 'admin':
      window.location.href = "/admin/dashboard";
      return (
        <div className="flex items-center justify-center min-h-screen">
          <LoadingAnimation size="lg" text="Loading admin dashboard..." />
        </div>
      );
    case 'customer':
    default:
      return (
        <PageTransition transitionKey="home-customer" direction="fade">
          <Home />
        </PageTransition>
      );
  }
}

function CurrencyManager() {
  const { toast } = useToast();
  const detectCountry = useCurrencyStore(state => state.detectCountry);
  const currency = useCurrencyStore(state => state.currency);
  const { SUPPORTED_CURRENCIES, REGIONS } = useCurrencyStore.getState() as any;
  
  // Used to track if this is the first mount or a subsequent currency change
  const previousCurrencyRef = useRef<string | null>(null);
  
  // Detect country on initial load
  useEffect(() => {
    const detectLocation = async () => {
      try {
        // Store the previous value
        const prevCurrency = useCurrencyStore.getState().currency;
        previousCurrencyRef.current = prevCurrency;
        
        // Detect country and set appropriate currency
        await detectCountry();
        
        // Get the new currency value and location after detection
        const newState = useCurrencyStore.getState();
        const newCurrency = newState.currency;
        const detectedCountry = newState.detectedLocation?.country;
        
        // Only show toast if currency was actually changed and not on first load
        if (previousCurrencyRef.current !== null && previousCurrencyRef.current !== newCurrency) {
          toast({
            title: detectedCountry 
              ? `Location detected: ${detectedCountry}` 
              : `Currency set to ${SUPPORTED_CURRENCIES[newCurrency].name}`,
            description: `Currency changed to ${SUPPORTED_CURRENCIES[newCurrency].name}`,
          });
        }
      } catch (error) {
        console.error("Currency detection issue:", error);
      }
    };

    detectLocation();
  }, [detectCountry, toast]);

  return null; // This component doesn't render anything
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LoadingProvider>
        <CurrencyManager />
        <Router />
        <GlobalActions />
        <AdminAccessButton />
        <Toaster />
        <LoadingOverlay />
      </LoadingProvider>
    </QueryClientProvider>
  );
}

export default App;