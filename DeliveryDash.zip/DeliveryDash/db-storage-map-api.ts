  // Map API configuration operations
  async getMapApiConfigurations(): Promise<MapApiConfig[]> {
    return await db.select().from(mapApiConfigs).orderBy(desc(mapApiConfigs.updatedAt));
  }

  async getMapApiConfiguration(id: number): Promise<MapApiConfig | undefined> {
    const [config] = await db.select().from(mapApiConfigs).where(eq(mapApiConfigs.id, id));
    return config;
  }

  async createMapApiConfiguration(config: InsertMapApiConfig): Promise<MapApiConfig> {
    // If this config should be the default one, clear other defaults first
    if (config.isDefault) {
      await db
        .update(mapApiConfigs)
        .set({ isDefault: false, updatedAt: new Date() })
        .where(eq(mapApiConfigs.isDefault, true));
    }
    
    const [newConfig] = await db.insert(mapApiConfigs).values(config).returning();
    return newConfig;
  }

  async updateMapApiConfiguration(id: number, update: Partial<MapApiConfig>): Promise<MapApiConfig> {
    // If setting as default, clear other defaults
    if (update.isDefault) {
      await db
        .update(mapApiConfigs)
        .set({ isDefault: false, updatedAt: new Date() })
        .where(and(
          notEq(mapApiConfigs.id, id),
          eq(mapApiConfigs.isDefault, true)
        ));
    }
    
    // Apply the update
    const [updatedConfig] = await db
      .update(mapApiConfigs)
      .set({ ...update, updatedAt: new Date() })
      .where(eq(mapApiConfigs.id, id))
      .returning();
      
    return updatedConfig;
  }

  async deleteMapApiConfiguration(id: number): Promise<boolean> {
    // Don't allow deleting default configs
    const [config] = await db
      .select()
      .from(mapApiConfigs)
      .where(eq(mapApiConfigs.id, id));
      
    if (!config) {
      return false;
    }
    
    if (config.isDefault) {
      throw new Error("Cannot delete the default map API configuration");
    }
    
    const result = await db
      .delete(mapApiConfigs)
      .where(eq(mapApiConfigs.id, id));
      
    return result.rowCount > 0;
  }