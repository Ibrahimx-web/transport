# Architecture Overview

## Overview

GoodsMover is a full-stack web application that provides transportation and delivery services. The application allows customers to book different types of vehicles for transporting goods and track their deliveries in real-time. It also has a driver/delivery person side where drivers can accept delivery requests.

The application follows a modern web architecture with a clear separation between frontend and backend components, using TypeScript throughout the codebase for type safety and better developer experience.

## System Architecture

The system follows a client-server architecture with the following main components:

1. **Client Application**: A React-based Single Page Application (SPA) built with TypeScript
2. **Server API**: An Express.js REST API that handles business logic and data access
3. **Database**: PostgreSQL database accessed via Drizzle ORM
4. **Authentication**: Session-based authentication using express-session

### High-Level Architecture Diagram

```
┌─────────────────┐      ┌─────────────────┐      ┌─────────────────┐
│                 │      │                 │      │                 │
│  React Client   │<─────│  Express Server │<─────│   PostgreSQL    │
│  (TypeScript)   │      │  (TypeScript)   │      │   Database      │
│                 │      │                 │      │                 │
└─────────────────┘      └─────────────────┘      └─────────────────┘
        │                        │                        │
        │                        │                        │
        ▼                        ▼                        ▼
┌─────────────────┐      ┌─────────────────┐      ┌─────────────────┐
│  Shadcn/UI      │      │  Drizzle ORM    │      │  Schema         │
│  TanStack Query │      │  Session Auth   │      │  Migrations     │
│  Router         │      │  REST API       │      │                 │
└─────────────────┘      └─────────────────┘      └─────────────────┘
```

## Key Components

### Frontend Components

1. **Routing**
   - Uses `wouter` for lightweight client-side routing
   - Main routes: Home, Login, Register, BookTransport, TrackDelivery, OrderHistory, Profile

2. **State Management**
   - TanStack React Query for server state (data fetching, caching, synchronization)
   - Custom hooks for UI state (e.g., `useDelivery` for delivery form state)
   - Context-based state when needed for component sharing

3. **UI Components**
   - Shadcn/UI component library (built on Radix UI)
   - Tailwind CSS for styling
   - Responsive design with mobile-first approach

4. **Features**
   - Location search and map visualization
   - Vehicle selection and pricing calculation
   - Order tracking
   - User authentication and profile management
   - Order history

### Backend Components

1. **API Server**
   - Express.js REST API built with TypeScript
   - Structured route handlers with appropriate HTTP methods
   - JSON response format for all API endpoints
   - Error handling middleware

2. **Database Access**
   - Drizzle ORM for type-safe database operations
   - PostgreSQL for data storage (via Neon serverless PostgreSQL)
   - Schema defined with type safety in mind
   - Migration support via Drizzle Kit

3. **Authentication**
   - Session-based authentication using express-session
   - User credentials validation
   - Session persistence

4. **Core Features**
   - User management (registration, login, profile)
   - Vehicle type management
   - Order creation and tracking
   - Price calculation based on distance and vehicle type

### Database Schema

The database schema includes the following main entities:

1. **Users**
   - Customer and delivery personnel user types
   - Authentication information
   - Profile details

2. **Vehicle Types**
   - Different vehicle categories (bike, motorbike, pickup, van, lorry)
   - Maximum weight capacity
   - Base pricing information

3. **Orders**
   - Delivery details (pickup, delivery locations)
   - Pricing information
   - Status tracking

4. **Order Status Updates**
   - Timestamped status changes for tracking

## Data Flow

### Authentication Flow

1. User submits login credentials or registration form
2. Server validates credentials or creates a new user
3. On successful authentication, server creates a session and sets session cookie
4. Client includes session cookie in all subsequent requests
5. Server validates session for protected endpoints

### Order Creation Flow

1. User selects pickup and delivery locations
2. System calculates distance and estimated pricing
3. User selects vehicle type and provides package details
4. User confirms order
5. Server creates order in database
6. Server returns order confirmation with tracking details

### Order Tracking Flow

1. User requests order tracking information
2. Server retrieves order and associated status updates
3. Client displays order status, locations, and delivery progress
4. For active orders, status updates are periodically fetched

## External Dependencies

### Frontend Dependencies

- **UI Framework**: React
- **Routing**: wouter
- **UI Components**: Radix UI components (via shadcn/ui)
- **Styling**: Tailwind CSS
- **Data Fetching**: TanStack React Query
- **Forms**: React Hook Form with Zod validation
- **Maps/Location**: Custom map implementation

### Backend Dependencies

- **Server Framework**: Express.js
- **Database ORM**: Drizzle ORM
- **Database**: PostgreSQL via Neon Serverless
- **Session Management**: express-session
- **Validation**: Zod
- **TypeScript Support**: tsx for running TypeScript files directly

## Deployment Strategy

The application is designed to be deployed on Replit, as evidenced by the Replit configuration files. The deployment strategy includes:

1. **Build Process**
   - Vite for frontend build
   - esbuild for backend bundling
   - Combined into a single deployable package

2. **Runtime Environment**
   - Node.js for server runtime
   - Environment variables for configuration
   - Production mode optimizations

3. **Database**
   - External PostgreSQL database (Neon Serverless)
   - Connection via environment variables

4. **Configuration**
   - Replit-specific configuration in `.replit` file
   - Environment variable management
   - Port configuration

5. **Continuous Integration**
   - Replit's built-in deployment tools
   - Defined workflows for development and production

## Development Setup

To set up the development environment:

1. Install dependencies with `npm install`
2. Set up environment variables (especially `DATABASE_URL`)
3. Run development server with `npm run dev`
4. Build for production with `npm run build`
5. Run database migrations with `npm run db:push`

## Performance and Scaling Considerations

1. **Frontend Performance**
   - Client-side caching with React Query
   - Code splitting for route-based component loading
   - Optimized builds with Vite

2. **Backend Performance**
   - Efficient database queries through Drizzle ORM
   - Session management for authentication without heavy JWT processing
   - Stateless API design for horizontal scaling potential

3. **Database Scaling**
   - Using Neon Serverless PostgreSQL for automatic scaling
   - Schema designed for efficient querying

## Security Considerations

1. **Authentication**
   - Secure session management
   - Password hashing (implementation details not specified in code)
   - CSRF protection via proper session configuration

2. **Data Validation**
   - Input validation using Zod schemas
   - Type safety through TypeScript

3. **API Security**
   - Authentication middleware for protected routes
   - Proper error handling to avoid information leakage