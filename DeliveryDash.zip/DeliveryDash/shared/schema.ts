import { pgTable, text, serial, integer, boolean, timestamp, real, jsonb, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define UserType explicitly for better type checking
export type UserType = 'customer' | 'delivery' | 'admin';

// Define payment method types
export type PaymentGatewayType = 'paypal' | 'google_pay' | 'airtel_money' | 'mpesa';

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  userType: text("user_type").notNull().default("customer"), // "customer", "delivery", or "admin"
  vehicleTypeId: integer("vehicle_type_id").references(() => vehicleTypes.id), // Only for delivery users
  profilePicture: text("profile_picture"),
  driversLicense: text("drivers_license"),
  licensePlateNumber: text("license_plate_number"), // Vehicle license plate number for delivery users
  vehicleRegistrationNumber: text("vehicle_registration_number"), // Vehicle registration/identification number
  preferredPaymentMethod: text("preferred_payment_method"), // Preferred payment method for delivery partners
  currentLat: real("current_lat"),
  currentLng: real("current_lng"),
  isAvailable: boolean("is_available").default(true),
  paymentDetails: jsonb("payment_details"), // Stores payment method specific details like phone numbers, emails, etc.
  autoPayoutEnabled: boolean("auto_payout_enabled").default(true), // Flag to enable/disable automatic payouts
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  phone: true,
  userType: true,
  vehicleTypeId: true,
  licensePlateNumber: true,
  vehicleRegistrationNumber: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const vehicleTypes = pgTable("vehicle_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  maxWeight: real("max_weight").notNull(),
  baseFare: real("base_fare").notNull(),
});

export const insertVehicleTypeSchema = createInsertSchema(vehicleTypes).pick({
  name: true,
  icon: true,
  maxWeight: true,
  baseFare: true,
});

export type InsertVehicleType = z.infer<typeof insertVehicleTypeSchema>;
export type VehicleType = typeof vehicleTypes.$inferSelect;

// Define payment method type
export type PaymentMethodType = 'stripe' | 'paypal' | 'google_pay' | 'mobile_money';

// Define mobile money provider type (especially important for Africa)
export type MobileMoneyProviderType = 'mpesa' | 'airtel_money' | 'orange_money' | 'mtn_mobile' | 'other';

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  vehicleTypeId: integer("vehicle_type_id").notNull().references(() => vehicleTypes.id),
  status: text("status").notNull().default("pending"),
  pickupLocation: text("pickup_location").notNull(),
  pickupLat: real("pickup_lat").notNull(),
  pickupLng: real("pickup_lng").notNull(),
  deliveryLocation: text("delivery_location").notNull(),
  deliveryLat: real("delivery_lat").notNull(),
  deliveryLng: real("delivery_lng").notNull(),
  distance: real("distance").notNull(),
  packageDescription: text("package_description"),
  packageWeight: real("package_weight"),
  packageDimensions: text("package_dimensions"),
  specialInstructions: text("special_instructions"),
  baseFare: real("base_fare").notNull(),
  distanceFare: real("distance_fare").notNull(),
  serviceFee: real("service_fee").notNull(),
  totalFare: real("total_fare").notNull(),
  paymentMethod: text("payment_method"), // 'stripe', 'paypal', 'google_pay', 'mobile_money'
  paymentStatus: text("payment_status").default("pending"), // 'pending', 'paid', 'failed', 'refunded'
  paymentId: text("payment_id"), // External payment ID from the payment processor
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export const orderStatusUpdates = pgTable("order_status_updates", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().references(() => orders.id),
  status: text("status").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertOrderStatusUpdateSchema = createInsertSchema(orderStatusUpdates).omit({
  id: true,
  timestamp: true,
});

export type InsertOrderStatusUpdate = z.infer<typeof insertOrderStatusUpdateSchema>;
export type OrderStatusUpdate = typeof orderStatusUpdates.$inferSelect;

// Fee configuration table - for admins to manage transport fees
export const feeConfigurations = pgTable("fee_configurations", {
  id: serial("id").primaryKey(),
  vehicleTypeId: integer("vehicle_type_id").notNull().references(() => vehicleTypes.id),
  baseFare: real("base_fare").notNull(),
  pricePerKm: real("price_per_km").notNull(),
  serviceFeePercentage: real("service_fee_percentage").notNull(),
  minDistance: real("min_distance").notNull().default(0),
  effectiveDate: timestamp("effective_date").notNull().defaultNow(),
  isActive: boolean("is_active").notNull().default(true),
  createdBy: integer("created_by").notNull().references(() => users.id), // admin user id
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertFeeConfigurationSchema = createInsertSchema(feeConfigurations).omit({
  id: true,
  updatedAt: true,
});

export type InsertFeeConfiguration = z.infer<typeof insertFeeConfigurationSchema>;
export type FeeConfiguration = typeof feeConfigurations.$inferSelect;

// Delivery partner payments/commissions
export const partnerPayments = pgTable("partner_payments", {
  id: serial("id").primaryKey(),
  partnerId: integer("partner_id").notNull().references(() => users.id), // delivery user id
  orderId: integer("order_id").notNull().references(() => orders.id),
  amount: real("amount").notNull(),
  commissionPercentage: real("commission_percentage").notNull(),
  commissionAmount: real("commission_amount").notNull(),
  finalPayment: real("final_payment").notNull(),
  status: text("status").notNull().default("pending"), // pending, paid, disputed
  paymentDate: timestamp("payment_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  processedBy: integer("processed_by").references(() => users.id), // admin who processed the payment
});

export const insertPartnerPaymentSchema = createInsertSchema(partnerPayments).omit({
  id: true,
  createdAt: true,
});

export type InsertPartnerPayment = z.infer<typeof insertPartnerPaymentSchema>;
export type PartnerPayment = typeof partnerPayments.$inferSelect;

// System settings for admin configuration
export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  settingKey: text("setting_key").notNull().unique(),
  settingValue: text("setting_value").notNull(),
  dataType: text("data_type").notNull(), // string, number, boolean, json
  description: text("description"),
  updatedBy: integer("updated_by").notNull().references(() => users.id), // admin user id
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});

export type InsertSystemSetting = z.infer<typeof insertSystemSettingSchema>;
export type SystemSetting = typeof systemSettings.$inferSelect;

// Documents for delivery partners
export const partnerDocuments = pgTable("partner_documents", {
  id: serial("id").primaryKey(),
  partnerId: integer("partner_id").notNull().references(() => users.id), // delivery user id
  documentType: text("document_type").notNull(), // id, license, vehicle_registration, etc.
  documentUrl: text("document_url").notNull(),
  verificationStatus: text("verification_status").notNull().default("pending"), // pending, verified, rejected
  verifiedBy: integer("verified_by").references(() => users.id), // admin user id who verified
  verificationDate: timestamp("verification_date"),
  rejectionReason: text("rejection_reason"),
  expiryDate: date("expiry_date"),
  uploadedAt: timestamp("uploaded_at").notNull().defaultNow(),
});

export const insertPartnerDocumentSchema = createInsertSchema(partnerDocuments).omit({
  id: true,
  uploadedAt: true,
});

export type InsertPartnerDocument = z.infer<typeof insertPartnerDocumentSchema>;
export type PartnerDocument = typeof partnerDocuments.$inferSelect;

// Customer payment transactions table
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().references(() => orders.id),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: real("amount").notNull(),
  paymentMethod: text("payment_method").notNull(), // stripe, paypal, google_pay, mobile_money
  paymentProvider: text("payment_provider"), // For mobile money: mpesa, airtel_money, etc.
  paymentStatus: text("payment_status").notNull().default("pending"), // pending, processing, completed, failed, refunded
  currency: text("currency").notNull().default("USD"), // USD, KES, etc.
  transactionId: text("transaction_id"), // External transaction ID from payment gateway
  phoneNumber: text("phone_number"), // For mobile money payments
  receiptUrl: text("receipt_url"), // URL to receipt/invoice
  metadata: jsonb("metadata"), // Additional payment data
  errorMessage: text("error_message"), // Error message if payment failed
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;

// Payment gateway configurations (for administrative settings)
export const paymentGateways = pgTable("payment_gateways", {
  id: serial("id").primaryKey(),
  gatewayType: text("gateway_type").notNull(), // 'paypal', 'google_pay', 'airtel_money', 'mpesa'
  displayName: text("display_name").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  isDefault: boolean("is_default").notNull().default(false),
  configuration: jsonb("configuration").notNull().default({}), // API keys, merchant IDs, etc.
  supportedCountries: text("supported_countries").array().notNull().default([]),
  supportedCurrencies: text("supported_currencies").array().notNull().default([]),
  minimumAmount: real("minimum_amount").notNull().default(0),
  processingFee: real("processing_fee").notNull().default(0), // Additional fee for using this payment method
  processingFeeType: text("processing_fee_type").notNull().default("percentage"), // 'fixed', 'percentage'
  adminNotes: text("admin_notes"),
  createdBy: integer("created_by").notNull().references(() => users.id), // admin user id
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertPaymentGatewaySchema = createInsertSchema(paymentGateways).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPaymentGateway = z.infer<typeof insertPaymentGatewaySchema>;
export type PaymentGateway = typeof paymentGateways.$inferSelect;

// Commission configuration for partner payments
export const commissionConfigurations = pgTable("commission_configurations", {
  id: serial("id").primaryKey(),
  commissionName: text("commission_name").notNull(),
  commissionPercentage: real("commission_percentage").notNull(),
  description: text("description"),
  appliesTo: text("applies_to").notNull(), // 'all', 'vehicle_type', 'specific_partners'
  vehicleTypeIds: integer("vehicle_type_ids").array(), // Only applicable when appliesTo is 'vehicle_type'
  partnerIds: integer("partner_ids").array(), // Only applicable when appliesTo is 'specific_partners'
  isDefault: boolean("is_default").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  effectiveFrom: timestamp("effective_from").notNull().defaultNow(),
  effectiveTo: timestamp("effective_to"),
  createdBy: integer("created_by").notNull().references(() => users.id), // admin user id
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertCommissionConfigurationSchema = createInsertSchema(commissionConfigurations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCommissionConfiguration = z.infer<typeof insertCommissionConfigurationSchema>;
export type CommissionConfiguration = typeof commissionConfigurations.$inferSelect;

// Map API configuration for map providers
export const mapApiConfigs = pgTable("map_api_configs", {
  id: serial("id").primaryKey(),
  provider: text("provider").notNull(), // 'google_maps', 'mapbox', 'osm' (OpenStreetMap)
  apiKey: text("apiKey").notNull(),
  isActive: boolean("isActive").notNull().default(true),
  isDefault: boolean("isDefault").notNull().default(false),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
});

export const insertMapApiConfigSchema = createInsertSchema(mapApiConfigs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertMapApiConfig = z.infer<typeof insertMapApiConfigSchema>;
export type MapApiConfig = typeof mapApiConfigs.$inferSelect;

// Define relationships between tables
// This is important for maintaining data integrity and enables easier querying with joins

// Note: We're using direct references in the table schemas instead of the relations API
// to ensure better type safety and compatibility with Drizzle
// All relationships are established using .references() in the table definitions above
